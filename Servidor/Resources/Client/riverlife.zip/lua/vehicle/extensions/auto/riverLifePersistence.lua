-- BeamNG 0.39 unloads vehicle extensions while serializing even with reason=save.
-- RLS damage capture needs a snapshot while the current vehicle keeps running.
local M={}
local originalSerialization,serializationWrapper,originalImport,importWrapper
local function transient(name,path)
  local lower=tostring(path or ''):lower()
  return name=='auto_riverLifePersistence' or name=='riverLifePersistence' or lower:find('beammp',1,true)~=nil
end
local function snapshot()
  local out={extensions={loadedModules={}}}
  local modules={}
  for _,module in pairs(extensions) do
    if type(module)=='table' and type(module.__extensionName__)=='string' and not module.__virtual__ then
      modules[#modules+1]=module
    end
  end
  for _,module in ipairs(modules) do
    local name=module.__extensionName__
    if not transient(name,module.__extensionPath__) then
      out.extensions.loadedModules[name]=module.__extensionPath__
      if module.onSerialize or module.onDeserialize or module.onDeserialized then
        if type(module.onSerialize)=='function' then out[name]=module.onSerialize('save')
        else out[name]=module.state or module end
      end
    end
  end
  return out
end
local function install()
  originalSerialization=extensions.getSerializationData
  serializationWrapper=function(reason)
    if reason=='save' then return snapshot() end
    return originalSerialization(reason)
  end
  extensions.getSerializationData=serializationWrapper
  originalImport=importPersistentData
  importWrapper=function(bytes)
    local caller=debug.getinfo(2,'S')
    if caller and tostring(caller.source):find('individualRepair',1,true) then
      local data=deserialize(bytes)
      local loaded=data and data.extensions and data.extensions.loadedModules
      if loaded then
        for name,path in pairs(loaded) do
          if transient(name,path) then loaded[name]=nil;data[name]=nil end
        end
        bytes=serialize(data)
      end
    end
    return originalImport(bytes)
  end
  importPersistentData=importWrapper
end
function M.onExtensionLoaded() install() end
function M.onExtensionUnloaded()
  if extensions.getSerializationData==serializationWrapper then extensions.getSerializationData=originalSerialization end
  if importPersistentData==importWrapper then importPersistentData=originalImport end
end
return M
