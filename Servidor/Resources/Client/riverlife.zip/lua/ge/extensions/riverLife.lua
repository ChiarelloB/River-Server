-- RiverLife client core. Original code.
-- Session lifecycle (solo RLS career or River BeamMP server), request transport,
-- wallet reconciliation with the RLS career, vehicle export/delivery, photos and
-- the bridge to the RiverOS computer and phone app. Feature helpers live in
-- riverLife_npcs (NPC visitors) and riverLife_players (presence, map, visibility).
local M = {}
M.dependencies = {'riverLife_npcs', 'riverLife_players', 'riverLife_display', 'riverLife_gigs', 'riverLife_partPhotos'}
local unpackArgs = unpack or table.unpack
local Domain = require('common/riverLife/domain')
local Wire = require('common/riverLife/wire')
local Wallet = require('common/riverLife/wallet')
local NetworkGuard = require('common/riverLife/networkGuard')
local http = require('socket.http')

local SETTINGS = '/settings/riverlife/'
local localMarket, localId, state, client, basePath
local pending, photoSources, spawnPending = {}, {}, {}
local clock, sequence, lastSend, lastSaveRetry, lastTickCheck = 0, 0, 0, 0, 0
local connected, walletPending, photoBusy = false, false, false
local deskOpen, phoneOpen, lastGui = 0, 0, -100
local multiplayerCareer, multiplayerPending = false, false
local saleGuards, saveJobs, receiptSaving, serviceApplying = {}, {}, {}, {}
local exportJobs, deliveryJobs, deliveryFetching, sendQueue, receiveChunks = {}, {}, {}, {}, {}
local waitingNotice = {}
local completedSaveSequence = 0
local originalLeave, guardedLeave, leavingCareer
local originalHttpRequest, guestAvatarRequest
local uiOpen = false
local guiDirty, guiTimer = false, 0

local function object(id) return id and getObjectByID(id) or nil end
local function active() return career_career and career_career.isActive() and career_modules_inventory and true or false end
local function multi() return MPCoreNetwork and MPCoreNetwork.isMPSession() or false end
local function attr(key) return career_modules_playerAttributes.getAttributeValue(key) or 0 end
local function cents() return math.floor(attr('money') * 100 + 0.5) end
local function posOf(obj)
  if not obj then return nil end
  local p = obj:getPosition()
  return {x = p.x, y = p.y, z = p.z}
end
local function playerPos() return posOf(getPlayerVehicle(0)) or posOf(scenetree.findObject('freeCamera')) end
local function mapName() local level = getCurrentLevelIdentifier(); return level and tostring(level) or 'unknown' end
local function hourOfDay()
  local tod = core_environment and core_environment.getTimeOfDay and core_environment.getTimeOfDay()
  return math.floor((((tod and tod.time) or 0) * 24 + 12) % 24)
end
local function pathId(v) return tostring(v):gsub('[^%w%-_]', '_') end
local function message(text, kind)
  guihooks.trigger('RiverLifeNotice', {text = text, kind = kind or 'info'})
  ui_message(text, 8, 'riverLife')
end
M.message = message
M.posOf, M.playerPos, M.mapName, M.hourOfDay, M.multi, M.active = posOf, playerPos, mapName, hourOfDay, multi, active

local function invByVin(vin)
  if not vin then return nil end
  for id, v in pairs(career_modules_inventory.getVehicles()) do if v.riverLifeVIN == vin then return id, v end end
end
local function inventoryPos(invId)
  return invId and posOf(object(career_modules_inventory.getVehicleIdFromInventoryId(tonumber(invId))))
end
local function listedLocally(inventoryId)
  local v = career_modules_inventory and career_modules_inventory.getVehicles()[tonumber(inventoryId)]
  if not v or not v.riverLifeVIN or not state then return false end
  for _, l in ipairs(state.listings or {}) do
    if l.assetId == v.riverLifeVIN and l.status == 'active' then return true end
  end
  return false
end

-- RLS sale paths must not sell a car that is advertised here.
local function installSaleGuards()
  local function guard(module, key, ids)
    if not module or type(module[key]) ~= 'function' then return end
    for _, g in ipairs(saleGuards) do if g.module == module and g.key == key then return end end
    local original = module[key]
    local wrapper = function(first, ...)
      for _, id in ipairs(ids and ids(first) or {first}) do
        if listedLocally(id) then message('Retire o anúncio do RiverLife antes de vender por outro serviço.', 'warning'); return false end
      end
      return original(first, ...)
    end
    saleGuards[#saleGuards + 1] = {module = module, key = key, original = original, wrapper = wrapper}
    module[key] = wrapper
  end
  for _, key in ipairs({'sellVehicle', 'sellVehicleFromInventory'}) do guard(career_modules_inventory, key) end
  guard(career_modules_marketplace, 'listVehicles', function(entries)
    local ids = {}
    for _, e in ipairs(entries or {}) do ids[#ids + 1] = e.inventoryId end
    return ids
  end)
end

-- Wallet ------------------------------------------------------------------------------
local function applyWallet(snapshot, alreadyEarned)
  if not active() or not snapshot or not snapshot.me then return end
  local initialized = attr('riverLifeInitialized') == 1
  local plan = Wallet.plan({initialized = initialized, money = cents(), balance = attr('riverLifeBalance'),
    revision = attr('riverLifeWalletRevision'), intentRevision = attr('riverLifeWalletIntentRevision'),
    intentDelta = attr('riverLifeWalletIntentDelta')}, snapshot.me)
  local delta = plan.delta
  if alreadyEarned then delta = plan.balance - (initialized and attr('riverLifeBalance') or cents()) - alreadyEarned end
  local changes = {riverLifeBalance = plan.balance - attr('riverLifeBalance'),
    riverLifeInitialized = initialized and 0 or 1,
    riverLifeWalletRevision = plan.revision - attr('riverLifeWalletRevision'),
    riverLifeWalletIntentRevision = -attr('riverLifeWalletIntentRevision'),
    riverLifeWalletIntentDelta = -attr('riverLifeWalletIntentDelta')}
  if delta ~= 0 then changes.money = delta / 100 end
  local any = delta ~= 0
  for _, v in pairs(changes) do if v ~= 0 then any = true end end
  if any then career_modules_playerAttributes.addAttributes(changes, {label = 'RiverLife: negócios e recibos', tags = {'riverLife'}}) end
end

-- Durable saves -------------------------------------------------------------------------
local function persistentLocal()
  if client and basePath then jsonWriteFile(basePath .. 'client-state.json', client, true) end
end
local function savedVehicle(id, vin)
  local _, path = career_saveSystem.getCurrentProfile()
  local data = path and jsonReadFile(path .. '/career/vehicles/' .. id .. '.json')
  return data and data.riverLifeVIN == vin
end
local function saveThen(check, done)
  saveJobs[#saveJobs + 1] = {profile = career_saveSystem.getCurrentProfile(), after = completedSaveSequence, check = check, done = done}
  career_saveSystem.saveCurrent(nil, {force = true})
end
local function finishSavedJobs(finished)
  if finished then completedSaveSequence = completedSaveSequence + 1 end
  local remaining, complete = {}, {}
  for _, job in ipairs(saveJobs) do
    if job.profile == career_saveSystem.getCurrentProfile() then
      if completedSaveSequence > job.after and job.check() then complete[#complete + 1] = job.done else remaining[#remaining + 1] = job end
    end
  end
  saveJobs = remaining
  for _, done in ipairs(complete) do done() end
end
M.saveThen = saveThen

-- Leaving a BeamMP server waits until the career save holds the synced state.
local function installLeaveGuard()
  if not MPCoreNetwork or guardedLeave == MPCoreNetwork.leaveServer then return end
  originalLeave = MPCoreNetwork.leaveServer
  if type(originalLeave) ~= 'function' then return end
  guardedLeave = function(...)
    if not multiplayerCareer or not active() then return originalLeave(...) end
    if leavingCareer then return end
    leavingCareer = true
    local args = {...}
    local expectedMoney, expectedRevision = cents(), attr('riverLifeWalletRevision')
    local vehicles = {}
    for id, v in pairs(career_modules_inventory.getVehicles()) do vehicles[id] = v.riverLifeVIN or false end
    message('Salvando a carreira antes de sair do servidor...')
    local deadline = clock + 20
    saveThen(function()
      if clock > deadline then return true end
      local _, path = career_saveSystem.getCurrentProfile()
      local saved = path and jsonReadFile(path .. '/career/playerAttributes.json')
      if not saved or not saved.money or math.floor(saved.money.value * 100 + 0.5) ~= expectedMoney then return false end
      if (saved.riverLifeWalletRevision and saved.riverLifeWalletRevision.value or 0) ~= expectedRevision then return false end
      for id, vin in pairs(vehicles) do
        local v = jsonReadFile(path .. '/career/vehicles/' .. tostring(id) .. '.json')
        if not v or (v.riverLifeVIN or false) ~= vin then return false end
      end
      return true
    end, function() originalLeave(unpackArgs(args)) end)
  end
  MPCoreNetwork.leaveServer = guardedLeave
end

-- View model --------------------------------------------------------------------------------
local function garageView()
  local list = {}
  local inv = career_modules_inventory.getVehicles()
  for id, v in pairs(inv) do
    if v.owned ~= false and not v.loanType then
      local vin = v.riverLifeVIN
      local locked = false
      for _, l in ipairs((state and state.listings) or {}) do if l.assetId == vin and l.status == 'active' then locked = true end end
      local needsRepair = career_modules_insurance_insurance and career_modules_insurance_insurance.inventoryVehNeedsRepair
        and career_modules_insurance_insurance.inventoryVehNeedsRepair(id) or false
      local repairCost = 0
      if needsRepair and career_modules_valueCalculator.getRepairDetails then
        local ok, d = pcall(career_modules_valueCalculator.getRepairDetails, v)
        repairCost = ok and d and d.price or 0
      end
      local value = 0
      if career_modules_valueCalculator.getInventoryVehicleValue then
        local ok, x = pcall(career_modules_valueCalculator.getInventoryVehicleValue, id)
        value = ok and x or v.configBaseValue or 0
      end
      list[#list + 1] = {inventoryId = id, niceName = v.niceName, model = v.model, vin = vin, locked = locked,
        thumbnail = career_modules_inventory.getVehicleThumbnail(id),
        spawned = career_modules_inventory.getVehicleIdFromInventoryId(id) ~= nil,
        mileage = v.mileage or 0, value = math.floor((value or 0) * 100), needsRepair = needsRepair and true or false,
        repairCost = math.floor((repairCost or 0) * 100), timeToAccess = v.timeToAccess,
        position = inventoryPos(id), plate = v.config and v.config.licenseName}
    end
  end
  table.sort(list, function(a, b) return a.inventoryId < b.inventoryId end)
  return list
end

-- Catalog picture of a model/config, shown until the car has real photos.
local previewCache = {}
local function previewFor(model, config)
  if type(model) ~= 'string' or model == '' then return nil end
  local key = model .. '|' .. tostring(config)
  if previewCache[key] ~= nil then return previewCache[key] or nil end
  local path = false
  pcall(function()
    local name = type(config) == 'string' and config:match('([^/]+)%.pc$') or nil
    local info = name and core_vehicles.getConfig(model, name)
    if not (info and info.preview) then
      local m = core_vehicles.getModel(model)
      info = m and m.model and m.model.default_pc and core_vehicles.getConfig(model, m.model.default_pc) or (m and m.model)
    end
    if info and type(info.preview) == 'string' and info.preview ~= '' then path = info.preview end
  end)
  previewCache[key] = path
  return path or nil
end

-- RiverOS preferences (wallpaper...) belong to the player, not to a career.
local DESKTOP_FILE = SETTINGS .. 'desktop.json'
local desktopPrefs
local function desktop()
  if desktopPrefs == nil then desktopPrefs = jsonReadFile(DESKTOP_FILE) or {} end
  return desktopPrefs
end

local function gui()
  guiDirty = false
  if not active() then guihooks.trigger('RiverLifeView', {careerActive = false}); return end
  local payload = state and Domain.copy(state) or {}
  for _, key in ipairs({'listings', 'stores', 'workshops', 'visits', 'offers', 'receipts', 'npcs', 'orders', 'messages', 'accounts'}) do
    payload[key] = payload[key] or {}
  end
  payload.assets = payload.assets or {}
  payload.careerActive = true
  payload.mode = multi() and 'BeamMP' or 'Solo'
  payload.connected = connected
  payload.garage = garageView()
  payload.photos = photoSources
  for _, l in ipairs(payload.listings or {}) do
    if not l.cover then l.cover = previewFor(l.model, l.config) end
  end
  payload.money = cents()
  payload.map = mapName()
  payload.position = playerPos()
  payload.hour = hourOfDay()
  payload.players = riverLife_players and riverLife_players.getPlayers() or {}
  payload.costs = {store = Domain.C.STORE_COST, storeRent = Domain.C.STORE_RENT, shop = Domain.C.SHOP_COST,
    shopRent = Domain.C.SHOP_RENT, storeFee = Domain.C.STORE_FEE_RATE, inspection = Domain.C.INSPECTION_FEE,
    lotRadius = Domain.C.LOT_RADIUS}
  payload.nearby = riverLife_display and riverLife_display.nearby() or nil
  payload.serverName = multi() and MPCoreNetwork.getCurrentServer and (MPCoreNetwork.getCurrentServer() or {}).name or nil
  payload.desktop = desktop()
  -- Rebuilding the RLS computer menu is only safe (and useful) while the RiverOS desktop is on screen:
  -- RLS closes every menu when the rebuild fails.
  local computerId = career_modules_computer and career_modules_computer.getComputerId and career_modules_computer.getComputerId()
  if computerId and deskOpen > 0 then
    local ok, data = pcall(career_modules_computer.getComputerUIData)
    payload.computer = ok and data or {}
  end
  guihooks.trigger('RiverLifeView', payload)
end
local function refreshGui() guiDirty = true end
M.refreshGui = refreshGui

-- Transport -------------------------------------------------------------------------------
local function sendRequest(p)
  local bytes = jsonEncode(p.request)
  if #bytes > Wire.maxBytes then
    pending[p.request.id] = nil
    if p.callback then p.callback({ok = false, error = 'vehicle_data_too_large'}) end
    return
  end
  -- Launcher 2.8.1 aborts large packets containing "Zp"; those go base64 chunked.
  if #bytes < 48000 and not bytes:find('Zp', 1, true) then p.sentAt = clock; TriggerServerEvent('RLRequest', bytes); return end
  p.sending = true
  sendQueue[#sendQueue + 1] = {id = p.request.id, encoded = Wire.encode64(bytes), offset = 1, pending = p}
end

local function localContext(request)
  local s = localMarket.state
  local p = request.payload or {}
  local l = s.listings[p.listingId]
  local v = s.visits[p.visitId]
  local o = s.offers[p.offerId]
  if o then v = s.visits[o.visitId] end
  local n = p.npcId and s.npcs[p.npcId]
  if n and n.visitId then v = s.visits[n.visitId] end
  if v then l = s.listings[v.listingId] end
  local c = {name = 'Você', allowImport = true, position = playerPos(), map = mapName(), hour = hourOfDay()}
  local veh = getPlayerVehicle(0)
  if veh then local d = veh:getDirectionVector(); c.heading = math.atan2(d.x, d.y) end
  if l then
    c.sellerPosition = playerPos()
    local a = s.assets[l.assetId]
    c.vehiclePosition = a and inventoryPos(invByVin(a.id) or a.localId)
    c.buyerPosition = playerPos()
    if v and s.npcs[v.buyer] then c.buyerPosition = riverLife_npcs.npcPosition(v.buyer) end
  end
  local order = p.orderId and s.orders[p.orderId]
  if order then
    if s.npcs[order.customer] then c.vehiclePosition = riverLife_npcs.npcPosition(order.customer)
    else c.vehiclePosition = inventoryPos(order.vehicle and order.vehicle.localId) end
  end
  if request.op == 'serviceRequest' and type(p.vehicle) == 'table' then c.vehiclePosition = inventoryPos(p.vehicle.localId) end
  if request.op == 'stockIn' or request.op == 'streetSell' then
    local a = s.assets[p.assetId]
    c.vehiclePosition = a and inventoryPos(invByVin(a.id) or a.localId)
  end
  if request.op == 'displayPhoto' then c.displayHost = true end
  if request.op == 'gigDeliver' and riverLife_gigs then c.vehiclePosition = riverLife_gigs.vehiclePos(p.gigId) end
  if request.op == 'npcCreate' or request.op == 'npcSellerCreate' or request.op == 'npcCustomerCreate' then c.system = true end
  if n and (request.op == 'npcArrive' or request.op == 'npcReply') then
    c.system = true
    c.position = riverLife_npcs.npcPosition(n.id)
    c.buyerPosition = c.position
  end
  return c
end

local function rpc(op, payload, callback, id)
  sequence = sequence + 1
  local request = {id = id or (tostring(os.time()) .. '-' .. tostring(sequence) .. '-' .. tostring(math.random(10000, 99999))),
    op = op, payload = payload or {}}
  if multi() then
    if not TriggerServerEvent or not (MPGameNetwork and MPGameNetwork.launcherConnected()) then
      connected = false
      if callback then callback({ok = false, error = 'multiplayer_unavailable'}) end
      return
    end
    pending[request.id] = {request = request, callback = callback, sentAt = clock, retries = 0}
    sendRequest(pending[request.id])
  else
    if not localMarket then if callback then callback({ok = false, error = 'not_ready'}) end; return end
    local result = localMarket:dispatch(localId, request, localContext(request))
    if result.ok then
      state = localMarket:snapshot(localId)
      applyWallet(state, op == 'wallet' and payload.delta or 0)
    end
    if callback then callback(result) end
    M.afterState()
  end
end
M.rpc = rpc
M.getState = function() return state end
M.getLocalId = function() return localId end
M.isConnected = function() return connected end

-- Vehicle export (career -> ledger) ---------------------------------------------------------
local function prune(node)
  if type(node) ~= 'table' then return end
  node.suitablePartNames = nil; node.unsuitablePartNames = nil
  for _, value in pairs(node) do if type(value) == 'table' then prune(value) end end
end
local function exportVehicle(inventoryId, callback, refresh)
  local id = tonumber(inventoryId)
  local v = id and career_modules_inventory.getVehicles()[id]
  if not v or v.owned == false then callback({ok = false, error = 'not_owner'}); return end
  if v.timeToAccess or v.listedForAuction or (career_modules_marketplace and career_modules_marketplace.findVehicleListing
    and career_modules_marketplace.findVehicleListing(id)) then
    callback({ok = false, error = 'listed_elsewhere'}); return
  end
  local vid = career_modules_inventory.getVehicleIdFromInventoryId(id)
  if not vid then callback({ok = false, error = 'spawn_vehicle_first'}); return end
  career_modules_inventory.updatePartConditions(vid, id, function()
    if career_modules_inventory.setMileage then career_modules_inventory.setMileage(id) end
    local data = Domain.copy(career_modules_inventory.getVehicles()[id])
    data.id = nil; data.riverLifeVIN = nil; data.riverLifeReceipt = nil
    data.damageSummary = {brokenParts = career_modules_valueCalculator.getNumberOfBrokenParts(data.partConditions or {})}
    data.thumbnail = nil
    if data.config and data.config.partsTree then prune(data.config.partsTree) end
    local function publishDamage()
      rpc(refresh and 'updateVehicle' or 'import', {localId = tostring(id), assetId = v.riverLifeVIN, data = data}, function(r)
        if r.ok then
          v.riverLifeVIN = r.data.assetId
          career_modules_inventory.setVehicleDirty(id)
          saveThen(function() return savedVehicle(id, r.data.assetId) end, function() callback(r) end)
        else
          callback(r)
        end
      end)
    end
    sequence = sequence + 1
    local exportId = tostring(os.time()) .. '-' .. sequence
    local path = basePath .. 'exports/' .. exportId .. '.json'
    FS:directoryCreate(basePath .. 'exports/')
    exportJobs[exportId] = {path = path, data = data, done = publishDamage, profile = career_saveSystem.getCurrentProfile()}
    be:queueObjectLua(vid, "extensions.load('individualRepair'); individualRepair.saveDamageData(" .. string.format('%q', path) ..
      "); obj:queueGameEngineLua(" .. string.format('%q', "extensions.riverLife.onDamageExportReady(" .. string.format('%q', exportId) .. ")") .. ")")
  end)
end
M.exportVehicle = exportVehicle
function M.onDamageExportReady(id)
  local job = exportJobs[id]; exportJobs[id] = nil
  if not job or job.profile ~= career_saveSystem.getCurrentProfile() then return end
  job.data.damageState = jsonReadFile(job.path)
  FS:removeFile(job.path)
  job.done()
end

-- Deliveries (ledger -> career) ----------------------------------------------------------------
local function ack(receipt, invId) rpc('ack', {receiptId = receipt.id, localId = invId and tostring(invId) or nil}) end
local function completeDelivery(receipt, invId)
  career_modules_inventory.setVehicleDirty(invId)
  spawnPending[receipt.id] = nil
  client.deliveries[receipt.id] = invId
  persistentLocal()
  receiptSaving[receipt.id] = true
  saveThen(function() return savedVehicle(invId, receipt.assetId) end, function()
    receiptSaving[receipt.id] = nil
    ack(receipt, invId)
    message(receipt.kind == 'trade_in' and 'Carro da troca registrado na sua garagem.' or 'Compra concluída. O carro está na sua garagem.')
    refreshGui()
  end)
end
local function finishDelivery(receipt, vehId)
  local v = object(vehId)
  if not v then spawnPending[receipt.id] = nil; return end
  local data = receipt.data or {}
  local invId = career_modules_inventory.addVehicle(vehId, nil, {owned = true, finalPrice = receipt.price / 100,
    skipPartConditionInit = data.partConditions ~= nil})
  if not invId then
    v:delete(); spawnPending[receipt.id] = nil
    message('Entrega pendente: libere uma vaga na garagem.', 'warning')
    return
  end
  local entry = career_modules_inventory.getVehicles()[invId]
  local protected = {id = true, model = true, config = true, owned = true, damageState = true, wear = true, condition = true}
  for k, value in pairs(data) do if not protected[k] then entry[k] = Domain.copy(value) end end
  if type(data.config) == 'table' then entry.config = Domain.copy(data.config) end
  entry.riverLifeVIN = receipt.assetId; entry.riverLifeReceipt = receipt.id
  entry.owned = true; entry.id = invId; entry.finalBuyingPrice = receipt.price / 100
  if data.partConditions then
    core_vehicleBridge.executeAction(v, 'initPartConditions', data.partConditions, 0, 1, 1)
  elseif data.tradeIn then
    -- Trade-in cars arrive with their real odometer and wear.
    local wear = tonumber(data.wear) or 0.75
    core_vehicleBridge.executeAction(v, 'initPartConditions', {}, data.mileage or 0, wear, wear)
  end
  if data.damageState then
    local _, savePath = career_saveSystem.getCurrentProfile()
    local path = savePath .. '/career/vehicles/damage/' .. invId .. '_damageState.json'
    FS:directoryCreate(savePath .. '/career/vehicles/damage/')
    jsonWriteFile(path, data.damageState, true)
    deliveryJobs[receipt.id] = {receipt = receipt, inventoryId = invId}
    be:queueObjectLua(vehId, "extensions.load('individualRepair'); individualRepair.loadDamageData(" .. string.format('%q', path) ..
      "); obj:queueGameEngineLua(" .. string.format('%q', "extensions.riverLife.onDamageDelivered(" .. string.format('%q', receipt.id) .. ")") .. ")")
  else
    local delay = 1.5
    deliveryJobs[receipt.id] = {receipt = receipt, inventoryId = invId, at = clock + delay}
  end
end
function M.onDamageDelivered(id)
  local job = deliveryJobs[id]; deliveryJobs[id] = nil
  if job then completeDelivery(job.receipt, job.inventoryId) end
end
local function deliveryPosition()
  local veh = getPlayerVehicle(0)
  local p = playerPos() or {x = 0, y = 0, z = 0}
  if veh then
    local d = veh:getDirectionVector()
    local right = vec3(d.y, -d.x, 0):normalized()
    local spot = vec3(p.x, p.y, p.z) + right * 5
    return spot, quatFromDir(vec3(d.x, d.y, 0))
  end
  return vec3(p.x + 5, p.y, p.z), nil
end
local function spotIsClear(p)
  for i = 0, be:getObjectCount() - 1 do
    local o = be:getObject(i)
    if o and o.JBeam ~= 'unicycle' and o:getPosition():distance(vec3(p.x, p.y, p.z)) < 3.5 then return false end
  end
  return true
end
local spawnDelivery
local function spawnAtPickup(receipt)
  -- The display car on that spot is removed by its host a moment after the sale.
  core_jobsystem.create(function(job)
    local deadline = clock + 12
    while clock < deadline and not spotIsClear(receipt.pickup) do job.sleep(0.5) end
    spawnDelivery(receipt, true)
  end)
end
function spawnDelivery(receipt, ready)
  local data = receipt.data or {}
  if receipt.pickup and not ready then spawnAtPickup(receipt); return end
  local spot, rot
  if receipt.pickup then
    local h = receipt.pickup.h or 0
    spot = vec3(receipt.pickup.x, receipt.pickup.y, receipt.pickup.z)
    rot = quatFromDir(vec3(math.sin(h), math.cos(h), 0))
  else
    spot, rot = deliveryPosition()
  end
  local options = {config = type(data.config) == 'table' and Domain.copy(data.config) or data.config,
    pos = spot + vec3(0, 0, 0.5), rot = rot, autoEnterVehicle = false}
  local ok, v = pcall(core_vehicles.spawnNewVehicle, data.model, options)
  if ok and v then
    client.pendingSpawns[receipt.id] = {vehicleId = v:getID(), receipt = receipt, at = clock}
    persistentLocal()
  else
    spawnPending[receipt.id] = nil
    message('Não foi possível carregar o modelo ' .. tostring(data.model) .. '. Confira se o mod desse carro está instalado.', 'error')
  end
end

local function applyLotStock()
  for vin, a in pairs(state.assets or {}) do
    if a.location == 'lot' or a.location == 'street' then
      local invId = invByVin(vin)
      if invId then
        career_modules_inventory.removeVehicle(invId)
        refreshGui()
        message(a.location == 'lot' and 'O carro foi para o pátio da loja e está à venda.'
          or 'Carro à venda na rua: a placa está nele e ele responde às propostas sozinho.')
      end
    end
  end
end
local function applyReceipts()
  if not state or not active() or not state.me then return end
  pcall(applyLotStock)
  local me = state.me.id
  for _, receipt in ipairs(state.receipts or {}) do
    if receipt.seller == me and not (state.assets or {})[receipt.assetId] then
      local invId = invByVin(receipt.assetId)
      if not invId then
        local candidate = tonumber(receipt.sellerLocalId)
        local v = candidate and career_modules_inventory.getVehicles()[candidate]
        if v and v.riverLifeVIN == receipt.assetId then invId = candidate end
      end
      if invId then career_modules_inventory.removeVehicle(invId); refreshGui() end
      if not receipt.sellerApplied and not receiptSaving[receipt.id] then
        receiptSaving[receipt.id] = true
        -- Done once the saved career no longer holds THIS car (the slot may hold another car, or none).
        saveThen(function()
          if not receipt.sellerLocalId then return true end
          local _, path = career_saveSystem.getCurrentProfile()
          local file = path and (path .. '/career/vehicles/' .. tostring(receipt.sellerLocalId) .. '.json')
          if not file or not FS:fileExists(file) then return path ~= nil end
          local data = jsonReadFile(file)
          return not data or data.riverLifeVIN ~= receipt.assetId
        end, function() receiptSaving[receipt.id] = nil; ack(receipt) end)
      end
    elseif receipt.buyer == me and (state.assets or {})[receipt.assetId] and not spawnPending[receipt.id] then
      local invId = invByVin(receipt.assetId)
      if invId then
        if not receipt.buyerApplied and not receiptSaving[receipt.id] then
          receiptSaving[receipt.id] = true
          saveThen(function() return savedVehicle(invId, receipt.assetId) end, function() receiptSaving[receipt.id] = nil; ack(receipt, invId) end)
        end
      elseif not receipt.buyerApplied and not career_modules_inventory.hasFreeSlot() then
        -- Paid for but no garage slot: remind the buyer now and then.
        if clock - (waitingNotice[receipt.id] or -1e9) > 180 then
          waitingNotice[receipt.id] = clock
          local title = receipt.summary and receipt.summary.niceName or 'seu carro'
          message(title .. ' está pago e esperando vaga na garagem. Venda ou guarde um carro, ou compre outra garagem, para recebê-lo.', 'warning')
        end
      elseif not receipt.buyerApplied and not deliveryFetching[receipt.id] then
        spawnPending[receipt.id] = true
        deliveryFetching[receipt.id] = true
        rpc('delivery', {receiptId = receipt.id}, function(r)
          deliveryFetching[receipt.id] = nil
          if not r.ok then spawnPending[receipt.id] = nil; return end
          -- A trade-in car is already parked at the store: it simply changes hands.
          local claimed = r.data.kind == 'trade_in' and riverLife_npcs and riverLife_npcs.claimVehicle(r.data.seller)
          if claimed then
            client.pendingSpawns[receipt.id] = {vehicleId = claimed, receipt = r.data, at = clock}
            persistentLocal()
          else
            spawnDelivery(r.data)
          end
        end)
      end
    end
  end
end

-- A car in service stays at the workshop until the job is done, like an RLS repair.
local takenToShop = {}
local function takeCarsIntoShops()
  for _, o in ipairs(state.orders or {}) do
    if o.customer == state.me.id and o.status == 'in_progress' and not takenToShop[o.id] then
      local invId = tonumber(o.vehicle and o.vehicle.localId)
      local vehInfo = invId and career_modules_inventory.getVehicles()[invId]
      if not vehInfo then
        takenToShop[o.id] = true
      elseif career_modules_inventory.getCurrentVehicle and career_modules_inventory.getCurrentVehicle() == invId then
        if not takenToShop['warned' .. o.id] then
          takenToShop['warned' .. o.id] = true
          message('Saia do carro: a oficina vai levar o ' .. (vehInfo.niceName or 'veículo') .. ' para o elevador.', 'warning')
        end
      else
        takenToShop[o.id] = true
        local remaining = math.max(5, (o.finishesAt or os.time()) - os.time())
        if career_modules_inventory.getVehicleIdFromInventoryId(invId) then career_modules_inventory.removeVehicleObject(invId) end
        if career_modules_inventory.delayVehicleAccess then career_modules_inventory.delayVehicleAccess(invId, remaining, 'repair') end
        refreshGui()
      end
    end
  end
end

-- Completed workshop jobs repair the customer's own car through RLS.
local function applyServices()
  if not state or not active() or not state.me then return end
  takeCarsIntoShops()
  for _, o in ipairs(state.orders or {}) do
    if o.customer == state.me.id and o.status == 'completed' and not o.customerApplied and not serviceApplying[o.id] then
      local invId = tonumber(o.vehicle and o.vehicle.localId)
      local vehInfo = invId and career_modules_inventory.getVehicles()[invId]
      serviceApplying[o.id] = true
      if not vehInfo then
        rpc('serviceAck', {orderId = o.id})
      else
        local function done()
          career_modules_inventory.setVehicleDirty(invId)
          saveThen(function() return true end, function()
            rpc('serviceAck', {orderId = o.id}, function() serviceApplying[o.id] = nil end)
            message('Serviço concluído na ' .. (o.shopName or 'oficina') .. ': seu ' .. (vehInfo.niceName or 'carro') .. ' está pronto.')
          end)
        end
        local ok = pcall(function()
          career_modules_insurance_insurance.startRepair(invId, {cost = {}}, function() done() end)
        end)
        if not ok then done() end
        if not career_modules_inventory.getVehicleIdFromInventoryId(invId) then done() end
      end
    end
  end
end

-- Workshop diagnosis is measured on the customer's own career data.
local function diagnose(invId)
  local v = career_modules_inventory.getVehicles()[tonumber(invId)]
  if not v then return nil end
  local details = {price = 0, partsCountToBeReplaced = 0}
  local ok, d = pcall(career_modules_valueCalculator.getRepairDetails, v)
  if ok and d then details = d end
  local broken = 0
  pcall(function() broken = career_modules_valueCalculator.getNumberOfBrokenParts(v.partConditions or {}) end)
  local notes = {}
  if (details.partsCountToBeReplaced or 0) > 0 then notes[#notes + 1] = details.partsCountToBeReplaced .. ' peça(s) para trocar' end
  if (v.mileage or 0) > 150000000 then notes[#notes + 1] = 'quilometragem alta' end
  return {partsCost = math.floor((details.price or 0) * 100), brokenParts = broken,
    partsToReplace = details.partsCountToBeReplaced or 0, notes = table.concat(notes, ', ')},
    {localId = tostring(invId), model = v.model, niceName = v.niceName, assetId = v.riverLifeVIN, mileage = v.mileage}
end
M.diagnose = diagnose

-- Photos ----------------------------------------------------------------------------------------
-- One shot from cp looking at center; done(photoId or nil).
local photoStarted, markersHidden = 0, false
local function photoDone()
  photoBusy = false
  if markersHidden then photoModeOpen = false; markersHidden = false end
end

local function shoot(center, cp, done, delay)
  sequence = sequence + 1
  local photoId = 'photo-' .. os.time() .. '-' .. sequence
  local relative = basePath .. 'photos/' .. photoId .. '.png'
  FS:directoryCreate(basePath .. 'photos/')
  local tod = core_environment.getTimeOfDay().time or 0
  local light
  if tod >= 0.25 and tod <= 0.75 then
    -- Night shots get a soft flash so the car is visible in the listing.
    light = (worldEditorCppApi and worldEditorCppApi.createObject('SpotLight')) or createObject('SpotLight')
  end
  if light then
    light.canSave = false
    light:setPosition(cp)
    local rot = quatFromDir(center - cp):toTorqueQuat()
    light:setField('rotation', 0, rot.x .. ' ' .. rot.y .. ' ' .. rot.z .. ' ' .. rot.w)
    light:setField('color', 0, '1 0.96 0.92 1'); light:setField('intensity', 0, '25000')
    light:setField('innerAngle', 0, '0'); light:setField('outerAngle', 0, '75'); light:setField('range', 0, '30')
    light:setField('attenuationRatio', 0, '1 0 0'); light:setField('castShadows', 0, 'false'); light:setField('isEnabled', 0, 'true')
    light:registerObject('RiverLifeFlash_' .. photoId)
    scenetree.MissionGroup:add(light)
  end
  photoBusy, photoStarted = true, os.clock()
  -- Same flag the game's photo mode sets: GPS arrows and markers stay out of the picture.
  markersHidden = photoModeOpen ~= true
  if markersHidden then photoModeOpen = true end
  render_renderViews.takeScreenshot({renderViewName = 'RiverLifePhoto_' .. photoId, resolution = vec3(1280, 720, 0),
    screenshotDelay = delay or 0.75, downscaleFactor = 1, pos = cp, rot = quatFromDir(center - cp), fov = 55, nearPlane = 0.1,
    filename = relative}, function(success)
    photoDone()
    if light then light:delete() end
    if success then
      client.photos[photoId] = relative
      photoSources[photoId] = '/' .. relative:gsub('^/', '')
      persistentLocal()
    end
    done(success and photoId or nil)
  end)
end

local function capture(inventoryId, angle)
  if photoBusy then message('Aguarde a foto atual terminar.'); return end
  local id = tonumber(inventoryId)
  local vid = id and career_modules_inventory.getVehicleIdFromInventoryId(id)
  local v = object(vid)
  if not v then message('Traga o veículo para fotografar.', 'warning'); return end
  angle = tonumber(angle) or 0
  local center = v:getPosition() + vec3(0, 0, 0.9)
  local a = angle * math.pi / 180
  local cp = center + vec3(math.cos(a) * 6.5, math.sin(a) * 6.5, 1.6)
  shoot(center, cp, function(photoId)
    if photoId then
      guihooks.trigger('RiverLifePhotoCaptured', {photoId = photoId, url = photoSources[photoId], inventoryId = id, mp = multi()})
    else
      message('A foto não foi concluída. Tente novamente.', 'warning')
    end
  end)
end

-- Cars on a lot or by the road are photographed where they stand by the client that spawned
-- them: front 3/4 from both sides and a rear 3/4. The UI uploads them and attaches them to the ad.
local DISPLAY_ANGLES = {35, -35, 160}
local displayShots = {}
function M.captureDisplay(listingId, vehId, count)
  if not listingId or displayShots[listingId] then return end
  displayShots[listingId] = true
  core_jobsystem.create(function(job)
    for i = 1, math.min(tonumber(count) or #DISPLAY_ANGLES, #DISPLAY_ANGLES) do
      local waited = 0
      while photoBusy and waited < 30 do job.sleep(0.5); waited = waited + 0.5 end
      local v = object(vehId)
      if not v or photoBusy then displayShots[listingId] = nil; return end
      local center = v:getPosition() + vec3(0, 0, 0.8)
      local fwd = vec3(v:getDirectionVector()); fwd.z = 0
      if fwd:length() < 0.1 then fwd = vec3(0, 1, 0) end
      fwd = fwd:normalized()
      local a = math.rad(DISPLAY_ANGLES[i])
      local dir = vec3(fwd.x * math.cos(a) - fwd.y * math.sin(a), fwd.x * math.sin(a) + fwd.y * math.cos(a), 0)
      -- Far enough to frame the whole car (vans and trucks need more room), never behind a wall.
      local halfLen = 2.3
      pcall(function()
        for axis = 0, 2 do halfLen = math.max(halfLen, vec3(be:getObjectOOBBHalfAxisXYZ(vehId, axis)):length()) end
      end)
      local range = math.max(6.2, halfLen * 2.7)
      local hit = castRayStatic(center, dir, range)
      if hit and hit < range then range = math.max(3, hit - 0.6) end
      local cp = center + dir * range + vec3(0, 0, 0.9)
      local finished = false
      -- A longer delay lets the new view settle its exposure (short ones can come out washed white).
      shoot(center, cp, function(photoId)
        finished = true
        if photoId then
          guihooks.trigger('RiverLifePhotoCaptured', {photoId = photoId, url = photoSources[photoId], display = listingId, mp = multi()})
        end
      end, 1.8)
      local t = 0
      while not finished and t < 15 do job.sleep(0.25); t = t + 0.25 end
    end
  end)
end


-- Session -----------------------------------------------------------------------------------------
-- The server plugin was reloaded (or restarted) while we stayed connected: introduce
-- ourselves again and resend the request once, instead of failing every action.
local lastRehello = -100
local function rehello(retry)
  if clock - lastRehello < 10 then return end
  lastRehello = clock
  local identity = jsonReadFile(SETTINGS .. 'client.json') or {}
  rpc('hello', {balance = cents(), guestToken = identity.guestToken}, function(r)
    if r.ok then state = r.data; connected = true; applyWallet(state); M.afterState(); if retry then retry() end end
  end)
end

local function onReply(bytes)
  local r = type(bytes) == 'table' and bytes or jsonDecode(bytes)
  if not r then return end
  local p = pending[r.id]; pending[r.id] = nil
  if r.error == 'hello_required' and p and p.request and p.request.op ~= 'hello' and not p.rehelloed and multi() then
    p.rehelloed = true
    pending[r.id] = p
    rehello(function() p.sentAt = clock; sendRequest(p) end)
    return
  end
  if p and p.callback then p.callback(r) end
  if not r.ok then guihooks.trigger('RiverLifeError', {id = r.id, error = r.error}) end
end
local function onState(bytes)
  local snapshot = type(bytes) == 'table' and bytes or jsonDecode(bytes)
  if not snapshot or not snapshot.me then return end
  state = snapshot; connected = true
  if not walletPending then applyWallet(state) end
  M.afterState()
end
function M.afterState()
  applyReceipts()
  applyServices()
  if riverLife_npcs then riverLife_npcs.onState(state) end
  if riverLife_players then riverLife_players.onState(state) end
  refreshGui()
end

local function openLocalMarket()
  local latest, revision = nil, -1
  for _, file in ipairs(FS:findFiles(basePath, 'market.*.json', 0, true, false)) do
    local saved = jsonReadFile(file)
    if saved and saved.revision and saved.revision > revision then latest = saved; revision = saved.revision end
  end
  FS:directoryCreate(basePath .. 'blobs/')
  localMarket = Domain.new({now = os.time, encode = jsonEncode,
    photoOwned = function(_, photo) return client.photos[photo] ~= nil end,
    putBlob = function(data)
      sequence = sequence + 1
      local ref = 'b' .. os.time() .. '-' .. sequence
      jsonWriteFile(basePath .. 'blobs/' .. ref .. '.json', data, true)
      return ref
    end,
    getBlob = function(ref)
      if type(ref) ~= 'string' or not ref:match('^[%w%-]+$') then return nil end
      return jsonReadFile(basePath .. 'blobs/' .. ref .. '.json')
    end,
    save = function(s)
      local path = basePath .. 'market.' .. string.format('%d', s.revision) .. '.json'
      jsonWriteFile(path, s, true)
      local saved = jsonReadFile(path)
      if not saved or saved.revision ~= s.revision then return false end
      for _, file in ipairs(FS:findFiles(basePath, 'market.*.json', 0, true, false)) do
        local r = tonumber(file:match('market%.(%d+)%.json$'))
        if r and r < s.revision - 3 then FS:removeFile(file) end
      end
      return true
    end,
    log = function(err) log('E', 'RiverLife', err) end}, latest)
end

-- BeamMP keeps the old handler when a lone handler is registered again (any Lua
-- reload of this extension), so two RiverLife instances would both apply the same
-- receipt and deliver a car twice. One trampoline per event lives for the whole
-- Lua VM and only its target changes; a reloaded BeamMP gets fresh trampolines.
local function onServer(event, fn)
  local targets = rawget(_G, '__riverLifeEvents')
  if not targets or targets.__add ~= AddEventHandler then
    targets = {__add = AddEventHandler}
    rawset(_G, '__riverLifeEvents', targets)
  end
  local registered = targets[event] ~= nil
  targets[event] = fn
  if not registered then
    AddEventHandler(event, function(data)
      local current = rawget(_G, '__riverLifeEvents')
      local f = current and current[event]
      if f then return f(data) end
    end, 'RiverLife')
  end
end

local function initialize()
  if not active() then return end
  installSaleGuards()
  local slot = career_saveSystem.getCurrentProfile()
  if not slot then return end
  basePath = SETTINGS .. 'saves/' .. pathId(slot) .. '/'
  FS:directoryCreate(basePath)
  client = jsonReadFile(basePath .. 'client-state.json') or {}
  client.deliveries = client.deliveries or {}; client.pendingSpawns = {}; client.photos = client.photos or {}
  for id, path in pairs(client.photos) do photoSources[id] = '/' .. tostring(path):gsub('^/', '') end
  localId = 'solo:' .. pathId(slot)
  if not multi() then openLocalMarket() end
  if AddEventHandler then
    onServer('RLReply', onReply)
    onServer('RLState', onState)
    onServer('RLChunk', function(bytes)
      local p = jsonDecode(bytes); if not p then return end
      local joined = Wire.accept(receiveChunks, p.id, p, clock)
      if joined then
        if p.event == 'RLReply' then onReply(joined) elseif p.event == 'RLState' then onState(joined) end
      end
    end)
    onServer('RLPhotoAck', function(bytes)
      local p = jsonDecode(bytes); if not p then return end
      client.photos[p.photoId] = client.photoUploads and client.photoUploads[p.uploadId]
      photoSources[p.photoId] = client.photos[p.photoId] and ('/' .. client.photos[p.photoId]:gsub('^/', ''))
      persistentLocal()
      guihooks.trigger('RiverLifePhotoUploaded', p)
    end)
    onServer('RLPhotoData', function(bytes)
      local p = jsonDecode(bytes); if not p then return end
      if type(p.chunk) == 'string' then p.chunk = p.chunk:gsub('_', 'Z') end
      guihooks.trigger('RiverLifePhotoChunk', p)
    end)
    onServer('RLPlayers', function(bytes)
      local p = jsonDecode(bytes)
      if p and riverLife_players then riverLife_players.onPresence(p.players or {}) end
    end)
    onServer('RLDisplays', function(bytes)
      local p = jsonDecode(bytes)
      if p and riverLife_display then riverLife_display.onAssign(p) end
    end)
    onServer('RLNeedSpots', function()
      if riverLife_gigs then riverLife_gigs.onNeedSpots() end
    end)
    onServer('RLNpcSlot', function(bytes)
      local p = jsonDecode(bytes)
      if p and riverLife_npcs then riverLife_npcs.onSlot(p) end
    end)
  end
  local identity = jsonReadFile(SETTINGS .. 'client.json') or {}
  rpc('hello', {balance = cents(), guestToken = identity.guestToken}, function(r)
    if r.ok then state = r.data; connected = true; applyWallet(state); M.afterState()
    elseif r.error then message('RiverLife: ' .. tostring(r.error), 'error') end
  end)
end

-- Career money changes are mirrored to the ledger before any transaction.
local walletWaiters = {}
local function walletDone(ok)
  walletPending = false
  local waiting = walletWaiters; walletWaiters = {}
  if ok then for _, f in ipairs(waiting) do f() end end
end
local function syncWallet(done)
  if not state then if done then done() end; return end
  local delta = cents() - attr('riverLifeBalance')
  if delta == 0 then if done then done() end; return end
  -- A sync already running: this request goes on as soon as it finishes (never left hanging).
  if walletPending then if done then walletWaiters[#walletWaiters + 1] = done end; return end
  walletPending = true
  local revision = attr('riverLifeWalletRevision') + 1
  career_modules_playerAttributes.addAttributes({riverLifeWalletIntentRevision = revision - attr('riverLifeWalletIntentRevision'),
    riverLifeWalletIntentDelta = delta - attr('riverLifeWalletIntentDelta')}, {label = 'RiverLife: sincronização pendente'})
  saveThen(function()
    local _, path = career_saveSystem.getCurrentProfile()
    local saved = path and jsonReadFile(path .. '/career/playerAttributes.json')
    return saved and saved.riverLifeWalletIntentRevision and saved.riverLifeWalletIntentRevision.value == revision
      and saved.riverLifeWalletIntentDelta and saved.riverLifeWalletIntentDelta.value == delta
  end, function()
    rpc('wallet', {delta = delta, revision = revision}, function(r)
      if r.ok then
        if multi() then
          rpc('snapshot', {}, function(s)
            if s.ok then state = s.data; applyWallet(state); walletDone(true); M.afterState(); if done then done() end
            else walletDone(false) end
          end)
        else
          walletDone(true)
          if done then done() end
        end
      else
        walletDone(false)
        guihooks.trigger('RiverLifeError', {error = r.error})
      end
    end)
  end)
end
M.syncWallet = syncWallet

-- UI requests ---------------------------------------------------------------------------------------
local respond
local LOCAL_OPS = {}
function LOCAL_OPS.refresh() refreshGui() end
-- The RiverOS desktop tells when it is on screen (each RLS screen remounts it).
function LOCAL_OPS.desk(p)
  if p.kind == 'phone' then phoneOpen = math.max(0, phoneOpen + (p.open and 1 or -1))
  else deskOpen = math.max(0, deskOpen + (p.open and 1 or -1)) end
  refreshGui()
end
function LOCAL_OPS.close()
  uiOpen = false
  guihooks.trigger('RiverLifeOpen', {open = false})
  if career_modules_computer and career_modules_computer.getComputerId and career_modules_computer.getComputerId() then
    career_career.closeAllMenus()
  end
end
function LOCAL_OPS.gps(p)
  local x = p.position
  if x and type(x.x) == 'number' then
    core_groundMarkers.setPath({vec3(x.x, x.y, x.z)}, {clearPathOnReachingTarget = true})
    message('Destino marcado no GPS.')
  end
end
function LOCAL_OPS.gpsPlayer(p) if riverLife_players then riverLife_players.gpsTo(p.pid) end end
function LOCAL_OPS.native(p)
  if career_modules_computer and career_modules_computer.computerButtonCallback then
    career_modules_computer.computerButtonCallback(p.buttonId, p.inventoryId and tonumber(p.inventoryId) or nil)
  end
end
function LOCAL_OPS.spawn(p)
  local id = tonumber(p.inventoryId)
  if id then career_modules_inventory.spawnVehicle(id, 2, function() refreshGui() end) end
end
function LOCAL_OPS.capture(p) capture(p.inventoryId, p.angle) end
function LOCAL_OPS.photoData(p)
  if not multi() or not TriggerServerEvent or not client.photos[p.sourceId] then return end
  if type(p.chunk) ~= 'string' or #p.chunk > Wire.chunkSize then return end
  p.chunk = p.chunk:gsub('Z', '_')
  client.photoUploads = client.photoUploads or {}
  client.photoUploads[p.uploadId] = client.photos[p.sourceId]
  TriggerServerEvent('RLPhoto', jsonEncode(p))
end
function LOCAL_OPS.photoGet(p)
  if multi() then TriggerServerEvent('RLPhoto', jsonEncode({op = 'get', photoId = p.photoId})) else refreshGui() end
end
function LOCAL_OPS.walkTo(p) if riverLife_players then riverLife_players.focus(p) end end
-- RiverOS wallpaper: a built-in theme, a solid color or a picture (game screenshot or RiverLife photo).
function LOCAL_OPS.desktopPrefs(p)
  local prefs = desktop()
  local w = p and p.wallpaper
  if type(w) == 'table' and (w.kind == 'theme' or w.kind == 'color' or w.kind == 'image') and type(w.value) == 'string' and #w.value < 300 then
    if w.kind == 'image' and not (w.value:match('^/screenshots/') or w.value:match('^/settings/riverlife/')) then return end
    prefs.wallpaper = {kind = w.kind, value = w.value, fit = w.fit == 'center' and 'center' or 'cover'}
    jsonWriteFile(DESKTOP_FILE, prefs, true)
    refreshGui()
  end
end
local function newestFiles(dir, patterns, limit)
  local out = {}
  for _, pattern in ipairs(patterns) do
    for _, f in ipairs(FS:findFiles(dir, pattern, -1, false, false) or {}) do out[#out + 1] = f end
  end
  table.sort(out, function(a, b) return a > b end) -- names carry the date: newest first
  local list = {}
  for i = 1, math.min(limit, #out) do list[i] = out[i] end
  return list
end
function LOCAL_OPS.partPhotos(p)
  if riverLife_partPhotos then riverLife_partPhotos.request(p) end
end
function LOCAL_OPS.wallpapers(_, r)
  local shots = newestFiles('/screenshots/', {'*.png', '*.jpg'}, 40)
  local photos = {}
  for _, path in pairs(photoSources) do if tostring(path):match('^/settings/riverlife/') then photos[#photos + 1] = path end end
  table.sort(photos, function(a, b) return a > b end)
  while #photos > 40 do table.remove(photos) end
  respond(r, 'wallpapers', {ok = true, data = {screenshots = shots, photos = photos}})
end

-- Store lot layout ---------------------------------------------------------------------
local function groundAt(p)
  local origin = vec3(p.x, p.y, p.z + 4)
  local d = castRayStatic(origin, vec3(0, 0, -1), 14)
  if d >= 14 then return nil end
  return origin.z - d
end
local function spotFree(p)
  local center = vec3(p.x, p.y, p.z + 1)
  for _, dir in ipairs({vec3(1, 0, 0), vec3(-1, 0, 0), vec3(0, 1, 0), vec3(0, -1, 0)}) do
    if castRayStatic(center, dir, 2.2) < 2 then return false end
  end
  return true
end
local function myStore(storeId)
  for _, st in ipairs((state and state.stores) or {}) do
    if st.id == storeId and st.owner == (state.me and state.me.id) then return st end
  end
end
local function playerHeading()
  local veh = getPlayerVehicle(0)
  if not veh then return 0 end
  local d = veh:getDirectionVector()
  return math.atan2(d.x, d.y)
end
-- A row (or two) of spots in front of the owner, cars facing the owner like a showroom.
function LOCAL_OPS.lotAuto(p, r)
  local st = myStore(p.storeId)
  local here = playerPos()
  if not st or not here then respond(r, 'lotAuto', {ok = false, error = 'store_missing'}); return end
  local h = playerHeading()
  local fwd = vec3(math.sin(h), math.cos(h), 0)
  local right = vec3(fwd.y, -fwd.x, 0)
  local want = math.min(st.capacity or 4, Domain.C.STORE_MAX_CAPACITY)
  local spots = {}
  for row = 0, 3 do
    for col = 0, 11 do
      if #spots >= want then break end
      local side = (col % 2 == 0) and 1 or -1
      local offset = side * (math.floor((col + 1) / 2) * 3.6 + (col == 0 and 0 or 0))
      local base = vec3(here.x, here.y, here.z) + fwd * (7 + row * 7) + right * offset
      local z = groundAt(base)
      if z then
        local spot = {x = base.x, y = base.y, z = z, h = h + math.pi}
        local zl, zr = groundAt(base + right * 1), groundAt(base - right * 1)
        local flat = zl and zr and math.abs(zl - zr) < 0.8
        if flat and spotFree(spot) and Domain.distance(spot, st.position) <= Domain.C.LOT_RADIUS then spots[#spots + 1] = spot end
      end
    end
  end
  if #spots == 0 then respond(r, 'lotAuto', {ok = false, error = 'no_room'}); return end
  rpc('setLot', {storeId = st.id, spots = spots}, function(res)
    respond(r, 'lotAuto', res)
    if res.ok then message(#spots .. ' vaga(s) marcadas no pátio.') end
  end)
end
function LOCAL_OPS.lotMark(p, r)
  local st = myStore(p.storeId)
  local here = playerPos()
  if not st or not here then respond(r, 'lotMark', {ok = false, error = 'store_missing'}); return end
  local spots = Domain.copy(st.lot or {})
  local z = groundAt(here) or here.z
  spots[#spots + 1] = {x = here.x, y = here.y, z = z, h = playerHeading()}
  rpc('setLot', {storeId = st.id, spots = spots}, function(res)
    respond(r, 'lotMark', res)
    if res.ok then message('Vaga ' .. #spots .. ' marcada aqui.') end
  end)
end
function LOCAL_OPS.lotClear(p, r)
  local st = myStore(p.storeId)
  if not st then respond(r, 'lotClear', {ok = false, error = 'store_missing'}); return end
  rpc('setLot', {storeId = st.id, spots = {}}, function(res) respond(r, 'lotClear', res) end)
end
function LOCAL_OPS.gpsTo(p) if p and p.x then riverLife_gigs.gpsTo(p) end end

function respond(r, op, result)
  guihooks.trigger('RiverLifeAction', {id = r.id, op = op, result = result})
end

-- RLS limits owned cars to garage slots; a bought car waits in the ledger until
-- one is free, so the buyer side is stopped up front with a clear reason.
local function buyerSide(op, p)
  if op == 'visit' or op == 'tradeOffer' then return true end
  local me = state and state.me and state.me.id
  if op == 'offer' then
    for _, v in ipairs(state.visits or {}) do if v.id == p.visitId then return v.buyer == me end end
  elseif op == 'accept' then
    for _, o in ipairs(state.offers or {}) do if o.id == p.offerId then return o.buyer == me end end
  end
  return false
end
local function garageFull()
  return career_modules_inventory and career_modules_inventory.hasFreeSlot and not career_modules_inventory.hasFreeSlot()
end

-- A street car has to be where anyone can walk up to it: not inside a garage or dealer zone.
local function inPrivateArea(pos)
  if not freeroam_facilities then return false end
  for _, kind in ipairs({'garage', 'dealership'}) do
    for _, f in ipairs(freeroam_facilities.getFacilitiesByType(kind) or {}) do
      local ok, zones = pcall(freeroam_facilities.getZonesForFacility, f)
      for _, z in ipairs(ok and zones or {}) do
        if z.containsPoint2D and z:containsPoint2D(pos) then return true end
      end
    end
  end
  return false
end

-- Operations that need career data attached before reaching the ledger.
local function handleDomain(r)
  local p = r.payload or {}
  if (r.op == 'visit' or r.op == 'offer' or r.op == 'accept' or r.op == 'tradeOffer') and buyerSide(r.op, p) and garageFull() then
    respond(r, r.op, {ok = false, error = 'garage_full'})
    return
  end
  if r.op == 'publishVehicle' then
    exportVehicle(p.inventoryId, function(result)
      if not result.ok then respond(r, 'publish', result); return end
      local payload = {assetId = result.data.assetId, title = p.title, description = p.description or '', price = p.price,
        photos = p.photos, storeId = p.storeId, negotiable = p.negotiable}
      rpc('publish', payload, function(published)
        respond(r, 'publish', published)
        if published.ok then message('Anúncio publicado no RiverLife Classificados.') end
      end, r.id)
    end)
    return
  end
  if r.op == 'stockIn' then
    exportVehicle(p.inventoryId, function(result)
      if not result.ok then respond(r, 'stockIn', result); return end
      rpc('stockIn', {storeId = p.storeId, assetId = result.data.assetId, price = p.price, title = p.title,
        description = p.description, photos = p.photos, spot = p.spot}, function(res)
        respond(r, 'stockIn', res)
        if res.ok then message('Carro no pátio. A placa de preço já está nele.') end
      end, r.id)
    end)
    return
  end
  if r.op == 'streetSellVehicle' then
    -- The car stays where it is parked, with a sign; it leaves the garage like a lot car.
    local vid = career_modules_inventory.getVehicleIdFromInventoryId(tonumber(p.inventoryId) or -1)
    local veh = vid and getObjectByID(vid)
    if not veh then respond(r, 'streetSell', {ok = false, error = 'spawn_vehicle_first'}); return end
    if inPrivateArea(veh:getPosition()) then respond(r, 'streetSell', {ok = false, error = 'private_area'}); return end
    local d = veh:getDirectionVector()
    local heading = math.atan2(d.x, d.y)
    exportVehicle(p.inventoryId, function(result)
      if not result.ok then respond(r, 'streetSell', result); return end
      rpc('streetSell', {assetId = result.data.assetId, price = p.price, minimum = p.minimum, title = p.title,
        description = p.description, heading = heading}, function(res)
        respond(r, 'streetSell', res)
      end, r.id)
    end)
    return
  end
  if r.op == 'serviceRequest' then
    local diagnosis, vehicle = diagnose(p.inventoryId)
    if not diagnosis then respond(r, r.op, {ok = false, error = 'invalid_vehicle'}); return end
    rpc('serviceRequest', {workshopId = p.workshopId, vehicle = vehicle, diagnosis = diagnosis, notes = p.notes},
      function(result) respond(r, r.op, result); if result.ok then message('Pedido enviado à oficina.') end end, r.id)
    return
  end
  local function perform()
    rpc(r.op, p, function(result)
      if result.ok and r.op == 'offer' and riverLife_npcs then riverLife_npcs.afterOffer(p.visitId) end
      if result.ok and result.data and result.data.message then message(result.data.message) end
      if result.ok and not multi() then applyReceipts() end
      respond(r, r.op, result)
    end, r.id)
  end
  -- Before a seller signs, refresh the ledger copy so the buyer gets the car as it is now.
  local visit
  if r.op == 'offer' then for _, v in ipairs(state.visits or {}) do if v.id == p.visitId then visit = v end end end
  if r.op == 'accept' then
    for _, o in ipairs(state.offers or {}) do
      if o.id == p.offerId then for _, v in ipairs(state.visits or {}) do if v.id == o.visitId then visit = v end end end
    end
  end
  local assetId
  if visit and visit.seller == state.me.id then
    for _, l in ipairs(state.listings or {}) do if l.id == visit.listingId then assetId = l.assetId end end
  end
  local invId = assetId and invByVin(assetId)
  if invId and career_modules_inventory.getVehicleIdFromInventoryId(invId) then
    exportVehicle(invId, function(result)
      if result.ok then perform() else respond(r, r.op, result) end
    end, true)
  else
    perform()
  end
end

local function uiRequest(bytes)
  local r = jsonDecode(bytes)
  if type(r) ~= 'table' or type(r.op) ~= 'string' then return end
  if not active() then guihooks.trigger('RiverLifeView', {careerActive = false}); return end
  if not client then initialize() end
  local p = r.payload or {}
  if LOCAL_OPS[r.op] then LOCAL_OPS[r.op](p, r); return end
  if not state then respond(r, r.op, {ok = false, error = connected and 'not_ready' or 'server_unreachable'}); return end
  syncWallet(function() handleDomain(r) end)
end
M.uiRequest = uiRequest

-- Update loop ----------------------------------------------------------------------------------------
local function onUpdate(dtReal)
  -- A screenshot that never reports back must not leave photos blocked or the GPS hidden.
  if photoBusy and os.clock() - photoStarted > 20 then photoDone() end
  clock = clock + (dtReal or 0)
  if multi() then NetworkGuard.update() end
  installLeaveGuard()
  if multi() and connected and not (MPGameNetwork and MPGameNetwork.launcherConnected()) then
    connected = false; refreshGui()
    message('Conexão com o servidor perdida. Reconecte para continuar seus negócios.', 'warning')
  end
  if multiplayerPending and multi() and not MPCoreNetwork.isGoingMPSession() and MPGameNetwork and MPGameNetwork.launcherConnected() then
    multiplayerPending = false
    M.activateMultiplayerCareer()
  end
  if not active() then return end
  if not client then initialize() end
  if clock - lastSend >= 0.1 and #sendQueue > 0 then
    lastSend = clock
    local job = sendQueue[1]
    for _ = 1, 2 do
      if job.offset > #job.encoded then break end
      TriggerServerEvent('RLRequestChunk', jsonEncode({id = job.id, total = #job.encoded, offset = job.offset,
        chunk = job.encoded:sub(job.offset, job.offset + Wire.chunkSize - 1)}))
      job.offset = job.offset + Wire.chunkSize
    end
    if job.offset > #job.encoded then job.pending.sending = false; job.pending.sentAt = clock; table.remove(sendQueue, 1) end
  end
  for id, job in pairs(receiveChunks) do if clock - job.at > 180 then receiveChunks[id] = nil end end
  -- A pending job may force a few career saves; after that it waits for the game's own saves,
  -- so a check that never passes can not make the game save every two seconds.
  if #saveJobs > 0 and clock - lastSaveRetry > 2 then
    lastSaveRetry = clock
    finishSavedJobs()
    local force = false
    for _, job in ipairs(saveJobs) do
      job.forced = (job.forced or 0) + 1
      if job.forced <= 5 then force = true end
      if job.forced == 6 then log('W', 'riverLife', 'a career save check is still pending; waiting for normal saves') end
    end
    if force and not (career_saveSystem.isSaveBusy and career_saveSystem.isSaveBusy()) then
      career_saveSystem.saveCurrent(nil, {force = true})
    end
  end
  for id, p in pairs(pending) do
    if not p.sending and clock - p.sentAt > 10 then
      if p.retries < 3 then p.retries = p.retries + 1; p.sentAt = clock; sendRequest(p)
      else pending[id] = nil; if p.callback then p.callback({ok = false, error = 'server_timeout'}) end end
    end
  end
  for id, p in pairs(client.pendingSpawns) do
    if clock - p.at > 1 then client.pendingSpawns[id] = nil; finishDelivery(p.receipt, p.vehicleId) end
  end
  for id, job in pairs(deliveryJobs) do
    if job.at and clock >= job.at then deliveryJobs[id] = nil; completeDelivery(job.receipt, job.inventoryId) end
  end
  if not multi() and localMarket and clock - lastTickCheck > 1 then
    lastTickCheck = clock
    if localMarket:needsTick(os.time()) then rpc('tick', {}) end
  end
  -- The full view (state copy, garage values, computer menu) is only built while the PC or the
  -- phone app is on screen; otherwise at most every 30 s so badges and the photo uploads stay current.
  if guiDirty then
    guiTimer = guiTimer + (dtReal or 0)
    local watching = deskOpen > 0 or phoneOpen > 0
    if guiTimer > 0.25 and (watching or clock - lastGui > 30) then guiTimer = 0; lastGui = clock; gui() end
  end
end

local function resetSession()
  if riverLife_npcs then riverLife_npcs.reset() end
  client = nil; state = nil; localMarket = nil; connected = false
  pending = {}; photoSources = {}; spawnPending = {}; walletPending = false; walletWaiters = {}; saveJobs = {}; receiptSaving = {}
  exportJobs = {}; deliveryJobs = {}; deliveryFetching = {}; sendQueue = {}; receiveChunks = {}; serviceApplying = {}
  waitingNotice = {}
end
local function onCareerActive(enabled) resetSession(); if enabled then initialize() end end

-- BeamMP: each server gets its own career save; solo progress never mixes in.
function M.activateMultiplayerCareer()
  if not career_saveSystem or not career_career or not multi() then return end
  local server = MPCoreNetwork.getCurrentServer() or {}
  local config = jsonReadFile(SETTINGS .. 'client.json') or {}
  local realm = tostring(server.ip or 'server') .. ':' .. tostring(server.port or 0)
  local hash = 5381
  for i = 1, #realm do hash = (hash * 33 + realm:byte(i)) % 2147483647 end
  local slot = config.multiplayerProfile or ('riverlifemp' .. tostring(hash))
  if riverLife_players then riverLife_players.applyMultiplayerVisibility(true) end
  if active() and career_saveSystem.getCurrentProfile() == slot then
    multiplayerCareer = true
    if not client then initialize() end
    return
  end
  if active() then career_saveSystem.saveCurrent(); career_career.deactivateCareer() end
  -- RLS preload markers can survive a BeamMP remount; retry them on activation.
  for key, value in pairs(package.loaded) do
    if value == true and (key:match('^career/modules/') or key:match('^/lua/ge/extensions/career/modules/')) then package.loaded[key] = nil end
  end
  career_saveSystem.setProfile(slot)
  multiplayerCareer = true
  career_career.activateCareer(false, getCurrentLevelIdentifier())
  message('Carreira online deste servidor: ' .. slot)
end

local function onServerLeave()
  if multiplayerCareer and active() then career_career.deactivateCareer() end
  leavingCareer = false
  multiplayerCareer = false; multiplayerPending = false
  if riverLife_players then riverLife_players.applyMultiplayerVisibility(false) end
  resetSession()
end
local function onServerJoined()
  resetSession()
  -- BeamMP runs this inside its mission-start hook, before the game socket is up.
  multiplayerPending = true
end

-- The RLS computer gets a RiverLife entry; the RiverOS desktop replaces its screen.
local function onComputerAddFunctions(menuData, functions)
  functions.general.riverLife = {id = 'riverLife', label = 'RiverLife — classificados, lojas e oficinas', order = 1,
    callback = function() M.open('market') end}
end
local function atComputer()
  return career_modules_computer and career_modules_computer.getComputerId and career_modules_computer.getComputerId() ~= nil
end
function M.open(app, focus)
  if not active() then message('Abra sua carreira RLS para usar o RiverLife.', 'warning'); return end
  if not client then initialize() end
  uiOpen = true
  gui()
  guihooks.trigger('RiverLifeOpen', {open = true, app = app or 'market', focus = focus})
  if not atComputer() then guihooks.trigger('RiverLifeOpenPhone', {open = true, app = app, focus = focus}) end
end
-- Keyboard shortcut and RLS phone: the mobile app works anywhere in the map.
function M.openPhone(app)
  if not active() then message('Abra sua carreira RLS para usar o RiverLife.', 'warning'); return end
  if not client then initialize() end
  gui()
  local near = not app and riverLife_display and riverLife_display.nearby()
  if near then
    guihooks.trigger('RiverLifeOpenPhone', {open = true, app = 'market', focus = near, walkIn = true})
    return
  end
  guihooks.trigger('RiverLifeOpenPhone', {open = true, app = app})
end
M.isOpen = function() return uiOpen end
M.capture = capture
-- In-world signs and labels hide while a photo is taken, so they never end up in a listing.
function M.isShooting() return photoBusy end
-- Any photo on its way (listing shots or RiverPeças catalog shots): signs and labels stay hidden.
function M.anyShooting() return photoBusy or (riverLife_partPhotos ~= nil and riverLife_partPhotos.isShooting()) end

M.onUpdate = onUpdate
M.onComputerMenuOpened = function() if active() then if not client then initialize() end; gui() end end
M.onComputerAddFunctions = onComputerAddFunctions
M.onSaveFinished = function() finishSavedJobs(true) end
M.onCareerActive = onCareerActive
M.onBeamMPServerLeave = onServerLeave
M.onBeamMPPostJoin = onServerJoined
M.onVehicleSwitched = function() refreshGui() end

function M.onExtensionUnloaded()
  NetworkGuard.unload()
  if MPCoreNetwork and MPCoreNetwork.leaveServer == guardedLeave then MPCoreNetwork.leaveServer = originalLeave end
  for _, g in ipairs(saleGuards) do if g.module[g.key] == g.wrapper then g.module[g.key] = g.original end end
  if guestAvatarRequest and http.request == guestAvatarRequest then http.request = originalHttpRequest end
end
function M.onExtensionLoaded()
  installLeaveGuard()
  -- BeamMP guests have no forum avatar; that synchronous lookup can block GE Lua.
  if not guestAvatarRequest then
    originalHttpRequest = http.request
    guestAvatarRequest = function(req, ...)
      local url = type(req) == 'table' and req.url or req
      if type(url) == 'string' and url:match('^http://localhost:%d+/avatar/guest%d+$') then return nil, 404 end
      return originalHttpRequest(req, ...)
    end
    http.request = guestAvatarRequest
  end
  -- Every profile gets a private guest token once; it identifies guests on River servers.
  local identity = jsonReadFile(SETTINGS .. 'client.json')
  if not identity or type(identity.guestToken) ~= 'string' or #identity.guestToken ~= 64 then
    identity = identity or {}
    -- Mix several entropy sources; an unseeded generator would give every profile the same token.
    local addr = tonumber((tostring({}):match('0x(%x+)') or '0'), 16) or 0
    math.randomseed((os.time() + math.floor(os.clock() * 1000000) + addr) % 2147483647)
    local chars = {}
    for i = 1, 64 do chars[i] = string.format('%x', math.random(0, 15)) end
    identity.guestToken = table.concat(chars)
    jsonWriteFile(SETTINGS .. 'client.json', identity, true)
  end
  if active() and not client then initialize() end
end
M.debugStatus = function()
  return {initialized = client ~= nil, connected = connected, pending = tableSize(pending), basePath = basePath,
    mode = multi() and 'BeamMP' or 'solo', saveJobs = #saveJobs, multiplayerPending = multiplayerPending,
    transport = NetworkGuard.status(), npcs = riverLife_npcs and riverLife_npcs.debugStatus()}
end

return M
