-- RiverLife multiplayer helper. Original code.
-- RLS Career Overhaul deactivates BeamMP on startup (it targets single player). When the game
-- runs a BeamMP session, BeamMP's GE code is already running; unmounting its zip only removes
-- the vehicle-side scripts and every synced vehicle then floods "positionVE is nil".
-- Keep BeamMP mounted while a multiplayer session is active. Does nothing in single player.
local M = {}
local logTag = 'riverLifeMP'
local BEAMMP = 'multiplayerbeammp'
local clock, nextPoll = 0, 0

local function beammpWanted()
  if not MPCoreNetwork then return false end
  if MPCoreNetwork.isLauncherConnected and MPCoreNetwork.isLauncherConnected() then return true end
  if MPCoreNetwork.isMPSession and MPCoreNetwork.isMPSession() then return true end
  return false
end

local function modTable()
  return core_modmanager and core_modmanager.getMods and core_modmanager.getMods() or {}
end

local function protect()
  local mm = core_modmanager
  if not mm or type(mm.deactivateMod) ~= 'function' or rawget(mm, '__riverLifeMPDeactivate') then return end
  local original = mm.deactivateMod
  rawset(mm, '__riverLifeMPDeactivate', original)
  mm.deactivateMod = function(modname, ...)
    if modname == BEAMMP and beammpWanted() then
      log('I', logTag, 'Kept BeamMP active (multiplayer session)')
      return
    end
    return original(modname, ...)
  end
end

local function unprotect()
  local mm = core_modmanager
  local original = mm and rawget(mm, '__riverLifeMPDeactivate')
  if not original then return end
  mm.deactivateMod = original
  rawset(mm, '__riverLifeMPDeactivate', nil)
end

-- Fallback when BeamMP was unmounted before we could intervene: mount the zip again without
-- reactivating the mod (a reactivation reloads BeamMP's GE code mid-session) and reload the
-- BeamMP vehicle scripts on our own vehicles.
local function repair()
  if not beammpWanted() then return end
  local bm = modTable()[BEAMMP]
  if not bm or not bm.fullpath or FS:isMounted(bm.fullpath) then return end
  FS:mount(bm.fullpath)
  log('W', logTag, 'BeamMP was unmounted; mounted again')
  if MPVehicleGE and MPVehicleGE.getOwnMap then
    for gameVehicleID in pairs(MPVehicleGE.getOwnMap() or {}) do
      local veh = be:getObjectByID(tonumber(gameVehicleID) or -1)
      if veh then veh:queueLuaCommand("extensions.loadModulesInDirectory('lua/vehicle/extensions/BeamMP')") end
    end
  end
end

function M.onUpdate(dtReal)
  clock = clock + (dtReal or 0)
  if clock < nextPoll then return end
  nextPoll = clock + 1
  protect()
  local ok, err = pcall(repair)
  if not ok then log('E', logTag, 'repair: ' .. tostring(err)) end
end

M.onExtensionLoaded = protect
M.onExtensionUnloaded = unprotect
return M
