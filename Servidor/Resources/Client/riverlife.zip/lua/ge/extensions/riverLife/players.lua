-- RiverLife players and places. Original code.
-- Online directory (who is playing, what they drive, where they are), GPS to a
-- player, big map markers for stores/workshops/listings/players, in-world
-- labels, and BeamMP settings that keep other players' cars fully visible.
local M = {}
local players = {}
local clock, lastPresence, lastBind, lastLabels, lastPoi = 0, 0, 0, 0, 0
local lastBindKey
local savedSettings
local poiDirty = false
local state

local VISIBILITY = {simplifyRemoteVehicles = false, skipOtherPlayersVehicles = false,
  trafficSimpleVehicles = false, trafficAllowMods = false, trafficExtraVehicles = false}
-- Career traffic in BeamMP: each player's traffic is synced to everyone, so it
-- stays light, uses full vehicles (BeamMP cannot sync simplified or pooled
-- inactive cars) and has no parked cars (every client would park its own copy
-- on the same spots). Override per profile in /settings/riverlife/client.json.
local MP_TRAFFIC = {traffic = 0, parked = 0}
local trafficPatch

local function core() return riverLife end
local function dist(a, b) if not a or not b then return math.huge end; return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) end
local function serverVid(gameId)
  if not (MPVehicleGE and gameId) then return nil end
  local sid = MPVehicleGE.getServerVehicleID(gameId)
  return type(sid) == 'string' and tonumber(sid:match('%-(%d+)$')) or nil
end

function M.getPlayers() return players end

local function trafficLimits()
  local cfg = jsonReadFile('/settings/riverlife/client.json') or {}
  return math.max(0, tonumber(cfg.mpTraffic) or MP_TRAFFIC.traffic), math.max(0, tonumber(cfg.mpParked) or MP_TRAFFIC.parked)
end

local function patchTraffic(on)
  if on and not trafficPatch and gameplay_traffic and gameplay_traffic.setupTrafficHelper then
    local traffic, parked = trafficLimits()
    trafficPatch = {helper = gameplay_traffic.setupTrafficHelper, setup = gameplay_traffic.setupTraffic,
      active = gameplay_traffic.setActiveAmount, parking = gameplay_parking and gameplay_parking.setActiveAmount}
    gameplay_traffic.setupTraffic = function(amount, options, ...)
      if traffic <= 0 then return false end
      options = type(options) == 'table' and deepcopy(options) or {}
      options.simpleVehs = false
      local n = math.min(amount and amount >= 0 and amount or traffic, traffic)
      options.activeAmount = n
      return trafficPatch.setup(n, options, ...)
    end
    gameplay_traffic.setupTrafficHelper = function(amount, options, parkingAmount, ...)
      options = type(options) == 'table' and deepcopy(options) or {}
      options.simpleVehs = false
      options.activeAmount = math.min(tonumber(amount) or 0, traffic)
      return trafficPatch.helper(math.min(tonumber(amount) or 0, traffic), options, math.min(tonumber(parkingAmount) or 0, parked), ...)
    end
    gameplay_traffic.setActiveAmount = function(amount, ...)
      return trafficPatch.active(math.min(tonumber(amount) or 0, traffic), ...)
    end
    if trafficPatch.parking then
      gameplay_parking.setActiveAmount = function(amount, ...) return trafficPatch.parking(math.min(tonumber(amount) or 0, parked), ...) end
    end
    -- Anything already spawned before the patch (e.g. during the join) goes away.
    if traffic <= 0 then pcall(gameplay_traffic.deleteVehicles) end
    if parked <= 0 and gameplay_parking and gameplay_parking.deleteVehicles then pcall(gameplay_parking.deleteVehicles) end
  elseif not on and trafficPatch then
    if gameplay_traffic then
      gameplay_traffic.setupTrafficHelper = trafficPatch.helper; gameplay_traffic.setupTraffic = trafficPatch.setup
      gameplay_traffic.setActiveAmount = trafficPatch.active
    end
    if gameplay_parking and trafficPatch.parking then gameplay_parking.setActiveAmount = trafficPatch.parking end
    trafficPatch = nil
  end
end

-- BeamMP keeps querying every own vehicle; a dormant (inactive) one floods the
-- log with sync errors. Dormant traffic is removed while in a session.
local function sweepDormant()
  if not (MPVehicleGE and gameplay_traffic and gameplay_traffic.getTrafficData) then return end
  local data = gameplay_traffic.getTrafficData() or {}
  for id in pairs(data) do
    local veh = getObjectByID(id)
    if veh and veh.getActive and not veh:getActive() and MPVehicleGE.isOwn(id) and veh.JBeam ~= 'unicycle' then
      pcall(gameplay_traffic.removeTraffic, id)
      veh:delete()
    end
  end
end
M.sweepDormant = sweepDormant

-- Remote cars as real vehicles, not grey placeholder orbs.
function M.applyMultiplayerVisibility(on)
  patchTraffic(on)
  if on then
    if not savedSettings then
      savedSettings = {}
      for k in pairs(VISIBILITY) do savedSettings[k] = settings.getValue(k) end
    end
    for k, v in pairs(VISIBILITY) do settings.setValue(k, v) end
  elseif savedSettings then
    for k, v in pairs(savedSettings) do if v ~= nil then settings.setValue(k, v) end end
    savedSettings = nil
  end
end

function M.onVehicleSpawned(gameId)
  if not (MPVehicleGE and MPCoreNetwork and MPCoreNetwork.isMPSession()) then return end
  local veh = getObjectByID(gameId)
  if veh and not MPVehicleGE.isOwn(gameId) then veh:setField('renderDistance', '', 1610) end
end

-- Rebuilding the map POIs is costly (and runs RLS' delivery code), so it only happens when what the
-- markers show changes; other players' positions refresh every 5 s with the big map open, else every 60 s.
local lastPoiSig, playersMoved, lastPlayerPoi, lastPlayerCount = nil, false, -100, -1
local function poiSignature(s)
  local parts = {}
  for _, st in ipairs(s.stores or {}) do
    parts[#parts + 1] = tostring(st.id) .. ':' .. tostring(st.open) .. ':' .. tostring(st.stock) .. ':' .. tostring(st.opensAt) .. '-' .. tostring(st.closesAt)
  end
  for _, w in ipairs(s.workshops or {}) do
    parts[#parts + 1] = tostring(w.id) .. ':' .. tostring(w.open) .. ':' .. tostring(w.bays) .. ':' .. tostring(w.reputation)
  end
  for _, l in ipairs(s.listings or {}) do
    if l.status == 'active' then parts[#parts + 1] = tostring(l.id) .. ':' .. tostring(l.price) .. ':' .. tostring(l.inspection and l.inspection.verdict) end
  end
  for _, g in ipairs(s.gigs or {}) do
    if g.status == 'taken' then parts[#parts + 1] = tostring(g.id) .. ':' .. tostring(g.taker) end
  end
  return table.concat(parts, '|')
end
function M.onPresence(list)
  players = list or {}
  playersMoved = true
  if #players ~= lastPlayerCount then lastPlayerCount = #players; poiDirty = true end
  if core() then core().refreshGui() end
end
function M.onState(s)
  state = s
  local sig = poiSignature(s or {})
  if sig ~= lastPoiSig then lastPoiSig = sig; poiDirty = true end
end

function M.gpsTo(pid)
  for _, p in ipairs(players) do
    if p.pid == pid and p.position then
      core_groundMarkers.setPath({vec3(p.position.x, p.position.y, p.position.z)}, {clearPathOnReachingTarget = true})
      core().message('GPS marcado até ' .. (p.name or 'jogador') .. '.')
      return
    end
  end
  core().message('Posição do jogador indisponível no momento.', 'warning')
end
function M.focus(p)
  if p and p.position then
    core_groundMarkers.setPath({vec3(p.position.x, p.position.y, p.position.z)}, {clearPathOnReachingTarget = true})
  end
end

-- Presence and bindings (BeamMP only) ---------------------------------------------------
local function reportPresence()
  local veh = getPlayerVehicle(0)
  local data = {hour = core().hourOfDay()}
  if veh then
    data.vehicleId = serverVid(veh:getID())
    data.model = veh.JBeam
    local vd = core_vehicle_manager and core_vehicle_manager.getPlayerVehicleData and core_vehicle_manager.getPlayerVehicleData()
    local info = vd and vd.vdata and vd.vdata.information
    data.niceName = info and type(info.name) == 'string' and info.name or veh.JBeam
    data.walking = veh.JBeam == 'unicycle'
    data.speed = math.floor(veh:getVelocity():length() * 3.6)
    local d = veh:getDirectionVector()
    data.heading = math.floor(math.deg(math.atan2(d.x, d.y)))
  end
  local s = core().getState()
  if s and s.me then
    for _, o in ipairs(s.orders or {}) do
      if o.shopOwner == s.me.id and o.status == 'in_progress' then data.activity = 'Trabalhando na oficina' end
    end
  end
  TriggerServerEvent('RLPresence', jsonEncode(data))
end

local function bindVehicles()
  local c = core()
  local s = c.getState()
  if not s or not s.me then return end
  local payload = {vehicles = {}, npcs = {}}
  local player = getPlayerVehicle(0)
  payload.playerVehicleId = player and serverVid(player:getID())
  for invId in pairs(career_modules_inventory.getVehicles()) do
    local sid = serverVid(career_modules_inventory.getVehicleIdFromInventoryId(invId))
    if sid then payload.vehicles[tostring(invId)] = sid end
  end
  for npcId, vehId in pairs(riverLife_npcs.getObjects()) do
    local sid = serverVid(vehId)
    if sid then payload.npcs[npcId] = sid end
  end
  payload.gigs = {}
  for gigId, vehId in pairs(riverLife_gigs and riverLife_gigs.getCars() or {}) do
    local sid = serverVid(vehId)
    if sid then payload.gigs[gigId] = sid end
  end
  local key = jsonEncode(payload)
  -- Rebind when something changed, and refresh every 15 s in case the server restarted.
  if key == lastBindKey and clock - lastBind < 15 then return end
  lastBindKey = key; lastBind = clock
  c.rpc('bind', payload)
end

-- Big map markers --------------------------------------------------------------------------
local function marker(elements, id, pos, icon, nameText, desc)
  table.insert(elements, {id = id, data = {type = 'riverLife', id = id},
    markerInfo = {bigmapMarker = {pos = vec3(pos.x, pos.y, pos.z), icon = icon, name = nameText, description = desc,
      cluster = false}}})
end
local Text = require('common/riverLife/text') -- map and label texts in the game language (public edition)
local tr, money, join = Text.tr, Text.money, Text.join

function M.onGetRawPoiListForLevel(levelIdentifier, elements)
  local c = core()
  if not c or not c.active() or not state or not state.me then return end
  for _, st in ipairs(state.stores or {}) do
    if st.position then
      marker(elements, 'rlStore' .. st.id, st.position, 'carDealer', st.name,
        join(tr('Loja de carros de ' .. (st.ownerName or '?')), tr((st.stock or 0) .. ' carro(s) à venda'),
          tr((st.open and 'Aberta' or 'Fechada') .. ' ' .. st.opensAt .. 'h–' .. st.closesAt .. 'h')))
    end
  end
  for _, w in ipairs(state.workshops or {}) do
    if w.position then
      marker(elements, 'rlShop' .. w.id, w.position, 'wrench', w.name,
        join(tr('Oficina de ' .. (w.ownerName or '?')), tr((w.bays or 0) .. ' elevador(es)'),
          tr('reputação ' .. (w.reputation or 0) .. '/100'), tr(w.open and 'Aberta' or 'Fechada')))
    end
  end
  for _, l in ipairs(state.listings or {}) do
    if l.status == 'active' and l.position and not l.storeId and l.seller ~= state.me.id and not l.npcSeller then
      marker(elements, 'rlAd' .. l.id, l.position, 'carStarred', tr(l.title), join(tr('Classificado'), money(l.price), l.sellerName))
    end
  end
  for _, l in ipairs(state.listings or {}) do
    if l.status == 'active' and l.npcSeller and l.position then
      marker(elements, 'rlNpcAd' .. l.id, l.position, 'carStarred', tr(l.title),
        join(tr('Particular'), money(l.price), l.inspection and tr(l.inspection.verdict)))
    end
  end
  for _, g in ipairs(state.gigs or {}) do
    if g.status == 'taken' and g.taker == state.me.id then
      marker(elements, 'rlGig' .. g.id, g.to, 'flag', tr(g.title), tr('Destino do seu bico'))
    end
  end
  for _, p in ipairs(players) do
    if p.position and p.account ~= state.me.id then
      marker(elements, 'rlPlayer' .. tostring(p.pid), p.position, 'peopleOutline', p.name or tr('Jogador'),
        join(tr(p.walking and 'A pé' or ('Dirigindo ' .. (p.niceName or p.model or 'um carro'))), p.activity and tr(p.activity)))
    end
  end
end

local function refreshPois()
  poiDirty = false
  if gameplay_rawPois and gameplay_rawPois.clear then gameplay_rawPois.clear() end
  if freeroam_bigMapPoiProvider and freeroam_bigMapPoiProvider.invalidateCache then pcall(freeroam_bigMapPoiProvider.invalidateCache) end
end

-- In-world labels above businesses and advertised cars -------------------------------------
local labelColor, labelBack = ColorF(1, 1, 1, 1), ColorI(14, 40, 80, 200)
local function label(pos, text, height)
  debugDrawer:drawTextAdvanced(vec3(pos.x, pos.y, pos.z + (height or 4)), String(text), labelColor, true, false, labelBack)
end
local function drawLabels()
  local c = core()
  local player = c.playerPos()
  if not player or not state or not state.me then return end
  for _, st in ipairs(state.stores or {}) do
    if st.position and dist(player, st.position) < 140 then
      label(st.position, tr('[Loja] ' .. st.name) .. (st.open and '' or (' ' .. tr('(fechada)'))), 5)
    end
  end
  for _, w in ipairs(state.workshops or {}) do
    if w.position and dist(player, w.position) < 140 then
      label(w.position, tr('[Oficina] ' .. w.name) .. (w.open and '' or (' ' .. tr('(fechada)'))), 5)
    end
  end
  for _, l in ipairs(state.listings or {}) do
    if l.status == 'active' and l.position and not l.display and dist(player, l.position) < 60 then
      label(l.position, join(tr(l.title), money(l.price)), 2.4)
    end
  end
end

function M.onUpdate(dtReal)
  clock = clock + (dtReal or 0)
  local c = core()
  if not c or not c.active() then return end
  local mp = c.multi()
  if mp and c.isConnected() and clock - lastPresence > 2 then lastPresence = clock; pcall(reportPresence) end
  if mp and c.isConnected() and clock - lastLabels > 3 then lastLabels = clock; pcall(bindVehicles) end
  if playersMoved then
    local bigMap = freeroam_bigMapMode and freeroam_bigMapMode.bigMapActive and freeroam_bigMapMode.bigMapActive()
    if clock - lastPlayerPoi > (bigMap and 5 or 60) then lastPlayerPoi = clock; playersMoved = false; poiDirty = true end
  end
  if poiDirty and clock - lastPoi > 3 then lastPoi = clock; refreshPois() end
  if mp and trafficPatch and clock - (M.lastSweep or 0) > 2 then M.lastSweep = clock; pcall(sweepDormant) end
  local shooting = riverLife and (riverLife.anyShooting or riverLife.isShooting) and (riverLife.anyShooting or riverLife.isShooting)()
  local ok, err = true, nil
  if not shooting then ok, err = pcall(drawLabels) end
  if not ok then log('E', 'riverLife.players', tostring(err)) end
end

function M.onBeamMPServerLeave() players = {}; lastBindKey = nil end

return M
