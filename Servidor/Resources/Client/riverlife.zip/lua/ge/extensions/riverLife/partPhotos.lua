-- RiverPeças catalog photos. Original code.
-- A part mounted on the car (installed, or tried on through the shop cart) is shown alone: the car is
-- hidden except that part's meshes, photographed from above the side the part sits on, and put back
-- exactly as it was. Parts that are not mounted have no meshes on the car yet, so they get their photo
-- once tried on. Photos are cached per model and part name, so the catalog fills up as people shop.
local M = {}
-- OFF: in QA (2026-10-08) taking a series of render-view shots ended in a D3D12 "device hung" crash
-- every time (8 runs: with or without the rest of the car hidden, extra lights, the UI shown or hidden,
-- reused or fresh views). Until a safe way exists, the store only shows photos already cached.
M.enabled = false
M.isolate = true

local jbeamIO = require('jbeam/io')

local DIR = '/settings/riverlife/parts/'
local FOV = 34
local queue, shooting, sequence = {}, false, 0
local markersHidden = false

local function safe(s) return (tostring(s or ''):gsub('[^%w%-_]', '_')) end
local function fileOf(model, part) return DIR .. safe(model) .. '/' .. safe(part) .. '.png' end

local function vehicleOf(inventoryId)
  local vid = career_modules_inventory and career_modules_inventory.getVehicleIdFromInventoryId(tonumber(inventoryId) or -1)
  local veh = vid and getObjectByID(vid)
  local data = veh and core_vehicle_manager and core_vehicle_manager.getVehicleData(vid)
  if not (veh and data and data.vdata) then return nil end
  return veh, data
end

local function partOf(data, name)
  if not data.ioCtx or not name then return nil end
  local ok, part = pcall(jbeamIO.getPart, data.ioCtx, name)
  return ok and part or nil
end

-- Meshes a part draws (flexbodies and props; header rows hold the column names).
local function meshesOf(part)
  local list = {}
  for _, f in pairs(part and part.flexbodies or {}) do
    local m = type(f) == 'table' and (f.mesh or f[1])
    if type(m) == 'string' and m ~= '' and m ~= 'mesh' then list[m] = true end
  end
  for _, p in pairs(part and part.props or {}) do
    local m = type(p) == 'table' and (p.mesh or p[2])
    if type(m) == 'string' and m ~= '' and m ~= 'mesh' and m ~= 'SPOTLIGHT' and m ~= 'POINTLIGHT' then list[m] = true end
  end
  return list
end

-- Which part sits in a slot path ("/body/bumper_F/") right now.
local function chosenAt(tree, path)
  local node = tree
  for seg in tostring(path or ''):gmatch('[^/]+') do
    if not (node and node.children) then return nil end
    local nextNode = node.children[seg]
    if not nextNode then
      for _, c in pairs(node.children) do if c.id == seg then nextNode = c break end end
    end
    node = nextNode
  end
  return node and node ~= tree and node.chosenPartName or nil
end

-- Points around the part, in world space: the nodes that carry its meshes (flexbody groups, prop
-- anchors), else its own nodes, else the part installed in that slot, else the whole car.
local function pointsFor(veh, data, partName, meshes, slotPath)
  local pts, seen = {}, {}
  local pos = veh:getPosition()
  local function add(cid)
    if type(cid) == 'number' and not seen[cid] then seen[cid] = true; pts[#pts + 1] = pos + veh:getNodePosition(cid) end
  end
  for _, f in pairs(data.vdata.flexbodies or {}) do
    if (f.mesh and meshes[f.mesh]) or f.partOrigin == partName then for _, cid in pairs(f._group_nodes or {}) do add(cid) end end
  end
  for _, p in pairs(data.vdata.props or {}) do
    if (p.mesh and meshes[p.mesh]) or p.partOrigin == partName then add(p.idRef); add(p.idX); add(p.idY) end
  end
  if #pts < 2 then
    for _, n in pairs(data.vdata.nodes or {}) do if type(n) == 'table' and n.partOrigin == partName then add(n.cid) end end
  end
  if #pts < 2 then
    local installed = chosenAt(data.config and data.config.partsTree, slotPath)
    for _, n in pairs(data.vdata.nodes or {}) do if installed and type(n) == 'table' and n.partOrigin == installed then add(n.cid) end end
  end
  if #pts < 2 then
    local box = veh:getSpawnWorldOOBB()
    local c, h = box:getCenter(), box:getHalfExtents()
    pts = {c - h, c + h}
  end
  return pts
end

-- Box of the points without the odd far node (5th to 95th percentile on each axis).
local function bounds(pts)
  local xs, ys, zs = {}, {}, {}
  for i, p in ipairs(pts) do xs[i], ys[i], zs[i] = p.x, p.y, p.z end
  table.sort(xs); table.sort(ys); table.sort(zs)
  local n = #pts
  local lo, hi = math.max(1, math.floor(n * 0.05 + 0.5)), math.min(n, math.ceil(n * 0.95))
  if n < 8 then lo, hi = 1, n end
  return vec3(xs[lo], ys[lo], zs[lo]), vec3(xs[hi], ys[hi], zs[hi])
end

local ELEV = math.rad(42)
local MAX_DIST = 3.6
local function frame(veh, pts)
  local lo, hi = bounds(pts)
  local center = (lo + hi) * 0.5
  local radius = math.max(0.2, math.min(3.5, (hi - lo):length() * 0.5))
  local fwd, up = veh:getDirectionVector():normalized(), veh:getDirectionVectorUp():normalized()
  local right = fwd:cross(up):normalized()
  local rel = center - veh:getSpawnWorldOOBB():getCenter()
  local along, side = rel:dot(fwd), rel:dot(right)
  -- From above, on the end and side of the car where the part is: with the rest of the car hidden the
  -- garage floor is a clean backdrop, and walls and pillars stay out of the way.
  local flat = right * (side < -0.15 and -1 or 1)
  if along > 0.5 then flat = flat + fwd * 1.1 elseif along < -0.5 then flat = flat - fwd * 1.1 end
  local dir = (flat:normalized() * math.cos(ELEV) + up * math.sin(ELEV)):normalized()
  -- Stay under the ceiling and inside the walls: big parts get a wider lens instead of more distance.
  local ceiling = castRayStatic(center, up, 12)
  local maxDist = math.min(MAX_DIST, math.max(0.9, ((ceiling or 12) - 0.35) / math.sin(ELEV)))
  local wall = castRayStatic(center, dir, maxDist)
  if wall and wall < maxDist and wall > 0.7 then maxDist = wall - 0.15 end
  local fov = FOV
  local dist = radius / math.tan(math.rad(fov) * 0.5) * 0.95 + 0.2
  if dist > maxDist then
    dist = maxDist
    fov = math.min(80, 2 * math.deg(math.atan(radius * 0.95 / math.max(0.3, dist - 0.2))))
  end
  return center, center + dir * dist, fov
end

-- What the car shows normally: the meshes of its installed parts.
local function restore(veh, data)
  veh:setMeshAlpha(0, '', false)
  for _, f in pairs(data.vdata.flexbodies or {}) do
    if f.mesh and f.mesh ~= '' and f.meshLoaded ~= false then veh:setMeshAlpha(1, f.mesh, false) end
  end
  for _, p in pairs(data.vdata.props or {}) do
    if p.mesh and p.mesh ~= '' and p.mesh ~= 'SPOTLIGHT' and p.mesh ~= 'POINTLIGHT' then veh:setMeshAlpha(1, p.mesh, false) end
  end
end

-- Photo sessions: the game UI stays hidden while the shots are taken (as the game's screenshot helper
-- does per shot, without the flicker), the car is put back after each shot, and the UI always comes back.
local W, H = 512, 384
local SESSION_MAX = 40 -- seconds
local lastSpawn, session = -math.huge, nil

local function sessionStart()
  if session then return end
  session = {started = os.clock()}
  pcall(ui_visibility.set, false)
  pcall(function() gameplay_markerInteraction.setMarkersVisibleTemporary(false) end)
  markersHidden = photoModeOpen ~= true
  if markersHidden then photoModeOpen = true end
end
local function sessionEnd()
  if not session then return end
  session = nil
  pcall(function() gameplay_markerInteraction.setMarkersVisibleTemporary(true) end)
  pcall(ui_visibility.set, true)
  if markersHidden then photoModeOpen = false; markersHidden = false end
end

-- Same steps as the game's own screenshot helper (render_renderViews), which is the only way that never
-- hung the GPU in tests: a fresh view per shot, saved, re-encoded through GBitmap and destroyed right away.
local function capture(file, center, cp, fov, done)
  local name = 'RiverPecas_' .. sequence
  local view = RenderViewManagerInstance:getOrCreateView(name)
  view.luaOwned = true
  local rot = quatFromDir(center - cp)
  local mat = QuatF(rot.x, rot.y, rot.z, rot.w):getMatrix()
  mat:setPosition(cp)
  view.renderCubemap = false
  view.cameraMatrix = mat
  view.resolution = Point2I(W, H)
  view.viewPort = RectI(0, 0, W, H)
  view.namedTexTargetColor = name
  view.useManualEV = false
  view.manualEV = 0
  view.frustum = Frustum.construct(false, math.rad(fov), W / H, 0.1, 2000)
  view.fov = fov
  view.renderEditorIcons = false
  core_jobsystem.create(function(job)
    job.sleep(0.3)
    local temp, ok = file .. '.tmp.png', false
    if view:saveToDisk(temp) then
      local bmp = GBitmap()
      if bmp:loadFile(temp) then
        bmp:setFormat(10)
        local small = bmp:createDownscaledBitmap(1)
        ok = small and small:saveFile(file) or false
      end
    end
    FS:removeFile(temp)
    RenderViewManagerInstance:destroyView(view)
    done(ok and true or false)
  end)
end

-- What we can tell without shooting: a cached photo, nothing to see, not mounted, or "can be shot".
local function lookup(job)
  local file = fileOf(job.model, job.name)
  if FS:fileExists(file) then return 'cached', file end
  local veh, data = vehicleOf(job.inventoryId)
  if not veh then return 'none' end
  local part = partOf(data, job.name)
  local meshes = meshesOf(part)
  if not next(meshes) then return 'none' end -- tunes, ECUs... nothing to see
  -- Only the meshes of mounted parts exist on the car: the others get their photo once tried on.
  local mounted = {}
  for m in pairs(meshes) do if (veh:getMeshAlpha(m) or -1) >= 0 then mounted[m] = true end end
  if not next(mounted) then return 'try' end
  return 'shoot', file, veh, data, mounted
end
local function report(job, status, file)
  guihooks.trigger('RiverLifePartPhoto', {name = job.name, model = job.model, url = status == 'cached' and file or nil,
    notMounted = status == 'try' or nil, missing = status == 'shoot' or nil})
end

local function nextJob()
  if shooting then return end
  if #queue == 0 then sessionEnd(); return end
  if os.clock() - lastSpawn < 3 then return end -- the shop rebuilds the car on every change: let it settle
  if riverLife and riverLife.isShooting and riverLife.isShooting() then return end -- a listing photo goes first
  local job = table.remove(queue, 1)
  local status, file, veh, data, meshes = lookup(job)
  if status ~= 'shoot' or not job.shoot then report(job, status, file); return nextJob() end
  local center, cp, fov = frame(veh, pointsFor(veh, data, job.name, meshes, job.slot))
  sessionStart()
  shooting = true
  sequence = sequence + 1
  if M.isolate then
    veh:setMeshAlpha(0, '', false)
    for m in pairs(meshes) do veh:setMeshAlpha(1, m, false) end
  end
  FS:directoryCreate(DIR .. safe(job.model) .. '/')
  local ok = pcall(capture, file, center, cp, fov, function(success)
    local v, d = vehicleOf(job.inventoryId)
    if v and M.isolate then pcall(restore, v, d) end
    shooting = false
    report(job, success and 'cached' or 'none', file)
  end)
  if not ok then pcall(restore, veh, data); shooting = false; report(job, 'none') end
end

-- p = {inventoryId, model, parts = {{name, slot}}, shoot, reset}. Without shoot it only reports what is
-- known (cached photo, nothing to see, not mounted, can be shot); with shoot it runs a photo session.
-- Answers come one by one as RiverLifePartPhoto.
function M.request(p)
  if type(p) ~= 'table' or type(p.parts) ~= 'table' then return end
  if not M.enabled then
    local veh = vehicleOf(p.inventoryId)
    local model = p.model or (veh and veh:getJBeamFilename())
    for _, x in ipairs(p.parts) do
      if type(x) == 'table' and type(x.name) == 'string' and model then
        local file = fileOf(model, x.name)
        report({name = x.name, model = model}, FS:fileExists(file) and 'cached' or 'none', file)
      end
    end
    return
  end
  local veh = vehicleOf(p.inventoryId)
  local model = p.model or (veh and veh:getJBeamFilename())
  if not model then return end
  if p.reset then
    for i = #queue, 1, -1 do if not queue[i].shoot then table.remove(queue, i) end end
  end
  for _, x in ipairs(p.parts) do
    if type(x) == 'table' and type(x.name) == 'string' and x.name ~= '' and #queue < 200 then
      queue[#queue + 1] = {inventoryId = p.inventoryId, model = model, name = x.name, slot = x.slot, shoot = p.shoot == true}
    end
  end
  nextJob()
end
function M.isShooting() return shooting or session ~= nil end
function M.onUpdate()
  if session and os.clock() - session.started > SESSION_MAX then
    log('W', 'riverLife.partPhotos', 'photo session took too long: stopped')
    queue = {}
    shooting = false
    sessionEnd()
    return
  end
  if not shooting then nextJob() end
end
function M.onVehicleSpawned() lastSpawn = os.clock() end
function M.onVehicleResetted() lastSpawn = os.clock() end
function M.onExtensionUnloaded() queue = {}; shooting = false; sessionEnd() end

return M
