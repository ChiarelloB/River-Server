-- RiverLife display cars. Original code.
-- Cars for sale on a store lot or by the road stand where the ad says, parked,
-- locked and with a price sign. One client spawns each car (the server picks a
-- nearby player in BeamMP; BeamMP shows the car to everyone); every client draws
-- the signs and offers a walk-up proposal when the player stands next to a car.
local M = {}
local hosted = {}        -- listingId -> {vehId, revision}
local assigned = nil     -- BeamMP: listingIds this client must host (nil in solo)
local dataCache = {}     -- assetId..revision -> display data
local fetching = {}
local clock, lastSync, lastHint = 0, 0, -100
local nearbyId
local signText, signBack, signFore = ColorF(1, 1, 1, 1), ColorI(18, 110, 60, 220), ColorI(250, 200, 30, 235)

local function core() return riverLife end
local function obj(id) return id and getObjectByID(id) or nil end
local function dist(a, b) if not a or not b then return math.huge end; return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) end
local Text = require('common/riverLife/text') -- sign texts in the game language (public edition)
local tr, money = Text.tr, Text.money
local function km(m) return string.format('%d km', math.floor((m or 0) / 1000)) end

function M.getHosted() return hosted end
function M.nearby() return nearbyId end

local function displayListings(state)
  local out = {}
  for _, l in ipairs((state and state.listings) or {}) do
    if l.status == 'active' and l.display and l.position then out[l.id] = l end
  end
  return out
end

local function park(veh)
  veh:queueLuaCommand('ai.setState({mode="disabled"}) input.event("throttle",0,1) input.event("brake",0,1) ' ..
    'input.event("parkingbrake",1,1) electrics.setIgnitionLevel(0)')
end

local function despawn(lid)
  local h = hosted[lid]
  hosted[lid] = nil
  local veh = h and obj(h.vehId)
  if veh then veh:delete() end
end

local function spawnDisplay(l, data)
  local model = data.model or l.model
  if not model then return end
  local h = l.heading or 0
  local rot = quatFromDir(vec3(math.sin(h), math.cos(h), 0))
  local options = {pos = vec3(l.position.x, l.position.y, l.position.z + 0.4), rot = rot, autoEnterVehicle = false}
  if data.config then options.config = type(data.config) == 'table' and deepcopy(data.config) or data.config end
  local ok, veh = pcall(core_vehicles.spawnNewVehicle, model, options)
  if not ok or not veh then
    log('W', 'riverLife.display', 'could not spawn ' .. tostring(model) .. ' for ' .. l.id)
    hosted[l.id] = {failed = true, pos = l.position}
    return
  end
  local vehId = veh:getID()
  hosted[l.id] = {vehId = vehId, pos = l.position}
  veh:setField('riverLifeDisplay', 0, l.id)
  pcall(function() veh.playerUsable = false end)
  if data.wear or data.mileage then
    local wear = tonumber(data.wear) or 0.9
    core_vehicleBridge.executeAction(veh, 'initPartConditions', {}, data.mileage or 0, wear, wear)
  end
  local missing = 3 - #(l.photos or {})
  core_jobsystem.create(function(job)
    job.sleep(1.2)
    local v = obj(vehId)
    if v then park(v) end
    -- Ads without photos get real ones, taken here once the car has settled.
    if missing > 0 then
      job.sleep(2.5)
      if obj(vehId) and core().captureDisplay then core().captureDisplay(l.id, vehId, missing) end
    end
  end)
end

local function wantHost(l, player)
  if assigned then return assigned[l.id] == true end
  return player and dist(player, l.position) < 350
end

local function sync()
  local c = core()
  local state = c.getState()
  local player = c.playerPos()
  local list = displayListings(state)
  for lid in pairs(hosted) do
    local l = list[lid]
    local moved = l and hosted[lid].pos and dist(hosted[lid].pos, l.position) > 1
    if not l or not wantHost(l, player) or moved then
      despawn(lid)
    elseif hosted[lid].vehId and not obj(hosted[lid].vehId) then
      hosted[lid] = nil
    end
  end
  for lid, l in pairs(list) do
    if not hosted[lid] and wantHost(l, player) then
      if l.config then
        spawnDisplay(l, {model = l.model, config = l.config})
      else
        local key = l.assetId or lid
        if dataCache[key] then
          spawnDisplay(l, dataCache[key])
        elseif not fetching[key] then
          fetching[key] = true
          c.rpc('displayData', {listingId = lid}, function(r)
            fetching[key] = nil
            if r.ok then dataCache[key] = r.data end
          end)
        end
      end
    end
  end
end

-- BeamMP: the server tells each client which cars it hosts.
function M.onAssign(p)
  assigned = {}
  for _, lid in ipairs((p and p.listings) or {}) do assigned[lid] = true end
  lastSync = -10
end

-- In-world price signs and the walk-up prompt.
local function drawSigns(state, player)
  local closest, closestD
  for _, l in ipairs((state and state.listings) or {}) do
    if l.status == 'active' and l.display and l.position then
      local d = dist(player, l.position)
      if d < 55 then
        local base = vec3(l.position.x, l.position.y, l.position.z)
        debugDrawer:drawTextAdvanced(base + vec3(0, 0, 2.6), String('  ' .. money(l.price) .. '  '), signText, true, false, signBack)
        local who = tr(l.storeName and ('Loja ' .. l.storeName) or (l.street and ('Vende-se · ' .. (l.sellerName or '')))
          or (l.npcSeller and ('Particular · ' .. (l.sellerName or '')) or (l.sellerName or '')))
        local fipe
        if l.fipe and l.fipe > 0 then
          local delta = (l.price - l.fipe) / l.fipe
          local pct = math.floor(math.abs(delta) * 100 + 0.5)
          fipe = tr(pct < 3 and 'na FIPE' or (pct .. '% ' .. (delta < 0 and 'abaixo' or 'acima') .. ' da FIPE'))
        end
        local line = Text.join(tr(l.niceName or l.title or 'Carro'), km(l.mileage), fipe,
          l.inspection and tr('Vistoriado: ' .. tostring(l.inspection.verdict)))
        debugDrawer:drawTextAdvanced(base + vec3(0, 0, 2.15), String(line), signText, true, false, ColorI(20, 40, 70, 210))
        if d < 20 then
          local mine = l.seller == (state.me and state.me.id)
          local tail = tr(mine and '· seu anúncio' or (l.reserved and '· em negociação' or '· [U] fazer proposta'))
          debugDrawer:drawTextAdvanced(base + vec3(0, 0, 1.75), String(who .. ' ' .. tail),
            ColorF(0.1, 0.1, 0.1, 1), true, false, signFore)
        end
        if d < 9 and (not closestD or d < closestD) and l.seller ~= (state.me and state.me.id) then closest, closestD = l, d end
      end
    end
  end
  -- The owner sees the free spots of the lot.
  for _, st in ipairs(state.stores or {}) do
    if st.owner == (state.me and state.me.id) and st.lot and dist(player, st.position) < 80 then
      local used = {}
      for _, l in ipairs(state.listings or {}) do if l.storeId == st.id and l.lot and l.status == 'active' then used[l.lotSpot] = true end end
      for i, sp in ipairs(st.lot) do
        if not used[i] and i <= (st.capacity or 4) then
          debugDrawer:drawTextAdvanced(vec3(sp.x, sp.y, sp.z + 0.6), String(' ' .. tr('Vaga ' .. i .. ' livre') .. ' '), signText, true, false, ColorI(40, 90, 200, 200))
          debugDrawer:drawCylinder(vec3(sp.x, sp.y, sp.z + 0.05), vec3(sp.x, sp.y, sp.z + 0.12), 1.2, ColorF(0.2, 0.45, 1, 0.35))
        end
      end
    end
  end
  local before = nearbyId
  nearbyId = closest and closest.id or nil
  if nearbyId ~= before then core().refreshGui() end
  if closest and clock - lastHint > 12 then
    lastHint = clock
    core().message(closest.title .. ' por ' .. money(closest.price) .. '. Pressione U para fazer uma proposta.')
  end
end

function M.onUpdate(dtReal)
  clock = clock + (dtReal or 0)
  local c = core()
  if not c or not c.active() then return end
  local state = c.getState()
  if not state or not state.me then return end
  local player = c.playerPos()
  if player and not ((c.anyShooting or c.isShooting) and (c.anyShooting or c.isShooting)()) then
    local ok, err = pcall(drawSigns, state, player)
    if not ok then log('E', 'riverLife.display', tostring(err)) end
  end
  if clock - lastSync > 2 then
    lastSync = clock
    local ok, err = pcall(sync)
    if not ok then log('E', 'riverLife.display', tostring(err)) end
  end
end

-- Display cars must never become anyone's car by accident.
function M.onVehicleSwitched(oldId, newId)
  for _, h in pairs(hosted) do
    if h.vehId == newId and oldId and obj(oldId) then
      be:enterVehicle(0, obj(oldId))
      core().message('Esse carro está à venda. Fale com o vendedor (U) para negociar.', 'warning')
      return
    end
  end
end

function M.reset()
  for lid in pairs(hosted) do despawn(lid) end
  hosted, dataCache, fetching, nearbyId = {}, {}, {}, nil
end
function M.onBeamMPServerLeave() M.reset(); assigned = nil end
M.onExtensionUnloaded = M.reset
M.onClientEndMission = M.reset
M.debugStatus = function()
  local out = {}
  for lid, h in pairs(hosted) do out[lid] = {vehicleId = h.vehId, failed = h.failed} end
  return {hosted = out, assigned = assigned, nearby = nearbyId}
end

return M
