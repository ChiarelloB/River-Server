-- RiverLife gigs ("bicos") and map spots. Original code.
-- Transfer jobs: the car appears where the client left it, the player drives it
-- to the destination and parks; delivery is checked by the ledger (the server
-- measures the car's position in BeamMP). Inspections: walk up to the car and the
-- report is filed. The module also reports map spots so the server can place NPC
-- sellers and jobs anywhere on the map: roadside points from the road graph, and
-- parking spots clear of the road (driveways, car parks) where NPC sellers park.
local M = {}
local gigCars = {}         -- gigId -> vehicle id
local clock, lastCheck, lastSpots, lastGps = 0, 0, -1000, -100
local stoppedSince
local delivering, inspecting = {}, {}

local function core() return riverLife end
local function obj(id) return id and getObjectByID(id) or nil end
local function dist(a, b) if not a or not b then return math.huge end; return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) end
local function v3(p) return vec3(p.x, p.y, p.z) end

function M.getCars() return gigCars end
function M.vehiclePos(gigId)
  local veh = obj(gigCars[gigId])
  return veh and core().posOf(veh) or nil
end

-- Map spots ---------------------------------------------------------------------------------
-- Roadside points on ordinary roads (no junctions), facing along the lane.
function M.collectSpots(max)
  local m = map.getMap()
  local nodes = m and m.nodes
  if not nodes then return {} end
  local names = {}
  for name, n in pairs(nodes) do
    local links = 0
    for _ in pairs(n.links or {}) do links = links + 1 end
    if links == 2 and (n.radius or 0) >= 3 and (n.radius or 0) <= 9 then names[#names + 1] = name end
  end
  local out = {}
  local tries = 0
  while #out < (max or 30) and tries < 600 and #names > 0 do
    tries = tries + 1
    local name = names[math.random(#names)]
    local n = nodes[name]
    local other
    for linked in pairs(n.links or {}) do other = nodes[linked]; break end
    if other then
      local dir = (other.pos - n.pos)
      dir.z = 0
      if dir:length() > 2 then
        dir = dir:normalized()
        local right = vec3(dir.y, -dir.x, 0)
        local p = n.pos + right * math.max(2.2, (n.radius or 4) - 1.2)
        local far = true
        for _, q in ipairs(out) do if dist(q, p) < 150 then far = false; break end end
        if far then out[#out + 1] = {x = p.x, y = p.y, z = p.z, h = math.atan2(dir.x, dir.y)} end
      end
    end
  end
  return out
end

-- Parking spots for NPC sellers: house driveways and car parks, never the street. Candidates are the
-- level's parking spots (city.sites.json: the ones RLS uses for private sales, minus "street" and
-- "notprivatesale") and its residential delivery spots; a spot counts only if a parked car stands
-- clear of the road. (West Coast: the residential ones are all kerbside, the rest are mostly house
-- driveways.)
local function siteSpots()
  local out = {}
  local level = getCurrentLevelIdentifier and getCurrentLevelIdentifier()
  if not level then return out end
  if not gameplay_sites_sitesManager then pcall(extensions.load, 'gameplay_sites_sitesManager') end
  if not gameplay_sites_sitesManager then return out end
  local files = {'/levels/' .. level .. '/city.sites.json'}
  for _, file in ipairs(FS:findFiles('/levels/' .. level .. '/facilities/', '*.sites.json', -1, false, false) or {}) do
    if file:lower():find('residential', 1, true) then files[#files + 1] = file end
  end
  for _, file in ipairs(files) do
    local ok, site = false, nil
    if FS:fileExists(file) then ok, site = pcall(gameplay_sites_sitesManager.loadSites, file) end
    for _, sp in ipairs(ok and site and site.parkingSpots and site.parkingSpots.sorted or {}) do
      local tags = sp.customFields and sp.customFields.tags or {}
      if not tags.street and not tags.notprivatesale then out[#out + 1] = sp end
    end
  end
  return out
end

local function clearOfRoad(p, nodes)
  local n1, n2, d = map.findClosestRoad(p, 40)
  if not n1 then return true end
  local r = math.max((nodes[n1] or {}).radius or 0, (nodes[n2] or {}).radius or 0)
  return d > r + 1.6 -- half a car plus a margin beyond the road's edge
end

-- Up to max spots 40 m apart, plus how many such spots the map has in total.
function M.collectParkingSpots(max)
  local m = map.getMap()
  local nodes = m and m.nodes
  if not nodes or not next(nodes) then return {}, nil end
  local usable = {}
  for _, sp in ipairs(siteSpots()) do
    if sp.pos and clearOfRoad(sp.pos, nodes) then usable[#usable + 1] = sp end
  end
  for i = #usable, 2, -1 do local j = math.random(i); usable[i], usable[j] = usable[j], usable[i] end
  local spaced = {}
  for _, sp in ipairs(usable) do
    local far = true
    for _, q in ipairs(spaced) do if dist(q.pos, sp.pos) < 40 then far = false; break end end
    if far then spaced[#spaced + 1] = sp end
  end
  local out = {}
  for i = 1, math.min(max or 30, #spaced) do
    local sp = spaced[i]
    local f = vec3(0, 1, 0):rotated(sp.rot or quat(0, 0, 0, 1))
    out[i] = {x = sp.pos.x, y = sp.pos.y, z = sp.pos.z, h = math.atan2(f.x, f.y), k = 'p'}
  end
  return out, #spaced
end

function M.contribute()
  local spots = M.collectSpots(30)
  local parking, available = M.collectParkingSpots(30)
  if available == nil then return end -- the level is not loaded yet
  for _, sp in ipairs(parking) do spots[#spots + 1] = sp end
  core().rpc('contributeSpots', {spots = spots, parking = available})
end
function M.onNeedSpots() M.contribute() end

-- Transfer jobs --------------------------------------------------------------------------
local function myGig(state)
  for _, g in ipairs((state and state.gigs) or {}) do
    if g.taker == state.me.id and g.status == 'taken' then return g end
  end
end

local function spawnGigCar(g)
  local h = g.fromH or 0
  local rot = quatFromDir(vec3(math.sin(h), math.cos(h), 0))
  local ok, veh = pcall(core_vehicles.spawnNewVehicle, g.car.model, {config = g.car.config,
    pos = vec3(g.from.x, g.from.y, g.from.z + 0.5), rot = rot, autoEnterVehicle = false})
  if not ok or not veh then
    core().message('Não foi possível carregar o carro do bico (' .. tostring(g.car.model) .. ').', 'error')
    return
  end
  gigCars[g.id] = veh:getID()
  veh:setField('riverLifeGig', 0, g.id)
  local wear = tonumber(g.car.wear) or 0.85
  core_vehicleBridge.executeAction(veh, 'initPartConditions', {}, math.floor((1 - wear) * 250000000), wear, wear)
  core().message('O ' .. g.car.name .. ' está te esperando. Entre nele e leve até o destino marcado.')
end

local function damageOf(vehId)
  local o = map.objects and map.objects[vehId]
  local d = o and tonumber(o.damage) or 0
  return math.max(0, math.min(50, math.floor(d / 1500)))
end

local function gps(p)
  if core_groundMarkers and p then core_groundMarkers.setPath({v3(p)}, {clearPathOnReachingTarget = true}) end
end

local function removeCar(gigId, delay)
  local vehId = gigCars[gigId]
  gigCars[gigId] = nil
  if not vehId then return end
  core_jobsystem.create(function(job)
    job.sleep(delay or 0)
    local veh = obj(vehId)
    if veh then
      local player = getPlayerVehicle(0)
      if player and player:getID() == vehId and gameplay_walk and gameplay_walk.setWalkingMode then
        pcall(gameplay_walk.setWalkingMode, true)
        job.sleep(0.5)
      end
      veh = obj(vehId)
      if veh then veh:delete() end
    end
  end)
end

local function updateTransfer(g)
  local veh = obj(gigCars[g.id])
  local player = core().playerPos()
  if not veh then
    if player and dist(player, g.from) < 160 then spawnGigCar(g)
    elseif clock - lastGps > 30 then lastGps = clock; gps(g.from) end
    return
  end
  local current = getPlayerVehicle(0)
  local driving = current and current:getID() == veh:getID()
  if driving and clock - lastGps > 30 then lastGps = clock; gps(g.to) end
  local carPos = core().posOf(veh)
  if dist(carPos, g.to) < 15 and veh:getVelocity():length() < 1 then
    stoppedSince = stoppedSince or clock
    if clock - stoppedSince > 2 and not delivering[g.id] then
      delivering[g.id] = true
      core().rpc('gigDeliver', {gigId = g.id, damage = damageOf(veh:getID())}, function(r)
        delivering[g.id] = nil
        if r.ok then
          local paid = r.data and r.data.paid or 0
          core().message(string.format('Entrega feita! Você recebeu $%d%s.', math.floor(paid / 100),
            (r.data and r.data.damage or 0) > 0 and ' (desconto por avarias)' or ''))
          if core_groundMarkers then core_groundMarkers.setPath(nil) end
          removeCar(g.id, 3)
        elseif r.error ~= 'not_at_destination' then
          core().message('Entrega não aceita: ' .. tostring(r.error), 'warning')
        end
      end)
    end
  else
    stoppedSince = nil
  end
end

local function updateInspection(g, state)
  local player = core().playerPos()
  if not player or not g.to then return end
  if dist(player, g.to) > 40 and clock - lastGps > 30 then lastGps = clock; gps(g.to) end
  if dist(player, g.to) < 8 and not inspecting[g.id] then
    inspecting[g.id] = true
    core().message('Fazendo a vistoria...')
    core_jobsystem.create(function(job)
      job.sleep(4)
      core().rpc('inspect', {gigId = g.id}, function(r)
        inspecting[g.id] = nil
        if r.ok then
          core().message('Vistoria concluída: ' .. tostring(r.data.inspection.verdict) .. '. Pagamento recebido.')
          if core_groundMarkers then core_groundMarkers.setPath(nil) end
        else
          core().message('Vistoria: ' .. tostring(r.error), 'warning')
        end
      end)
    end)
  end
end

function M.onUpdate(dtReal)
  clock = clock + (dtReal or 0)
  if clock - lastCheck < 0.5 then return end
  lastCheck = clock
  local c = core()
  if not c or not c.active() then return end
  local state = c.getState()
  if not state or not state.me then return end
  local g = myGig(state)
  for gigId in pairs(gigCars) do
    if not g or g.id ~= gigId then removeCar(gigId, 2) end
  end
  if g and g.kind == 'translado' then
    local ok, err = pcall(updateTransfer, g)
    if not ok then log('E', 'riverLife.gigs', tostring(err)) end
  elseif g and g.kind == 'vistoria' then
    local ok, err = pcall(updateInspection, g, state)
    if not ok then log('E', 'riverLife.gigs', tostring(err)) end
  end
  -- Solo careers report spots themselves (the server asks in BeamMP).
  if not c.multi() and clock - lastSpots > 120 then
    lastSpots = clock
    if (state.spotsNeeded or {})[c.mapName()] ~= false then M.contribute() end
  end
end

function M.gpsTo(p) gps(p) end
function M.reset()
  for gigId in pairs(gigCars) do removeCar(gigId) end
  gigCars, delivering, inspecting = {}, {}, {}
end
M.onExtensionUnloaded = M.reset
M.onClientEndMission = M.reset
M.debugStatus = function() return {cars = gigCars} end

return M
