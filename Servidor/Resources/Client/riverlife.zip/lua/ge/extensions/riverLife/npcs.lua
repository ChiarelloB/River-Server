-- RiverLife NPC visitors. Original code.
-- Buyers, trade-in sellers and workshop customers arrive by road: they spawn on
-- the navigation graph a few hundred meters away, drive in lane to the business
-- and park. Details (budget, car, problem) are generated here within the bounds
-- the ledger enforces; in BeamMP the server decides when a visit happens.
local M = {}
local npcObjects = {}       -- npcId -> vehicle object id
local drivers = {}          -- npcId -> drive state
local leaving = {}          -- vehicle id -> {until}
local claimed = {}          -- npcId -> true when the car became a player's vehicle
local catalogCache
local clock, lastSolo, lastCheck = 0, {}, 0
local pendingSlots = {}

local FIRST_NAMES = {'Marcos', 'Camila', 'João', 'Patrícia', 'Rafael', 'Luiza', 'Thiago', 'Fernanda', 'Bruno',
  'Juliana', 'Diego', 'Aline', 'Gustavo', 'Larissa', 'Felipe', 'Bianca', 'Rodrigo', 'Carla', 'Eduardo', 'Natália',
  'Vinícius', 'Renata', 'Lucas', 'Mariana', 'André', 'Paula', 'Caio', 'Débora', 'Otávio', 'Simone'}
local LAST_NAMES = {'Silva', 'Souza', 'Oliveira', 'Pereira', 'Costa', 'Rodrigues', 'Almeida', 'Nascimento', 'Lima',
  'Araújo', 'Fernandes', 'Carvalho', 'Gomes', 'Martins', 'Rocha', 'Ribeiro', 'Barbosa', 'Moreira'}
local PERSONALITIES = {'Entusiasta', 'Família', 'Colecionador', 'Revendedor', 'Apressado', 'Pechincheiro'}
-- Reliable vanilla cars for NPCs' own transport and workshop jobs.
local COMMUTER_MODELS = {'covet', 'pessima', 'midsize', 'vivace', 'etk800', 'legran', 'sunburst2', 'bastion',
  'bluebuck', 'fullsize', 'van', 'pickup', 'roamer', 'wendover', 'lansdale', 'moonhawk', 'barstow', 'etki', 'nine'}
local JOBS = {
  {key = 'revisao', label = 'Revisão completa', share = {0.015, 0.03}, minutes = 3},
  {key = 'freios', label = 'Freios e suspensão', share = {0.03, 0.06}, minutes = 5},
  {key = 'batidaLeve', label = 'Batida leve (lataria e para-choque)', share = {0.05, 0.12}, minutes = 6},
  {key = 'pintura', label = 'Pintura completa', share = {0.04, 0.08}, minutes = 8},
  {key = 'motor', label = 'Motor falhando', share = {0.08, 0.16}, minutes = 9},
  {key = 'batidaForte', label = 'Batida forte (frente destruída)', share = {0.15, 0.3}, minutes = 12},
}

local function core() return riverLife end
local function pick(list) return list[math.random(#list)] end
local function name() return pick(FIRST_NAMES) .. ' ' .. pick(LAST_NAMES) end
local function obj(id) return id and getObjectByID(id) or nil end
local function v3(p) return vec3(p.x, p.y, p.z) end
local function dist(a, b) if not a or not b then return math.huge end; return math.sqrt((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) end

function M.npcPosition(npcId)
  local o = obj(npcObjects[npcId])
  return o and core().posOf(o) or nil
end
function M.getObjects() return npcObjects end

-- Vehicle catalog ---------------------------------------------------------------------
local function catalog()
  if catalogCache then return catalogCache end
  catalogCache = {all = {}, commuters = {}}
  local ok, list = pcall(core_vehicles.getConfigList, true)
  if not ok or type(list) ~= 'table' then return catalogCache end
  local commuterSet = {}
  for _, m in ipairs(COMMUTER_MODELS) do commuterSet[m] = true end
  -- Only drivable street cars: no bare chassis, shells, derby or race builds.
  local banned = {'chassis', 'rolling', 'shell', 'bare', 'derby', 'crawler', 'drag', 'race', 'rally', 'trophy', 'drift',
    'police', 'polícia', 'ambulance', 'fire', 'taxi', 'stunt', 'track', 'gymkhana', 'prerunner', 'baja'}
  local function drivable(c)
    local label = string.lower(tostring(c.Name or '') .. ' ' .. tostring(c.key or '') .. ' ' .. tostring(c.Configuration or ''))
    for _, word in ipairs(banned) do if label:find(word, 1, true) then return false end end
    local ct = c.aggregates and c.aggregates['Config Type']
    if type(ct) == 'table' and next(ct) and not (ct.Factory or ct.Custom) then return false end
    return true
  end
  for _, c in ipairs(list.configs or {}) do
    local value = tonumber(c.Value)
    local kind = c.aggregates and c.aggregates.Type
    local isCar = (type(kind) == 'table' and (kind.Car or kind.Truck)) or c.Type == 'Car' or c.Type == 'Truck'
    local source = c.Source or (c.aggregates and c.aggregates.Source and next(c.aggregates.Source))
    local official = source == 'BeamNG - Official'
    -- Modded cars only with their default config (the one validated for the pack).
    local trusted = official or (source == 'Mod' and c.is_default_config == true)
    if isCar and trusted and value and value >= 1500 and value <= 2000000 and c.model_key and c.key
      and not c.isAuxiliary and drivable(c) then
      local entry = {model = c.model_key, config = c.pcFilename or ('vehicles/' .. c.model_key .. '/' .. c.key .. '.pc'),
        key = c.key, niceName = ((c.Brand and c.Brand ~= '') and (c.Brand .. ' ') or '') .. (c.Configuration or c.Name or c.key),
        value = value, official = official,
        year = type(c.Years) == 'table' and c.Years.min or (c.aggregates and c.aggregates.Years and c.aggregates.Years.min)}
      table.insert(catalogCache.all, entry)
      if official and commuterSet[c.model_key] then table.insert(catalogCache.commuters, entry) end
    end
  end
  return catalogCache
end
local function commuter()
  local c = catalog()
  if #c.commuters > 0 then return pick(c.commuters) end
  return {model = 'pessima', config = 'vehicles/pessima/LX_A.pc', niceName = 'Ibishu Pessima', value = 9000}
end

-- Road graph helpers -----------------------------------------------------------------
local function closestNode(p)
  local n1, n2 = map.findClosestRoad(v3(p))
  if not n1 then return nil end
  local nodes = map.getMap().nodes
  local a, b = nodes[n1], nodes[n2]
  if not a then return n2, b and b.pos end
  if not b then return n1, a.pos end
  if a.pos:distance(v3(p)) <= b.pos:distance(v3(p)) then return n1, a.pos end
  return n2, b.pos
end

local function pickSpawn(dest, destNode)
  local nodes = map.getMap().nodes
  local player = core().playerPos()
  local candidates = {}
  for nodeName, n in pairs(nodes) do
    local d = n.pos:distance(v3(dest))
    if d > 220 and d < 750 and (not player or n.pos:distance(v3(player)) > 120) and (n.radius or 0) >= 2.5 then
      candidates[#candidates + 1] = nodeName
      if #candidates > 400 then break end
    end
  end
  for _ = 1, 25 do
    if #candidates == 0 then break end
    local i = math.random(#candidates)
    local start = candidates[i]
    table.remove(candidates, i)
    local path = map.getPath(start, destNode)
    if path and #path >= 3 and #path < 400 then
      local p1, p2 = nodes[path[1]].pos, nodes[path[2]].pos
      local dir = (p2 - p1):normalized()
      local right = vec3(dir.y, -dir.x, 0)
      local lane = math.max(1.5, math.min(3.5, (nodes[start].radius or 4) * 0.5))
      return p1 + right * lane + vec3(0, 0, 0.6), quatFromDir(vec3(dir.x, dir.y, 0)), start
    end
  end
end

-- Parking spots around a business: one spot per NPC, spread along the frontage.
local function parkingSpot(base, index)
  local i = (index or 0) % 6
  local angle = (i * 52 + 25) * math.pi / 180
  local r = 7 + math.floor(i / 3) * 4
  return {x = base.x + math.cos(angle) * r, y = base.y + math.sin(angle) * r, z = base.z}
end

-- Drive state machine ------------------------------------------------------------------
local function driveTo(id, vehId, dest)
  local destNode, nodePos = closestNode(dest)
  local veh = obj(vehId)
  if not veh then return end
  if destNode then
    veh:queueLuaCommand('ai.setState({mode="manual"}) ai.driveUsingPath({wpTargetList={' .. string.format('%q', destNode) ..
      '}, driveInLane="on", avoidCars="on", routeSpeed=13, routeSpeedMode="limit", aggression=0.3})')
  end
  drivers[id] = {vehId = vehId, dest = dest, nodePos = nodePos and {x = nodePos.x, y = nodePos.y, z = nodePos.z},
    phase = destNode and 'road' or 'final', since = clock, lastMove = clock, lastPos = core().posOf(veh)}
  if not destNode then
    local p = core().posOf(veh)
    veh:queueLuaCommand('ai.driveUsingPath({script={{x=' .. p.x .. ',y=' .. p.y .. ',z=' .. p.z .. ',v=5},{x=' .. dest.x ..
      ',y=' .. dest.y .. ',z=' .. dest.z .. ',v=0}}})')
  end
end

local function park(veh)
  veh:queueLuaCommand('ai.setState({mode="disabled"}) input.event("throttle",0,1) input.event("brake",0,1) input.event("parkingbrake",1,1)')
end

-- Final approach: short scripted path from the road into the parking spot.
local function approach(veh, from, to)
  local pts = {}
  local dx, dy, dz = to.x - from.x, to.y - from.y, to.z - from.z
  local len = math.sqrt(dx * dx + dy * dy)
  local steps = math.max(2, math.min(12, math.floor(len / 4)))
  for i = 0, steps do
    local t = i / steps
    local v = i == steps and 0 or math.max(2, 5 - t * 3)
    pts[#pts + 1] = string.format('{x=%.2f,y=%.2f,z=%.2f,v=%.1f}', from.x + dx * t, from.y + dy * t, from.z + dz * t, v)
  end
  veh:queueLuaCommand('input.event("parkingbrake",0,1) ai.driveUsingPath({script={' .. table.concat(pts, ',') .. '}})')
end

local function updateDriver(id, d)
  local veh = obj(d.vehId)
  if not veh then drivers[id] = nil; return end
  local p = core().posOf(veh)
  if d.lastPos and dist(p, d.lastPos) > 1.5 then d.lastMove = clock; d.lastPos = p end
  if d.phase == 'road' then
    if dist(p, d.nodePos) < 22 or dist(p, d.dest) < 30 then
      d.phase = 'final'; d.since = clock; d.lastMove = clock
      approach(veh, p, d.dest)
    elseif clock - d.lastMove > 25 then
      -- Stuck on the way: hop to the road node next to the business.
      local q = d.nodePos
      local rot = quatFromDir(vec3(d.dest.x - q.x, d.dest.y - q.y, 0))
      veh:setPositionRotation(q.x, q.y, q.z + 0.5, rot.x, rot.y, rot.z, rot.w)
      veh:queueLuaCommand('recovery.recoverInPlace()')
      d.lastMove = clock
    end
  elseif d.phase == 'final' then
    local speed = veh:getVelocity():length()
    if dist(p, d.dest) < 6 and speed < 0.6 then
      park(veh); d.phase = 'parked'; d.parkedAt = clock
    elseif clock - d.lastMove > 12 or clock - d.since > 45 then
      -- Blocked lot entrance: settle into the spot instead of waiting forever.
      local rot = quatFromDir(vec3(d.dest.x - p.x, d.dest.y - p.y, 0))
      veh:setPositionRotation(d.dest.x, d.dest.y, d.dest.z + 0.4, rot.x, rot.y, rot.z, rot.w)
      park(veh); d.phase = 'parked'; d.parkedAt = clock
    end
  end
end

local function sendAway(id)
  local vehId = npcObjects[id]
  npcObjects[id] = nil; drivers[id] = nil
  local veh = obj(vehId)
  if not veh then return end
  veh:queueLuaCommand('input.event("parkingbrake",0,1) ai.setState({mode="traffic", aggression=0.3}) ai.setSpeedMode("legal")')
  leaving[vehId] = {untilClock = clock + 120}
end

local function spawnNpc(n, dest)
  local spawnPos, rot = pickSpawn(dest, closestNode(dest))
  if not spawnPos then
    -- Small or unusual maps: appear just out of sight behind the business.
    spawnPos = v3(dest) + vec3(40, 25, 0.8); rot = quatFromDir(vec3(-40, -25, 0))
  end
  -- Sellers and customers drive the very car being sold or serviced.
  local ride = (n.vehicle and n.vehicle.model) and n.vehicle or commuter()
  local ok, veh = pcall(core_vehicles.spawnNewVehicle, ride.model, {config = ride.config, pos = spawnPos, rot = rot,
    autoEnterVehicle = false})
  if not ok or not veh then
    ok, veh = pcall(core_vehicles.spawnNewVehicle, 'pessima', {config = 'vehicles/pessima/LX_A.pc', pos = spawnPos, rot = rot, autoEnterVehicle = false})
  end
  if not ok or not veh then return end
  local vehId = veh:getID()
  npcObjects[n.id] = vehId
  veh:setField('riverLifeNpcId', 0, n.id)
  if n.kind == 'seller' and n.vehicle and n.vehicle.wear then
    core_vehicleBridge.executeAction(veh, 'initPartConditions', {}, n.vehicle.mileage or 0, n.vehicle.wear, n.vehicle.wear)
  end
  -- Give the AI a moment to settle physics before driving.
  local nid = n.id
  core_jobsystem.create(function(job)
    job.sleep(1.5)
    if npcObjects[nid] == vehId then driveTo(nid, vehId, dest) end
  end)
  core().message(n.name .. (n.kind == 'buyer' and ' está a caminho para ver seu carro.' or
    n.kind == 'seller' and ' está trazendo um carro para vender.' or ' está trazendo o carro para a oficina.'))
end

-- After a Lua reload NPCs already at the business reappear parked in their spot.
local function placeParked(n, dest)
  local ride = (n.vehicle and n.vehicle.model) and n.vehicle or commuter()
  local rot = quatFromDir(vec3(1, 0, 0))
  local ok, veh = pcall(core_vehicles.spawnNewVehicle, ride.model, {config = ride.config, pos = v3(dest) + vec3(0, 0, 0.6),
    rot = rot, autoEnterVehicle = false})
  if not ok or not veh then return end
  npcObjects[n.id] = veh:getID()
  veh:setField('riverLifeNpcId', 0, n.id)
  drivers[n.id] = {vehId = veh:getID(), dest = dest, phase = 'parked', since = clock, lastMove = clock, announced = true}
  park(veh)
end

local function destinationFor(state, n)
  if n.kind == 'buyer' then
    for _, l in ipairs(state.listings or {}) do
      if l.id == n.listingId then
        if l.lot then
          -- Park beside the lot car, not on top of it.
          local h = l.heading or 0
          local side = vec3(math.cos(h), -math.sin(h), 0)
          local fwd = vec3(math.sin(h), math.cos(h), 0)
          local p = vec3(l.position.x, l.position.y, l.position.z) + fwd * 8 + side * 3.5
          return {x = p.x, y = p.y, z = l.position.z}
        end
        return parkingSpot(l.position, (tonumber(n.id:match('%d+')) or 0))
      end
    end
  elseif n.kind == 'seller' then
    for _, st in ipairs(state.stores or {}) do if st.id == n.storeId then return parkingSpot(st.position, 1) end end
  elseif n.kind == 'customer' then
    for _, w in ipairs(state.workshops or {}) do
      if w.id == n.workshopId then return parkingSpot(w.position, (tonumber(n.id:match('%d+')) or 0) % (w.bays or 2)) end
    end
  end
end

function M.onState(state)
  if not state or not state.me then return end
  local live = {}
  for _, n in ipairs(state.npcs or {}) do
    if n.owner == state.me.id then
      live[n.id] = true
      local vehicle = obj(npcObjects[n.id])
      if n.status == 'travelling' and not vehicle and not claimed[n.id] then
        local dest = destinationFor(state, n)
        local player = core().playerPos()
        if dest and player and dist(player, dest) < 300 then spawnNpc(n, dest) end
      elseif (n.status == 'negotiating' or n.status == 'waiting') and not vehicle and not claimed[n.id] then
        local dest = destinationFor(state, n)
        local player = core().playerPos()
        if dest and player and dist(player, dest) < 300 then placeParked(n, dest) end
      elseif n.kind == 'seller' and n.status == 'sold' and vehicle and not claimed[n.id] then
        -- Bought straight to the lot: the lot spot shows the car from now on.
        local delay = 0
        core_jobsystem.create(function(job)
          job.sleep(4)
          local v = obj(npcObjects[n.id])
          if v and not claimed[n.id] then v:delete(); npcObjects[n.id] = nil; drivers[n.id] = nil end
        end)
      elseif (n.status == 'leaving' or n.status == 'purchased' or n.status == 'served') and vehicle then
        sendAway(n.id)
      end
    end
  end
  for id in pairs(npcObjects) do
    if not live[id] then sendAway(id) end
  end
end

-- A trade-in car stays where the seller parked it and becomes the owner's vehicle.
function M.claimVehicle(npcId)
  local vehId = npcObjects[npcId]
  if not obj(vehId) then return nil end
  npcObjects[npcId] = nil; drivers[npcId] = nil; claimed[npcId] = true
  obj(vehId):queueLuaCommand('ai.setState({mode="disabled"})')
  if gameplay_traffic and gameplay_traffic.removeTraffic then pcall(gameplay_traffic.removeTraffic, vehId) end
  return vehId
end

-- When the owner makes an offer during a visit, the NPC buyer answers.
function M.afterOffer(visitId)
  local state = core().getState()
  for _, n in ipairs((state and state.npcs) or {}) do
    if n.visitId == visitId and n.status == 'negotiating' then
      core().rpc('npcReply', {npcId = n.id}, function(reply)
        if reply.ok and reply.data and reply.data.message then core().message(n.name .. ': ' .. reply.data.message) end
      end)
      return
    end
  end
end

-- NPC generation ------------------------------------------------------------------------------
local function jitter(lo, hi) return lo + math.random() * (hi - lo) end

local function buyerPayload(slot, listing)
  local personality = pick(PERSONALITIES)
  local stretch = ({Entusiasta = 1.05, ['Família'] = 0.98, Colecionador = 1.08, Revendedor = 0.88,
    Apressado = 1.0, ['Pechincheiro'] = 0.9})[personality] or 0.96
  local budget = math.floor(listing.price * jitter(0.86, 1.0) * stretch)
  budget = math.max(math.floor(listing.price * 0.62), math.min(budget, math.floor(listing.price * 1.2)))
  -- Buyers know what the car is worth (the server refuses budgets far above it).
  local worth = (tonumber(listing.value) or 0) * 100
  if worth > 0 then budget = math.min(budget, math.floor(worth * 1.12)) end
  local first = math.floor(budget * jitter(0.8, 0.92))
  return {listingId = listing.id, name = name(), personality = personality, budget = budget, firstOffer = first,
    slot = slot, vehicle = commuter()}
end

local function sellerPayload(slot, budget)
  local c = catalog()
  local options = {}
  local cap = (budget or 5000000) / 100
  for _, e in ipairs(c.all) do if e.value <= cap * 1.05 and e.value >= 2500 then options[#options + 1] = e end end
  if #options == 0 then return nil end
  local e = pick(options)
  local condition = jitter(0.55, 0.98)
  local mileage = math.floor(jitter(20000, 260000) * 1000)
  local value = math.floor(e.value * 100 * (0.45 + condition * 0.45))
  local asking = math.floor(value * jitter(0.92, 1.08))
  asking = math.min(asking, math.floor(value * 1.1))
  local minimum = math.max(math.floor(value * 0.5), math.floor(asking * jitter(0.72, 0.88)))
  return {name = name(), personality = pick(PERSONALITIES), slot = slot,
    vehicle = {model = e.model, config = e.config, niceName = e.niceName, value = value, mileage = mileage,
      year = e.year, condition = math.floor(condition * 100), wear = condition},
    asking = asking, minimum = math.min(minimum, asking)}
end

local function customerPayload(slot, workshopId)
  local ride = commuter()
  local job = pick(JOBS)
  local value = (ride.value or 15000) * 100
  local share = jitter(job.share[1], job.share[2])
  local parts = math.max(15000, math.floor(value * share))
  local labor = math.floor(jitter(25000, 120000) + parts * 0.35)
  local budget = math.floor((parts + labor) * jitter(1.0, 1.45))
  budget = math.min(budget, math.max(200000, parts * 3 + 300000))
  return {workshopId = workshopId, name = name(), personality = pick(PERSONALITIES), slot = slot,
    vehicle = {model = ride.model, config = ride.config, niceName = ride.niceName, mileage = math.floor(jitter(40000, 220000) * 1000)},
    diagnosis = {partsCost = parts, brokenParts = math.random(1, 6), notes = job.label, job = job.key, minutes = job.minutes},
    budget = budget}
end

local function submit(op, payload)
  if not payload then return end
  core().rpc(op, payload, function(r)
    if not r.ok and r.error ~= 'npc_busy' and r.error ~= 'store_unavailable' and r.error ~= 'shop_unavailable' then
      log('W', 'riverLife.npcs', op .. ': ' .. tostring(r.error))
    end
  end)
end

local function handleSlot(p)
  local state = core().getState()
  if not state or not state.me then return end
  if p.kind == 'buyer' then
    for _, l in ipairs(state.listings or {}) do
      if l.id == p.listingId and l.status == 'active' and not l.reserved then
        -- Nobody comes to look at a car priced far above what it is worth.
        local worth = (tonumber(l.value) or 0) * 100
        if worth > 0 and l.price > worth * 1.3 then return end
        submit('npcCreate', buyerPayload(p.slot, l)); return
      end
    end
  elseif p.kind == 'seller' then
    submit('npcSellerCreate', (function()
      local x = sellerPayload(p.slot, p.tradeBudget)
      if x then x.storeId = p.storeId end
      return x
    end)())
  elseif p.kind == 'customer' then
    submit('npcCustomerCreate', customerPayload(p.slot, p.workshopId))
  end
end
function M.onSlot(p) pendingSlots[#pendingSlots + 1] = p end

-- Solo careers schedule visits locally with the same cadence as the server.
local SOLO = {buyer = 150, seller = 300, customer = 200}
local function soloSchedule(state)
  local me = state.me.id
  local player = core().playerPos()
  local hour = core().hourOfDay()
  local busy, buyers, sellers = {}, {}, {}
  for _, n in ipairs(state.npcs or {}) do
    if n.status == 'travelling' or n.status == 'negotiating' or n.status == 'waiting' then
      local key = n.storeId or n.workshopId or ''
      busy[key] = (busy[key] or 0) + 1
      if n.kind == 'buyer' then buyers[key] = (buyers[key] or 0) + 1 end
      if n.kind == 'seller' then sellers[key] = (sellers[key] or 0) + 1 end
    end
  end
  local function due(kind) return clock - (lastSolo[kind] or -60) >= SOLO[kind] end
  local Domain = require('common/riverLife/domain')
  for _, st in ipairs(state.stores or {}) do
    if st.owner == me and st.open and dist(player, st.position) < 250 and Domain.withinHours(st.opensAt, st.closesAt, hour) then
      if st.npcEnabled and (buyers[st.id] or 0) < 2 and due('buyer') then
        for _, l in ipairs(state.listings or {}) do
          if l.storeId == st.id and l.status == 'active' and not l.reserved then
            lastSolo.buyer = clock; buyers[st.id] = (buyers[st.id] or 0) + 1
            handleSlot({kind = 'buyer', listingId = l.id, slot = 'solo'})
            break
          end
        end
      end
      if st.npcSellersEnabled and (sellers[st.id] or 0) == 0 and due('seller') then
        lastSolo.seller = clock; sellers[st.id] = 1
        handleSlot({kind = 'seller', storeId = st.id, tradeBudget = st.tradeBudget, slot = 'solo'})
      end
    end
  end
  for _, w in ipairs(state.workshops or {}) do
    if w.owner == me and w.open and w.npcEnabled and dist(player, w.position) < 250 and (busy[w.id] or 0) <= (w.bays or 2)
      and Domain.withinHours(w.opensAt, w.closesAt, hour) and due('customer') then
      lastSolo.customer = clock
      handleSlot({kind = 'customer', workshopId = w.id, slot = 'solo'})
    end
  end
end

function M.onUpdate(dtReal)
  clock = clock + (dtReal or 0)
  for id, d in pairs(drivers) do
    local ok, err = pcall(updateDriver, id, d)
    if not ok then log('E', 'riverLife.npcs', tostring(err)); drivers[id] = nil end
  end
  if clock - lastCheck < 1 then return end
  lastCheck = clock
  local c = core()
  if not c or not c.active() then return end
  local state = c.getState()
  if not state or not state.me then return end
  while #pendingSlots > 0 do handleSlot(table.remove(pendingSlots, 1)) end
  -- Parked NPCs announce themselves to the ledger once.
  for _, n in ipairs(state.npcs or {}) do
    local d = drivers[n.id]
    if n.owner == state.me.id and n.status == 'travelling' and d and d.phase == 'parked' and not d.announced then
      d.announced = true
      c.rpc('npcArrive', {npcId = n.id}, function(r)
        local reply = r.ok and r.data and ((r.data.offer and r.data.offer.reply) or r.data.trade)
        if reply then
          c.message(reply.message or (n.name .. ' foi atendido pela equipe.'))
        elseif r.ok then
          c.message(n.name .. ' chegou. Abra o RiverLife para negociar.')
          guihooks.trigger('RiverLifeOpen', {open = true, app = n.kind == 'customer' and 'workshop' or 'store', focus = n.id})
        else
          d.announced = false
        end
      end)
    end
  end
  for vehId, l in pairs(leaving) do
    local veh = obj(vehId)
    local player = c.playerPos()
    if not veh then leaving[vehId] = nil
    elseif clock > l.untilClock or (player and dist(c.posOf(veh), player) > 300) then
      if gameplay_traffic and gameplay_traffic.removeTraffic then pcall(gameplay_traffic.removeTraffic, vehId) end
      veh:delete(); leaving[vehId] = nil
    end
  end
  if not c.multi() then soloSchedule(state) end
end

-- QA and host tools: schedule a visit right away (same path as the timers).
function M.forceVisit(kind)
  local state = core().getState()
  if not state or not state.me then return 'no state' end
  for _, st in ipairs(state.stores or {}) do
    if st.owner == state.me.id then
      if kind == 'buyer' then
        for _, l in ipairs(state.listings or {}) do
          if l.storeId == st.id and l.status == 'active' and not l.reserved then handleSlot({kind = 'buyer', listingId = l.id, slot = 'solo'}); return 'buyer' end
        end
      elseif kind == 'seller' then handleSlot({kind = 'seller', storeId = st.id, tradeBudget = st.tradeBudget, slot = 'solo'}); return 'seller' end
    end
  end
  for _, w in ipairs(state.workshops or {}) do
    if w.owner == state.me.id and kind == 'customer' then handleSlot({kind = 'customer', workshopId = w.id, slot = 'solo'}); return 'customer' end
  end
  return 'nothing to do'
end

function M.reset()
  for id, vehId in pairs(npcObjects) do local v = obj(vehId); if v then v:delete() end end
  for vehId in pairs(leaving) do local v = obj(vehId); if v then v:delete() end end
  npcObjects, drivers, leaving, claimed, pendingSlots = {}, {}, {}, {}, {}
end
M.onExtensionUnloaded = M.reset
M.onClientEndMission = M.reset
M.debugStatus = function()
  local out = {}
  for id, vehId in pairs(npcObjects) do
    out[id] = {vehicleId = vehId, phase = drivers[id] and drivers[id].phase, position = M.npcPosition(id)}
  end
  return out
end

return M
