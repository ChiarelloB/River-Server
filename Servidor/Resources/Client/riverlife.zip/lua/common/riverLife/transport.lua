-- Original nonblocking writer. Retains the remainder of a partially sent frame.
local M={}
function M.new(getSocket,onClosed,onSent)
  local self={queue={},offset=1,bytes=0,socket=nil}
  function self:flush()
    local socket=getSocket()
    if socket~=self.socket then self.queue={};self.offset=1;self.bytes=0;self.socket=socket end
    if not socket then return end
    for _=1,8 do
      local packet=self.queue[1];if not packet then return end
      local sent,err,last=socket:send(packet,self.offset)
      if sent then
        self.bytes=self.bytes-#packet;table.remove(self.queue,1);self.offset=1
        if onSent then onSent(#packet) end
      elseif err=='timeout' or err=='Socket is not connected' then
        self.offset=math.max(self.offset,(last or 0)+1);return
      else
        self.queue={};self.bytes=0;self.offset=1
        if onClosed then onClosed(err) end;return
      end
    end
  end
  function self:send(packet)
    local socket=getSocket()
    if socket~=self.socket then self.queue={};self.offset=1;self.bytes=0;self.socket=socket end
    if not socket then return end
    if self.bytes+#packet>8*1024*1024 then
      self.queue={};self.bytes=0;self.offset=1
      if onClosed then onClosed('queue limit') end;return
    end
    self.queue[#self.queue+1]=packet;self.bytes=self.bytes+#packet;self:flush()
  end
  return self
end
return M
