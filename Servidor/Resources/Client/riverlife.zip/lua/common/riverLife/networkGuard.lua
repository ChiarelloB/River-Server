-- Integrates with BeamMP's existing socket without copying its implementation.
local Transport=require('common/riverLife/transport')
local M={}
local module,original,wrapper,writer
local function socket()
  if not original then return end
  for i=1,30 do
    local name,value=debug.getupvalue(original,i)
    if not name then break end
    if name=='TCPLauncherSocket' then return type(value)=='userdata' and value or nil end
  end
end
local function bootstrap()
  local tcp=socket()
  if tcp and not module.launcherConnected() and tcp:getpeername() then original('A') end
end
function M.install()
  if not MPGameNetwork or type(MPGameNetwork.send)~='function' then return end
  if module==MPGameNetwork and module.send==wrapper then return end
  module=MPGameNetwork;original=module.send
  writer=Transport.new(socket,function(err)
    log('W','RiverLife','BeamMP socket interrupted: '..tostring(err))
    module.disconnectLauncher()
    guihooks.trigger('RiverLifeNotice',{text='Conexão BeamMP interrompida. Reconecte para recuperar suas negociações.'})
  end,function(bytes)
    if MPDebug then MPDebug.packetSent(bytes) end
  end)
  wrapper=function(data)
    if type(data)~='string' then
      local ok,bytes=pcall(function() return data:tostring() end)
      if not ok or type(bytes)~='string' then return original(data) end
      data=bytes
    end
    -- Let BeamMP perform its own five-byte handshake and set its private flags.
    -- Its socket must have completed the TCP handshake before that first write.
    if data=='A' and not module.launcherConnected() then
      bootstrap()
      return
    end
    local n=#data
    local header=string.char(n%256,math.floor(n/256)%256,math.floor(n/65536)%256,math.floor(n/16777216)%256)
    writer:send(header..data)
  end
  module.send=wrapper
end
function M.update() M.install();if writer then bootstrap();writer:flush() end end
function M.status() return {installed=module and module.send==wrapper or false,socket=socket()~=nil,queued=writer and writer.bytes or 0} end
function M.unload()
  if module and module.send==wrapper then module.send=original end
  module=nil;original=nil;wrapper=nil;writer=nil
end
return M
