-- RiverLife translations for Lua messages (public edition). Original code.
-- Notices and toasts are written in Portuguese; when the game language is English, Spanish or
-- Russian they are translated here (exact texts first, then templates like "Vendido por {0}").
local M = {}

local DATA_PATH = '/lua/common/riverLife/i18n.json'
local COLUMN = {en = 1, es = 2, ru = 3}
local lang, exact, templates

local function langFromCode(code)
  local c = string.lower(tostring(code or ''))
  if c:sub(1, 2) == 'pt' then return 'pt' end
  if c:sub(1, 2) == 'es' then return 'es' end
  if c:sub(1, 2) == 'ru' then return 'ru' end
  return 'en'
end

local function escapePattern(s) return (s:gsub('[%^%$%(%)%%%.%[%]%*%+%-%?]', '%%%0')) end

local function load()
  local code = ''
  if Lua and Lua.getSelectedLanguage then
    local ok, v = pcall(function() return Lua:getSelectedLanguage() end)
    if ok then code = v end
  end
  lang = langFromCode(code)
  exact, templates = {}, {}
  if lang == 'pt' then return end
  local data = jsonReadFile(DATA_PATH)
  local col = COLUMN[lang]
  if type(data) ~= 'table' or not col then lang = 'pt'; return end
  for pt, row in pairs(data) do
    local out = type(row) == 'table' and row[col]
    local letters = #(pt:gsub('{%d+}', ''):gsub('[^%a\128-\255]', ''))
    local openEnds = pt:find('^{%d+}') and pt:find('{%d+}$')
    if type(out) == 'string' and out ~= '' and out ~= pt and not (openEnds and letters < 6) then
      if pt:find('{0}', 1, true) then
        local order, pattern, weight = {}, {'^'}, 0
        local pos = 1
        while true do
          local s, e, n = pt:find('{(%d+)}', pos)
          local literal = pt:sub(pos, (s or 0) - 1)
          if not s then literal = pt:sub(pos) end
          table.insert(pattern, escapePattern(literal))
          weight = weight + #literal
          if not s then break end
          table.insert(pattern, '(.-)')
          table.insert(order, tonumber(n))
          pos = e + 1
        end
        table.insert(pattern, '$')
        table.insert(templates, {pattern = table.concat(pattern), order = order, out = out, weight = weight})
      else
        exact[pt] = out
      end
    end
  end
  table.sort(templates, function(a, b) return a.weight > b.weight end)
end

function M.tr(text)
  if type(text) ~= 'string' or text == '' then return text end
  if not lang then load() end
  if lang == 'pt' then return text end
  local key = text:gsub('^%s+', ''):gsub('%s+$', '')
  if exact[key] then return exact[key] end
  for _, t in ipairs(templates) do
    local caps = {key:match(t.pattern)}
    if #caps > 0 then
      local vals = {}
      for i, n in ipairs(t.order) do vals[n] = exact[caps[i]] or caps[i] end
      return (t.out:gsub('{(%d+)}', function(n) return vals[tonumber(n)] or '' end))
    end
  end
  return text
end

-- the player may change the game language while playing
function M.reset() lang = nil end

return M
