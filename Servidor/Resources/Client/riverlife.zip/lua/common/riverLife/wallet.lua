-- Reconcile a server wallet with the durable RLS intent saved before sending it.
local M={}

-- Ledger tag kept in the career save: which server account its RiverLife balance mirrors.
function M.ledgerTag(key)
  local h=5381
  for i=1,#key do h=(h*33+key:byte(i))%2147483647 end
  return h
end

function M.plan(localState,server)
  -- The account was just created from this save's money (new server, or a save made elsewhere), or the
  -- save's balance mirrors another ledger: the career money stays and the ledger follows the save.
  local foreign=localState.initialized and (localState.ledger or 0)~=0 and localState.currentLedger~=nil
    and localState.ledger~=localState.currentLedger
  if server.fresh or foreign then
    return {delta=0,balance=server.balance,revision=server.careerRevision,intentRevision=0,intentDelta=0,adopted=true}
  end
  local old=localState.initialized and localState.balance or localState.money
  local earned=0
  if localState.intentRevision>localState.revision and server.careerRevision>=localState.intentRevision then
    earned=localState.intentDelta
  end
  return {delta=server.balance-old-earned,balance=server.balance,revision=server.careerRevision,
    intentRevision=0,intentDelta=0}
end
return M
