-- Reconcile a server wallet with the durable RLS intent saved before sending it.
local M={}
function M.plan(localState,server)
  local old=localState.initialized and localState.balance or localState.money
  local earned=0
  if localState.intentRevision>localState.revision and server.careerRevision>=localState.intentRevision then
    earned=localState.intentDelta
  end
  return {delta=server.balance-old-earned,balance=server.balance,revision=server.careerRevision,
    intentRevision=0,intentDelta=0}
end
return M
