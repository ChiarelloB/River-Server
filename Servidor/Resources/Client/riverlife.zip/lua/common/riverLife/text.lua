-- RiverLife in-world texts: price signs, labels and big map markers. Original code.
-- They are written in Portuguese. The public edition ships common/riverLife/i18n, which translates
-- them to the game language (English, Spanish, Russian); without it (River Pack) they stay as they are.
-- Signs are drawn every frame, so translations are cached.
local M = {}

local I18n
if FS and FS.fileExists and FS:fileExists('/lua/common/riverLife/i18n.lua') then
  local ok, mod = pcall(require, 'common/riverLife/i18n')
  if ok and type(mod) == 'table' and mod.tr then I18n = mod end
end

local cache, cached = {}, 0
function M.tr(text)
  if not I18n or type(text) ~= 'string' or text == '' then return text end
  local hit = cache[text]
  if hit then return hit end
  if cached > 2000 then cache, cached = {}, 0 end
  hit = I18n.tr(text) or text
  cache[text], cached = hit, cached + 1
  return hit
end

-- Thousands separator of the game language ("$86.000" in Portuguese, "$86,000" in English).
local sep, checkedAt = '.', -10
local function separator()
  if not I18n then return '.' end
  local now = os.clock()
  if now - checkedAt > 5 then
    checkedAt = now
    local ok, code = pcall(function() return Lua:getSelectedLanguage() end)
    local c = ok and string.lower(tostring(code or '')):sub(1, 2) or ''
    sep = (c == 'pt' or c == 'es') and '.' or (c == 'ru' and ' ' or ',')
  end
  return sep
end

function M.money(cents)
  local s = separator()
  local digits = tostring(math.floor((cents or 0) / 100))
  local out = digits:reverse():gsub('(%d%d%d)', '%1' .. s):reverse()
  if out:sub(1, #s) == s then out = out:sub(#s + 1) end
  return '$' .. out
end

-- Pieces joined with " · ", each translated on its own (nil and empty pieces are skipped).
function M.join(...)
  local out = {}
  for i = 1, select('#', ...) do
    local piece = select(i, ...)
    if piece and piece ~= '' then out[#out + 1] = piece end
  end
  return table.concat(out, ' · ')
end

return M
