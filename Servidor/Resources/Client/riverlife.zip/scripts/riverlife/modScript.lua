-- RiverLife: classifieds, car dealerships, workshops and players for RLS careers.
-- The server copy of this mod replaces the solo copy while connected; reload so
-- the running code always matches the files that are mounted.
-- public edition: keep BeamMP mounted under RLS in multiplayer
if not extensions.isExtensionLoaded('riverLifeMP') then extensions.load('riverLifeMP') end
local names = {'riverLife_npcs', 'riverLife_players', 'riverLife_display', 'riverLife_gigs', 'riverLife'}
for _, name in ipairs(names) do setExtensionUnloadMode(name, 'manual') end
if extensions.isExtensionLoaded('riverLife') then
  for _, name in ipairs(names) do extensions.reload(name) end
else
  extensions.load('riverLife')
end
