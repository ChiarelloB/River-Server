<template>
  <div class="wpd-mask" @pointerdown.self="$emit('close')">
    <div class="wpd" role="dialog" aria-label="Propriedades de Vídeo">
      <header class="wpd-title"><span>Propriedades de Vídeo</span><button aria-label="Fechar" @click="$emit('close')">×</button></header>
      <nav class="wpd-tabs"><button class="on">Área de trabalho</button></nav>
      <div class="wpd-body">
        <div class="wpd-monitor">
          <div class="wpd-screen"><Wallpaper :value="draft" /></div>
          <div class="wpd-stand"></div>
        </div>

        <h4>Temas do RiverOS</h4>
        <div class="wpd-grid themes">
          <button v-for="t in THEMES" :key="t.id" class="wpd-item" :class="{ on: draft.kind === 'theme' && draft.value === t.id }" @click="pick('theme', t.id)">
            <span class="wpd-thumb"><Wallpaper :value="{ kind: 'theme', value: t.id }" /></span><small>{{ t.label }}</small>
          </button>
        </div>

        <h4>Cor sólida</h4>
        <div class="wpd-colors">
          <button v-for="c in COLORS" :key="c" class="wpd-color" :class="{ on: draft.kind === 'color' && draft.value === c }" :style="{ background: c }"
            :title="c" @click="pick('color', c)"></button>
        </div>

        <h4>Suas imagens <small class="rl-muted">capturas de tela do jogo (tecla F12) e fotos do RiverLife</small></h4>
        <div v-if="!loaded" class="rl-muted">Procurando imagens…</div>
        <div v-else-if="!images.length" class="rl-muted">Nenhuma imagem ainda. Aperte F12 no jogo para tirar uma captura de tela, ou fotografe um carro no RiverLife.</div>
        <div v-else class="wpd-grid images">
          <button v-for="img in images" :key="img" class="wpd-item" :class="{ on: draft.kind === 'image' && draft.value === img }" @click="pick('image', img)">
            <span class="wpd-thumb"><img :src="img" alt="" loading="lazy" @error="e => (e.target.closest('.wpd-item').style.display = 'none')" /></span>
          </button>
        </div>
        <div v-if="draft.kind === 'image'" class="wpd-fit">
          <span>Posição:</span>
          <XPSelect :model-value="draft.fit || 'cover'" :options="[{ value: 'cover', label: 'Preencher a tela' }, { value: 'center', label: 'Centralizar' }]"
            @update:model-value="f => (draft = { ...draft, fit: f })" />
        </div>
      </div>
      <footer class="wpd-foot">
        <button class="rl-btn primary" @click="save(true)">OK</button>
        <button class="rl-btn" @click="$emit('close')">Cancelar</button>
        <button class="rl-btn" :disabled="!changed" @click="save(false)">Aplicar</button>
      </footer>
    </div>
  </div>
</template>

<script setup>
// Original code: RiverOS "Display Properties" — pick the desktop background.
import { computed, onMounted, onUnmounted, ref } from "vue"
import { request, onAction } from "../rl.js"
import Wallpaper from "./Wallpaper.vue"
import XPSelect from "./XPSelect.vue"

const props = defineProps({ value: Object })
const emit = defineEmits(["close", "preview"])

const THEMES = [
  { id: "bliss", label: "Colinas" }, { id: "azure", label: "Azul RiverOS" }, { id: "sunset", label: "Pôr do sol" },
  { id: "night", label: "Noite estrelada" }, { id: "ocean", label: "Oceano" }, { id: "highway", label: "River Highway" }, { id: "graphite", label: "Grafite" },
]
const COLORS = ["#3a6ea5", "#004e98", "#0f6b5b", "#2f6e1b", "#6b8e23", "#7a1f1f", "#a3501a", "#4b2a6b", "#5c5c5c", "#222831", "#000000"]

const initial = props.value && typeof props.value === "object" ? { ...props.value } : { kind: "theme", value: "bliss" }
const draft = ref({ ...initial })
const saved = ref({ ...initial })
const changed = computed(() => JSON.stringify(draft.value) !== JSON.stringify(saved.value))
const images = ref([])
const loaded = ref(false)
let off, reqId

function pick(kind, value) { draft.value = kind === "image" ? { kind, value, fit: draft.value.fit || "cover" } : { kind, value } }
function save(close) {
  request("desktopPrefs", { wallpaper: draft.value })
  saved.value = { ...draft.value }
  emit("preview", { ...draft.value })
  if (close) emit("close")
}
onMounted(() => {
  off = onAction(e => {
    if (e?.op !== "wallpapers" || (reqId && e.id !== reqId)) return
    const d = e.result?.data || {}
    images.value = [...(d.screenshots || []), ...(d.photos || [])].filter(x => typeof x === "string")
    loaded.value = true
  })
  reqId = request("wallpapers")
  setTimeout(() => { loaded.value = true }, 4000)
})
onUnmounted(() => off && off())
</script>

<style scoped>
.wpd-mask { position: absolute; inset: 0; z-index: 1004; display: flex; align-items: center; justify-content: center; background: rgba(0, 20, 60, .2); }
.wpd { width: min(620px, 94vw); max-height: calc(100vh - 70px); display: flex; flex-direction: column; background: #ece9d8; border: 3px solid #0831d9; border-top: 0;
  border-radius: 8px 8px 3px 3px; box-shadow: 4px 6px 18px rgba(0,0,0,.45); overflow: hidden; }
.wpd-title { height: 30px; display: flex; align-items: center; justify-content: space-between; padding: 0 4px 0 10px; color: #fff; font: bold 13px "Trebuchet MS", Tahoma, sans-serif;
  text-shadow: 1px 1px #0a1f69; background: linear-gradient(180deg, #0997ff 0%, #0053ee 8%, #0050ee 40%, #06f 88%, #003dd7 100%); }
.wpd-title button { width: 22px; height: 22px; border: 1px solid #fff; border-radius: 3px; color: #fff; font: bold 16px Tahoma, sans-serif; cursor: pointer;
  background: radial-gradient(circle at 30% 30%, #f09a73, #d2421f 70%); }
.wpd-tabs { display: flex; gap: 2px; padding: 8px 10px 0; border-bottom: 1px solid #919b9c; }
.wpd-tabs button { font: 12px Tahoma, sans-serif; padding: 5px 12px; border: 1px solid #919b9c; border-bottom: 0; border-radius: 4px 4px 0 0; background: #fff; border-top: 2px solid #f8b636; position: relative; top: 1px; }
.wpd-body { flex: 1; min-height: 0; overflow: auto; padding: 10px 14px; background: #fff; margin: 0 10px; border: 1px solid #919b9c; border-top: 0; }
.wpd-monitor { display: flex; flex-direction: column; align-items: center; margin: 4px 0 6px; }
.wpd-screen { position: relative; width: 220px; height: 138px; border: 10px solid #d6d3c8; border-radius: 6px 6px 2px 2px; box-shadow: inset 0 0 0 1px #8b887d, 0 1px 0 #a9a69a; overflow: hidden; background: #000; }
.wpd-stand { width: 70px; height: 16px; background: linear-gradient(180deg, #d6d3c8, #b9b6aa); clip-path: polygon(25% 0, 75% 0, 100% 100%, 0 100%); }
h4 { margin: 12px 0 6px; font: bold 12px Tahoma, sans-serif; color: #1d3f69; } h4 small { font-weight: normal; }
.wpd-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(104px, 1fr)); gap: 8px; }
.wpd-item { display: flex; flex-direction: column; gap: 4px; align-items: center; padding: 4px; border: 2px solid transparent; border-radius: 3px; background: none; cursor: pointer; font: 11px Tahoma, sans-serif; color: #222; }
.wpd-item:hover { border-color: #aac0e0; } .wpd-item.on { border-color: #316ac5; background: #e8f0fc; }
.wpd-thumb { position: relative; width: 100%; aspect-ratio: 16/10; overflow: hidden; border: 1px solid #8b9bb0; background: #1c2533; }
.wpd-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
.wpd-colors { display: flex; flex-wrap: wrap; gap: 6px; }
.wpd-color { width: 30px; height: 22px; border: 1px solid #555; cursor: pointer; border-radius: 2px; }
.wpd-color.on { outline: 2px solid #316ac5; outline-offset: 2px; }
.wpd-fit { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 12px; }
.wpd-foot { display: flex; justify-content: flex-end; gap: 6px; padding: 10px; }
.wpd-foot .rl-btn { min-width: 76px; }
</style>
