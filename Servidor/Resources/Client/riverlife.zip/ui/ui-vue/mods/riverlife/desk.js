// RiverOS window state survives route changes (native RLS screens unmount the desktop).
import { reactive } from "vue"

export const desk = reactive({
  windows: [], // 3D side tools (painting, tuning, parts panel)
  tabs: [], // River Explorer tabs: { id, history: [{ app, props }], pos, subtitle, hostedRoute }
  active: "",
  browser: { id: "browser", x: 40, y: 14, w: 1200, h: 760, minimized: false, maximized: false, placed: false },
  order: [],
  focused: "",
  firstApp: "internet",
  partsMode: "", // "3d" shows the RLS parts screen as the side panel instead of the RiverPeças store
  peek: false, // the store hides itself so the player can look at the car
})
