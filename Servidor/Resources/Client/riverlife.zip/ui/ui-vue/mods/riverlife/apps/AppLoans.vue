<template>
  <div v-if="!hosted" class="rl-page bk-launch">
    <div class="bk-intro">
      <div class="bk-logo big"><BngIcon type="banknotes" /></div>
      <div>
        <h2 class="rl-h1">Banco River</h2>
        <p class="rl-muted">Empréstimos das organizações em que você tem reputação, com parcelas a cada 10 minutos de jogo. Acompanhe e quite seus contratos.</p>
        <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>O banco atende pelos computadores das suas garagens.</div>
        <template v-else-if="fn">
          <button class="rl-btn primary" :disabled="fn.disabled" @click="launch">Entrar no Banco River</button>
          <p v-if="fn.disabled && reasonText(fn)" class="rl-error">{{ reasonText(fn) }}</p>
        </template>
        <div v-else class="rl-empty"><b>Indisponível aqui</b>Este computador não oferece empréstimos.</div>
      </div>
    </div>
  </div>

  <div v-else class="bk">
    <header class="bk-head">
      <div class="bk-brand">
        <div class="bk-logo"><BngIcon type="banknotes" /></div>
        <div><b>Banco River</b><small>Crédito para quem dirige a economia</small></div>
      </div>
      <div class="bk-score" v-if="credit.score != null" :title="'Score de crédito: ' + credit.score">
        <small>Score de crédito</small>
        <div class="bk-score-row"><b>{{ credit.score }}</b><span class="rl-badge" :class="tierClass(credit.tier)">{{ tierName(credit.tier) }}</span></div>
        <div class="bk-gauge"><i :style="{ left: scorePct + '%' }"></i></div>
      </div>
    </header>

    <div class="bk-body">
      <div class="rl-stats">
        <div><b>{{ dollars(funds) }}</b><small>Saldo disponível</small></div>
        <div><b>{{ dollars(totalOwed) }}</b><small>Saldo devedor</small></div>
        <div><b>{{ loans.length }}</b><small>Empréstimos ativos</small></div>
        <div><b>{{ nextDue ? dollars(nextDue.amount) : "—" }}</b><small>{{ nextDue ? "Próxima parcela em " + countdown(nextDue.seconds) : "Nenhuma parcela pendente" }}</small></div>
      </div>

      <nav class="rl-tabs">
        <button :class="{ on: tab === 'new' }" @click="tab = 'new'">Contratar empréstimo</button>
        <button :class="{ on: tab === 'loans' }" @click="tab = 'loans'">Meus empréstimos<span v-if="loans.length" class="bk-count">{{ loans.length }}</span></button>
        <button v-if="mortgages.length" :class="{ on: tab === 'mortgages' }" @click="tab = 'mortgages'">Financiamentos<span class="bk-count">{{ mortgages.length }}</span></button>
      </nav>

      <div v-if="!loaded" class="rl-empty"><b>Conectando ao banco...</b>Buscando ofertas e contratos.</div>

      <!-- New loan -->
      <section v-else-if="tab === 'new'">
        <div v-if="!offers.length" class="rl-empty"><b>Nenhuma oferta de crédito</b>As organizações liberam empréstimos conforme sua reputação com elas cresce. Volte quando tiver mais reputação.</div>
        <div v-else class="bk-new">
          <div class="bk-offers">
            <h3 class="rl-h2">Escolha a instituição</h3>
            <button v-for="o in offers" :key="o.id" class="bk-offer" :class="{ on: o.id === orgId }" @click="selectOffer(o.id)">
              <span class="bk-offer-icon"><BngIcon type="moneyBag" /></span>
              <span class="bk-offer-text">
                <b>{{ o.name }}</b>
                <small>Taxa a partir de {{ pct(o.rate) }} · até {{ dollars(o.max) }}</small>
              </span>
              <span v-if="o.max <= 0" class="rl-badge warn">Limite usado</span>
            </button>
          </div>

          <div v-if="offer" class="bk-calc rl-box">
            <h3 class="rl-h2 first">Simulação — {{ offer.name }}</h3>
            <div class="bk-amount">
              <small>Valor do empréstimo</small>
              <b>{{ dollars(amount) }}</b>
            </div>
            <input v-model.number="amount" class="bk-range" type="range" min="0" :max="maxAmount" step="500" :disabled="maxAmount <= 0" aria-label="Valor" />
            <div class="rl-row bk-amount-row">
              <input v-model.number="amountInput" class="rl-input bk-num" type="number" min="0" :max="maxAmount" step="500"
                @focus="typing(true)" @blur="typing(false); commitAmount()" @keydown.enter="commitAmount" />
              <button v-for="q in [0.25, 0.5, 0.75, 1]" :key="q" class="rl-btn" :disabled="maxAmount <= 0" @click="setAmount(maxAmount * q)">{{ q === 1 ? "Máx." : q * 100 + "%" }}</button>
            </div>
            <p class="rl-muted small">Valores em múltiplos de $500 · limite nesta instituição: {{ dollars(offer.max) }}</p>

            <small class="bk-label">Prazo</small>
            <div class="bk-terms">
              <button v-for="t in terms" :key="t" class="bk-term" :class="{ on: t === term }" @click="term = t">
                <b>{{ t }}x</b><small>{{ termDuration(t) }}</small>
              </button>
            </div>

            <table class="bk-summary"><tbody>
              <tr><td>Taxa do contrato</td><td>{{ pct(adjustedRate) }}</td></tr>
              <tr><td>Parcela ({{ term || 0 }}x, a cada 10 min)</td><td><b>{{ dollars(preview.per, true) }}</b></td></tr>
              <tr><td>Juros totais</td><td>{{ dollars(Math.max(0, preview.total - amount), true) }}</td></tr>
              <tr class="total"><td>Total a pagar</td><td>{{ dollars(preview.total, true) }}</td></tr>
            </tbody></table>

            <div v-if="confirmLoan" class="bk-confirm">
              <p>Contratar <b>{{ dollars(amount) }}</b> com {{ offer.name }} em <b>{{ term }}x de {{ dollars(preview.per, true) }}</b>? O valor entra na hora no seu saldo e as parcelas são cobradas automaticamente.</p>
              <div class="rl-row">
                <button class="rl-btn go" :disabled="busy" @click="takeLoan">Confirmar contratação</button>
                <button class="rl-btn" :disabled="busy" @click="confirmLoan = false">Voltar</button>
              </div>
            </div>
            <button v-else class="rl-btn primary bk-take" :disabled="!canTake || busy" @click="confirmLoan = true">Contratar empréstimo</button>
            <p v-if="loanError" class="rl-error">{{ loanError }}</p>
          </div>
        </div>
      </section>

      <!-- Active loans -->
      <section v-else-if="tab === 'loans'">
        <div v-if="!loans.length" class="rl-empty"><b>Nenhum empréstimo ativo</b>Você não deve nada ao banco. Simule um empréstimo na aba ao lado.</div>
        <article v-for="l in loans" :key="l.id" class="bk-loan rl-box">
          <div class="rl-row between">
            <div class="bk-loan-title"><b>{{ l.orgName || l.orgId }}</b>
              <small class="rl-muted">Contratado {{ l.createdAt ? dateTime(l.createdAt) : "" }}{{ l.businessAccountId ? " · conta empresarial" : "" }}</small></div>
            <span class="rl-badge">{{ l.paymentsRemaining }} parcela(s) restante(s)</span>
          </div>
          <div class="bk-progress-row">
            <div class="rl-progress"><i :style="{ width: paidPct(l) + '%' }"></i></div>
            <small>{{ paidPct(l) }}% pago</small>
          </div>
          <div class="bk-kv">
            <div><small>Valor contratado</small><b>{{ dollars(l.principal, true) }}</b></div>
            <div><small>Saldo devedor</small><b>{{ dollars(l.principalOutstanding, true) }}</b></div>
            <div><small>Parcela</small><b>{{ dollars(l.perPayment, true) }}</b></div>
            <div><small>Próxima cobrança</small><b>{{ dollars(l.nextPaymentDue ?? l.perPayment, true) }}</b><em>em {{ countdown(secondsLeft(l)) }}</em></div>
            <div><small>Taxa</small><b>{{ pct(l.currentRate ?? l.rate) }}</b></div>
            <div><small>Juros restantes</small><b>{{ dollars(l.interestRemaining, true) }}</b></div>
            <div v-if="l.prepaidCredit > 0"><small>Adiantado na parcela</small><b>{{ dollars(l.prepaidCredit, true) }}</b></div>
          </div>
          <div class="bk-prepay">
            <span class="rl-muted">Pagamento antecipado:</span>
            <input v-model.number="prepay[l.id]" class="rl-input bk-num" type="number" min="0" :max="payoffAmount(l)" step="100" placeholder="Valor ($)"
              @focus="typing(true)" @blur="typing(false)" />
            <button class="rl-btn" :disabled="busy || !(prepay[l.id] > 0)" @click="askPrepay(l, prepay[l.id])">Pagar</button>
            <button class="rl-btn primary" :disabled="busy || payoffAmount(l) <= 0" @click="askPrepay(l, payoffAmount(l), true)">Quitar {{ dollars(payoffAmount(l), true) }}</button>
          </div>
          <div v-if="confirmPay && confirmPay.id === l.id" class="bk-confirm">
            <p>{{ confirmPay.full ? "Quitar" : "Antecipar" }} <b>{{ dollars(confirmPay.amount, true) }}</b> do empréstimo com {{ l.orgName || l.orgId }}?
              <template v-if="confirmPay.full && confirmPay.amount < fullOwed(l)"> Seu saldo não cobre tudo: o restante continua nas parcelas.</template></p>
            <div class="rl-row">
              <button class="rl-btn go" :disabled="busy" @click="doPrepay(l)">Confirmar pagamento</button>
              <button class="rl-btn" :disabled="busy" @click="confirmPay = null">Cancelar</button>
            </div>
          </div>
          <p v-if="payError[l.id]" class="rl-error">{{ payError[l.id] }}</p>
        </article>
      </section>

      <!-- Mortgages (read only) -->
      <section v-else-if="tab === 'mortgages'">
        <p class="rl-muted">Financiamentos de imóveis (garagens) são cobrados automaticamente. Eles aparecem aqui só para consulta.</p>
        <table class="rl-table">
          <thead><tr><th>Imóvel</th><th>Parcela</th><th>Parcelas restantes</th><th>Saldo devedor</th><th>Valor financiado</th><th>Taxa</th><th>Próxima</th></tr></thead>
          <tbody><tr v-for="m in mortgages" :key="m.garageId">
            <td><b>{{ m.garageName }}</b><span v-if="m.missedPayments > 0" class="rl-badge bad bk-missed">{{ m.missedPayments }} atrasada(s)</span></td>
            <td>{{ dollars(m.monthlyPayment, true) }}</td>
            <td>{{ m.remainingPayments }}</td>
            <td>{{ dollars(m.remainingBalance, true) }}</td>
            <td>{{ dollars(m.principal, true) }}</td>
            <td>{{ pct(m.interestRate) }}</td>
            <td>{{ m.secondsUntilNextPayment != null ? countdown(mortgageSeconds(m)) : "—" }}</td>
          </tr></tbody>
        </table>
      </section>
    </div>

    <footer class="bk-foot">
      <label class="bk-notif"><input v-model="notifications" type="checkbox" @change="setNotifications" /> Avisos de cobrança no celular</label>
      <span class="rl-muted">Parcelas a cada 10 minutos de jogo. Atraso derruba o score de crédito.</span>
    </footer>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaValue, onGameEvent, dollars, arr, typing, toast, dateTime } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])

const PAYMENT_INTERVAL_MIN = 10
const TIERS = { Excellent: "Excelente", Good: "Bom", Fair: "Regular", Poor: "Baixo", Bad: "Ruim" }
const LOAN_ERRORS = {
  invalid_org: "Instituição indisponível.", no_offer: "Esta oferta não está mais disponível.",
  term_not_available: "Esse prazo não está liberado para o seu score de crédito.",
}
const PAY_ERRORS = {
  invalid_amount: "Informe um valor válido.", loan_not_found: "Empréstimo não encontrado (talvez já quitado).",
  nothing_owed: "Não há nada a pagar neste empréstimo.", insufficient_funds: "Saldo insuficiente para esse pagamento.",
  pay_failed: "O pagamento não foi concluído.",
}

const hosted = computed(() => !!props.route)
const fn = computed(() => rl.view.computer?.computerFunctions?.general?.loans)
const tab = ref("new")
const loaded = ref(false)
const busy = ref(false)
const offers = ref([])
const orgId = ref(null)
const amount = ref(0)
const amountInput = ref(0)
const term = ref(null)
const loans = ref([])
const loansAt = ref(Date.now())
const mortgages = ref([])
const mortgagesAt = ref(Date.now())
const funds = ref(0)
const notifications = ref(true)
const credit = reactive({ score: null, tier: null })
const prepay = reactive({})
const payError = reactive({})
const loanError = ref("")
const confirmLoan = ref(false)
const confirmPay = ref(null)
const now = ref(Date.now())
let timer, offs = []

// engineLua callbacks never fire when the Lua side errors: never wait forever.
function callT(expr, ms = 8000) { return Promise.race([luaCall(expr), new Promise(r => setTimeout(() => r(undefined), ms))]) }
function label(l) { return typeof l === "string" ? l : l?.txt || l?.label || "" }
function reasonText(f) { return label(f?.reason?.label) || label(f?.reason) }
function launch() { request("native", { buttonId: "loans" }) }
function pct(r) { return ((Number(r) || 0) * 100).toFixed(1).replace(/\.0$/, "").replace(".", ",") + "%" }
function tierName(t) { return TIERS[t] || t || "—" }
function tierClass(t) { return t === "Excellent" || t === "Good" ? "ok" : t === "Fair" ? "warn" : t ? "bad" : "" }
function termDuration(n) {
  const minutes = n * PAYMENT_INTERVAL_MIN, h = Math.floor(minutes / 60), m = minutes % 60
  return (h ? h + " h" : "") + (h && m ? " " : "") + (m ? m + " min" : "")
}
function countdown(s) {
  if (s == null) return "breve"
  const d = Math.max(0, Math.floor(s)), m = Math.floor(d / 60), r = d % 60
  return m > 0 ? m + " min " + String(r).padStart(2, "0") + " s" : r + " s"
}
const r2 = n => Math.round((Number(n) || 0) * 100) / 100

const offer = computed(() => offers.value.find(o => o.id === orgId.value))
const maxAmount = computed(() => Math.max(0, Math.floor((offer.value?.max || 0) / 500) * 500))
const terms = computed(() => arr(offer.value?.terms).map(Number).filter(n => n > 0))
// Same rate the RLS screen sends: longer terms add 10% of the base rate per extra year.
const adjustedRate = computed(() => {
  const base = offer.value?.rate || 0
  if (!term.value) return base
  const step = term.value / 12 - 1
  return base * (step > 0 ? 1 + 0.1 * step : 1)
})
// Mirrors loans.calculatePayment(amount, rate, payments).
const preview = computed(() => {
  if (!term.value || amount.value <= 0) return { per: 0, total: 0 }
  const per = r2((amount.value / term.value) * (1 + adjustedRate.value))
  return { per, total: r2(per * term.value) }
})
const canTake = computed(() => !!offer.value && amount.value > 0 && amount.value <= (offer.value?.max || 0) && !!term.value)
const totalOwed = computed(() => loans.value.reduce((s, l) => s + (Number(l.principalOutstanding) || 0), 0))
const nextDue = computed(() => {
  let best = null
  for (const l of loans.value) {
    const s = secondsLeft(l)
    if (!best || s < best.seconds) best = { seconds: s, amount: l.nextPaymentDue ?? l.perPayment }
  }
  return best
})
const scorePct = computed(() => Math.max(0, Math.min(100, ((Number(credit.score) || 300) - 300) / 550 * 100)))

function secondsLeft(l) { return Math.max(0, (Number(l.secondsUntilNextPayment) || 0) - (now.value - loansAt.value) / 1000) }
function mortgageSeconds(m) { return Math.max(0, (Number(m.secondsUntilNextPayment) || 0) - (now.value - mortgagesAt.value) / 1000) }
function paidPct(l) {
  const p = Number(l.principal) || 0
  if (p <= 0) return 0
  return Math.max(0, Math.min(100, Math.round((1 - (Number(l.principalOutstanding) || 0) / p) * 100)))
}
function interestNow(l) { return Math.max(0, l.nextPaymentInterest ?? Math.max(0, (l.perPayment || 0) - (l.basePayment || 0))) }
function fullOwed(l) { return Math.ceil((Number(l.principalOutstanding) || 0) + interestNow(l) - 1e-6) }
// "Quitar": everything owed now, limited to what the player can pay.
function payoffAmount(l) { return Math.max(0, Math.min(Math.floor(funds.value || 0), fullOwed(l))) }

function setAmount(v) {
  const max = maxAmount.value
  amount.value = Math.max(0, Math.min(max, Math.round((Number(v) || 0) / 500) * 500))
}
function commitAmount() { setAmount(amountInput.value) }
watch(amount, v => { amountInput.value = v; confirmLoan.value = false; loanError.value = "" })
watch(term, () => { confirmLoan.value = false })

function selectOffer(id) {
  orgId.value = id
  confirmLoan.value = false
  loanError.value = ""
  term.value = terms.value[0] || null
  setAmount(Math.min(maxAmount.value, 5000))
}
function syncOfferLimits() {
  if (!offer.value) { term.value = null; amount.value = 0; return }
  if (!terms.value.includes(term.value)) term.value = terms.value[0] || null
  if (amount.value > maxAmount.value) amount.value = maxAmount.value
}

async function refreshOffers() {
  const res = arr(await callT("career_modules_loans.getLoanOffers()"))
  offers.value = res
  const first = res[0]
  if (first && first.creditScore != null) { credit.score = first.creditScore; credit.tier = first.creditTier }
  if (!res.find(o => o.id === orgId.value)) { if (res[0]) selectOffer(res[0].id); else orgId.value = null }
  else syncOfferLimits()
  if (!res.length && credit.score == null) {
    const s = await callT("career_modules_credit and career_modules_credit.getScore and career_modules_credit.getScore() or nil")
    if (s && s.score != null) { credit.score = s.score; credit.tier = s.tier?.label }
  }
}
function setLoans(list) {
  loans.value = arr(list)
  loansAt.value = Date.now()
  for (const id of Object.keys(prepay)) if (!loans.value.some(l => l.id === id)) delete prepay[id]
}
async function refreshLoans() { setLoans(await callT("career_modules_loans.getActiveLoans()")) }
async function refreshMortgages() {
  const data = await callT("career_modules_propertyMortgage and career_modules_propertyMortgage.getAllMortgages and career_modules_propertyMortgage.getAllMortgages() or {}")
  const out = []
  if (data && typeof data === "object") {
    for (const [garageId, m] of Object.entries(data)) {
      if (!m || typeof m !== "object") continue
      out.push({
        garageId, garageName: m.garageName || garageId, monthlyPayment: m.monthlyPayment || 0,
        remainingBalance: m.remainingBalance ?? m.principal ?? 0, remainingPayments: m.remainingPayments || 0,
        interestRate: m.interestRate || 0, missedPayments: m.missedPayments || 0,
        secondsUntilNextPayment: m.secondsUntilNextPayment ?? null, principal: m.principal || 0,
      })
    }
  }
  mortgages.value = out
  mortgagesAt.value = Date.now()
  if (!out.length && tab.value === "mortgages") tab.value = "loans"
}
async function refreshFunds() { const f = await callT("career_modules_loans.getAvailableFunds()"); if (typeof f === "number") funds.value = f }

async function takeLoan() {
  if (!canTake.value || busy.value) return
  busy.value = true
  loanError.value = ""
  try {
    const res = await callT("career_modules_loans.takeLoan(" + luaValue(orgId.value) + ", " + Math.floor(amount.value) + ", " + Number(term.value)
      + ", " + Number(adjustedRate.value) + ", false, nil)")
    if (!res || res.error) {
      const err = res?.error
      loanError.value = err === "invalid_amount" ? "O valor deve ficar entre $1 e " + dollars(res?.max ?? offer.value?.max ?? 0) + "."
        : LOAN_ERRORS[err] || "Não foi possível contratar" + (err ? " (" + err + ")." : ".")
      return
    }
    toast("Empréstimo aprovado: " + dollars(amount.value) + " creditados no seu saldo.")
    confirmLoan.value = false
    await Promise.all([refreshLoans(), refreshOffers(), refreshFunds()])
    tab.value = "loans"
  } finally { busy.value = false }
}

function askPrepay(l, value, full = false) {
  const amt = Math.max(0, Math.floor(Number(value) || 0))
  payError[l.id] = ""
  if (!amt) { payError[l.id] = PAY_ERRORS.invalid_amount; return }
  if (amt > (funds.value || 0)) { payError[l.id] = PAY_ERRORS.insufficient_funds; return }
  confirmPay.value = { id: l.id, amount: amt, full }
}
async function doPrepay(l) {
  const c = confirmPay.value
  if (!c || busy.value) return
  busy.value = true
  try {
    const res = await callT("career_modules_loans.prepayLoan(" + luaValue(String(l.id)) + ", " + c.amount + ")")
    if (!res || res.error) { payError[l.id] = PAY_ERRORS[res?.error] || "Pagamento recusado."; return }
    // A payoff is announced by the loans:completed event.
    if (res.status !== "paid_off") toast("Pagamento de " + dollars(c.amount, true) + " aplicado.")
    prepay[l.id] = null
    confirmPay.value = null
    await Promise.all([refreshLoans(), refreshOffers(), refreshFunds()])
  } finally { busy.value = false }
}
async function setNotifications() {
  await callT("career_modules_loans.setNotificationsEnabled(" + (notifications.value ? "true" : "false") + ")")
}

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  luaCall("career_modules_loans.closeMenu()")
}
defineExpose({ requestClose })

onMounted(async () => {
  if (!hosted.value) return
  emit("title", "Empréstimos")
  timer = setInterval(() => { now.value = Date.now() }, 1000)
  offs.push(onGameEvent("loans:activeUpdated", async () => { await refreshLoans(); await refreshMortgages(); await refreshOffers() }))
  // Ticks arrive every ~5 s; offers only change when a balance moved (getLoanOffers also re-saves the credit score).
  offs.push(onGameEvent("loans:tick", data => {
    if (!data || typeof data !== "object") return
    const before = loans.value.map(l => l.id + ":" + l.principalOutstanding).join("|")
    setLoans(data)
    if (loans.value.map(l => l.id + ":" + l.principalOutstanding).join("|") !== before) refreshOffers()
  }))
  offs.push(onGameEvent("loans:funds", v => { if (typeof v === "number") funds.value = v }))
  offs.push(onGameEvent("loans:completed", async p => { toast("Empréstimo com " + (p?.orgName || "o banco") + " quitado!"); await refreshLoans(); await refreshOffers() }))
  offs.push(onGameEvent("credit:updated", p => { if (p?.score != null) { credit.score = p.score; credit.tier = p.tier?.label || credit.tier } refreshOffers() }))
  offs.push(onGameEvent("loans:notificationsUpdated", v => { notifications.value = !!v }))
  try {
    await refreshOffers()
    await refreshLoans()
    await refreshMortgages()
    await refreshFunds()
    const n = await callT("career_modules_loans.getNotificationsEnabled()")
    if (typeof n === "boolean") notifications.value = n
    if (!offers.value.length && loans.value.length) tab.value = "loans"
  } finally { loaded.value = true }
})
onUnmounted(() => { clearInterval(timer); offs.forEach(off => off()); offs = []; typing(false) })
</script>

<style scoped>
.small { font-size: 11.5px; }
.between { justify-content: space-between; }
.bk-launch .bk-intro { display: flex; gap: 18px; padding: 10px 4px; }
.bk { height: 100%; display: flex; flex-direction: column; background: #fff; }
.bk-head { display: flex; justify-content: space-between; align-items: center; gap: 16px; padding: 12px 20px; color: #fff; flex-wrap: wrap;
  background: linear-gradient(180deg, #1a6b4f 0%, #12553e 60%, #0d4331 100%); border-bottom: 3px solid #e2b23a; }
.bk-brand { display: flex; align-items: center; gap: 12px; }
.bk-brand b { display: block; font: bold 22px "Trebuchet MS", Tahoma, sans-serif; letter-spacing: .5px; }
.bk-brand small { font-size: 11.5px; opacity: .85; }
.bk-logo { width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #12553e;
  background: radial-gradient(circle at 35% 30%, #fff3c4, #e2b23a 70%); box-shadow: 0 2px 5px rgba(0,0,0,.35); flex-shrink: 0; }
.bk-logo.big { width: 84px; height: 84px; font-size: 46px; }
.bk-score { min-width: 200px; }
.bk-score small { font-size: 11px; opacity: .85; text-transform: uppercase; letter-spacing: 1px; }
.bk-score-row { display: flex; align-items: center; gap: 8px; }
.bk-score-row b { font-size: 24px; }
.bk-gauge { position: relative; height: 8px; margin-top: 4px; border-radius: 4px; background: linear-gradient(90deg, #d9412b, #f0a43a 40%, #e8d64a 60%, #5cbf4a 85%); }
.bk-gauge i { position: absolute; top: -3px; width: 4px; height: 14px; margin-left: -2px; background: #fff; border-radius: 2px; box-shadow: 0 0 2px #000; }
.bk-body { flex: 1; min-height: 0; overflow: auto; padding: 10px 20px 16px; }
.bk-count { margin-left: 6px; background: #12553e; color: #fff; border-radius: 8px; padding: 0 6px; font-size: 11px; font-weight: normal; }
.bk-new { display: grid; grid-template-columns: minmax(240px, 1fr) minmax(320px, 1.4fr); gap: 16px; align-items: start; }
@media (max-width: 860px) { .bk-new { grid-template-columns: 1fr; } }
.bk-offers { display: flex; flex-direction: column; gap: 6px; }
.bk-offers .rl-h2 { margin-top: 4px; }
.bk-offer { display: flex; align-items: center; gap: 10px; padding: 9px 10px; border: 1px solid #c9d7e8; border-radius: 4px; background: linear-gradient(180deg, #fff, #f3f7fb);
  cursor: pointer; text-align: left; font: 12px Tahoma, sans-serif; color: #1b2733; }
.bk-offer:hover { border-color: #f8b636; }
.bk-offer.on { border-color: #12553e; background: #e8f5ef; box-shadow: inset 3px 0 0 #12553e; }
.bk-offer-icon { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; color: #fff; background: #1a6b4f; flex-shrink: 0; }
.bk-offer-text { flex: 1; display: flex; flex-direction: column; gap: 2px; }
.bk-offer-text b { font-size: 13px; }
.bk-offer-text small { color: #5f7186; }
.bk-calc { margin-top: 0; background: #fbfdfc; border-color: #b9d8c9; }
.rl-h2.first { margin-top: 0; }
.bk-amount { display: flex; justify-content: space-between; align-items: baseline; }
.bk-amount small, .bk-label { font-size: 11px; color: #4e6276; text-transform: uppercase; letter-spacing: .6px; }
.bk-amount b { font: bold 26px "Trebuchet MS", Tahoma, sans-serif; color: #12553e; }
.bk-range { width: 100%; margin: 6px 0; accent-color: #1a6b4f; }
.bk-amount-row { margin-bottom: 4px; }
.bk-num { width: 120px; }
.bk-terms { display: grid; grid-template-columns: repeat(auto-fit, minmax(80px, 1fr)); gap: 6px; margin: 4px 0 12px; }
.bk-term { display: flex; flex-direction: column; align-items: center; padding: 7px 4px; border: 1px solid #a9bccf; border-radius: 3px; cursor: pointer;
  background: linear-gradient(180deg, #fff, #ecebe6); font: 12px Tahoma, sans-serif; color: #1b2733; }
.bk-term b { font-size: 15px; }
.bk-term small { color: #5f7186; }
.bk-term.on { border-color: #12553e; background: #12553e; color: #fff; }
.bk-term.on small { color: #d8efe3; }
.bk-summary { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-bottom: 10px; }
.bk-summary td { padding: 5px 2px; border-bottom: 1px dotted #c7d3df; }
.bk-summary td:last-child { text-align: right; }
.bk-summary tr.total td { border-bottom: 0; border-top: 2px solid #12553e; font-weight: bold; font-size: 14px; color: #12553e; }
.bk-take { width: 100%; padding: 8px; }
.bk-confirm { border: 1px solid #e8c76c; background: #fff8dc; border-radius: 3px; padding: 8px 10px; margin: 6px 0; }
.bk-confirm p { margin: 0 0 8px; line-height: 1.45; }
.bk-loan-title { display: flex; flex-direction: column; gap: 2px; }
.bk-loan-title b { font-size: 14px; color: #12553e; }
.bk-progress-row { display: flex; align-items: center; gap: 10px; margin: 8px 0; }
.bk-progress-row .rl-progress { flex: 1; }
.bk-progress-row small { min-width: 60px; text-align: right; color: #4e6276; }
.bk-kv { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px 14px; }
.bk-kv div { display: flex; flex-direction: column; }
.bk-kv small { font-size: 11px; color: #5f7186; }
.bk-kv b { font-size: 13.5px; }
.bk-kv em { font-style: normal; font-size: 11px; color: #9a5b00; }
.bk-prepay { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-top: 10px; padding-top: 8px; border-top: 1px solid #dde6ef; }
.bk-missed { margin-left: 6px; }
.bk-foot { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; padding: 6px 14px; background: #ece9d8; border-top: 1px solid #aca899; font-size: 12px; }
.bk-notif { display: flex; align-items: center; gap: 6px; cursor: pointer; }
</style>
