<template>
  <div class="mail">
    <aside class="folders">
      <button class="rl-btn primary" @click="composeTo('')">Nova mensagem</button>
      <button v-for="f in folders" :key="f.id" class="folder" :class="{ on: folder === f.id }" @click="folder = f.id; selected = null">
        {{ f.label }} <b v-if="f.count">({{ f.count }})</b></button>
    </aside>
    <section class="list">
      <div v-if="!items.length" class="rl-empty"><b>Nada por aqui</b>Avisos de visitas, vendas e serviços chegam nesta caixa.</div>
      <button v-for="m in items" :key="m.id" class="item" :class="{ unread: !m.read && m.to === me.id, on: selected?.id === m.id }" @click="openMsg(m)">
        <b>{{ m.from === "system" ? "RiverLife" : (m.from === me.id ? "Para: " + nameOf(m.to) : (m.fromName || nameOf(m.from))) }}</b>
        <span>{{ m.subject || "(sem assunto)" }}</span><small>{{ ago(m.createdAt) }}</small>
      </button>
    </section>
    <section class="read">
      <template v-if="composing">
        <form class="rl-form" @submit.prevent="send">
          <b>Nova mensagem</b>
          <label>Para
            <XPSelect v-model="draft.to" placeholder="Escolha um jogador" :options="recipients.map(a => ({ value: a.id, label: a.name + (online(a.id) ? ' · online' : '') }))" /></label>
          <label>Assunto<input v-model.trim="draft.subject" class="rl-input" maxlength="120" /></label>
          <label>Mensagem<textarea v-model="draft.body" class="rl-input" rows="7" maxlength="1000" required></textarea></label>
          <div class="rl-row"><button class="rl-btn primary" :disabled="rl.busy.message">Enviar</button><button type="button" class="rl-btn" @click="composing = false">Descartar</button></div>
        </form>
      </template>
      <template v-else-if="selected">
        <h3>{{ selected.subject || "(sem assunto)" }}</h3>
        <p class="rl-muted">De {{ selected.from === "system" ? "RiverLife" : (selected.fromName || nameOf(selected.from)) }} · {{ dateTime(selected.createdAt) }}</p>
        <p class="body">{{ selected.body }}</p>
        <div class="rl-row">
          <button v-if="selected.from !== 'system' && selected.from !== me.id" class="rl-btn primary" @click="composeTo(selected.from, 'Re: ' + (selected.subject || ''))">Responder</button>
          <button v-if="selected.meta?.receiptId" class="rl-btn" @click="$emit('open', 'finance')">Ver extrato</button>
          <button v-if="selected.meta?.visitId" class="rl-btn" @click="$emit('open', 'agenda')">Abrir agenda</button>
          <button v-if="selected.meta?.orderId" class="rl-btn" @click="$emit('open', myShop ? 'workshop' : { app: 'internet', props: { start: 'oficinas' } })">Ver serviço</button>
          <button v-if="selected.meta?.npcId" class="rl-btn" @click="$emit('open', 'store')">Ver cliente</button>
        </div>
      </template>
      <div v-else class="rl-empty"><b>Selecione uma mensagem</b></div>
    </section>
  </div>
</template>

<script setup>
import XPSelect from "../components/XPSelect.vue"
import { computed, reactive, ref, watch } from "vue"
import { rl, request, ago, dateTime, me, myShop, toast } from "../rl.js"
const props = defineProps({ to: String, nonce: Number })
defineEmits(["open"])
const folder = ref("inbox"), selected = ref(null), composing = ref(false)
const draft = reactive({ to: "", subject: "", body: "" })
const messages = computed(() => rl.view.messages || [])
const folders = computed(() => [
  { id: "inbox", label: "Caixa de entrada", count: messages.value.filter(m => m.to === me.value.id && !m.read).length },
  { id: "system", label: "Avisos do RiverLife" },
  { id: "sent", label: "Enviadas" },
])
const items = computed(() => {
  if (folder.value === "sent") return messages.value.filter(m => m.from === me.value.id)
  if (folder.value === "system") return messages.value.filter(m => m.from === "system")
  return messages.value.filter(m => m.to === me.value.id)
})
const recipients = computed(() => (rl.view.accounts || []).filter(a => a.id !== me.value.id))
function nameOf(id) { return (rl.view.accounts || []).find(a => a.id === id)?.name || "jogador" }
function online(id) { return (rl.view.players || []).some(p => p.account === id) }
function openMsg(m) {
  selected.value = m; composing.value = false
  if (!m.read && m.to === me.value.id) request("markRead", { ids: [m.id] })
}
function composeTo(to, subject = "") { draft.to = to || ""; draft.subject = subject; draft.body = ""; composing.value = true; selected.value = null }
function send() {
  if (!draft.to) { toast("Escolha para quem enviar.", "warning"); return }
  request("message", { to: draft.to, subject: draft.subject || undefined, body: draft.body }); composing.value = false; folder.value = "sent"
}
watch(() => [props.to, props.nonce], () => { if (props.to) composeTo(props.to) }, { immediate: true })
</script>

<style scoped>
.mail { display: grid; grid-template-columns: 180px 300px 1fr; height: 100%; min-height: 380px; }
.folders { background: #e7eef8; border-right: 1px solid #b8c9df; padding: 10px 8px; display: grid; align-content: start; gap: 6px; }
.folder { text-align: left; border: 0; background: none; padding: 6px 8px; cursor: pointer; font: 12px Tahoma, sans-serif; border-radius: 3px; }
.folder.on { background: #316ac5; color: #fff; }
.list { border-right: 1px solid #c9d7e8; overflow: auto; }
.item { display: grid; width: 100%; text-align: left; gap: 2px; padding: 8px 10px; border: 0; border-bottom: 1px solid #e3e8ef; background: #fff; cursor: pointer; font: 12px Tahoma, sans-serif; }
.item.unread b, .item.unread span { font-weight: bold; color: #0c3a7d; }
.item.on { background: #dbe8fb; } .item small { color: #7a8796; }
.read { padding: 14px 18px; overflow: auto; } .read h3 { margin: 0 0 4px; color: #12407c; }
.body { white-space: pre-wrap; line-height: 1.55; background: #fafcff; border: 1px solid #e0e8f2; padding: 10px 12px; border-radius: 4px; }
@media (max-width: 700px) { .mail { grid-template-columns: 1fr; } .folders { display: flex; flex-wrap: wrap; } }
</style>
