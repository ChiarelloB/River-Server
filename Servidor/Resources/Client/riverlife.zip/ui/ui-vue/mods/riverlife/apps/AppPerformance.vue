<template>
  <div class="rl-page perf" :class="{ testing }">
    <template v-if="testing">
      <h2 class="rl-h1">Teste de certificação</h2>
      <p class="rl-muted">O carro está na pista de arrancada. Acompanhe na tela; o resultado aparece aqui quando o teste terminar.</p>
      <div class="rl-progress run"><i></i></div>
      <div class="rl-row"><button class="rl-btn danger" :disabled="cancelling" @click="cancel">Cancelar teste</button></div>
    </template>

    <template v-else-if="!route">
      <h2 class="rl-h1">Desempenho</h2>
      <p class="rl-muted">Certifique um carro para saber a classe e o índice de desempenho (usados em corridas e eventos).</p>
      <div v-if="!launchers.length" class="rl-empty"><b>Nenhum carro nesta garagem</b>Traga um carro para a garagem para certificar.</div>
      <div v-for="v in launchers" :key="v.inventoryId" class="rl-box rl-row between">
        <b>{{ v.vehicleName || v.niceName }}</b>
        <button class="rl-btn primary" :disabled="v.fn.disabled" :title="v.fn.reason?.label || ''" @click="request('native', { buttonId: 'performanceIndex', inventoryId: v.inventoryId })">Abrir</button>
      </div>
    </template>

    <template v-else>
      <div v-if="!veh" class="rl-empty"><b>{{ loadFailed ? "Não foi possível ler este carro" : "Carregando o carro..." }}</b>{{ loadFailed ? "Feche e abra o Desempenho de novo pela garagem." : "" }}</div>
      <template v-else>
        <header class="head">
          <img v-if="veh.thumbnail" :src="veh.thumbnail" alt="" />
          <div>
            <h2 class="rl-h1">{{ veh.niceName }}</h2>
            <p class="rl-muted">{{ cert ? "Certificado" : "Ainda sem certificação" }}{{ veh.savedVehicleClassUi?.label ? " · " + veh.savedVehicleClassUi.label : "" }}</p>
          </div>
          <div v-if="klass" class="klass"><b>{{ klass.name }}</b><small>PI {{ pi }}</small></div>
        </header>

        <div class="rl-stats">
          <div><b>{{ fmt(cert?.power ?? veh.power, 0) }} cv</b><small>Potência</small></div>
          <div><b>{{ fmt(cert?.weight ?? veh.weight, 0) }} kg</b><small>Peso</small></div>
          <div><b>{{ fmt(cert?.torque ?? veh.torque, 0) }} Nm</b><small>Torque</small></div>
          <div v-if="cert?.powerPerTon"><b>{{ fmt(cert.powerPerTon, 0) }}</b><small>cv por tonelada</small></div>
          <div v-if="cert?.drivetrain"><b>{{ cert.drivetrain }}</b><small>Tração</small></div>
          <div v-if="cert?.fuelType"><b>{{ cert.fuelType }}</b><small>Combustível</small></div>
          <div v-if="cert?.inductionType"><b>{{ cert.inductionType }}</b><small>Aspiração</small></div>
          <div v-if="cert?.lateralGForce"><b>{{ fmt(cert.lateralGForce, 2) }} g</b><small>Aceleração lateral</small></div>
        </div>

        <template v-if="scores.length">
          <h3 class="rl-h2">Notas por categoria</h3>
          <div v-for="s in scores" :key="s.key" class="score">
            <span>{{ s.label }}</span><div class="rl-progress"><i :style="{ width: s.pct + '%' }"></i></div><b>{{ fmt(s.value, 0) }}</b>
          </div>
        </template>

        <div class="rl-box">
          <b>Teste de certificação</b>
          <p class="rl-muted">O carro vai para a pista de arrancada (aceleração, frenagem e curva). Danos graves cancelam o teste.</p>
          <p v-if="!canTest" class="rl-error">{{ testBlock }}</p>
          <div class="rl-row"><button class="rl-btn primary" :disabled="!canTest || starting" @click="start">Certificar agora</button>
            <button class="rl-btn" @click="requestClose">Voltar</button></div>
        </div>

        <template v-if="history.length">
          <h3 class="rl-h2">Certificações anteriores</h3>
          <table class="rl-table">
            <tr><th>Classe</th><th>PI</th><th>Potência</th><th>Peso</th></tr>
            <tr v-for="(h, i) in history" :key="i"><td>{{ h.vehicleClass?.class?.name || h.vehicleClass?.label || "—" }}</td>
              <td>{{ h.vehicleClass?.performanceIndex != null ? fmt(h.vehicleClass.performanceIndex, 0) : "—" }}</td>
              <td>{{ fmt(h.power, 0) }} cv</td><td>{{ fmt(h.weight, 0) }} kg</td></tr>
          </table>
        </template>
      </template>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from "vue"
import { rl, request, luaCall, arr } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const veh = ref(null), map = ref(""), starting = ref(false), cancelling = ref(false), loadFailed = ref(false)

const testing = computed(() => props.route === "career.computer.vehiclePerformance.certificationTest")
const launchers = computed(() => (rl.view.computer?.vehicles || []).map(v => ({ ...v, fn: rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.performanceIndex }))
  .filter(v => v.fn))
const cert = computed(() => veh.value?.certificationData || null)
const klass = computed(() => cert.value?.vehicleClass?.class || (veh.value?.savedVehicleClassUi ? { name: veh.value.savedVehicleClassUi.label } : null))
const pi = computed(() => fmt(cert.value?.vehicleClass?.performanceIndex ?? veh.value?.savedVehicleClassUi?.performanceIndex, 0))
const scores = computed(() => {
  const s = cert.value?.performanceAggregateScores || {}
  const names = { acceleration: "Aceleração", braking: "Frenagem", cornering: "Curvas", topSpeed: "Velocidade máxima", handling: "Dirigibilidade", power: "Potência" }
  const list = Object.entries(s).filter(([, v]) => typeof v === "number").map(([key, value]) => ({ key, value, label: names[key] || key }))
  const max = Math.max(100, ...list.map(x => x.value))
  return list.map(x => ({ ...x, pct: Math.max(2, Math.min(100, x.value / max * 100)) }))
})
const history = computed(() => arr(veh.value?.performanceHistory).slice().reverse())
// The RLS drag test uses the West Coast USA strip.
const testBlock = computed(() => veh.value?.needsRepair ? "Conserte o carro antes do teste." : veh.value?.timeToAccess ? "O carro está indisponível agora."
  : map.value && map.value !== "west_coast_usa" ? "A pista de certificação fica em West Coast USA. Faça o teste naquele mapa." : "")
const canTest = computed(() => !testBlock.value)

function fmt(v, d) { const n = Number(v); return isFinite(n) ? n.toLocaleString((window.__rlLocale || "pt-BR"), { maximumFractionDigits: d, minimumFractionDigits: d }) : "—" }
// The route changes when the test starts or ends; if nothing happens, the buttons come back.
async function start() { starting.value = true; await luaCall("career_modules_vehiclePerformance.startDragTest()"); setTimeout(() => (starting.value = false), 8000) }
async function cancel() { cancelling.value = true; await luaCall("career_modules_vehiclePerformance.cancelTest()"); setTimeout(() => (cancelling.value = false), 8000) }
function requestClose() {
  if (testing.value) return cancel()
  luaCall("extensions.ui_router.back()")
}
defineExpose({ requestClose })

onMounted(async () => {
  if (!props.route || testing.value) return
  map.value = (await luaCall("getCurrentLevelIdentifier()")) || ""
  veh.value = await luaCall("career_modules_vehiclePerformance.getActiveVehicleUiData()")
  if (!veh.value) loadFailed.value = true
  if (veh.value?.niceName) emit("title", veh.value.niceName)
})
</script>

<style scoped>
.between { justify-content: space-between; }
.head { display: flex; gap: 14px; align-items: center; margin-bottom: 6px; }
.head img { width: 200px; height: 112px; object-fit: cover; border-radius: 3px; background: #eef2f7; }
.head > div:nth-child(2) { flex: 1; }
.klass { width: 96px; height: 96px; border-radius: 8px; border: 2px solid #1d4fae; background: linear-gradient(180deg, #5d9bf0, #2259c0); color: #fff;
  display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: inset 0 1px 0 #ffffff80; }
.klass b { font: bold 40px "Trebuchet MS", Tahoma, sans-serif; line-height: 1; } .klass small { font-size: 12px; }
.score { display: grid; grid-template-columns: 150px 1fr 60px; gap: 10px; align-items: center; margin: 5px 0; }
.score b { text-align: right; color: #164a8c; }
.run i { width: 100%; animation: rl-run 1.2s linear infinite; background-size: 20px 100%; }
@keyframes rl-run { from { background-position: 0 0; } to { background-position: 20px 0; } }
.perf.testing { padding: 14px 16px; }
</style>
