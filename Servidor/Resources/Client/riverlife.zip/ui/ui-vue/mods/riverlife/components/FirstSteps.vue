<template>
  <section v-if="visible" class="fs" :class="{ compact }">
    <header>
      <b>Primeiros passos</b>
      <span>{{ doneCount }}/{{ steps.length }} · bônus final {{ money(bonus) }}</span>
    </header>
    <div class="fs-bar"><i :style="{ width: (doneCount / steps.length * 100) + '%' }"></i></div>
    <ul>
      <li v-for="s in steps" :key="s.id" :class="{ done: s.done }">
        <span class="mark">{{ s.done ? "✓" : "" }}</span>
        <div class="txt"><b>{{ s.title }}</b><small>{{ s.hint }}</small></div>
        <span class="reward">+{{ money(s.reward) }}</span>
        <button v-if="!s.done && s.action" class="rl-btn small" :disabled="s.busy" @click="s.action()">{{ s.button }}</button>
      </li>
    </ul>
  </section>
</template>

<script setup>
import { computed, onMounted, onUnmounted } from "vue"
import { rl, request, money, me, onAction, distance, toast } from "../rl.js"

defineProps({ compact: Boolean })
const emit = defineEmits(["go", "open"])
let off

const done = computed(() => me.value.firstSteps || {})
const rewards = computed(() => rl.view.firstSteps?.rewards || {})
const bonus = computed(() => rl.view.firstSteps?.bonus || 0)
const nearestDisplay = computed(() => (rl.view.listings || []).filter(l => l.status === "active" && l.display && l.seller !== me.value.id)
  .sort((a, b) => distance(rl.view.position, a.position) - distance(rl.view.position, b.position))[0])
const myGig = computed(() => (rl.view.gigs || []).find(g => g.taker === me.value.id && g.status === "taken"))
const steps = computed(() => [
  { id: "view", title: "Abra um anúncio nos classificados", hint: "Veja fotos, preço e onde o carro está.", button: "Ver anúncios",
    action: () => emit("go", "classificados") },
  { id: "news", title: "Leia o Jornal do River", hint: "Notícias, rankings e a Tabela FIPE do River.", button: "Abrir jornal",
    action: () => emit("open", "news") },
  { id: "walkIn", title: "Faça uma proposta num carro com placa", hint: "Vá até um carro exposto e aperte U perto dele.",
    button: nearestDisplay.value ? "GPS até um carro" : "", action: nearestDisplay.value ? () => request("gps", { position: nearestDisplay.value.position }) : null },
  { id: "gig", title: "Complete um bico de translado", hint: myGig.value ? "Bico em andamento: siga o GPS e estacione no destino." : "Leve um carro de um ponto a outro do mapa.",
    button: "Bico perto de mim", busy: rl.busy.starterGig || rl.busy.gigTake, action: myGig.value ? null : () => request("starterGig") },
].map(s => ({ ...s, reward: rewards.value[s.id] || 0, done: !!done.value[s.id] })))
const doneCount = computed(() => steps.value.filter(s => s.done).length)
const visible = computed(() => rl.view.careerActive && rl.view.firstSteps && !done.value.bonus)

onMounted(() => {
  off = onAction(e => {
    if (e?.op !== "starterGig") return
    if (e.result?.ok) {
      const g = e.result.data
      request("gigTake", { gigId: g.id })
      toast("Bico reservado para você: " + g.title + ". Siga o GPS até o carro.")
    }
  })
})
onUnmounted(() => off && off())
</script>

<style scoped>
.fs { border: 1px solid #e8c76c; border-radius: 6px; background: linear-gradient(180deg, #fffbea, #fff4cf); padding: 10px 12px; margin: 0 0 14px; }
.fs header { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; }
.fs header b { color: #7b5600; font-size: 14px; } .fs header span { font-size: 11.5px; color: #8a6d1d; }
.fs-bar { height: 6px; border-radius: 3px; background: #f1e2a6; margin: 6px 0 8px; overflow: hidden; }
.fs-bar i { display: block; height: 100%; background: linear-gradient(90deg, #e3a600, #3aa33a); }
.fs ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
.fs li { display: grid; grid-template-columns: 20px 1fr auto auto; gap: 8px; align-items: center; }
.fs li.done { opacity: .6; } .fs li.done b { text-decoration: line-through; }
.mark { width: 18px; height: 18px; border-radius: 50%; border: 1px solid #c9a227; background: #fff; display: flex; align-items: center; justify-content: center; color: #2f8a22; font-weight: bold; font-size: 12px; }
.txt b { display: block; font-size: 12.5px; color: #3d3216; } .txt small { color: #7d6a3a; font-size: 11px; }
.reward { color: #2f8a22; font-weight: bold; font-size: 12px; }
.small { padding: 3px 8px !important; font-size: 11.5px !important; }
.compact li { grid-template-columns: 18px 1fr auto; } .compact .reward { display: none; }
.compact li .rl-btn { grid-column: 2 / -1; justify-self: start; }
</style>
