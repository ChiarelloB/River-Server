<template>
  <!-- Opened from the desktop: start the RLS part inventory session from this garage computer. -->
  <div v-if="!hosted" class="rl-page">
    <header class="ap-head">
      <span class="ap-tile"><BngIcon type="engine" /></span>
      <div><h2 class="rl-h1">Minhas peças</h2><p class="rl-muted">Peças guardadas no estoque e instaladas nos seus carros.</p></div>
    </header>
    <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>O inventário de peças do RLS só funciona em um computador de garagem.</div>
    <div v-else-if="!launchFn" class="rl-empty"><b>Inventário indisponível aqui</b>Este computador não oferece o inventário de peças.</div>
    <div v-else class="rl-box ap-launch">
      <div><b>Inventário de peças</b><p class="rl-muted">{{ launchFn.disabled ? (launchFn.reason?.label || "Indisponível agora.") : "Veja e venda as peças que você tem." }}</p></div>
      <button class="rl-btn primary" :disabled="launchFn.disabled" @click="request('native', { buttonId: 'partInventory' })">Abrir</button>
    </div>
  </div>

  <div v-else class="mp">
    <header class="mp-top">
      <span class="ap-tile"><BngIcon type="engine" /></span>
      <div class="mp-title"><h2 class="rl-h1">Minhas peças</h2>
        <p class="rl-muted">Só as peças <b>no estoque</b> podem ser vendidas. Para tirar uma peça de um carro, use Peças e personalização.</p></div>
    </header>
    <div class="rl-stats mp-stats">
      <div><b>{{ parts.length }}</b><small>Peças no total</small></div>
      <div><b>{{ stock.length }}</b><small>No estoque</small></div>
      <div><b>{{ dollars(stockValue) }}</b><small>Valor do estoque</small></div>
      <div><b>{{ parts.length - stock.length }}</b><small>Instaladas em carros</small></div>
    </div>

    <div class="mp-toolbar">
      <input v-model.trim="search" class="rl-input mp-search" placeholder="Buscar peça ou modelo" @focus="typing(true)" @blur="typing(false)" />
      <XPSelect v-model="filter" aria-label="Filtrar peças" :options="[{ value: 'all', label: 'Todas' }, { value: 'stock', label: 'No estoque' }, { value: 'installed', label: 'Instaladas' },
        ...vehicleOptions.map(v => ({ value: 'veh:' + v.id, label: 'No carro: ' + v.name + ' (' + v.count + ')' }))]" />
      <span class="mp-count rl-muted">{{ shown.length }} peça(s)</span>
      <button class="rl-btn" :disabled="!selectableShown.length || selling" @click="selectAllShown">Selecionar estoque visível</button>
      <button class="rl-btn" :disabled="!selected.size || selling" @click="clearSel">Limpar seleção</button>
    </div>

    <div class="mp-list">
      <div v-if="!loaded" class="rl-empty"><b>{{ stalled ? "As peças não carregaram" : "Carregando peças..." }}</b>{{ stalled ? "" : "Lendo o inventário da carreira." }}
        <div v-if="stalled" class="rl-row" style="justify-content:center;margin-top:8px"><button class="rl-btn" @click="askData">Tentar de novo</button></div></div>
      <div v-else-if="!parts.length" class="rl-empty"><b>Nenhuma peça</b>As peças aparecem aqui quando você compra carros ou troca peças.</div>
      <div v-else-if="!shown.length" class="rl-empty"><b>Nada encontrado</b>Mude a busca ou o filtro.</div>
      <table v-else class="rl-table mp-table">
        <thead>
          <tr>
            <th class="ck"><input type="checkbox" :checked="allShownSelected" :disabled="!selectableShown.length || selling" @change="toggleAllShown" /></th>
            <th class="sort" @click="sortBy('name')">Peça {{ arrow("name") }}</th>
            <th class="sort" @click="sortBy('model')">Modelo {{ arrow("model") }}</th>
            <th class="sort" @click="sortBy('where')">Local {{ arrow("where") }}</th>
            <th class="sort r" @click="sortBy('condition')">Estado {{ arrow("condition") }}</th>
            <th class="sort r" @click="sortBy('mileage')">Rodagem {{ arrow("mileage") }}</th>
            <th class="sort r" @click="sortBy('value')">Valor {{ arrow("value") }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="p in visible" :key="p.id" :class="{ sel: selected.has(p.id), off: !p.sellable }" @click="toggle(p)">
            <td class="ck"><input type="checkbox" :checked="selected.has(p.id)" :disabled="!p.sellable || selling" @click.stop @change="toggle(p)" /></td>
            <td><b>{{ p.title }}</b><small class="mp-code">{{ p.code }}</small></td>
            <td>{{ p.model }}</td>
            <td>
              <span v-if="p.location === 0" class="rl-badge ok">No estoque</span>
              <span v-else class="mp-veh"><BngIcon type="keys1" /> {{ p.where }}<span v-if="!p.accessible" class="rl-badge warn">indisponível</span></span>
            </td>
            <td class="r">
              <template v-if="p.condition != null">
                <div class="mp-cond"><div class="mp-bar" :class="condTone(p.condition)"><i :style="{ width: p.condition + '%' }"></i></div>{{ p.condition }}%</div>
              </template>
              <span v-else class="rl-muted">—</span>
            </td>
            <td class="r">{{ p.mileage != null ? km(p.mileage) : "—" }}</td>
            <td class="r"><b>{{ dollars(p.value) }}</b></td>
          </tr>
        </tbody>
      </table>
      <div v-if="shown.length > limit" class="mp-more"><button class="rl-btn" @click="limit += 200">Mostrar mais ({{ shown.length - limit }} restantes)</button></div>
    </div>

    <footer class="mp-foot">
      <div v-if="confirmSell" class="mp-confirm">
        <b>Vender {{ selectedParts.length }} peça(s) por {{ dollars(selectedTotal) }}? Não dá para desfazer.</b>
        <button class="rl-btn danger" :disabled="selling" @click="sell">Vender</button>
        <button class="rl-btn" :disabled="selling" @click="confirmSell = false">Cancelar</button>
      </div>
      <template v-else>
        <span class="mp-status">{{ selectedParts.length ? selectedParts.length + " selecionada(s) · total " + dollars(selectedTotal) : "Marque as peças do estoque que deseja vender." }}</span>
        <button class="rl-btn go" :disabled="!selectedParts.length || selling" @click="confirmSell = true"><BngIcon type="banknotes" /> Vender selecionadas</button>
        <button class="rl-btn" :disabled="selling" @click="requestClose">Fechar</button>
      </template>
    </footer>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, luaCall, luaDo, luaValue, onGameEvent, dollars, arr, typing, toast, km } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const MOD = "career_modules_partInventory"

const hosted = computed(() => !!props.route)
const payload = ref(null)
const loaded = ref(false), stalled = ref(false)
const search = ref("")
const filter = ref("all")
const sortKey = ref("where")
const sortDir = ref(1)
const limit = ref(200)
const selected = reactive(new Set())
const confirmSell = ref(false)
const selling = ref(false)
let offs = []

const vehiclesMap = computed(() => payload.value?.vehicles || {})
function vehName(id) {
  const v = vehiclesMap.value[String(id)]
  const n = v?.niceName
  return (typeof n === "string" ? n : n?.txt) || v?.model || "Veículo " + id
}
const parts = computed(() => arr(payload.value?.partList).filter(Boolean).map(p => {
  const location = Number(p.location) || 0
  const cond = p.partCondition || {}
  const integrity = Number(cond.integrityValue)
  const desc = p.description?.description
  return {
    id: Number(p.id), raw: p, location,
    title: p.missingFile ? "Arquivo da peça ausente" : (typeof desc === "string" && desc) || p.name || "Peça",
    code: p.name || "", model: p.vehicleModelDisplayName || p.vehicleModel || "",
    where: location === 0 ? "No estoque" : vehName(location),
    condition: Number.isFinite(integrity) ? Math.round(Math.max(0, Math.min(1, integrity)) * 100) : null,
    mileage: Number.isFinite(Number(cond.odometer)) ? Number(cond.odometer) : null,
    value: Number(p.finalValue ?? p.value) || 0,
    accessible: p.accessible !== false,
    sellable: location === 0,
  }
}))
const stock = computed(() => parts.value.filter(p => p.location === 0))
const stockValue = computed(() => stock.value.reduce((s, p) => s + p.value, 0))
const vehicleOptions = computed(() => {
  const by = {}
  for (const p of parts.value) if (p.location !== 0) (by[p.location] = by[p.location] || { id: p.location, name: p.where, count: 0 }).count++
  return Object.values(by).sort((a, b) => a.name.localeCompare(b.name))
})
const shown = computed(() => {
  const q = search.value.toLowerCase()
  const f = filter.value
  const list = parts.value.filter(p => {
    if (f === "stock" && p.location !== 0) return false
    if (f === "installed" && p.location === 0) return false
    if (f.startsWith("veh:") && String(p.location) !== f.slice(4)) return false
    return !q || p.title.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || p.model.toLowerCase().includes(q)
  })
  const k = sortKey.value, d = sortDir.value
  return list.sort((a, b) => {
    let r
    if (k === "where") r = (a.location === 0 ? -1 : 0) - (b.location === 0 ? -1 : 0) || a.where.localeCompare(b.where) || a.title.localeCompare(b.title)
    else if (k === "name") r = a.title.localeCompare(b.title)
    else if (k === "model") r = a.model.localeCompare(b.model) || a.title.localeCompare(b.title)
    else r = (a[k] ?? -1) - (b[k] ?? -1)
    return r * d
  })
})
const visible = computed(() => shown.value.slice(0, limit.value))
const selectableShown = computed(() => shown.value.filter(p => p.sellable))
const allShownSelected = computed(() => selectableShown.value.length > 0 && selectableShown.value.every(p => selected.has(p.id)))
const selectedParts = computed(() => parts.value.filter(p => selected.has(p.id) && p.sellable))
const selectedTotal = computed(() => selectedParts.value.reduce((s, p) => s + p.value, 0))
watch([search, filter], () => { limit.value = 200 })

function sortBy(k) {
  if (sortKey.value === k) sortDir.value = -sortDir.value
  else { sortKey.value = k; sortDir.value = ["value", "condition", "mileage"].includes(k) ? -1 : 1 }
}
function arrow(k) { return sortKey.value === k ? (sortDir.value > 0 ? "▲" : "▼") : "" }
function condTone(c) { return c < 35 ? "bad" : c < 75 ? "warn" : "ok" }
function toggle(p) {
  if (!p.sellable || selling.value) return
  if (selected.has(p.id)) selected.delete(p.id)
  else selected.add(p.id)
  confirmSell.value = false
}
function selectAllShown() { for (const p of selectableShown.value) selected.add(p.id) }
function toggleAllShown() {
  if (allShownSelected.value) for (const p of selectableShown.value) selected.delete(p.id)
  else selectAllShown()
}
function clearSel() { selected.clear(); confirmSell.value = false }

function onData(d) {
  payload.value = d || {}
  loaded.value = true
  // Drop selections for parts that were sold or moved into a car.
  const ids = new Set(stock.value.map(p => p.id))
  for (const id of Array.from(selected)) if (!ids.has(id)) selected.delete(id)
}
async function sell() {
  const list = selectedParts.value
  if (!list.length || selling.value) return
  selling.value = true
  const count = list.length, total = selectedTotal.value
  try {
    // Only parts in storage (location 0); RLS refreshes the list through partInventoryData.
    if (await luaDo(MOD + ".sellParts(" + luaValue(list.map(p => p.id)) + ")")) toast(count + " peça(s) vendida(s) por " + dollars(total) + ".")
    else toast("A venda das peças não foi concluída. Tente de novo.", "error")
    selected.clear()
    confirmSell.value = false
  } finally { selling.value = false }
}

// Launcher
const launchFn = computed(() => rl.view.computer?.computerFunctions?.general?.partInventory || null)

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  if (selling.value) return
  luaCall(MOD + ".closeMenu()")
}
defineExpose({ requestClose })

onMounted(() => {
  if (!hosted.value) return
  offs.push(onGameEvent("partInventoryData", onData))
  askData()
})
// The list comes by event; ask again if it does not arrive, then offer a retry.
function askData() {
  stalled.value = false
  luaCall(MOD + ".sendUIData()")
  setTimeout(() => { if (!loaded.value) luaCall(MOD + ".sendUIData()") }, 4000)
  setTimeout(() => { if (!loaded.value) stalled.value = true }, 12000)
}
onUnmounted(() => {
  offs.forEach(off => off()); offs = []
  typing(false)
  if (hosted.value) luaCall(MOD + ".partInventoryClosed()")
})
</script>

<style scoped>
.ap-head { display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }
.ap-head .rl-h1 { margin: 0; }
.ap-tile { width: 44px; height: 44px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #fff;
  background: linear-gradient(135deg, #b8c6d8, #56667c); box-shadow: 0 2px 4px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.45); flex-shrink: 0; }
.ap-launch { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
.ap-launch p { margin: 4px 0 0; }
.r { text-align: right; }
.mp { display: flex; flex-direction: column; height: 100%; min-height: 420px; }
.mp-top { display: flex; gap: 12px; align-items: center; padding: 14px 18px 4px; }
.mp-title .rl-h1 { margin: 0; }
.mp-title p { margin: 2px 0 0; }
.mp-stats { margin: 6px 18px 8px; }
.mp-toolbar { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; padding: 6px 10px; background: #ece9d8; border-top: 1px solid #fff; border-bottom: 1px solid #aca899; }
.mp-search { width: 230px; }
.mp-count { margin-right: auto; }
.mp-list { flex: 1; min-height: 0; overflow: auto; background: #fff; }
.mp-table thead th { position: sticky; top: 0; z-index: 1; }
.mp-table th.sort { cursor: pointer; white-space: nowrap; }
.mp-table th.sort:hover { background: #f4f2e8; }
.mp-table .ck { width: 28px; text-align: center; }
.mp-table tbody tr { cursor: default; }
.mp-table tbody tr:not(.off) { cursor: pointer; }
.mp-table tbody tr:hover td { background: #f3f7fd; }
.mp-table tbody tr.sel td { background: #dce8fb; }
.mp-table tbody tr.off td { color: #5a6573; }
.mp-code { display: block; color: #8a96a6; font-size: 10.5px; font-family: Consolas, monospace; }
.mp-veh { display: inline-flex; gap: 5px; align-items: center; }
.mp-cond { display: inline-flex; gap: 6px; align-items: center; justify-content: flex-end; }
.mp-bar { width: 60px; height: 8px; border: 1px solid #8f9aa6; border-radius: 2px; padding: 1px; background: #fff; }
.mp-bar i { display: block; height: 100%; background: #36c13c; }
.mp-bar.warn i { background: #e8b42a; } .mp-bar.bad i { background: #d9452f; }
.mp-more { padding: 10px; text-align: center; }
.mp-foot { display: flex; gap: 8px; align-items: center; padding: 8px 12px; background: #ece9d8; border-top: 1px solid #aca899; }
.mp-status { flex: 1; font-size: 12px; color: #3d4b5c; }
.mp-confirm { flex: 1; display: flex; gap: 8px; align-items: center; padding: 4px 8px; border: 1px solid #e8c76c; background: #fff8dc; border-radius: 3px; }
.mp-confirm b { flex: 1; font-size: 12.5px; }
.mp-foot .rl-btn { display: inline-flex; gap: 5px; align-items: center; }
</style>
