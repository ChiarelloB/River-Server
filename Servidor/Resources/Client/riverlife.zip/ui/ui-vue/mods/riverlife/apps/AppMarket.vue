<template>
  <div class="market">
    <header class="mk-head">
      <div class="mk-logo"><b>classificados</b><span>.river</span></div>
      <div class="mk-search">
        <input v-model="search" class="rl-input" placeholder="Buscar modelo, anúncio ou loja..." aria-label="Buscar" />
        <button class="rl-btn primary" @click="$emit('open', 'sell')">+ Anunciar</button>
      </div>
    </header>
    <div class="mk-filters rl-row">
      <XPSelect v-model="sort" aria-label="Ordenar" :options="[{ value: 'recent', label: 'Mais recentes' }, { value: 'low', label: 'Menor preço' },
        { value: 'high', label: 'Maior preço' }, { value: 'near', label: 'Mais perto' }, { value: 'km', label: 'Menor km' }]" />
      <XPSelect v-model="seller" aria-label="Vendedor" :options="[{ value: '', label: 'Todos os vendedores' }, { value: 'private', label: 'Particulares' },
        { value: 'store', label: 'Lojas' }, { value: 'lot', label: 'Pátios (ver ao vivo)' }, { value: 'inspected', label: 'Vistoriados' }, { value: 'mine', label: 'Meus anúncios' }]" />
      <input v-model.number="maxPrice" class="rl-input small" type="number" min="0" placeholder="Preço máx. ($)" aria-label="Preço máximo" />
      <span class="rl-muted">{{ filtered.length }} anúncio(s)</span>
    </div>

    <div v-if="!filtered.length" class="rl-empty">
      <b>{{ rl.view.connected ? "Nenhum anúncio encontrado" : "Conectando ao mercado..." }}</b>
      Ajuste a busca ou anuncie um carro da sua garagem.
    </div>
    <div class="mk-list">
      <article v-for="l in filtered" :key="l.id" class="mk-item rl-card" @click="openDetail(l)">
        <div class="mk-photo">
          <img v-if="cover(l)" :src="cover(l)" alt="" />
          <span v-else-if="l.display" class="mk-live"><BngIcon type="parking" /> Exposto ao vivo</span>
          <span v-else>Carregando foto...</span>
          <i v-if="l.reserved" class="mk-flag">Em negociação</i>
          <i v-else-if="l.lot" class="mk-flag store">No pátio</i>
          <i v-else-if="l.street" class="mk-flag street">Vende-se</i>
          <i v-else-if="l.npcSeller" class="mk-flag npc">Particular</i>
          <i v-else-if="l.storeName" class="mk-flag store">Loja</i>
          <i v-if="l.inspection" class="mk-flag ok">Vistoriado</i>
          <i v-if="!photo(l.photos?.[0]) && l.cover" class="mk-flag cat">Foto de catálogo</i>
        </div>
        <div class="mk-info">
          <h3>{{ l.title }}</h3>
          <p>{{ l.year ? l.year + " · " : "" }}{{ km(l.mileage) }}{{ l.brokenParts ? " · " + l.brokenParts + " peça(s) danificada(s)" : "" }}</p>
          <p class="mk-where">{{ l.storeName || l.sellerName }} · {{ distanceText(distance(rl.view.position, l.position)) }}</p>
        </div>
        <div class="mk-price">
          <b>{{ money(l.price) }}</b>
          <small v-if="fipeText(l)" class="fipe" :class="fipeKind(l)">{{ fipeText(l) }}</small>
          <small v-if="l.negotiable">Aceita propostas</small>
          <small class="rl-muted">{{ ago(l.createdAt) }}</small>
        </div>
      </article>
    </div>

    <div v-if="detail" class="mk-modal" @click.self="detail = null">
      <div class="mk-detail">
        <header><b>{{ detail.title }}</b><button class="x" aria-label="Fechar" @click="detail = null">×</button></header>
        <div class="mk-dbody">
          <div class="mk-gallery">
            <img v-if="photo(detail.photos?.[shown])" class="big" :src="photo(detail.photos[shown])" alt="Foto do anúncio" />
            <div v-else-if="detail.cover && !(detail.photos || []).length" class="big catalog"><img :src="detail.cover" alt="Foto de catálogo" />
              <span>Foto de catálogo{{ detail.display ? " · as fotos do carro saem quando alguém passa perto dele" : "" }}</span></div>
            <div v-else-if="detail.display" class="big ph live"><BngIcon type="parking" /><b>Carro exposto {{ detail.lot ? "no pátio da " + detail.storeName : "na rua" }}</b>
              <span>Vá até ele para ver de perto: a placa com o preço está no carro.</span></div>
            <div v-else class="big ph">Carregando foto...</div>
            <div class="thumbs"><img v-for="(p, i) in detail.photos || []" :key="p" :src="photo(p)" :class="{ on: i === shown }" alt="" @click="shown = i" /></div>
          </div>
          <div class="mk-side">
            <b class="mk-bigprice">{{ money(detail.price) }}</b>
            <p class="rl-muted">{{ detail.negotiable ? "Aceita propostas na visita" : "Preço fechado" }}</p>
            <table class="rl-table specs">
              <tr><td>Modelo</td><td>{{ detail.niceName || detail.model }}</td></tr>
              <tr v-if="detail.year"><td>Ano</td><td>{{ detail.year }}</td></tr>
              <tr><td>Quilometragem</td><td>{{ km(detail.mileage) }}</td></tr>
              <tr><td>Peças danificadas</td><td>{{ detail.brokenParts ?? "—" }}</td></tr>
              <tr><td>Vendedor</td><td>{{ detail.storeName ? detail.storeName + " (" + detail.sellerName + ")" : detail.sellerName }} · ★ {{ ((detail.sellerReputation || 0) / 20).toFixed(1) }}</td></tr>
              <tr><td>Local</td><td>{{ distanceText(distance(rl.view.position, detail.position)) }} daqui</td></tr>
              <tr><td>Visualizações</td><td>{{ detail.views || 0 }}</td></tr>
              <tr v-if="detail.fipe"><td>Tabela FIPE do River</td><td><b>{{ money(detail.fipe) }}</b>
                <span class="fipe fipe-gap" :class="fipeKind(detail)">{{ fipeText(detail) }}</span><br />
                <small class="rl-muted">{{ detail.fipeSales >= 3 ? "Média das últimas " + detail.fipeSales + " vendas deste modelo" : "Avaliação do carro (poucas vendas deste modelo ainda)" }}</small></td></tr>
              <tr v-if="detail.inspection"><td>Vistoria</td><td><b :class="detail.inspection.verdict === 'Reprovado' ? 'bad' : 'good'">{{ detail.inspection.verdict }}</b>
                · {{ detail.inspection.by }} · {{ ago(detail.inspection.at) }}<br /><small>{{ km(detail.inspection.mileage) }} · {{ detail.inspection.brokenParts || 0 }} peça(s) com defeito</small></td></tr>
            </table>
            <p class="mk-desc">{{ detail.description || "Sem descrição." }}</p>
            <template v-if="detail.display && detail.seller !== me.id">
              <div class="walkin rl-box">
                <b>Proposta no local</b>
                <p v-if="!near" class="rl-muted">Chegue perto do carro (a placa aparece a uns 50 m) para negociar. {{ distanceText(distance(rl.view.position, detail.position)) }} daqui.</p>
                <p v-if="staffed" class="rl-muted">A loja tem vendedor: a resposta vem na hora.</p>
                <p v-if="reply" class="reply" :class="reply.kind">{{ reply.message }}</p>
                <div v-if="counter" class="rl-row">
                  <span>Contraproposta: <b>{{ money(counter.price) }}</b></span>
                  <button class="rl-btn go" :disabled="!near || rl.busy.accept" @click="request('accept', { offerId: counter.id })">Aceitar e comprar</button>
                </div>
                <form class="rl-row" @submit.prevent="walkIn">
                  <input v-if="detail.negotiable !== false" v-model.number="offerValue" class="rl-input" type="number" min="1" :placeholder="'Sua oferta ($) — placa ' + Math.round(detail.price / 100)" required />
                  <span v-else class="rl-muted">Preço fechado: {{ money(detail.price) }}</span>
                  <button class="rl-btn primary" :disabled="!near || rl.busy.walkIn || rl.busy.offer">{{ detail.negotiable === false ? "Comprar pelo preço" : "Fazer proposta" }}</button>
                </form>
                <div class="rl-row"><button class="rl-btn" @click="gps(detail)">Marcar no GPS</button></div>
                <p class="rl-muted small">O dinheiro sai da sua carreira só quando o negócio fecha. O carro é entregue ali mesmo, na vaga.</p>
              </div>
            </template>
            <template v-else-if="detail.seller !== me.id">
              <label class="rl-muted">Horário da visita (opcional, até 2 horas)
                <input v-model="visitAt" class="rl-input" type="datetime-local" aria-label="Horário da visita" /></label>
              <div class="rl-row">
                <button class="rl-btn" @click="gps(detail)">Marcar no GPS</button>
                <button class="rl-btn primary" :disabled="detail.reserved || rl.busy.visit" @click="schedule">Agendar visita</button>
              </div>
              <p class="rl-muted">Reserva de 1% do valor (até $500), devolvida ao concluir ou cancelar. Vá até o carro e negocie com o vendedor no local.</p>
            </template>
            <template v-else>
              <p class="rl-badge">Este anúncio é seu</p>
              <div class="rl-row"><button class="rl-btn" @click="$emit('open', detail.lot ? 'store' : 'garage')">Gerenciar anúncio</button>
                <button v-if="!detail.inspection && detail.status === 'active'" class="rl-btn" :disabled="rl.busy.requestInspection"
                  @click="request('requestInspection', { listingId: detail.id })">Pedir vistoria ({{ money(rl.view.costs?.inspection || 15000) }})</button></div>
              <p v-if="!detail.inspection" class="rl-muted small">Um vistoriador (jogador) vai até o carro e publica o laudo no anúncio. Anúncios vistoriados vendem mais rápido.</p>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, money, km, ago, photo, cover, loadPhotos, loadCover, distance, distanceText, me, toast, onAction } from "../rl.js"

const props = defineProps({ focus: String })
const emit = defineEmits(["open"])
const search = ref(""), sort = ref("recent"), seller = ref(""), maxPrice = ref(null)
const detail = ref(null), shown = ref(0), visitAt = ref(""), offerValue = ref(null), reply = ref(null)
const near = computed(() => detail.value && (rl.view.nearby === detail.value.id || distance(rl.view.position, detail.value.position) < 15))
const staffed = computed(() => detail.value?.staffed)
// The latest pending counter-offer to me on this car (from the seller, staff or NPC).
const counter = computed(() => {
  if (!detail.value) return null
  const visit = (rl.view.visits || []).find(v => v.listingId === detail.value.id && v.buyer === me.value.id && ["arrived", "scheduled"].includes(v.status))
  if (!visit) return null
  return (rl.view.offers || []).filter(o => o.visitId === visit.id && o.status === "pending" && o.from !== me.value.id).sort((a, b) => b.createdAt - a.createdAt)[0] || null
})
// Price against the "Tabela FIPE do River".
function fipeDelta(l) { return l?.fipe ? (l.price - l.fipe) / l.fipe : null }
function fipeText(l) {
  const d = fipeDelta(l)
  if (d === null) return ""
  const pct = Math.round(Math.abs(d) * 100)
  return pct < 3 ? "Na FIPE" : pct + "% " + (d < 0 ? "abaixo" : "acima") + " da FIPE"
}
function fipeKind(l) { const d = fipeDelta(l); return d === null ? "" : Math.abs(d) < 0.03 ? "fair" : d < 0 ? "below" : "above" }
function walkIn() {
  // Fixed-price ads: the offer is the price on the sign.
  const price = detail.value?.negotiable === false ? detail.value.price : Math.round((offerValue.value || 0) * 100)
  if (!price) return
  const visit = (rl.view.visits || []).find(v => v.listingId === detail.value.id && v.buyer === me.value.id && v.status === "arrived")
  if (visit) request("offer", { visitId: visit.id, price })
  else request("walkIn", { listingId: detail.value.id, price })
}
const viewed = new Set()
let off

const filtered = computed(() => {
  const q = search.value.trim().toLowerCase()
  let ads = (rl.view.listings || []).filter(l => l.status === "active" || (seller.value === "mine" && l.seller === me.value.id))
  if (q) ads = ads.filter(l => [l.title, l.model, l.niceName, l.storeName, l.sellerName].join(" ").toLowerCase().includes(q))
  if (seller.value === "private") ads = ads.filter(l => !l.storeId)
  if (seller.value === "store") ads = ads.filter(l => l.storeId)
  if (seller.value === "mine") ads = ads.filter(l => l.seller === me.value.id)
  if (seller.value === "lot") ads = ads.filter(l => l.display)
  if (seller.value === "inspected") ads = ads.filter(l => l.inspection)
  if (maxPrice.value) ads = ads.filter(l => l.price <= maxPrice.value * 100)
  const pos = rl.view.position
  const sorters = { low: (a, b) => a.price - b.price, high: (a, b) => b.price - a.price, km: (a, b) => a.mileage - b.mileage,
    near: (a, b) => distance(pos, a.position) - distance(pos, b.position), recent: (a, b) => b.createdAt - a.createdAt }
  return [...ads].sort(sorters[sort.value] || sorters.recent)
})
watch(filtered, list => list.slice(0, 24).forEach(loadCover), { immediate: true })

function openDetail(l) {
  detail.value = l; shown.value = 0; visitAt.value = ""; reply.value = null; offerValue.value = null
  loadPhotos(l)
  if (l.seller !== me.value.id && !viewed.has(l.id)) { viewed.add(l.id); request("view", { listingId: l.id }) }
}
function gps(l) { request("gps", { position: l.position }) }
function schedule() {
  const at = visitAt.value ? Math.floor(new Date(visitAt.value).getTime() / 1000) : undefined
  const now = Math.floor(Date.now() / 1000)
  if (at !== undefined && (!isFinite(at) || at < now - 5 || at > now + 7200)) { toast("Escolha um horário nas próximas 2 horas.", "warning"); return }
  request("visit", { listingId: detail.value.id, scheduledAt: at })
}
watch(() => rl.view.listings, list => {
  if (!detail.value) return
  const fresh = (list || []).find(x => x.id === detail.value.id)
  if (fresh) detail.value = fresh
})
watch(() => props.focus, id => { const l = (rl.view.listings || []).find(x => x.id === id); if (l) openDetail(l) }, { immediate: true })
onMounted(() => {
  off = onAction(e => {
    if ((e?.op === "walkIn" || e?.op === "offer") && e.result?.ok && e.result.data?.reply) reply.value = e.result.data.reply
    if ((e?.op === "walkIn" || e?.op === "offer") && e.result?.ok && !e.result.data?.reply) reply.value = { kind: "sent", message: "Proposta enviada. Aguarde a resposta do vendedor." }
    if (e?.op === "accept" && e.result?.ok && detail.value) { toast("Negócio fechado! O carro é seu, retire na vaga."); detail.value = null }
    if (e?.op === "visit" && e.result?.ok) {
      toast("Visita marcada! O GPS mostra o local. Negocie quando chegar.")
      if (detail.value) gps(detail.value)
      detail.value = null
      emit("open", "agenda")
    }
  })
})
onUnmounted(() => off && off())
</script>

<style scoped>
.mk-live { display: flex; flex-direction: column; align-items: center; gap: 4px; color: #2d6a3a; font-weight: bold; }
.mk-flag.npc { background: #6b2fc0 !important; }
.mk-flag.ok { background: #1d7a2c !important; left: auto !important; right: 6px; }
.mk-flag.cat { background: rgba(20, 30, 50, .7) !important; top: auto !important; bottom: 6px; font-style: normal; }
.catalog { position: relative; display: block; background: #eef2f7; }
.catalog img { width: 100%; height: 100%; object-fit: contain; }
.catalog span { position: absolute; left: 8px; bottom: 8px; right: 8px; padding: 4px 8px; border-radius: 3px; background: rgba(20, 30, 50, .7); color: #fff; font-size: 11.5px; }
.live { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; text-align: center; padding: 20px; background: #eef7ee !important; color: #2b5a33; }
.live :deep(.bng-icon) { font-size: 54px; }
.walkin { display: grid; gap: 8px; }
.reply { margin: 0; padding: 6px 8px; border-radius: 4px; background: #eef4fb; }
.reply.accepted { background: #e3f7e0; color: #236b1a; font-weight: bold; } .reply.declined { background: #fde6e4; color: #8e2318; }
.reply.counter { background: #fff4d6; color: #7b5600; }
.good { color: #1d7a2c; } .bad { color: #b42318; }
.small { font-size: 11.5px; }
</style>

<style scoped>
.market { min-height: 100%; background: #f2f4f5; }
.mk-head { display: flex; align-items: center; gap: 16px; padding: 12px 18px; background: linear-gradient(90deg, #0d5f57, #13897a); flex-wrap: wrap; }
.mk-logo { font: bold 24px "Trebuchet MS", Tahoma, sans-serif; color: #fff; letter-spacing: -1px; } .mk-logo span { color: #ffd23f; }
.mk-search { flex: 1; display: flex; gap: 8px; min-width: 240px; } .mk-search input { flex: 1; }
.mk-filters { padding: 10px 18px; background: #fff; border-bottom: 1px solid #dde2e6; }
.mk-filters .small { width: 130px; }
.mk-list { display: grid; gap: 10px; padding: 12px 18px; }
.mk-item { display: grid; grid-template-columns: 200px 1fr auto; gap: 14px; cursor: pointer; padding: 0; }
.mk-photo { position: relative; aspect-ratio: 16/10; background: #e6eaee; display: flex; align-items: center; justify-content: center; color: #8a96a3; font-size: 11px; }
.mk-photo img { width: 100%; height: 100%; object-fit: cover; }
.mk-flag { position: absolute; left: 6px; top: 6px; font-style: normal; font-size: 10px; padding: 2px 7px; border-radius: 9px; background: #e67e00; color: #fff; }
.mk-flag.store { background: #0d5f57; }
.mk-info { padding: 10px 0; min-width: 0; } .mk-info h3 { margin: 0 0 6px; font-size: 15px; color: #1a1a1a; }
.mk-info p { margin: 2px 0; font-size: 12px; color: #4a4a4a; } .mk-where { color: #7a7a7a !important; }
.mk-price { padding: 10px 14px; text-align: right; display: grid; align-content: start; gap: 3px; }
.mk-price b { font-size: 18px; color: #1a1a1a; } .mk-price small { font-size: 11px; color: #2e8b2e; }
.fipe { font-size: 11px; font-weight: bold; } .fipe.below { color: #1d7a2c !important; } .fipe.above { color: #b25b00 !important; } .fipe.fair { color: #44627f !important; } .fipe-gap { margin-left: 6px; }
.mk-flag.street { background: #b51f1f !important; }
.mk-modal { position: absolute; inset: 0; background: rgba(20,30,45,.55); display: flex; align-items: center; justify-content: center; z-index: 10; padding: 16px; }
.mk-detail { width: min(980px, 100%); max-height: 100%; overflow: auto; background: #fff; border-radius: 6px; box-shadow: 0 10px 30px rgba(0,0,0,.4); }
.mk-detail header { position: sticky; top: 0; display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: #0d5f57; color: #fff; z-index: 2; }
.mk-detail .x { border: 0; background: none; color: #fff; font-size: 22px; cursor: pointer; }
.mk-dbody { display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; padding: 14px; }
.mk-gallery .big { width: 100%; aspect-ratio: 16/9; object-fit: cover; border-radius: 4px; background: #e6eaee; }
.mk-gallery .ph { display: flex; align-items: center; justify-content: center; color: #8a96a3; }
.thumbs { display: flex; gap: 6px; margin-top: 6px; overflow-x: auto; }
.thumbs img { width: 90px; height: 56px; object-fit: cover; border: 2px solid transparent; border-radius: 3px; cursor: pointer; }
.thumbs img.on { border-color: #ffb000; }
.mk-bigprice { font-size: 28px; color: #1a1a1a; }
.specs td:first-child { color: #6b7785; width: 40%; }
.mk-desc { white-space: pre-wrap; line-height: 1.5; font-size: 12.5px; background: #f7f7f7; padding: 8px 10px; border-radius: 4px; }
@media (max-width: 700px) {
  .mk-item { grid-template-columns: 120px 1fr; } .mk-price { grid-column: 1 / -1; text-align: left; padding-top: 0; }
  .mk-dbody { grid-template-columns: 1fr; }
}
</style>
