<template>
  <section class="xpw" :class="{ focused, maximized: win.maximized, native }" :style="style" @pointerdown="$emit('focus')">
    <header class="xpw-title" @pointerdown="dragStart" @dblclick="$emit('maximize')">
      <span class="xpw-icon"><BngIcon :type="icon" /></span>
      <span class="xpw-text">{{ title }}</span>
      <nav>
        <button aria-label="Minimizar" @pointerdown.stop @click="$emit('minimize')"><i class="m"></i></button>
        <button aria-label="Maximizar" @pointerdown.stop @click="$emit('maximize')"><i class="x"></i></button>
        <button class="close" aria-label="Fechar" @pointerdown.stop @click="$emit('close')">×</button>
      </nav>
    </header>
    <div class="xpw-body"><slot /></div>
    <span v-if="!win.maximized" class="xpw-grip" @pointerdown.stop="resizeStart"></span>
  </section>
</template>

<script setup>
import { computed, onUnmounted } from "vue"
import { BngIcon } from "@/common/components/base"

const props = defineProps({ win: Object, title: String, icon: { type: String, default: "screen" }, focused: Boolean, z: Number, native: Boolean })
defineEmits(["focus", "close", "minimize", "maximize"])

const style = computed(() => props.win.maximized
  ? { left: "0px", top: "0px", width: "100vw", height: "calc(100vh - 38px)", zIndex: props.z }
  : { left: props.win.x + "px", top: props.win.y + "px", width: Math.min(props.win.w, innerWidth - 20) + "px",
      height: Math.min(props.win.h, innerHeight - 60) + "px", zIndex: props.z })

let drag = null
function move(e) {
  if (!drag) return
  if (drag.mode === "move") {
    props.win.x = Math.max(-200, Math.min(innerWidth - 160, e.clientX - drag.dx))
    props.win.y = Math.max(0, Math.min(innerHeight - 80, e.clientY - drag.dy))
  } else {
    props.win.w = Math.max(520, e.clientX - props.win.x + 4)
    props.win.h = Math.max(320, e.clientY - props.win.y + 4)
  }
}
function end() { drag = null; window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end) }
function begin(d) { drag = d; window.addEventListener("pointermove", move); window.addEventListener("pointerup", end) }
function dragStart(e) {
  if (props.win.maximized || e.target.closest("button")) return
  begin({ mode: "move", dx: e.clientX - props.win.x, dy: e.clientY - props.win.y })
  e.preventDefault()
}
function resizeStart(e) { begin({ mode: "resize" }); e.preventDefault() }
onUnmounted(end)
</script>

<style scoped>
.xpw { position: absolute; display: flex; flex-direction: column; min-width: 520px; background: #ece9d8; border: 3px solid #0831d9; border-top: 0; border-radius: 8px 8px 3px 3px; box-shadow: 4px 6px 18px rgba(0,0,0,.4); }
.xpw:not(.focused) { border-color: #7a96df; }
.xpw:not(.focused) .xpw-title { background: linear-gradient(180deg, #9db9eb, #7a96df 15%, #7392e3 80%, #8aa3e6); }
.xpw.maximized { border-radius: 0; border-width: 0; }
.xpw-title { height: 30px; flex-shrink: 0; display: flex; align-items: center; gap: 6px; padding: 0 4px 0 6px; color: #fff; cursor: default; border-radius: 6px 6px 0 0; font: bold 13px "Trebuchet MS", Tahoma, sans-serif; text-shadow: 1px 1px #0a1f69; background: linear-gradient(180deg, #0997ff 0%, #0053ee 8%, #0050ee 40%, #06f 88%, #06f 93%, #005bff 95%, #003dd7 96%, #003dd7 100%); }
.xpw-icon { font-size: 16px; display: flex; }
.xpw-text { flex: 1; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.xpw-title nav { display: flex; gap: 2px; }
.xpw-title button { width: 22px; height: 22px; border: 1px solid #fff; border-radius: 3px; color: #fff; cursor: pointer; padding: 0; display: flex; align-items: center; justify-content: center; font: bold 16px Tahoma, sans-serif; background: radial-gradient(circle at 30% 30%, #3c8cff, #0446d6 70%); }
.xpw-title button.close { background: radial-gradient(circle at 30% 30%, #f09a73, #d2421f 70%); }
.xpw-title button:hover { filter: brightness(1.15); }
.xpw-title i.m { width: 8px; height: 3px; background: #fff; margin-top: 8px; }
.xpw-title i.x { width: 10px; height: 9px; border: 2px solid #fff; border-top-width: 3px; }
.xpw-body { flex: 1; min-height: 0; overflow: auto; background: #fff; user-select: text; }
.xpw-grip { position: absolute; right: -2px; bottom: -2px; width: 14px; height: 14px; cursor: nwse-resize; background: linear-gradient(135deg, transparent 50%, #a9a69a 50%, transparent 60%, #a9a69a 70%, transparent 80%); }
</style>
