<template>
  <div class="tun">
    <!-- Sem sessão do RLS: escolher o carro desta garagem -->
    <div v-if="!route" class="rl-page">
      <h2 class="rl-h1">Tuning</h2>
      <p class="rl-muted">Ajuste suspensão, câmbio, alinhamento, pneus e o que mais o carro permitir. Cada ajuste é testado no carro na hora e só é cobrado quando você paga.</p>
      <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>O tuning é feito com o carro estacionado na garagem.</div>
      <div v-else-if="!launchVehicles.length" class="rl-empty"><b>Nenhum carro nesta garagem</b>Estacione um carro perto do computador e tente de novo.</div>
      <article v-for="v in launchVehicles" :key="v.inventoryId" class="lv rl-card">
        <img v-if="v.thumbnail" :src="v.thumbnail" alt="" />
        <div class="lv-main">
          <b>{{ v.niceName || v.vehicleName || "Veículo" }}</b>
          <small class="rl-muted">{{ v.fn ? (v.fn.disabled ? reasonText(v.fn) : "Pronto para ajustar") : "Esta garagem não faz tuning" }}</small>
        </div>
        <button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button>
      </article>
    </div>

    <template v-else>
      <header class="bar">
        <span class="bar-ico"><BngIcon type="gearTuningOutline" /></span>
        <div class="bar-txt"><b>Tuning</b><small>{{ switching ? "Trocando de carro…" : (vehicleName || "Ajustes do veículo") }}</small></div>
        <span v-if="applying" class="rl-badge">Aplicando…</span>
        <span v-else-if="pendingCount" class="rl-badge warn">{{ pendingCount }} pendente(s)</span>
      </header>

      <div v-if="showSwitcher" class="switcher">
        <button class="rl-btn sm" :disabled="switching || busy" title="Carro anterior" @click="cycle(-1)"><BngIcon type="arrowSmallLeft" /></button>
        <XPSelect :model-value="String(session.activeInventoryId)" :disabled="switching || busy" aria-label="Carro"
          :options="sessionVehicles.map(v => ({ value: String(v.inventoryId), label: v.niceName }))" @update:model-value="switchTo" />
        <button class="rl-btn sm" :disabled="switching || busy" title="Próximo carro" @click="cycle(1)"><BngIcon type="arrowSmallRight" /></button>
      </div>
      <p v-if="switchError" class="rl-error sw-err">{{ switchError }}</p>

      <div class="tools">
        <input v-model="query" class="rl-input search" placeholder="Buscar ajuste…" @focus="typing(true)" @blur="typing(false)" />
        <label class="check" title="Testa cada ajuste no carro 1 segundo depois de você soltar o controle">
          <input type="checkbox" :checked="autoApply" @change="setAutoApply($event.target.checked)" /> Ao vivo
        </label>
        <button v-if="!autoApply" class="rl-btn sm primary" :disabled="!pendingCount || applying || switching" @click="applyNow">Aplicar</button>
        <button v-if="!autoApply && pendingCount" class="rl-btn sm" :disabled="applying || switching" title="Volta os controles para o que está no carro" @click="loadTuning(false)">Desfazer</button>
        <button class="rl-btn sm" :title="allOpen ? 'Recolher todos os grupos' : 'Abrir todos os grupos'" @click="toggleAll">{{ allOpen ? "Recolher" : "Expandir" }}</button>
      </div>

      <div class="body" :class="{ dim: switching }">
        <div v-if="error" class="rl-empty"><b>Sem dados de tuning</b>{{ error }}</div>
        <div v-else-if="loading" class="rl-empty"><b>Lendo o carro…</b>Carregando os ajustes disponíveis.</div>
        <div v-else-if="!buckets.length" class="rl-empty"><b>{{ query ? "Nada encontrado" : "Nada para ajustar" }}</b>{{ query ? "Nenhum ajuste com esse nome." : "Este carro não tem ajustes de tuning nas peças instaladas." }}</div>
        <template v-else>
        <section v-for="cat in buckets" :key="cat.name" class="cat">
          <button class="cat-h" @click="toggle(cat.name)">
            <i class="pm">{{ isOpen(cat.name) ? "−" : "+" }}</i>
            <b>{{ tr(cat.name) }}</b>
            <small>{{ cat.count }} ajuste(s)</small>
            <span v-if="cat.changed" class="rl-badge warn">{{ cat.changed }} alterado(s)</span>
          </button>
          <div v-if="isOpen(cat.name)" class="cat-b">
            <div v-for="sub in cat.items" :key="sub.name" class="sub">
              <button v-if="sub.name !== 'Other'" class="sub-h" @click="toggle(cat.name + '/' + sub.name, true)">
                <i class="pm sm">{{ isOpen(cat.name + '/' + sub.name, true) ? "−" : "+" }}</i>{{ tr(sub.name) }}
              </button>
              <template v-if="sub.name === 'Other' || isOpen(cat.name + '/' + sub.name, true)">
                <div v-for="m in sub.items" :key="m.name" class="var" :class="{ changed: isChanged(m.name), pending: edited[m.name] }">
                  <div class="var-h">
                    <span class="var-t" :title="m.description || m.title">{{ m.title }}</span>
                    <input type="number" class="rl-input num" :value="vars[m.name].valDis" :min="vars[m.name].minDis" :max="vars[m.name].maxDis"
                      :step="vars[m.name].stepDis" @focus="typing(true)" @blur="typing(false)" @change="setVal(m.name, $event.target.value, true)" />
                    <span class="unit">{{ m.unit || "" }}</span>
                    <button class="mini" :disabled="isDefault(m.name) || switching" title="Voltar ao padrão de fábrica" @click="toDefault(m.name)"><BngIcon type="undo" /></button>
                  </div>
                  <input type="range" class="sl" :min="vars[m.name].minDis" :max="vars[m.name].maxDis" :step="vars[m.name].stepDis" :value="vars[m.name].valDis"
                    :disabled="switching" :style="{ '--fill': fillPct(m.name) + '%' }" @input="setVal(m.name, $event.target.value)" @change="setVal(m.name, $event.target.value, true)" />
                  <div class="var-f">
                    <small>{{ fmt(m.name, vars[m.name].minDis) }}</small>
                    <small v-if="isChanged(m.name)" class="was">antes: {{ fmt(m.name, vars[m.name].origDis) }}</small>
                    <small v-else class="was">padrão: {{ fmt(m.name, vars[m.name].defDis) }}</small>
                    <small>{{ fmt(m.name, vars[m.name].maxDis) }}</small>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </section>
        </template>
      </div>

      <section class="cart" :class="{ open: cartOpen }">
        <button class="cart-h" @click="cartOpen = !cartOpen">
          <BngIcon type="shoppingCart" /> <b>Carrinho</b> <small>({{ cartRows.filter(r => r.varName).length }} ajuste(s))</small>
          <i class="pm sm right">{{ cartOpen ? "−" : "+" }}</i>
        </button>
        <div v-if="cartOpen" class="cart-list">
          <p v-if="!cartRows.length" class="rl-muted">Nenhum ajuste no carrinho. Mexa nos controles para testar no carro.</p>
          <div v-for="(r, k) in cartRows" :key="k" class="crow" :class="'lv' + (r.level || 1)">
            <button v-if="r.varName" class="mini x" :disabled="busy || switching || applying" title="Desfazer este ajuste" @click="removeItem(r)"><BngIcon type="abandon" /></button>
            <span v-else class="mini-sp"></span>
            <span class="cname">{{ tr(r.title) }}</span>
            <span class="cprice">{{ r.price ? dollars(r.price) : "" }}</span>
          </div>
        </div>
      </section>

      <footer class="foot">
        <div class="sums">
          <span>Subtotal <b>{{ dollars(subtotal) }}</b></span>
          <span>Impostos (7%) <b>{{ dollars(taxes) }}</b></span>
          <span class="tot">Total <b>{{ dollars(cartTotal) }}</b></span>
        </div>
        <div class="money"><span class="rl-muted">Saldo {{ playerMoney === null ? "—" : dollars(playerMoney) }}</span>
          <span v-if="tooExpensive" class="rl-error">Saldo insuficiente</span>
          <span v-else-if="pendingCount && cartRows.length" class="rl-muted">Aplique os ajustes pendentes antes de pagar.</span>
        </div>
        <div class="btns">
          <span class="grow"></span>
          <button class="rl-btn" :disabled="busy || switching" @click="requestClose">Cancelar</button>
          <button class="rl-btn go" :disabled="!canBuy" @click="buy">Aplicar e pagar</button>
        </div>
      </footer>

      <div v-if="confirm" class="cfm-mask">
        <div class="cfm" role="dialog">
          <b>{{ confirm.title }}</b>
          <p>{{ confirm.text }}</p>
          <div class="btns">
            <button v-for="b in confirm.buttons" :key="b.label" class="rl-btn" :class="b.kind" @click="b.action">{{ b.label }}</button>
          </div>
        </div>
      </div>
      <div v-if="busy" class="busy"><span>{{ busyText }}</span></div>
    </template>
  </div>
</template>

<script>
// Survives a minimize/restore of the window (the component remounts while the RLS session stays open).
const MEMO = new Map()
const AUTO_KEY = "applyTuningChangesAutomatically" // same preference the RLS tuning screen uses
</script>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, shallowRef, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, luaCall, luaRun, luaValue, luaString, onGameEvent, dollars, arr, typing, toast } from "../rl.js"
import { desk } from "../desk.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])

const ROUTE = "career.computer.tuning"
const PT = {
  Suspension: "Suspensão", Wheels: "Rodas", Transmission: "Transmissão", "Wheel Alignment": "Alinhamento", Chassis: "Chassi", Engine: "Motor",
  Brakes: "Freios", Differential: "Diferencial", Differentials: "Diferenciais", Front: "Dianteira", Rear: "Traseira", Center: "Central",
  Other: "Outros", Steering: "Direção", Aerodynamics: "Aerodinâmica", Body: "Carroceria", Electronics: "Eletrônica", Turbocharger: "Turbo",
  Supercharger: "Compressor", "Nitrous Oxide": "Nitro", Fuel: "Combustível", Tires: "Pneus", Tyres: "Pneus", Gearbox: "Câmbio",
  Clutch: "Embreagem", Exhaust: "Escapamento", Intake: "Admissão", Springs: "Molas", Dampers: "Amortecedores", Gears: "Marchas",
  "Anti-Roll Bars": "Barras estabilizadoras", Height: "Altura", Cargo: "Carga", Lights: "Luzes", Interior: "Interior", Misc: "Diversos",
}
const tr = s => (typeof s === "string" && PT[s.trim()]) || s

const meta = shallowRef([])    // tuning variables as sent by Lua
const vars = reactive({})      // name -> { valDis, minDis, maxDis, stepDis, defDis, origDis, origRaw, min, max }
const edited = reactive({})    // vars changed in the UI and not yet sent to the car
const open = reactive({})
const query = ref("")
const autoApply = ref(readAuto())
const shopping = shallowRef(null)
const playerMoney = ref(null)
const session = ref({ vehicles: [], activeInventoryId: null, isTuningTent: false })
const switching = ref(false)
const switchError = ref("")
const loading = ref(true)
const error = ref("")
const applying = ref(false)
const busy = ref(false)
const busyText = ref("")
const confirm = ref(null)
const cartOpen = ref(true)
const vehicleName = ref("")
let offs = []
let applyTimer = null
let applyingTimer = null
let busyTimer = null
let started = false

const memoKey = computed(() => String(props.nonce ?? props.route ?? ""))

// ---- launcher (no RLS session) ----
const launchVehicles = computed(() => arr(rl.view.computer?.vehicles).map(v => ({
  ...v, fn: rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.tuning,
})))
function reasonText(fn) { const r = fn?.reason; return (typeof r?.label === "string" ? r.label : r?.label?.txt) || "Indisponível agora" }
function launch(v) { request("native", { buttonId: "tuning", inventoryId: v.inventoryId }) }

// ---- value conversion (same maths as the RLS tuning store) ----
function decimals(n) { if (typeof n !== "number" || Number.isInteger(n) || !isFinite(n)) return 0; const s = String(n); return s.includes("e-") ? Number(s.split("e-")[1]) : (s.split(".")[1] || "").length }
function roundStep(v, step) { return step ? Math.round(v / step + Number.EPSILON) * step : v }
function roundDec(v, dec) { const p = Math.pow(10, dec); return Math.round(v * p + Number.EPSILON) / p }
function toDis(m, raw) {
  const span = m.max - m.min
  const frac = span ? (raw - m.min) / span : 0
  return roundDec(roundStep(frac * (m.maxDis - m.minDis), m.stepDis) + m.minDis, decimals(m.stepDis))
}
function toRaw(m, dis) {
  const span = m.maxDis - m.minDis
  const frac = span ? (dis - m.minDis) / span : 0
  return frac * (m.max - m.min) + m.min
}
function fmt(name, v) {
  const m = vars[name]
  const d = Math.min(4, decimals(m?.stepDis))
  return Number(v).toLocaleString((window.__rlLocale || "pt-BR"), { minimumFractionDigits: d, maximumFractionDigits: d })
}
const fillPct = name => { const m = vars[name]; const span = m.maxDis - m.minDis; return span ? Math.round(((m.valDis - m.minDis) / span) * 100) : 0 }
const same = (a, b) => Math.abs(Number(a) - Number(b)) < 1e-9
const isChanged = name => !same(vars[name].valDis, vars[name].origDis)
const isDefault = name => same(vars[name].valDis, vars[name].defDis)

// ---- building the groups ----
const norm = s => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
const buckets = computed(() => {
  const q = norm(query.value.trim())
  const cats = new Map()
  for (const m of meta.value) {
    if (q && ![m.title, m.category, m.subCategory, tr(m.category), tr(m.subCategory), m.name].some(s => norm(s).includes(q))) continue
    if (!cats.has(m.category)) cats.set(m.category, new Map())
    const subs = cats.get(m.category)
    if (!subs.has(m.subCategory)) subs.set(m.subCategory, [])
    subs.get(m.subCategory).push(m)
  }
  const byName = (a, b) => String(a.name).localeCompare(String(b.name))
  return [...cats.entries()].map(([name, subs]) => {
    const items = [...subs.entries()].map(([sname, list]) => ({ name: sname, items: list.sort(byName) })).sort(byName)
    const all = items.flatMap(s => s.items)
    return { name, items, count: all.length, changed: all.filter(m => isChanged(m.name)).length }
  }).sort(byName)
})
function isOpen(key, sub = false) {
  if (query.value.trim()) return true
  if (key in open) return open[key]
  if (sub) return true
  return buckets.value[0]?.name === key
}
function toggle(key, sub = false) { open[key] = !isOpen(key, sub) }
const allOpen = computed(() => buckets.value.length > 0 && buckets.value.every(c => isOpen(c.name)))
function toggleAll() { const v = !allOpen.value; for (const c of buckets.value) open[c.name] = v }

// ---- loading ----
async function loadTuning(fresh) {
  loading.value = true
  error.value = ""
  const data = await luaCall("career_modules_tuning.getTuningData()")
  if (!data || typeof data !== "object") {
    loading.value = false
    error.value = "O RLS não devolveu os ajustes deste carro. Feche e abra o tuning de novo."
    return
  }
  const memo = !fresh && MEMO.get(memoKey.value)
  const orig = (memo && memo.orig) || {}
  const list = []
  for (const k of Object.keys(vars)) delete vars[k]
  for (const k of Object.keys(edited)) delete edited[k]
  for (const [key, d] of Object.entries(data)) {
    if (!d || typeof d !== "object" || d.hideInUI) continue
    const category = d.category || "Other"
    if (category === "Cargo" || category === "Carga") continue
    const min = Number(d.min), max = Number(d.max)
    if (!isFinite(min) || !isFinite(max)) continue
    const m = { name: d.name || key, title: d.title || d.name || key, description: d.description || "", unit: d.unit || "", category, subCategory: d.subCategory || "Other",
      min, max, minDis: Number(d.minDis ?? min), maxDis: Number(d.maxDis ?? max) }
    m.stepDis = Number(d.stepDis) > 0 ? Number(d.stepDis) : Math.abs(m.maxDis - m.minDis) / 100 || 1
    const val = Number(d.val ?? d.default ?? min)
    const valDis = toDis(m, val)
    const o = orig[m.name] || { raw: val, dis: valDis }
    orig[m.name] = o
    vars[m.name] = { valDis, minDis: m.minDis, maxDis: m.maxDis, stepDis: m.stepDis, min, max, defDis: toDis(m, Number(d.default ?? val)), origDis: o.dis, origRaw: o.raw }
    list.push(m)
  }
  MEMO.set(memoKey.value, { ...(MEMO.get(memoKey.value) || {}), orig })
  meta.value = list
  loading.value = false
}
async function refreshSession(data) {
  const s = data || await luaCall("career_modules_tuning.getTuningSessionData()")
  if (s && typeof s === "object") session.value = { ...s, vehicles: arr(s.vehicles) }
  const id = session.value.activeInventoryId
  const fromList = sessionVehicles.value.find(v => String(v.inventoryId) === String(id))
  let name = fromList?.niceName
  if (!name && id != null) name = await luaRun("local v = career_modules_inventory.getVehicles()[" + Number(id) + "] return v and v.niceName or nil")
  if (typeof name === "string" && name) { vehicleName.value = name; emit("title", name) }
}
const sessionVehicles = computed(() => arr(session.value.vehicles))
const showSwitcher = computed(() => session.value.isTuningTent === true && sessionVehicles.value.length > 1)

// ---- editing ----
function setVal(name, raw, done = false) {
  const m = vars[name]
  if (!m) return
  let v = Number(String(raw).replace(",", "."))
  if (!isFinite(v)) return
  v = Math.min(m.maxDis, Math.max(m.minDis, v))
  if (done) v = roundDec(roundStep(v - m.minDis, m.stepDis) + m.minDis, decimals(m.stepDis))
  m.valDis = v
  edited[name] = true
  scheduleApply()
}
function toDefault(name) { setVal(name, vars[name].defDis, true) }
function scheduleApply() {
  clearTimeout(applyTimer)
  applyTimer = autoApply.value ? setTimeout(applyNow, 1000) : null
}
// Sends only the edited variables (raw values), like the RLS store. Back at the starting value, the exact original
// raw number is sent so the RLS cart drops the item instead of charging for a rounding difference.
function applyNow() {
  clearTimeout(applyTimer)
  applyTimer = null
  const names = Object.keys(edited)
  if (!names.length || switching.value) return
  const res = {}
  for (const n of names) {
    const m = vars[n]
    if (m) res[n] = same(m.valDis, m.origDis) ? m.origRaw : toRaw(m, m.valDis)
    delete edited[n]
  }
  applying.value = true
  clearTimeout(applyingTimer)
  applyingTimer = setTimeout(() => (applying.value = false), 5000)
  luaCall("career_modules_tuning.apply(" + luaValue(res) + ")").then(r => {
    if (r && r.success === false) { applying.value = false; toast("O carro está sendo trocado. Tente o ajuste de novo.", "error") }
  })
}
function readAuto() {
  try { const v = localStorage.getItem(AUTO_KEY); return v === null ? true : !!JSON.parse(v) } catch (err) { return true }
}
function setAutoApply(on) {
  autoApply.value = !!on
  try { localStorage.setItem(AUTO_KEY, JSON.stringify(!!on)) } catch (err) { /* ignore */ }
  if (on && Object.keys(edited).length) scheduleApply()
}
const pendingCount = computed(() => Object.keys(edited).length)

// ---- cart ----
const cart = computed(() => shopping.value?.shoppingCart || null)
const cartRows = computed(() => arr(cart.value?.items))
const cartTotal = computed(() => Number(cart.value?.total) || 0)
const taxes = computed(() => Number(cart.value?.taxes) || 0)
const subtotal = computed(() => cartTotal.value - taxes.value)
const tooExpensive = computed(() => cartTotal.value > 0 && playerMoney.value !== null && cartTotal.value > playerMoney.value)
const canBuy = computed(() => cartRows.value.length > 0 && !tooExpensive.value && !pendingCount.value && !applying.value && !switching.value && !busy.value)
function removeItem(r) {
  if (!r.varName) return
  delete edited[r.varName]
  applying.value = true
  clearTimeout(applyingTimer)
  applyingTimer = setTimeout(() => (applying.value = false), 5000)
  luaCall("career_modules_tuning.removeVarFromShoppingCart(" + luaString(String(r.varName)) + ")")
}

// ---- Lua events ----
function onShopping(d) {
  shopping.value = d || null
  if (d && d.playerMoney !== undefined && isFinite(Number(d.playerMoney))) playerMoney.value = Number(d.playerMoney)
  applying.value = false
  MEMO.set(memoKey.value, { ...(MEMO.get(memoKey.value) || {}), shopping: d })
}
function onVarUpdated(d) {
  const m = d && vars[d.name]
  if (!m) return
  m.valDis = toDis(m, Number(d.val))
  delete edited[d.name]
}
async function onVehicleChanged(d) {
  if (!d?.success) {
    switching.value = false
    switchError.value = "Não foi possível carregar os ajustes desse carro."
    return
  }
  try {
    // New car, new baseline; the RLS already sent this car's (empty) cart before this event.
    MEMO.set(memoKey.value, { shopping: shopping.value })
    await refreshSession(d)
    await loadTuning(true)
  } catch (err) {
    switchError.value = "Não foi possível carregar os ajustes desse carro."
  } finally {
    switching.value = false
  }
}

// ---- switching car (tuning tents) ----
const hasUnpurchased = () => cartRows.value.length > 0 || pendingCount.value > 0
function cycle(step) {
  const list = sessionVehicles.value
  if (list.length < 2) return
  const i = Math.max(0, list.findIndex(v => String(v.inventoryId) === String(session.value.activeInventoryId)))
  switchTo(list[(i + step + list.length) % list.length].inventoryId)
}
function switchTo(id) {
  if (String(id) === String(session.value.activeInventoryId) || switching.value) return
  const go = async () => {
    confirm.value = null
    clearTimeout(applyTimer)
    for (const k of Object.keys(edited)) delete edited[k]
    switching.value = true
    switchError.value = ""
    let r = null
    try { r = await luaCall("career_modules_tuning.switchVehicle(" + Number(id) + ")") } catch (err) { r = null }
    if (!r || !r.success) { switching.value = false; switchError.value = "Esse carro não está mais disponível na área de tuning." }
    else if (r.unchanged) switching.value = false
    else setTimeout(() => { if (switching.value) { switching.value = false; switchError.value = "A troca de carro demorou demais. Tente de novo." } }, 12000)
  }
  if (!hasUnpurchased()) { go(); return }
  confirm.value = {
    title: "Trocar de carro?",
    text: "Os ajustes não pagos deste carro serão desfeitos.",
    buttons: [{ label: "Trocar", kind: "primary", action: go }, { label: "Continuar aqui", kind: "", action: () => { confirm.value = null; session.value = { ...session.value } } }],
  }
}

// ---- buying / leaving ----
function setBusy(text, ms) {
  busy.value = true
  busyText.value = text
  clearTimeout(busyTimer)
  busyTimer = setTimeout(() => { busy.value = false; toast("O RLS não respondeu. Tente de novo.", "error") }, ms)
}
function buy() {
  if (!canBuy.value) return
  setBusy("Pagando e salvando o carro…", 8000)
  luaCall("career_modules_tuning.applyShopping()").then(r => {
    if (r && r.success === false) { busy.value = false; clearTimeout(busyTimer); toast("Aguarde a troca de carro terminar.", "error") }
  })
}
function cancelSession() {
  confirm.value = null
  clearTimeout(applyTimer)
  for (const k of Object.keys(edited)) delete edited[k]
  setBusy(cartRows.value.length ? "Desfazendo os ajustes…" : "Saindo do tuning…", 9000)
  luaCall("career_modules_tuning.cancelShopping()")
}
// Same flow as the RLS screen's back/cancel: ask only when the cart has something.
function requestClose() {
  if (!props.route) { emit("close"); return }
  if (busy.value || switching.value) return
  if (!cartRows.value.length) { cancelSession(); return }
  confirm.value = {
    title: "Descartar o tuning?",
    text: "Os ajustes do carrinho não foram pagos. O carro volta para a configuração anterior.",
    buttons: [
      { label: "Descartar e sair", kind: "danger", action: cancelSession },
      { label: "Continuar ajustando", kind: "", action: () => (confirm.value = null) },
    ],
  }
}
defineExpose({ requestClose })

async function start() {
  if (started || !props.route) return
  started = true
  offs.push(onGameEvent("sendTuningShoppingData", onShopping))
  offs.push(onGameEvent("updateTuningVariable", onVarUpdated))
  offs.push(onGameEvent("careerTuningVehicleChanged", onVehicleChanged))
  offs.push(onGameEvent("tuningRequestExit", requestClose))
  const memo = MEMO.get(memoKey.value)
  if (memo?.shopping) shopping.value = memo.shopping
  luaCall("career_modules_playerAttributes.getAttributeValue('money')").then(m => {
    if (playerMoney.value === null && isFinite(Number(m)) && m !== null) playerMoney.value = Number(m)
  })
  refreshSession().catch(() => { switchError.value = "Não foi possível listar os carros da área de tuning." })
  await loadTuning(false)
}
onMounted(start)
watch(() => props.route, r => { if (r) start() })
onUnmounted(() => {
  for (const off of offs) off()
  offs = []
  clearTimeout(applyTimer)
  clearTimeout(applyingTimer)
  clearTimeout(busyTimer)
  // Edits not yet sent are dropped; the RLS session itself is closed by its own back/cancel flow.
  const alive = window.vueRouter?.currentRoute?.value?.name === ROUTE && desk.windows.some(w => w.props && w.props.nonce === props.nonce)
  if (!alive) MEMO.delete(memoKey.value)
})
</script>

<style scoped>
.tun { position: relative; height: 100%; display: flex; flex-direction: column; background: #fff; font-size: 12px; }
.bar { flex: none; display: flex; align-items: center; gap: 8px; padding: 6px 10px; background: linear-gradient(180deg, #f7f6f0, #ece9d8); border-bottom: 1px solid #aca899; }
.bar-ico { width: 30px; height: 30px; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 19px; background: linear-gradient(135deg, #7fb2ff, #1d4fae); box-shadow: inset 0 1px 0 rgba(255,255,255,.4); }
.bar-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.bar-txt b { font-size: 13px; color: #12407c; } .bar-txt small { color: #5f7186; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.switcher { flex: none; display: flex; gap: 4px; align-items: center; padding: 5px 10px; background: #f3f1e6; border-bottom: 1px solid #d5d2c3; }
.switcher select { flex: 1; min-width: 0; padding: 4px 6px; }
.sw-err { margin: 0; padding: 4px 10px; background: #fde6e4; font-size: 11.5px; }
.tools { flex: none; display: flex; gap: 6px; align-items: center; padding: 5px 10px; background: #ece9d8; border-bottom: 1px solid #aca899; }
.search { flex: 1; min-width: 0; padding: 4px 7px !important; }
.check { display: flex; align-items: center; gap: 4px; white-space: nowrap; cursor: pointer; }
.body { flex: 1; min-height: 0; overflow-y: auto; padding: 6px 8px 10px; }
.body.dim { opacity: .45; pointer-events: none; }
.cat { margin-bottom: 5px; border: 1px solid #c9d7e8; border-radius: 4px; background: #fbfcfe; overflow: hidden; }
.cat-h { width: 100%; display: flex; align-items: center; gap: 7px; padding: 6px 8px; border: 0; cursor: pointer; text-align: left; font: 12px Tahoma, sans-serif;
  background: linear-gradient(180deg, #fff, #e4ecf7); color: #1d3f69; }
.cat-h:hover { background: linear-gradient(180deg, #fff, #d6e4f7); }
.cat-h b { font-size: 12.5px; } .cat-h small { color: #6a7b8f; flex: 1; }
.pm { width: 13px; height: 13px; flex: none; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #7f9db9; background: #fff; color: #1d3f69; font: bold 11px/1 Tahoma, sans-serif; font-style: normal; }
.pm.sm { width: 11px; height: 11px; font-size: 10px; }
.cat-b { padding: 2px 8px 6px; }
.sub-h { display: flex; align-items: center; gap: 6px; width: 100%; margin: 6px 0 2px; padding: 2px 0; border: 0; border-bottom: 1px dotted #b5c4d6; background: none; cursor: pointer; font: bold 11.5px Tahoma, sans-serif; color: #4b5d73; text-align: left; }
.var { padding: 5px 6px 3px; margin: 3px 0; border-left: 3px solid transparent; border-radius: 2px; }
.var:hover { background: #f1f6fd; }
.var.changed { border-left-color: #e8a200; background: #fffbea; }
.var.pending { border-left-color: #316ac5; }
.var-h { display: flex; align-items: center; gap: 5px; }
.var-t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #1b2733; }
.num { width: 74px; padding: 2px 4px !important; text-align: right; font-size: 11.5px !important; }
.unit { min-width: 26px; color: #5f7186; font-size: 11px; }
.mini { width: 20px; height: 20px; padding: 0; flex: none; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #7f9db9; border-radius: 3px; background: linear-gradient(180deg, #fff, #e9eef5); color: #1d3f69; cursor: pointer; font-size: 12px; }
.mini:disabled { opacity: .4; cursor: default; }
.mini.x { border-color: #a33; color: #a33; background: linear-gradient(180deg, #fff, #f6dcd8); }
.mini-sp { width: 20px; flex: none; }
.sl { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 2px 0 0; background: transparent; cursor: pointer; }
.sl:focus { outline: none; }
.sl:disabled { cursor: default; opacity: .6; }
.sl::-webkit-slider-runnable-track { height: 6px; border: 1px solid #8c9aab; border-radius: 3px; box-shadow: inset 1px 1px 1px rgba(0,0,0,.15);
  background: linear-gradient(90deg, #6aa0e6 0, #3d77cc var(--fill, 0%), #f2f4f7 var(--fill, 0%), #fff 100%); }
.sl::-webkit-slider-thumb { -webkit-appearance: none; width: 11px; height: 17px; margin-top: -6px; border: 1px solid #45679e; border-radius: 3px 3px 6px 6px; background: linear-gradient(180deg, #fff, #dfe7f3 55%, #b9c9e2); box-shadow: 0 1px 2px rgba(0,0,0,.3); }
.sl:hover::-webkit-slider-thumb { border-color: #e8a200; }
.var-f { display: flex; justify-content: space-between; gap: 6px; color: #8291a3; font-size: 10.5px; }
.var-f .was { color: #6a7b8f; }
.var.changed .var-f .was { color: #8a5a00; font-weight: bold; }
.cart { flex: none; border-top: 1px solid #aca899; background: #fff; }
.cart-h { width: 100%; display: flex; align-items: center; gap: 6px; padding: 5px 10px; border: 0; background: linear-gradient(180deg, #f7f6f0, #e8e5d4); cursor: pointer; font: 12px Tahoma, sans-serif; color: #1d3f69; text-align: left; }
.cart-h small { color: #6a7b8f; flex: 1; }
.cart-list { max-height: 26vh; overflow-y: auto; padding: 4px 10px 6px; }
.cart-list p { margin: 4px 0; }
.crow { display: flex; align-items: center; gap: 6px; padding: 2px 0; border-bottom: 1px solid #eef1f5; }
.crow.lv1 .cname { font-weight: bold; color: #1d3f69; }
.crow.lv2 .cname { padding-left: 12px; color: #2c4a6e; }
.crow.lv3 .cname { padding-left: 24px; color: #4b5d73; }
.cname { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cprice { white-space: nowrap; color: #1b2733; }
.foot { flex: none; border-top: 1px solid #aca899; background: #ece9d8; padding: 6px 10px 8px; }
.sums { display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; color: #4b5d73; }
.sums b { color: #1b2733; } .sums .tot { margin-left: auto; } .sums .tot b { font-size: 16px; color: #164a8c; }
.money { display: flex; justify-content: space-between; gap: 8px; margin: 3px 0 6px; font-size: 11.5px; }
.btns { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.grow { flex: 1; }
.rl-btn.sm { padding: 3px 8px; font-size: 11.5px; display: inline-flex; align-items: center; gap: 4px; }
.right { margin-left: auto; }
.cfm-mask { position: absolute; inset: 0; background: rgba(40,60,90,.25); display: flex; align-items: center; justify-content: center; z-index: 5; }
.cfm { width: 86%; max-width: 380px; background: #ece9d8; border: 2px solid #0831d9; border-radius: 6px; padding: 12px 14px; box-shadow: 3px 4px 14px rgba(0,0,0,.35); }
.cfm b { color: #12407c; font-size: 13px; } .cfm p { margin: 6px 0 12px; line-height: 1.45; }
.cfm .btns { justify-content: flex-end; }
.busy { position: absolute; inset: 0; z-index: 6; background: rgba(255,255,255,.55); display: flex; align-items: center; justify-content: center; cursor: progress; }
.busy span { padding: 8px 14px; background: #ffffe1; border: 1px solid #7a7a5a; border-radius: 4px; box-shadow: 2px 2px 6px rgba(0,0,0,.25); }
.lv { display: flex; align-items: center; gap: 10px; padding: 8px; margin: 8px 0; }
.lv img { width: 96px; height: 54px; object-fit: contain; background: #eef2f7; border-radius: 3px; flex: none; }
.lv-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.lv-main b { color: #1b3355; font-size: 13px; }
</style>
