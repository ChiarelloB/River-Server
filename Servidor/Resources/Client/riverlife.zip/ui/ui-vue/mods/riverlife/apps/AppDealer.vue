<template>
  <div class="dl-root">
    <!-- Launcher (opened from the desktop, no RLS session yet) -->
    <div v-if="!hosted" class="rl-page dl-launch">
      <div class="dl-intro">
        <div class="dl-intro-icon"><BngIcon type="carDealer" /></div>
        <div>
          <h2 class="rl-h1">Concessionárias</h2>
          <p class="rl-muted">Estoque das concessionárias e dos vendedores particulares do mapa, compra com entrega na garagem, seguro e troca,
            negociação de preço e o marketplace para vender os seus carros.</p>
          <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>As concessionárias atendem pelos computadores das suas garagens.</div>
          <template v-else-if="fn">
            <button class="rl-btn primary" :disabled="fn.disabled" @click="launch">Abrir concessionárias</button>
            <p v-if="fn.disabled && reasonText(fn)" class="rl-error">{{ reasonText(fn) }}</p>
          </template>
          <div v-else class="rl-empty"><b>Indisponível aqui</b>Este computador não tem acesso às concessionárias.</div>
        </div>
      </div>
    </div>

    <!-- ===================== Purchase ===================== -->
    <div v-else-if="isPurchase" class="dl">
      <header class="dl-site">
        <div class="dl-logo"><BngIcon type="carDealer" /><b>River<span>Autos</span></b><small>Finalizar compra</small></div>
        <div class="dl-wallet"><small>{{ rtFleet ? "Conta da equipe" : "Seu saldo" }}</small><b>{{ dollars(spendable) }}</b></div>
      </header>

      <div class="dl-scroll">
        <div v-if="pFailed && !pLoaded" class="rl-empty"><b>Não foi possível abrir a compra</b>O anúncio pode ter expirado.
          <div class="dl-center"><button class="rl-btn" @click="backToList">Voltar</button></div></div>
        <div v-else-if="!pLoaded" class="rl-empty"><b>Preparando a compra...</b>Calculando preço, taxas e opções.</div>

        <div v-else class="dl-buy">
          <div class="dl-buy-main">
            <section class="dl-buy-hero">
              <div class="dl-buy-photo">
                <img v-if="vi.preview" :src="vi.preview" alt="" @error="hideImg" />
                <div v-else class="dl-noimg"><BngIcon type="carStarred" /></div>
              </div>
              <div class="dl-buy-title">
                <small class="rl-muted">Comprando de {{ vi.sellerName || "vendedor" }}{{ channelOf(vi.salesChannel || pd.salesChannel) ? " · " + channelOf(vi.salesChannel || pd.salesChannel) : "" }}</small>
                <h2>{{ vi.year }} {{ vi.niceName }}</h2>
                <div class="dl-chips">
                  <span>{{ mileageText(vi.Mileage) }}</span>
                  <span v-if="vi.Power">{{ Math.round(vi.Power) }} cv</span>
                  <span v-if="vi.Transmission">{{ TRANSMISSION[vi.Transmission] || vi.Transmission }}</span>
                  <span v-if="vi.Drivetrain">{{ DRIVETRAIN[vi.Drivetrain] || vi.Drivetrain }}</span>
                  <span v-if="vi['Fuel Type']">{{ FUEL[vi['Fuel Type']] || vi['Fuel Type'] }}</span>
                  <span v-if="vi.insuranceClass?.name">Seguro exigido: {{ vi.insuranceClass.name }}</span>
                </div>
                <span v-if="pd.purchaseType === 'inspect'" class="rl-badge ok">Você está com o carro na loja</span>
              </div>
            </section>

            <!-- Delivery -->
            <section v-if="!isCarMeet" class="dl-sec">
              <h3 class="rl-h2"><BngIcon type="parking" /> Retirada ou entrega</h3>
              <label class="dl-opt" :class="{ on: !makeDelivery }">
                <input v-model="makeDelivery" type="radio" :value="false" />
                <span><b>{{ isOnlinePurchase ? "Retirar no ponto de frete" : "Retirar no local" }}</b><small>{{ pickupText }}</small></span>
              </label>
              <label class="dl-opt" :class="{ on: makeDelivery, off: !deliveryPossible }">
                <input v-model="makeDelivery" type="radio" :value="true" :disabled="!deliveryPossible" />
                <span><b>Entregar em uma garagem minha</b><small>{{ deliveryNote }}</small></span>
              </label>
              <div v-if="makeDelivery && deliveryPossible" class="dl-garages">
                <label v-for="g in pd.deliveryGarages" :key="g.id" class="dl-garage" :class="{ on: garageId === String(g.id), off: quotes[String(g.id)]?.disabled }">
                  <input v-model="garageId" type="radio" :value="String(g.id)" :disabled="quotes[String(g.id)]?.disabled" />
                  <span class="dl-garage-name"><b>{{ g.name }}</b><small>{{ g.freeSlots }} vaga(s) livre(s)</small></span>
                  <span v-if="quotesLoading" class="rl-muted">calculando...</span>
                  <span v-else-if="quotes[String(g.id)]?.disabled" class="dl-garage-price rl-error">{{ tr(quotes[String(g.id)].reason) }}</span>
                  <span v-else-if="quotes[String(g.id)]" class="dl-garage-price">
                    <s v-if="quotes[String(g.id)].discount > 0">{{ dollars(quotes[String(g.id)].fullPrice) }}</s>
                    <b>{{ dollars(quotes[String(g.id)].finalPrice) }}</b>
                    <small>{{ distanceText(quotes[String(g.id)].roadDistance) }} · chega em ~{{ eta(quotes[String(g.id)].etaSeconds) }}
                      <template v-if="quotes[String(g.id)].discount > 0"> · {{ Math.round(quotes[String(g.id)].discount * 100) }}% de desconto</template></small>
                  </span>
                </label>
              </div>
              <p v-if="!makeDelivery && pd.freightAvailable === false" class="dl-warn">{{ tr(pd.freightUnavailableReason) || "Retirada indisponível para esta loja." }}</p>
            </section>

            <!-- Insurance -->
            <section v-if="!isCarMeet && !rtFleet" class="dl-sec">
              <h3 class="rl-h2"><BngIcon type="shieldCheckmark" /> Seguro</h3>
              <div class="dl-line">
                <div>
                  <b>{{ insuranceId > 0 ? insuranceName : "Sem seguro" }}</b>
                  <small class="rl-muted">{{ insuranceId > 0 ? "Cobrado junto com a compra: " + dollars(pd.insuranceOptions.priceMoney || 0) : "Sem seguro você paga 100% dos reparos." }}</small>
                </div>
                <button class="rl-btn" :disabled="busy || !vi.insuranceClass?.id" :title="vi.insuranceClass?.id ? '' : 'Este carro não tem classe de seguro'" @click="openInsurance">Escolher seguro</button>
              </div>
            </section>

            <!-- Trade-in -->
            <section v-if="!isCarMeet && !rtFleet" class="dl-sec">
              <h3 class="rl-h2"><BngIcon type="keys1" /> Carro na troca</h3>
              <div class="dl-line">
                <div v-if="tradeIn.niceName">
                  <b>{{ tradeIn.niceName }}</b>
                  <small class="rl-muted">Abatimento de {{ dollars(tradeIn.Value || 0) }} no preço (o carro sai da sua garagem ao comprar).</small>
                </div>
                <div v-else>
                  <b>Nenhum</b>
                  <small class="rl-muted">{{ tradeInHint }}</small>
                </div>
                <div class="rl-row">
                  <button v-if="tradeIn.niceName" class="rl-btn danger" :disabled="busy" @click="removeTradeIn">Remover</button>
                  <button class="rl-btn" :disabled="busy || !pd.tradeInEnabled || inventoryEmpty" @click="chooseTradeIn">{{ tradeIn.niceName ? "Trocar o carro" : "Escolher carro" }}</button>
                </div>
              </div>
              <p v-if="pd.tradeInEnabled" class="rl-muted small">A escolha abre a lista de veículos do RLS; depois você volta para esta compra.</p>
            </section>

            <!-- Plate -->
            <section v-if="!isCarMeet && !rtFleet" class="dl-sec">
              <h3 class="rl-h2"><BngIcon type="badge" /> Placa</h3>
              <label class="dl-check"><input v-model="plate.on" type="checkbox" /> Placa personalizada (+{{ dollars(pd.prices.customLicensePlate || 0) }})</label>
              <div v-if="plate.on" class="rl-row dl-plate">
                <input v-model.trim="plate.text" class="rl-input dl-plate-input" maxlength="10" placeholder="RIVER01" @focus="typing(true)" @blur="typing(false)" />
                <span v-if="plate.checking" class="rl-muted">verificando...</span>
                <span v-else-if="plate.text && !plate.valid" class="rl-error">Caracteres inválidos</span>
                <span v-else-if="plate.text" class="rl-badge ok">Disponível</span>
              </div>
            </section>

            <!-- Extras -->
            <section v-if="canNegotiatePurchase || pd.purchaseType === 'inspect'" class="dl-sec">
              <h3 class="rl-h2"><BngIcon type="steeringWheelCommon" /> Antes de fechar</h3>
              <div class="rl-row">
                <button v-if="canNegotiatePurchase" class="rl-btn" :disabled="busy" @click="startBuyNego(vi, true)">Negociar o preço</button>
                <button v-if="pd.purchaseType === 'inspect'" class="rl-btn" :disabled="busy || pd.alreadyDidTestDrive" @click="testDrive">Test drive</button>
              </div>
              <p v-if="pd.purchaseType === 'inspect'" class="rl-muted small">{{ pd.alreadyDidTestDrive ? "Você já fez o test drive deste carro." : "No test drive você paga 50% dos reparos de qualquer dano." }}</p>
            </section>
          </div>

          <aside class="dl-buy-side">
            <div class="dl-receipt">
              <h3>Resumo da compra</h3>
              <table><tbody>
                <tr><td>Veículo</td><td><s v-if="vi.originalSellValue" class="rl-muted">{{ dollars(vi.originalSellValue) }}</s> {{ dollars(vi.valueAdjusted || vi.Value || 0, true) }}</td></tr>
                <tr v-if="!vi.hideMarketValue" class="sub"><td>Valor de mercado estimado</td><td>{{ dollars(vi.marketValueAdjusted || vi.marketValue || 0) }}</td></tr>
                <tr v-if="insuranceId > 0 && !rtFleet"><td>{{ insuranceName }}</td><td>{{ dollars(pd.insuranceOptions.priceMoney || 0, true) }}</td></tr>
                <tr><td>Taxas da loja</td><td>{{ dollars(pd.prices.fees ?? vi.fees ?? 0, true) }}</td></tr>
                <tr v-if="tradeIn.niceName" class="good"><td>Troca: {{ tradeIn.niceName }}</td><td>−{{ dollars(tradeIn.Value || 0, true) }}</td></tr>
                <tr class="line"><td>Subtotal</td><td>{{ dollars(subtotal, true) }}</td></tr>
                <tr><td>Impostos{{ taxLabel }}</td><td>{{ dollars(pd.prices.taxes || 0, true) }}</td></tr>
                <tr v-if="plateCost"><td>Placa personalizada</td><td>{{ dollars(plateCost, true) }}</td></tr>
                <tr v-if="deliveryOn"><td>Entrega: {{ quote.garageName }}</td><td>{{ dollars(quote.finalPrice, true) }}</td></tr>
                <tr class="total"><td>Total</td><td>{{ dollars(total, true) }}</td></tr>
                <tr class="sub"><td>{{ rtFleet ? "Conta da equipe" : "Seu saldo" }}</td><td>{{ dollars(spendable, true) }}</td></tr>
                <tr v-if="total > spendable" class="bad"><td>Faltam</td><td>{{ dollars(total - spendable, true) }}</td></tr>
              </tbody></table>
            </div>
            <ul v-if="blockers.length" class="dl-blockers">
              <li v-for="b in blockers" :key="b">{{ b }}</li>
            </ul>
            <button class="rl-btn go dl-buy-btn" :disabled="busy || blockers.length > 0" @click="askBuy">{{ busy ? "Aguarde..." : buyLabel }}</button>
            <button class="rl-btn dl-back-btn" :disabled="busy" @click="backToList">{{ pd.purchaseType === "inspect" ? "Desistir da compra" : "Voltar ao estoque" }}</button>
          </aside>
        </div>
      </div>
      <footer class="dl-status">
        <span>{{ pd?.inventoryHasFreeSlot ? "Há vaga livre nas suas garagens" : "Garagens sem vaga livre" }}</span>
        <span>{{ pd?.purchaseType === "inspect" ? "Compra presencial" : "Compra pelo computador" }}</span>
      </footer>
    </div>

    <!-- ===================== Shop ===================== -->
    <div v-else class="dl">
      <header class="dl-site">
        <div class="dl-logo"><BngIcon type="carDealer" /><b>River<span>Autos</span></b><small>Concessionárias e classificados</small></div>
        <form v-if="tab !== 'sell'" class="dl-search" @submit.prevent="searchGo">
          <BngIcon type="search" />
          <input v-model="filters.q" placeholder="Buscar marca, modelo ou vendedor" @focus="typing(true)" @blur="typing(false)" />
          <button class="rl-btn primary">Buscar</button>
        </form>
        <div class="dl-wallet"><small>{{ data.racingTeamBusinessId ? "Conta da equipe" : "Seu saldo" }}</small><b>{{ dollars(money) }}</b></div>
      </header>

      <nav v-if="tabs.length > 1" class="rl-tabs dl-tabs">
        <button v-for="t in tabs" :key="t.id" :class="{ on: tab === t.id }" @click="tab = t.id">{{ t.label }}<span v-if="t.id === 'sell' && offerCount" class="dl-count">{{ offerCount }}</span></button>
      </nav>

      <div ref="scrollEl" class="dl-scroll">
        <div v-if="!loaded" class="rl-empty"><b>Carregando o estoque...</b>Buscando concessionárias e anúncios.</div>
        <div v-else-if="loadFailed" class="rl-empty"><b>Não foi possível carregar o estoque</b>O jogo não respondeu.
          <div class="dl-center"><button class="rl-btn primary" @click="retryShop">Tentar de novo</button></div></div>
        <template v-else>
          <p v-if="data.disableShopping" class="dl-warn dl-pad">{{ data.disableShoppingReason || "Compras bloqueadas no momento." }}</p>

          <!-- Home: dealerships -->
          <section v-if="tab === 'home'" class="dl-pad">
            <div class="dl-sec-head">
              <div>
                <h2 class="rl-h1">Concessionárias</h2>
                <p class="rl-muted">Descobertas: {{ discovery.discovered }} de {{ discovery.total }} · visite uma loja pessoalmente para liberar o estoque dela aqui.</p>
              </div>
              <button class="rl-btn primary" @click="tab = 'all'">Ver todos os carros ({{ visibleVehicles.length }})</button>
            </div>
            <div class="dl-dealers">
              <article v-for="d in dealerCards" :key="d.id" class="dl-dealer" :class="{ locked: d.undiscovered, offline: d.hidden && !d.undiscovered }">
                <div class="dl-dealer-photo">
                  <img v-if="d.preview && !d.undiscovered" :src="d.preview" alt="" @error="hideImg" />
                  <div v-else class="dl-noimg"><BngIcon :type="d.undiscovered ? 'search' : 'carDealer'" /></div>
                  <span class="dl-channel" :class="d.channel">{{ CHANNELS[d.channel] || "Loja" }}</span>
                  <div v-if="d.thumbs.length && !d.undiscovered" class="dl-thumbs">
                    <img v-for="(t, i) in d.thumbs" :key="i" :src="t" alt="" @error="hideImg" />
                  </div>
                </div>
                <div class="dl-dealer-body">
                  <h3>{{ d.name }}</h3>
                  <p class="rl-muted dl-desc">{{ d.undiscovered ? "Loja ainda não descoberta. Vá até ela para liberar o estoque no computador." : (d.description || "Concessionária") }}</p>
                  <div class="dl-badges">
                    <span v-if="d.undiscovered" class="rl-badge">Não descoberta</span>
                    <span v-else-if="d.disabled" class="rl-badge bad">Bloqueada</span>
                    <span v-else-if="d.hidden" class="rl-badge warn">Estoque só na loja</span>
                    <span v-else class="rl-badge ok">{{ d.count }} carro(s){{ isFinite(d.min) ? " · desde " + dollars(d.min) : "" }}</span>
                    <span v-if="!d.undiscovered && d.online" class="rl-badge">Compra online</span>
                    <span v-else-if="!d.undiscovered && d.remotePurchaseAllowed" class="rl-badge ok">Compra à distância</span>
                    <span v-if="!d.undiscovered && d.garageDeliveryAllowed" class="rl-badge ok">Entrega na garagem</span>
                  </div>
                  <div v-if="d.rep && !d.undiscovered" class="dl-rep" :title="'Reputação com a loja'">
                    <div class="dl-rep-bar"><i :style="{ width: d.rep.percentage + '%' }"></i></div>
                    <small>Nível {{ d.rep.level }} · {{ d.rep.purchasesToNext > 0 ? "faltam ~" + d.rep.purchasesToNext + " compra(s) para subir" : "nível máximo" }}</small>
                  </div>
                  <p v-if="d.travel && !d.online && d.id !== 'private'" class="rl-muted small">
                    <template v-if="d.travel.distance != null">A {{ distanceText(d.travel.distance) }} daqui</template>
                    <template v-if="d.travel.price != null"> · táxi {{ dollars(d.travel.price) }}</template>
                  </p>
                  <p v-if="d.disabled && d.disabledReason" class="rl-error small">{{ d.disabledReason }}</p>
                  <div class="rl-row dl-dealer-actions">
                    <button class="rl-btn primary" :disabled="busy || !!d.stockBlock" :title="d.stockBlock" @click="viewStock(d)">Ver estoque</button>
                    <template v-if="!d.online && d.id !== 'private'">
                      <button class="rl-btn" :disabled="busy" @click="gpsDealer(d)">GPS</button>
                      <button class="rl-btn" :disabled="busy || d.disabled || (d.travel?.price > taxiMoney)" @click="taxiDealer(d)">Táxi{{ d.travel?.price != null ? " " + dollars(d.travel.price) : "" }}</button>
                    </template>
                  </div>
                </div>
              </article>
            </div>
            <div v-if="!dealerCards.length" class="rl-empty"><b>Nenhuma concessionária neste mapa</b>Este mapa não tem lojas configuradas.</div>
          </section>

          <!-- Seller hero (vehicles route) -->
          <div v-if="tab === 'stock' && !stockSellerId" class="dl-sec-head dl-pad">
            <div><h2 class="rl-h1">Todos os carros</h2><p class="rl-muted">Estoque de todas as concessionárias liberadas.</p></div>
            <button class="rl-btn" :disabled="busy" @click="leaveStock">← Concessionárias</button>
          </div>
          <section v-if="tab === 'stock' && stockSellerId" class="dl-hero">
            <div class="dl-hero-photo">
              <img v-if="stockDealer?.preview" :src="stockDealer.preview" alt="" @error="hideImg" />
              <div v-else class="dl-noimg"><BngIcon type="carDealer" /></div>
            </div>
            <div class="dl-hero-body">
              <div class="dl-sec-head">
                <div>
                  <h2 class="rl-h1">{{ stockName }}</h2>
                  <p class="rl-muted">{{ stockDealer?.description || (stockSellerId === "private" ? "Carros anunciados por particulares pelo mapa." : "Concessionária") }}</p>
                </div>
                <div class="rl-row">
                  <button class="rl-btn" :disabled="busy" @click="leaveStock">{{ data.currentSeller ? "Sair da loja" : "← Todas as concessionárias" }}</button>
                </div>
              </div>
              <div class="dl-badges">
                <span v-if="data.currentSeller" class="rl-badge ok">Você está na loja</span>
                <span v-if="stockDealer?.salesChannel" class="rl-badge">{{ CHANNELS[stockDealer.salesChannel] || "Loja" }}</span>
                <template v-if="stockDealer && stockSellerId !== 'private' && !data.currentSeller">
                  <span class="rl-badge" :class="stockDealer.remotePurchaseAllowed ? 'ok' : 'warn'">{{ stockDealer.remotePurchaseAllowed ? "Compra à distância liberada" : "Compra só na loja (nível 2)" }}</span>
                  <span class="rl-badge" :class="stockDealer.garageDeliveryAllowed ? 'ok' : ''">{{ stockDealer.garageDeliveryAllowed ? "Entrega na garagem" : "Sem entrega na garagem" }}</span>
                  <span v-if="stockDealer.deliveryDiscount > 0" class="rl-badge ok">{{ Math.round(stockDealer.deliveryDiscount * 100) }}% de desconto na entrega</span>
                </template>
              </div>
              <div v-if="repData(stockSellerId)" class="dl-rep">
                <div class="dl-rep-bar"><i :style="{ width: repData(stockSellerId).percentage + '%' }"></i></div>
                <small>Reputação nível {{ repData(stockSellerId).level }} · {{ repData(stockSellerId).purchasesToNext > 0 ? "faltam ~" + repData(stockSellerId).purchasesToNext + " compra(s) para subir" : "nível máximo" }}</small>
              </div>
            </div>
          </section>

          <!-- Vehicle list (all cars / one seller) -->
          <section v-if="tab === 'all' || tab === 'stock'">
            <div class="dl-toolbar">
              <XPSelect v-model="filters.brand" title="Marca" :options="[{ value: '', label: 'Todas as marcas' }, ...brands.map(b => ({ value: b, label: b }))]" />
              <XPSelect v-if="tab === 'all'" v-model="filters.seller" title="Vendedor"
                :options="[{ value: '', label: 'Todos os vendedores' }, ...sellerOptions.map(s => ({ value: s.id, label: s.name }))]" />
              <input v-model.number="filters.maxPrice" class="rl-input dl-num" type="number" min="0" step="1000" placeholder="Preço máx. ($)" @focus="typing(true)" @blur="typing(false)" />
              <input v-model.number="filters.minYear" class="rl-input dl-year" type="number" placeholder="Ano de" @focus="typing(true)" @blur="typing(false)" />
              <input v-model.number="filters.maxYear" class="rl-input dl-year" type="number" placeholder="até" @focus="typing(true)" @blur="typing(false)" />
              <input v-model.number="filters.maxKm" class="rl-input dl-num" type="number" min="0" step="1000" placeholder="Km máx." @focus="typing(true)" @blur="typing(false)" />
              <label class="dl-check"><input v-model="filters.affordable" type="checkbox" /> Só o que posso pagar</label>
              <XPSelect v-model="filters.sort" title="Ordenar" :options="SORTS.map(s => ({ value: s.id, label: s.label }))" />
              <button v-if="filtersActive" class="rl-btn" @click="clearFilters">Limpar</button>
            </div>
            <div class="dl-listhead dl-pad">
              <b>{{ filtered.length }} carro(s){{ tab === "stock" && stockSellerId ? " em " + stockName : "" }}</b>
              <span class="rl-muted">* Preços sem taxas da loja e impostos.</span>
            </div>

            <div v-if="!filtered.length" class="rl-empty">
              <b>{{ baseList.length ? "Nenhum carro com esses filtros" : "Nenhum carro disponível" }}</b>
              {{ baseList.length ? "Ajuste a busca ou limpe os filtros." : "O estoque se renova com o tempo. Volte mais tarde." }}
            </div>

            <div class="dl-ads dl-pad">
              <article v-for="v in pageItems" :key="v.shopId" class="dl-ad" :class="{ sold: isSold(v) }">
                <div class="dl-ad-photo">
                  <img v-if="v.preview" :src="v.preview" alt="" @error="hideImg" />
                  <div v-else class="dl-noimg"><BngIcon type="carStarred" /></div>
                  <span v-if="isSold(v)" class="dl-sold">VENDIDO</span>
                  <span v-else-if="isNew(v)" class="dl-flag">Novo</span>
                </div>
                <div class="dl-ad-info">
                  <h4>{{ v.year }} {{ v.Brand }} {{ v.Name }}</h4>
                  <div class="dl-chips">
                    <span>{{ mileageText(v.Mileage) }}</span>
                    <span v-if="v.Power">{{ Math.round(v.Power) }} cv</span>
                    <span v-if="v.Transmission">{{ TRANSMISSION[v.Transmission] || v.Transmission }}</span>
                    <span v-if="v.Drivetrain">{{ DRIVETRAIN[v.Drivetrain] || v.Drivetrain }}</span>
                    <span v-if="v['Fuel Type']">{{ FUEL[v['Fuel Type']] || v['Fuel Type'] }}</span>
                    <span v-if="v.Weight">{{ Math.round(v.Weight) }} kg</span>
                  </div>
                  <p class="dl-seller"><BngIcon :type="v.sellerId === 'private' ? 'personSolid' : 'carDealer'" /> {{ v.sellerName || "Vendedor" }}
                    <template v-if="!data.currentSeller && !isOnline(v) && v.distance != null"> · a {{ distanceText(v.distance) }}</template>
                    <template v-if="isOnline(v)"> · compra online</template></p>
                  <p class="rl-muted small">Seguro exigido: {{ v.insuranceClass?.name || v.requiredInsurance?.name || "—" }}<template v-if="v.generationTime"> · anunciado {{ adAge(v) }}</template></p>
                </div>
                <div class="dl-ad-side">
                  <div class="dl-price" :class="{ bad: priceOf(v) > money && !data.cheatsMode, sold: isSold(v) }">{{ dollars(priceOf(v)) }}</div>
                  <span v-if="marketTag(v)" class="rl-badge" :class="marketTag(v).cls">{{ marketTag(v).text }}</span>
                  <div class="dl-actions">
                    <button v-if="v.sellerId !== 'private'" class="rl-btn go" :disabled="busy || !!buyBlock(v)" :title="buyBlock(v)" @click="buyVehicle(v)">{{ buyLabelFor(v) }}</button>
                    <button v-if="negoBlock(v) !== null" class="rl-btn" :disabled="busy || !!negoBlock(v)" :title="negoBlock(v)" @click="startBuyNego(v)">Negociar</button>
                    <button v-if="!isOnline(v)" class="rl-btn" :disabled="busy || isSold(v) || data.disableShopping || !v.pos" @click="inspect(v)">{{ atSeller(v) ? "Inspecionar" : "Ver de perto" }}</button>
                    <button v-if="!isOnline(v) && !data.currentSeller" class="rl-btn" :disabled="busy || isSold(v) || data.disableShopping || taxiTooExpensive(v)" @click="taxiVehicle(v)">Táxi {{ isFinite(Number(v.quickTravelPrice)) ? dollars(v.quickTravelPrice) : "" }}</button>
                  </div>
                  <small v-if="!isSold(v) && sideReason(v)" class="dl-reason">{{ sideReason(v) }}</small>
                </div>
              </article>
            </div>

            <div v-if="pages > 1" class="dl-pager">
              <button class="rl-btn" :disabled="page <= 1" @click="page--">‹ Anterior</button>
              <span>Página {{ page }} de {{ pages }}</span>
              <button class="rl-btn" :disabled="page >= pages" @click="page++">Próxima ›</button>
            </div>

            <template v-if="soldList.length">
              <h3 class="rl-h2 dl-pad">Vendidos recentemente</h3>
              <div class="dl-soldgrid dl-pad">
                <div v-for="v in soldList" :key="'s' + v.shopId" class="dl-soldcard">
                  <div class="dl-soldphoto"><img v-if="v.preview" :src="v.preview" alt="" @error="hideImg" /><span class="dl-sold">VENDIDO</span></div>
                  <b>{{ v.year }} {{ v.Name }}</b><small class="rl-muted">{{ dollars(v.soldFor || priceOf(v)) }}</small>
                </div>
              </div>
            </template>
          </section>

          <!-- Sell tab (marketplace) -->
          <section v-if="tab === 'sell'" class="dl-pad">
            <div class="dl-sec-head">
              <div>
                <h2 class="rl-h1">Vender meu carro</h2>
                <p class="rl-muted">Anuncie no marketplace do RLS e receba propostas de compradores. Preço perto do mercado atrai propostas mais rápido.</p>
              </div>
            </div>

            <div class="rl-box dl-newlisting">
              <h3 class="rl-h2 first">Anunciar um carro</h3>
              <div v-if="!sellableLoaded" class="rl-muted">Carregando seus carros...</div>
              <div v-else-if="!sellable.length" class="rl-muted">Nenhum carro disponível para anunciar (todos já estão anunciados, ou você não tem carros próprios).</div>
              <div v-else class="dl-newlisting-row">
                <img v-if="chosenCar?.thumbnail" class="dl-mini" :src="chosenCar.thumbnail" alt="" @error="hideImg" />
                <label>Carro
                  <XPSelect v-model="listForm.id" :options="sellable.map(c => ({ value: c.id, label: c.niceName + (c.needsRepair ? ' (precisa de reparo)' : '') }))" />
                </label>
                <label>Preço pedido ($)
                  <input v-model.number="listForm.price" class="rl-input dl-num" type="number" min="50" step="50" @focus="typing(true)" @blur="typing(false)" />
                </label>
                <button class="rl-btn primary" :disabled="busy || !listForm.id || !(listForm.price > 0)" @click="listCar">Anunciar</button>
              </div>
              <p v-if="chosenCar" class="rl-muted small">Valor de mercado: {{ dollars(chosenCar.value) }}<template v-if="chosenCar.mileage != null"> · {{ km(chosenCar.mileage) }}</template>
                <template v-if="listForm.price > 0 && chosenCar.value > 0"> · seu preço: {{ ratioText(listForm.price, chosenCar.value) }}</template></p>
              <p v-if="listForm.error" class="rl-error">{{ listForm.error }}</p>
            </div>

            <h3 class="rl-h2">Meus anúncios</h3>
            <div v-if="!sellLoaded" class="rl-muted">Carregando anúncios...</div>
            <div v-else-if="!listings.length" class="rl-empty"><b>Nenhum anúncio ativo</b>Anuncie um carro acima para começar a receber propostas.</div>
            <article v-for="l in listings" :key="l.id" class="dl-listing rl-box" :class="{ off: l.disabled }">
              <div class="dl-listing-head">
                <img v-if="l.thumbnail" class="dl-mini" :src="l.thumbnail" alt="" @error="hideImg" />
                <div class="dl-listing-title">
                  <b>{{ l.niceName }}</b>
                  <small class="rl-muted">
                    <template v-if="l.vehicleData?.year">{{ l.vehicleData.year }} · </template>
                    <template v-if="l.vehicleData?.mileage != null">{{ km(l.vehicleData.mileage) }} · </template>
                    <template v-if="l.vehicleData?.condition != null">estado {{ l.vehicleData.condition }}% · </template>
                    mercado {{ dollars(l.marketValue || l.value) }}</small>
                </div>
                <div class="dl-listing-price">
                  <small>Preço pedido</small><b>{{ dollars(l.value) }}</b>
                  <small :class="deltaClass(l.value, l.marketValue)">{{ ratioText(l.value, l.marketValue) }}</small>
                </div>
              </div>
              <p v-if="l.disabled" class="dl-warn">{{ tr(l.disableReason) || "Anúncio bloqueado." }}</p>
              <div class="rl-row dl-listing-actions">
                <template v-if="priceEdit[l.id] != null">
                  <input v-model.number="priceEdit[l.id]" class="rl-input dl-num" type="number" min="50" step="50" @focus="typing(true)" @blur="typing(false)" @keydown.enter="savePrice(l)" />
                  <button class="rl-btn primary" :disabled="busy" @click="savePrice(l)">Salvar preço</button>
                  <button class="rl-btn" @click="priceEdit[l.id] = null">Cancelar</button>
                </template>
                <button v-else class="rl-btn" :disabled="busy" @click="priceEdit[l.id] = Math.max(50, Math.round((l.value || 0) / 50) * 50)">Alterar preço</button>
                <button class="rl-btn danger" :disabled="busy" @click="askRemoveListing(l)">Remover anúncio</button>
              </div>

              <div class="dl-offers">
                <div v-if="!l.offers.length" class="rl-muted small">Nenhuma proposta ainda.</div>
                <div v-for="o in l.offers" :key="o.id" class="dl-offer" :class="{ expired: o.expiredViewCounter }">
                  <span class="dl-avatar" :style="{ background: avatarColor(o.buyerPersonality?.name) }">{{ initials(o.buyerPersonality?.name) }}</span>
                  <div class="dl-offer-text">
                    <b>{{ o.buyerPersonality?.name || "Comprador" }}</b>
                    <small v-if="o.quote" class="rl-muted">“{{ o.quote }}”</small>
                  </div>
                  <div class="dl-offer-value">
                    <b>{{ dollars(o.value) }}</b>
                    <small :class="o.value >= l.value ? 'pos' : 'neg'">{{ o.value >= l.value ? "+" : "−" }}{{ dollars(Math.abs(o.value - l.value)) }}</small>
                    <small v-if="o.expiredViewCounter" class="rl-badge bad">Expirada</small>
                    <small v-else-if="o.secondsLeft != null" class="rl-muted">expira em {{ clock(offerSeconds(o)) }}</small>
                  </div>
                  <div class="rl-row dl-offer-actions">
                    <button class="rl-btn" :disabled="busy" @click="declineOffer(o)">{{ o.expiredViewCounter ? "Descartar" : "Recusar" }}</button>
                    <template v-if="!o.expiredViewCounter">
                      <button class="rl-btn" :disabled="busy || !o.negotiationPossible || o.value >= l.value || l.disabled || l.damagedAfterListing" @click="startSellNego(l, o)">Negociar</button>
                      <button class="rl-btn go" :disabled="busy || l.disabled || o.disabled || l.damagedAfterListing" @click="askAcceptOffer(l, o)">Aceitar</button>
                    </template>
                  </div>
                </div>
              </div>
            </article>
          </section>
        </template>
      </div>

      <footer class="dl-status">
        <span>Vagas livres nas garagens: <b>{{ data.numberOfFreeSlots ?? "—" }}</b></span>
        <span v-if="data.currentSeller">Na loja: {{ data.currentSellerNiceName || stockName }}</span>
        <span v-else-if="discovery.total">Concessionárias descobertas: {{ discovery.discovered }}/{{ discovery.total }}</span>
      </footer>
    </div>

    <!-- Insurance chooser (purchase) -->
    <div v-if="hosted && ins.open" class="dl-modal" @pointerdown.self="ins.open = false">
      <div class="dl-dialog wide">
        <header class="dl-dialog-title"><BngIcon type="shieldCheckmark" /> Escolher seguro<button @click="ins.open = false">×</button></header>
        <div class="dl-dialog-body">
          <div v-if="ins.failed && !ins.loaded" class="rl-empty"><b>Seguradoras indisponíveis</b>Não foi possível carregar as opções de seguro para este carro.</div>
          <div v-else-if="!ins.loaded" class="rl-empty"><b>Consultando seguradoras...</b></div>
          <template v-else>
            <p class="rl-muted">Classe exigida: <b>{{ vi.insuranceClass?.name || "—" }}</b><template v-if="ins.driverScore != null"> · seu score de motorista: <b>{{ ins.driverScore }}</b></template></p>
            <div class="dl-ins-grid">
              <button v-for="c in ins.list" :key="c.id" class="dl-ins" :class="{ on: c.id === ins.selected }" :style="{ borderTopColor: c.color || '#7f8ea3' }" @click="ins.selected = c.id">
                <div class="dl-ins-head">
                  <img v-if="c.image" :src="assetUrl(c.image)" alt="" @error="hideImg" />
                  <b>{{ c.id === -1 ? "Sem seguro" : c.name }}</b>
                </div>
                <small class="rl-muted">{{ c.id === -1 ? "Você paga todos os reparos do próprio bolso." : c.slogan }}</small>
                <ul><li v-for="(p, i) in perksOf(c)" :key="i">{{ p }}</li></ul>
                <div class="dl-ins-price">
                  <span><small>Na compra</small><b>{{ dollars(c.id === -1 ? 0 : (c.amountDue ?? c.addVehiclePrice ?? 0)) }}</b></span>
                  <span v-if="c.id !== -1 && c.futurePremiumDetails"><small>Renovação</small><b>{{ dollars(c.futurePremiumDetails.totalPriceWithDriverScore || 0) }}</b><small v-if="c.renewsEvery">a cada {{ c.renewsEvery }} km</small></span>
                  <span v-if="c.id !== -1 && c.baseDeductibledData?.price != null"><small>Franquia</small><b>{{ dollars(c.baseDeductibledData.price) }}</b></span>
                </div>
                <small v-if="c.carsInsuredCount" class="rl-muted">{{ c.carsInsuredCount }} carro(s) seu(s) já nesta seguradora</small>
              </button>
            </div>
          </template>
        </div>
        <footer class="dl-dialog-foot">
          <button class="rl-btn" @click="ins.open = false">Cancelar</button>
          <button class="rl-btn primary" :disabled="!ins.loaded || busy" @click="confirmInsurance">Usar esta opção</button>
        </footer>
      </div>
    </div>

    <!-- Negotiation (phone variant of the RLS negotiation, shown in-app) -->
    <div v-if="hosted && nego.open" class="dl-modal">
      <div class="dl-dialog nego">
        <header class="dl-dialog-title"><BngIcon type="envelope" /> Negociação<template v-if="nego.state.vehicleNiceName"> — {{ nego.state.vehicleNiceName }}</template>
          <button :disabled="nego.pending" @click="negoAskExit">×</button></header>
        <div class="dl-nego-who">
          <span class="dl-avatar big" :style="{ background: avatarColor(negoName) }">{{ initials(negoName) }}</span>
          <div class="dl-nego-whotext">
            <b>{{ negoName }}</b>
            <small>{{ nego.state.amISelling ? "quer comprar o seu carro" : nego.ctx?.sellerName && nego.ctx.sellerName !== negoName ? nego.ctx.sellerName : "vendedor" }}
              <template v-if="nego.state.vehicleMileage != null"> · {{ km(nego.state.vehicleMileage) }}</template></small>
          </div>
          <div v-if="negoMarket != null" class="dl-nego-market"><small>Mercado estimado</small><b>{{ dollars(negoMarket) }}</b></div>
        </div>

        <div ref="chatEl" class="dl-chat">
          <div v-if="nego.loading" class="rl-empty"><b>Abrindo a conversa...</b></div>
          <p v-else-if="!negoMessages.length" class="dl-chat-intro">{{ negoOpening ? "O vendedor não divulgou o preço. Faça a primeira oferta." : "Faça a sua proposta." }}</p>
          <div v-for="m in negoMessages" :key="m.key" class="dl-msg" :class="{ mine: m.mine }">
            <small>{{ m.label }}</small>
            <div class="dl-bubble" :class="m.tone">
              <b v-if="m.price != null">{{ dollars(m.price) }}</b>
              <i v-if="m.note">{{ m.note }}</i>
            </div>
          </div>
          <div v-if="negoWaiting" class="dl-msg"><small>{{ negoStatus === "typing" ? "Digitando" : "Pensando" }}</small><div class="dl-bubble typing"><span></span><span></span><span></span></div></div>
        </div>

        <div class="dl-nego-foot">
          <div class="dl-turn">
            <span class="dl-turn-tag" :class="negoTurnClass">{{ negoTurnText }}</span>
            <span class="dl-patience-text" :class="negoPatienceClass">{{ negoPatienceText }}</span>
          </div>
          <div class="dl-patience"><i :class="negoPatienceClass" :style="{ width: negoPatiencePct + '%' }"></i></div>

          <template v-if="nego.loading"></template>
          <template v-else-if="!negoResolved">
            <div class="dl-offer-row">
              <button class="rl-btn" :disabled="!negoMyTurn" @click="negoNudge(-500)">−500</button>
              <button class="rl-btn" :disabled="!negoMyTurn" @click="negoNudge(-50)">−50</button>
              <div class="dl-offer-input"><small>{{ negoOpening ? "Sua primeira oferta" : nego.state.amISelling ? "Seu novo preço" : "Sua oferta" }}</small>
                <input v-model.number="nego.preview" type="number" min="0" step="50" class="rl-input" :disabled="!negoMyTurn" @focus="typing(true)" @blur="typing(false)" @keydown.enter="negoSend" /></div>
              <button class="rl-btn" :disabled="!negoMyTurn" @click="negoNudge(50)">+50</button>
              <button class="rl-btn" :disabled="!negoMyTurn" @click="negoNudge(500)">+500</button>
              <button class="rl-btn" :disabled="!negoMyTurn || nego.splitUsed || !negoSplitOk" :title="'Meio-termo entre as duas propostas (uma vez por negociação)'" @click="negoSplit">Meio-termo</button>
            </div>
            <p v-if="negoMarketDiff" class="dl-nego-diff" :class="negoMarketDiff.good ? 'pos' : 'neg'">{{ negoMarketDiff.text }}</p>
            <p v-if="negoHint" class="dl-nego-hint">{{ negoHint }}</p>
            <div class="rl-row dl-nego-actions">
              <button class="rl-btn" :disabled="nego.pending" @click="negoAskExit">Desistir</button>
              <button v-if="nego.state.hasVisibleTheirOffer" class="rl-btn go" :disabled="!negoCanTake" @click="negoTake">Aceitar {{ dollars(nego.state.theirOffer) }}</button>
              <button class="rl-btn primary" :disabled="!negoCanSend" @click="negoSend">Enviar {{ dollars(Number(nego.preview) || 0) }}</button>
            </div>
          </template>
          <template v-else>
            <div class="dl-resolved" :class="{ bad: negoStatus === 'failed' || nego.state.purchaseFailureReason }">
              <b>{{ negoResolvedTitle }}</b>
              <p>{{ negoResolvedText }}</p>
            </div>
            <div class="rl-row dl-nego-actions">
              <button v-if="negoStatus === 'accepted' && !nego.state.purchaseFailureReason && !(nego.state.amISelling && nego.iAccepted)" class="rl-btn" :disabled="nego.pending" @click="negoAskExit">Agora não</button>
              <button class="rl-btn primary" :disabled="nego.pending" @click="negoStatus === 'accepted' && !nego.state.purchaseFailureReason ? negoFinish() : negoExit()">{{ nego.pending ? "Aguarde..." : negoResolvedAction }}</button>
            </div>
          </template>
        </div>
      </div>
    </div>

    <!-- Confirmation box -->
    <div v-if="confirmBox" class="dl-modal top" @pointerdown.self="confirmBox = null">
      <div class="dl-dialog small">
        <header class="dl-dialog-title">{{ confirmBox.title || "Confirmar" }}<button @click="confirmBox = null">×</button></header>
        <div class="dl-dialog-body"><p class="dl-confirm-text">{{ confirmBox.text }}</p></div>
        <footer class="dl-dialog-foot">
          <button class="rl-btn" @click="confirmBox = null">Cancelar</button>
          <button class="rl-btn" :class="confirmBox.danger ? 'danger' : 'primary'" @click="runConfirm">{{ confirmBox.yes || "Confirmar" }}</button>
        </footer>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, luaCall, luaRun, luaValue, onGameEvent, dollars, arr, typing, toast, km, distanceText, ago } from "../rl.js"

const props = defineProps({
  route: String, routeProps: Object, nonce: Number,
  screenTag: String, buyingAvailable: [String, Boolean], marketplaceAvailable: [String, Boolean], selectedSellerId: String,
})
const emit = defineEmits(["open", "title", "close"])

const R_SHOP = "career.computer.vehicleShopping"
const R_LIST = "career.computer.vehicleShopping.vehicles"
const R_BUY = "career.computer.vehicleShopping.vehicles.vehiclePurchase"
const VS = "career_modules_vehicleShopping"
const MP = "career_modules_marketplace"
const PAGE = 24

const CHANNELS = { local: "Loja física", factory: "Direto da fábrica", remanufactured: "Seminovos certificados", private: "Particulares" }
const TRANSMISSION = { Automatic: "Automático", Manual: "Manual", Sequential: "Sequencial", "Dual Clutch": "Dupla embreagem", DCT: "Dupla embreagem", CVT: "CVT" }
const DRIVETRAIN = { AWD: "Integral (AWD)", "4WD": "4x4", FWD: "Dianteira", RWD: "Traseira" }
const FUEL = { Gasoline: "Gasolina", Diesel: "Diesel", Battery: "Elétrico", Electric: "Elétrico", Hybrid: "Híbrido" }
const SORTS = [
  { id: "price_asc", label: "Menor preço" }, { id: "price_desc", label: "Maior preço" }, { id: "deal", label: "Melhor negócio" },
  { id: "year_desc", label: "Mais novos" }, { id: "year_asc", label: "Mais antigos" }, { id: "km_asc", label: "Menor km" },
  { id: "power_desc", label: "Mais potentes" }, { id: "dist_asc", label: "Mais perto" },
]
// Lua messages that reach the screen verbatim.
const LUA_TEXT = {
  "Garage delivery unlocks at dealer reputation level 2.": "A entrega na garagem libera no nível 2 de reputação com a loja.",
  "Choose an owned garage.": "Escolha uma garagem sua.",
  "The selected garage has no free space.": "A garagem escolhida não tem vaga livre.",
  "Delivery route is unavailable.": "Não há rota de entrega até essa garagem.",
  "No active vehicle purchase.": "Nenhuma compra em andamento.",
  "This map has no freight pickup point configured for online vehicle orders.": "Este mapa não tem ponto de retirada de frete para pedidos online.",
  "The dealership has no delivery origin configured.": "A loja não tem ponto de saída para entregas.",
  "Dealership is unavailable.": "Loja indisponível.",
  "This vehicle was damaged after listing. Repair it before accepting offers.": "O carro foi danificado depois do anúncio. Conserte antes de aceitar propostas.",
  "This offer is no longer available.": "Essa proposta não está mais disponível.",
  "This vehicle is no longer available for purchase.": "Este carro não está mais à venda.",
  "Purchase could not be completed.": "Não foi possível concluir a compra.",
  "Full repair cost": "Você paga o reparo inteiro", "No coverage": "Sem cobertura", "Not recommended": "Não recomendado",
}
function tr(s) { return s ? (LUA_TEXT[s] || s) : "" }

const hosted = computed(() => !!props.route)
const isPurchase = computed(() => props.route === R_BUY)
const isList = computed(() => props.route === R_LIST)
const rp = computed(() => ({ screenTag: props.screenTag, buyingAvailable: props.buyingAvailable, marketplaceAvailable: props.marketplaceAvailable,
  selectedSellerId: props.selectedSellerId, ...(props.routeProps || {}) }))
const fn = computed(() => rl.view.computer?.computerFunctions?.general?.vehicleShop)

const busy = ref(false)
const confirmBox = ref(null)
const now = ref(Date.now())
const scrollEl = ref(null)
const chatEl = ref(null)
let timer = null, offs = [], alive = true

// engineLua callbacks never fire when the Lua side errors: never wait forever.
function callT(expr, ms = 8000) { return Promise.race([luaCall(expr), new Promise(r => setTimeout(() => r(undefined), ms))]) }
function runT(code, ms = 8000) { return Promise.race([luaRun(code), new Promise(r => setTimeout(() => r(undefined), ms))]) }

/* ---------------- helpers ---------------- */
function label(l) { return typeof l === "string" ? l : l?.txt || l?.label || "" }
function reasonText(f) { return label(f?.reason?.label) || label(f?.reason) }
function launch() { request("native", { buttonId: "vehicleShop" }) }
function flag(v, dflt) { return v === undefined || v === null || v === "" ? dflt : v === true || v === "true" }
function hideImg(e) { if (e?.target) e.target.style.display = "none" }
function assetUrl(p) { return !p || /^(\/|https?:|local:|data:)/.test(p) ? p : "/" + p }
function channelOf(c) { return CHANNELS[c] || "" }
function mileageText(m) { const n = Number(m) || 0; return n <= 0 ? "0 km (novo)" : km(n) }
function eta(s) { const v = Math.max(0, Math.round(Number(s) || 0)); return v < 60 ? v + " s" : Math.ceil(v / 60) + " min" }
function clock(s) { const v = Math.max(0, Math.floor(s)); return Math.floor(v / 60) + ":" + String(v % 60).padStart(2, "0") }
function initials(name) { return String(name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase() || "?" }
function avatarColor(name) {
  let h = 0
  for (const ch of String(name || "")) h = (h * 31 + ch.charCodeAt(0)) % 360
  return "hsl(" + h + ", 45%, 42%)"
}
function ratioText(price, market) {
  const m = Number(market) || 0
  if (m <= 0) return ""
  const d = Math.round((Number(price) / m - 1) * 100)
  return d === 0 ? "no valor de mercado" : Math.abs(d) + "% " + (d < 0 ? "abaixo" : "acima") + " do mercado"
}
function deltaClass(price, market) { const m = Number(market) || 0; return !m ? "" : Number(price) <= m * 1.02 ? "pos" : Number(price) > m * 1.1 ? "neg" : "" }
async function runConfirm() {
  const c = confirmBox.value
  confirmBox.value = null
  if (c?.run) await c.run()
}

/* ================================================================
   Shop (dealership list, vehicle list, marketplace)
   ================================================================ */
const data = ref({})
const loaded = ref(false)
const loadFailed = ref(false)
const tab = ref("home")
const page = ref(1)
const filters = reactive({ q: "", brand: "", seller: "", maxPrice: null, minYear: null, maxYear: null, maxKm: null, affordable: false, sort: "price_asc" })
const dealerTravel = ref({})
let travelLoaded = false

const money = computed(() => {
  const d = data.value
  if (d.racingTeamBusinessId && d.racingTeamBusinessMoney != null) return Number(d.racingTeamBusinessMoney) || 0
  return Number(d.playerAttributes?.money?.value ?? d.playerAttributes?.money ?? 0) || 0
})
const taxiMoney = computed(() => {
  const d = data.value
  return Number(d.playerPersonalMoneyForTaxi ?? d.playerAttributes?.money?.value ?? d.playerAttributes?.money ?? 0) || 0
})
const buyingAvailable = computed(() => data.value.buyingAvailable ?? flag(rp.value.buyingAvailable, true))
const marketplaceAvailable = computed(() => data.value.marketplaceAvailable ?? flag(rp.value.marketplaceAvailable, true))
const discovery = computed(() => {
  const p = data.value.dealershipDiscovery || {}
  const total = Math.max(0, Number(p.total) || 0)
  return { total, discovered: Math.min(total, Math.max(0, Number(p.discovered) || 0)) }
})
const dealerMap = computed(() => {
  const m = {}
  for (const d of arr(data.value.dealerships)) if (d && d.id != null && !m[d.id]) m[d.id] = d
  return m
})
const uiDealerMap = computed(() => {
  const m = {}
  for (const d of arr(data.value.uiDealershipsData)) if (d && d.id != null) m[d.id] = d
  return m
})
function dealerName(id) {
  if (id === "private") return "Vendedores particulares"
  const n = uiDealerMap.value[id]?.name || dealerMap.value[id]?.name
  return n && !/^ui\./.test(n) ? n : String(id || "Loja")
}

// Same rule as the RLS shopping store: undiscovered or reputation-gated dealers hide their stock.
function isDealerHidden(id) {
  const d = data.value
  const meta = dealerMap.value[id]
  if (!meta) return false
  let hidden = !!meta.hiddenFromDealerList
  if (meta.undiscovered === false) return hidden
  const atThisSeller = d.currentSeller != null && String(d.currentSeller) === String(id)
  if (!atThisSeller && meta.associatedOrganization && d.organizations) {
    const org = d.organizations[meta.associatedOrganization]
    if (org?.reputationLevels && org.reputation && org.reputation.level != null) {
      const lvl = arr(org.reputationLevels)[(org.reputation.level || 0) + 1]
      if (lvl && lvl.hiddenFromDealerList) hidden = true
    }
  }
  return hidden
}
function repData(id) {
  const orgId = dealerMap.value[id]?.associatedOrganization
  const org = orgId && data.value.organizations ? data.value.organizations[orgId] : null
  if (!org || !org.reputation) return null
  const level = typeof org.reputation.level === "number" ? org.reputation.level : 0
  const cur = org.reputation.curLvlProgress, need = org.reputation.neededForNext
  const gain = Number(data.value.dealershipPurchaseReputationGain) || 786
  let percentage = 0, purchasesToNext = 0
  if (typeof cur === "number" && typeof need === "number" && need > 0) {
    percentage = Math.round(Math.max(0, Math.min(1, cur / need)) * 100)
    purchasesToNext = Math.ceil(Math.max(0, need - cur) / Math.max(1, gain))
  }
  return { level, percentage, purchasesToNext }
}

const tabs = computed(() => {
  if (isList.value) return []
  const t = []
  if (buyingAvailable.value) t.push({ id: "home", label: "Concessionárias" }, { id: "all", label: "Todos os carros" })
  if (marketplaceAvailable.value) t.push({ id: "sell", label: "Vender meu carro" })
  return t
})
function initialTab() {
  if (isList.value) return "stock"
  const tag = rp.value.screenTag || data.value.screenTag || ""
  if (tag === "marketplace" && marketplaceAvailable.value) return "sell"
  if (buyingAvailable.value) return "home"
  return marketplaceAvailable.value ? "sell" : "home"
}

function setData(d) {
  if (!d || typeof d !== "object") return
  data.value = {
    ...d,
    vehiclesInShop: arr(d.vehiclesInShop), soldVehicles: arr(d.soldVehicles), dealerships: arr(d.dealerships),
    uiDealershipsData: arr(d.uiDealershipsData), organizations: d.organizations && typeof d.organizations === "object" ? d.organizations : {},
  }
  loaded.value = true
  // Data that arrives after a slow first answer (the RLS restock can take seconds online) still fills the page.
  loadFailed.value = false
}
async function loadShop() {
  const d = await callT(VS + ".getShoppingData()", 30000)
  if (!d || typeof d !== "object") { if (!data.value.vehiclesInShop) loadFailed.value = true; return }
  loadFailed.value = false
  setData(d)
}
async function retryShop() {
  loadFailed.value = false
  await loadShop()
  if (tab.value === "home") { travelLoaded = false; loadTravel() }
}

// Live stock changes (RLS sends them only while setShoppingUiOpen(true)).
function applyDelta(delta) {
  if (!delta || typeof delta !== "object" || !loaded.value) return
  const d = data.value
  let list = arr(d.vehiclesInShop).slice(), sold = arr(d.soldVehicles).slice()
  for (const v of arr(delta.added)) {
    if (!v || v.shopId == null) continue
    const i = list.findIndex(x => x.shopId === v.shopId)
    if (i >= 0) list[i] = v; else list.push(v)
  }
  for (const s of arr(delta.sold)) {
    const id = s && typeof s === "object" ? s.shopId : s
    const i = list.findIndex(x => x.shopId === id)
    if (i < 0) continue
    const v = { ...list[i], ...(s && typeof s === "object" ? s : {}), __sold: true }
    list.splice(i, 1)
    const j = sold.findIndex(x => x.shopId === id)
    if (j >= 0) sold[j] = v; else sold.push(v)
  }
  for (const id of arr(delta.removed)) { list = list.filter(x => x.shopId !== id); sold = sold.filter(x => x.shopId !== id) }
  for (const u of arr(delta.updated)) {
    if (!u) continue
    const i = list.findIndex(x => x.shopId === u.shopId)
    if (i >= 0) list[i] = { ...list[i], ...u }
    const j = sold.findIndex(x => x.shopId === u.shopId)
    if (j >= 0) sold[j] = { ...sold[j], ...u }
  }
  const next = { ...d, vehiclesInShop: list, soldVehicles: sold }
  if (delta.organizations && typeof delta.organizations === "object") next.organizations = delta.organizations
  if (typeof delta.dealershipPurchaseReputationGain === "number") next.dealershipPurchaseReputationGain = delta.dealershipPurchaseReputationGain
  data.value = next
}

const DEALER_TRAVEL_LUA = `
local out = {}
local vs = career_modules_vehicleShopping
local okf, facilities = pcall(freeroam_facilities.getFacilities, getCurrentLevelIdentifier())
if not okf or type(facilities) ~= "table" then return out end
local pv = getPlayerVehicle(0)
local ppos = pv and pv:getPosition() or nil
for _, d in ipairs(facilities.dealerships or {}) do
  local e = {}
  local okp, price = pcall(vs.getTaxiPriceToDealership, d.id)
  if okp and type(price) == "number" then e.price = price end
  local okd, pos = pcall(freeroam_facilities.getAverageDoorPositionForFacility, d)
  if okd and pos and ppos then e.distance = (pos - ppos):length() end
  out[d.id] = e
end
return out`
async function loadTravel() {
  if (travelLoaded) return
  travelLoaded = true
  const res = await runT(DEALER_TRAVEL_LUA)
  dealerTravel.value = res && typeof res === "object" ? res : {}
}

function priceOf(v) { return Number(v?.valueAdjusted || v?.Value || 0) }
function isSold(v) { return !!(v.__sold || v.soldViewCounter > 0) }
function isNew(v) { return v.generationTime && Date.now() / 1000 - v.generationTime < 900 }
function adAge(v) { const a = ago(v.generationTime); return a === "agora" ? "agora" : "há " + a }
function sellerMeta(v) { return dealerMap.value[v.sellerId] || null }
function isOnline(v) { const c = sellerMeta(v)?.salesChannel ?? v.salesChannel; return c === "factory" || c === "remanufactured" }
function atSeller(v) { return data.value.currentSeller != null && String(v.sellerId) === String(data.value.currentSeller) }
function canBuyHere(v) { return atSeller(v) || (sellerMeta(v)?.remotePurchaseAllowed ?? v.remotePurchaseAllowed) === true }
function taxiTooExpensive(v) { const p = Number(v.quickTravelPrice); return !data.value.cheatsMode && isFinite(p) && taxiMoney.value < p }
function buyLabelFor(v) {
  if (data.value.racingTeamBusinessId) return "Comprar p/ equipe"
  const delivery = sellerMeta(v)?.garageDeliveryAllowed ?? v.garageDeliveryAllowed
  return isOnline(v) && !delivery ? "Encomendar" : "Comprar"
}
function buyBlock(v) {
  const d = data.value
  if (isSold(v)) return "Vendido"
  if (d.disableShopping) return d.disableShoppingReason || "Compras bloqueadas agora"
  if (d.tutorialPurchase) return "Compre o primeiro carro pessoalmente, na loja"
  if (!canBuyHere(v)) return "Compra à distância libera no nível 2 de reputação. Visite a loja para comprar."
  if (priceOf(v) > money.value && !d.cheatsMode) return "Saldo insuficiente"
  return ""
}
// null = button hidden; "" = enabled; text = disabled reason.
function negoBlock(v) {
  if (v.negotiationPossible === false && !isSold(v)) return "O vendedor não negocia mais este carro"
  if (Number(v.discountPercentage) > 0) return null
  if (isSold(v) || data.value.disableShopping) return "Indisponível"
  if (v.sellerId !== "private" && !canBuyHere(v)) return "Negocie pessoalmente na loja"
  return ""
}
function sideReason(v) {
  const b = v.sellerId !== "private" ? buyBlock(v) : ""
  if (b && b !== "Saldo insuficiente") return b
  if (b) return "Faltam " + dollars(priceOf(v) - money.value)
  if (v.sellerId === "private") return "Particular: veja o carro ou negocie o preço."
  return ""
}
function marketTag(v) {
  if (v.hideMarketValue || isSold(v)) return null
  const m = Number(v.marketValueAdjusted || v.marketValue) || 0
  if (m <= 0) return null
  const d = Math.round((priceOf(v) / m - 1) * 100)
  if (Math.abs(d) < 3) return { text: "Preço de mercado", cls: "" }
  return d < 0 ? { text: Math.abs(d) + "% abaixo do mercado", cls: "ok" } : { text: d + "% acima do mercado", cls: "warn" }
}

const visibleVehicles = computed(() => {
  const d = data.value
  return arr(d.vehiclesInShop).filter(v => d.currentSeller != null ? String(v.sellerId) === String(d.currentSeller) : !isDealerHidden(v.sellerId))
})
const stockSellerId = computed(() => String(data.value.currentSeller || data.value.selectedSellerId || rp.value.selectedSellerId || ""))
const stockDealer = computed(() => dealerMap.value[stockSellerId.value] || uiDealerMap.value[stockSellerId.value] || null)
const stockName = computed(() => data.value.currentSellerNiceName || (stockSellerId.value ? dealerName(stockSellerId.value) : "Todos os carros"))
const baseList = computed(() => tab.value === "stock"
  ? visibleVehicles.value.filter(v => !stockSellerId.value || String(v.sellerId) === stockSellerId.value)
  : visibleVehicles.value)
const brands = computed(() => [...new Set(baseList.value.map(v => v.Brand).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b))))
const sellerOptions = computed(() => {
  const seen = new Map()
  for (const v of visibleVehicles.value) if (v.sellerId != null && !seen.has(String(v.sellerId))) seen.set(String(v.sellerId), dealerName(v.sellerId))
  return [...seen].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name))
})
const filtersActive = computed(() => !!(filters.q || filters.brand || filters.seller || filters.maxPrice || filters.minYear || filters.maxYear || filters.maxKm || filters.affordable))
const filtered = computed(() => {
  const q = String(filters.q || "").trim().toLowerCase()
  const list = baseList.value.filter(v => {
    if (q && ![v.Name, v.Brand, v.niceName, v.model_key, v.config_name, v.sellerName].some(x => x && String(x).toLowerCase().includes(q))) return false
    if (filters.brand && v.Brand !== filters.brand) return false
    if (tab.value === "all" && filters.seller && String(v.sellerId) !== filters.seller) return false
    const p = priceOf(v)
    if (filters.maxPrice > 0 && p > filters.maxPrice) return false
    if (filters.affordable && p > money.value) return false
    if (filters.minYear > 0 && (Number(v.year) || 0) < filters.minYear) return false
    if (filters.maxYear > 0 && (Number(v.year) || 0) > filters.maxYear) return false
    if (filters.maxKm > 0 && (Number(v.Mileage) || 0) / 1000 > filters.maxKm) return false
    return true
  })
  const num = (x, dflt) => { const n = Number(x); return isFinite(n) ? n : dflt }
  const ratio = v => { const m = Number(v.marketValueAdjusted || v.marketValue) || 0; return m > 0 ? priceOf(v) / m : 9 }
  const by = {
    price_asc: (a, b) => priceOf(a) - priceOf(b), price_desc: (a, b) => priceOf(b) - priceOf(a), deal: (a, b) => ratio(a) - ratio(b),
    year_desc: (a, b) => num(b.year, 0) - num(a.year, 0), year_asc: (a, b) => num(a.year, 9999) - num(b.year, 9999),
    km_asc: (a, b) => num(a.Mileage, 1e12) - num(b.Mileage, 1e12), power_desc: (a, b) => num(b.Power, 0) - num(a.Power, 0),
    dist_asc: (a, b) => num(a.distance, 1e12) - num(b.distance, 1e12),
  }[filters.sort] || ((a, b) => priceOf(a) - priceOf(b))
  return list.sort((a, b) => (isSold(a) ? 1 : 0) - (isSold(b) ? 1 : 0) || by(a, b))
})
const pages = computed(() => Math.max(1, Math.ceil(filtered.value.length / PAGE)))
const pageItems = computed(() => filtered.value.slice((page.value - 1) * PAGE, page.value * PAGE))
const soldList = computed(() => {
  let list = arr(data.value.soldVehicles)
  if (tab.value === "stock" && stockSellerId.value) list = list.filter(v => String(v.sellerId) === stockSellerId.value)
  else if (data.value.currentSeller != null) list = list.filter(v => String(v.sellerId) === String(data.value.currentSeller))
  return list.slice(0, 8)
})
watch(filters, () => { page.value = 1 }, { deep: true })
watch(pages, p => { if (page.value > p) page.value = 1 })
watch(page, () => nextTick(() => { if (scrollEl.value) scrollEl.value.scrollTop = 0 }))
function clearFilters() { Object.assign(filters, { q: "", brand: "", seller: "", maxPrice: null, minYear: null, maxYear: null, maxKm: null, affordable: false }) }
function searchGo() { if (tab.value === "home") tab.value = "all" }

const dealerCards = computed(() => {
  const stats = {}
  for (const v of arr(data.value.vehiclesInShop)) {
    const s = stats[v.sellerId] || (stats[v.sellerId] = { count: 0, min: Infinity, thumbs: [] })
    s.count++
    s.min = Math.min(s.min, priceOf(v))
    if (s.thumbs.length < 4 && v.preview) s.thumbs.push(v.preview)
  }
  const out = []
  for (const m of Object.values(dealerMap.value)) {
    const st = stats[m.id] || { count: 0, min: Infinity, thumbs: [] }
    const channel = m.salesChannel || (m.id === "private" ? "private" : "local")
    const hidden = isDealerHidden(m.id)
    const card = {
      ...m, name: dealerName(m.id), channel, online: channel === "factory" || channel === "remanufactured", hidden,
      count: st.count, min: st.min, thumbs: st.thumbs, rep: repData(m.id), travel: dealerTravel.value[m.id] || null,
      preview: m.preview || uiDealerMap.value[m.id]?.preview,
    }
    card.stockBlock = m.undiscovered ? "Visite a loja pessoalmente para liberar o estoque"
      : m.disabled ? (m.disabledReason || "Loja bloqueada")
      : hidden ? "Estoque indisponível à distância no seu nível de reputação. Vá até a loja." : ""
    out.push(card)
  }
  const rank = c => c.undiscovered ? 2 : c.hidden ? 1 : 0
  return out.sort((a, b) => rank(a) - rank(b) || (a.id === "private" ? 1 : 0) - (b.id === "private" ? 1 : 0) || a.name.localeCompare(b.name))
})

function viewStock(d) {
  if (d.stockBlock || busy.value) return
  busy.value = true
  luaCall(VS + ".selectSeller(" + luaValue(String(d.id)) + ")")
  setTimeout(() => { if (alive) busy.value = false }, 2500)
}
function gpsDealer(d) { luaCall(VS + ".navigateToDealership(" + luaValue(String(d.id)) + ")") }
async function taxiDealer(d) {
  let price = d.travel?.price
  if (price == null) price = await callT(VS + ".getTaxiPriceToDealership(" + luaValue(String(d.id)) + ")", 4000)
  confirmBox.value = {
    title: "Táxi", text: "Ir de táxi até " + d.name + " por " + dollars(Math.max(0, Number(price) || 0)) + "?", yes: "Chamar táxi",
    run: () => luaCall(VS + ".taxiToDealership(" + luaValue(String(d.id)) + ")"),
  }
}
function leaveStock() { luaCall("extensions.ui_router.back()") }
function inspect(v) {
  const id = Number(v.shopId)
  if (atSeller(v)) luaCall(VS + ".showVehicle(" + id + ")")
  else luaCall(VS + ".navigateToPos(" + luaValue(v.pos) + ", " + id + ")")
}
function taxiVehicle(v) {
  const p = Number(v.quickTravelPrice)
  confirmBox.value = {
    title: "Táxi até o carro", yes: "Chamar táxi",
    text: "Ir de táxi até o " + [v.year, v.Brand, v.Name].filter(Boolean).join(" ") + (isFinite(p) ? " por " + dollars(p) : " (preço calculado na corrida)") + "?",
    run: () => luaCall(VS + ".quickTravelToVehicle(" + Number(v.shopId) + ")"),
  }
}
function buyVehicle(v) {
  if (buyBlock(v) || busy.value) return
  busy.value = true
  luaCall(VS + ".openPurchaseMenu('instant', " + Number(v.shopId) + ")")
  setTimeout(() => { if (alive) busy.value = false }, 2500)
}

/* ---------------- marketplace (sell) ---------------- */
const listings = ref([])
const listingsAt = ref(Date.now())
const sellLoaded = ref(false)
const sellable = ref([])
const sellableLoaded = ref(false)
const listForm = reactive({ id: "", price: null, error: "" })
const priceEdit = reactive({})
let sellActive = false, offSell = null, offSellDone = null

const SELLABLE_LUA = `
local out = {}
local inv = career_modules_inventory
if not inv or not inv.getVehicles then return out end
local mp = career_modules_marketplace
local vc = career_modules_valueCalculator
local ins = career_modules_insurance_insurance
for id, v in pairs(inv.getVehicles() or {}) do
  if type(id) == "number" and type(v) == "table" and v.owned ~= false and not v.loanType and not (mp and mp.findVehicleListing and mp.findVehicleListing(id)) then
    local name = v.niceName
    if core_locales and core_locales.translateWithOrWithoutContext then
      local ok, t = pcall(core_locales.translateWithOrWithoutContext, name)
      if ok and type(t) == "string" then name = t end
    end
    local okv, value = pcall(vc.getInventoryVehicleSellValue, id)
    local okt, thumb = pcall(inv.getVehicleThumbnail, id)
    local okm, miles = pcall(vc.getVehicleMileageById, id)
    local okr, repair = pcall(ins.inventoryVehNeedsRepair, id)
    table.insert(out, { id = id, niceName = type(name) == "string" and name or tostring(v.model or id), value = okv and tonumber(value) or 0,
      thumbnail = okt and thumb or nil, mileage = okm and tonumber(miles) or nil, needsRepair = okr and repair and true or false })
  end
end
table.sort(out, function(a, b) return a.niceName < b.niceName end)
return out`

const chosenCar = computed(() => sellable.value.find(c => c.id === listForm.id) || null)
const offerCount = computed(() => listings.value.reduce((s, l) => s + l.offers.filter(o => !o.expiredViewCounter).length, 0))
watch(() => listForm.id, () => {
  listForm.error = ""
  if (chosenCar.value) listForm.price = Math.max(50, Math.round((chosenCar.value.value || 0) / 50) * 50)
})
function setListings(d) {
  listings.value = arr(d).map(l => ({ ...l, offers: arr(l.offers) }))
  listingsAt.value = Date.now()
  sellLoaded.value = true
}
async function refreshListings() { setListings(await callT(MP + ".getListings()")) }
async function refreshSellable() {
  sellable.value = arr(await runT(SELLABLE_LUA))
  sellableLoaded.value = true
  if (!sellable.value.some(c => c.id === listForm.id)) listForm.id = sellable.value[0]?.id ?? ""
}
async function startSell() {
  if (sellActive) return
  sellActive = true
  luaCall(MP + ".menuOpened(true)")
  offSell = onGameEvent("marketplaceListingsUpdated", setListings)
  await refreshListings()
  await refreshSellable()
}
function stopSell() {
  if (!sellActive) return
  sellActive = false
  luaCall(MP + ".menuOpened(false)")
  if (offSell) { offSell(); offSell = null }
  if (offSellDone) { offSellDone(); offSellDone = null }
}
function offerSeconds(o) { return Math.max(0, (Number(o.secondsLeft) || 0) - (now.value - listingsAt.value) / 1000) }
async function listCar() {
  const car = chosenCar.value
  const price = Math.round(Number(listForm.price) || 0)
  if (!car || price <= 0 || busy.value) return
  busy.value = true
  listForm.error = ""
  const requestId = "riveros_" + Date.now()
  const ok = await new Promise(resolve => {
    let done = false
    const finish = v => { if (done) return; done = true; if (offSellDone) { offSellDone(); offSellDone = null } resolve(v) }
    offSellDone = onGameEvent("marketplaceListVehiclesFinished", p => { if (p?.requestId === requestId) finish(!!p.ok) })
    luaCall(MP + ".listVehicles(" + luaValue([{ inventoryId: Number(car.id), value: price }]) + ", " + luaValue(requestId) + ")").then(r => { if (r === false) finish(false) })
    setTimeout(() => finish(false), 8000)
  })
  busy.value = false
  if (!alive) return
  if (!ok) { listForm.error = "O marketplace não aceitou o anúncio agora. Tente de novo."; return }
  toast(car.niceName + " anunciado por " + dollars(price) + ".")
  await refreshListings()
  await refreshSellable()
}
async function savePrice(l) {
  const price = Math.round(Number(priceEdit[l.id]) || 0)
  if (price <= 0 || busy.value) return
  busy.value = true
  const ok = await callT(MP + ".updateListingValue(" + Number(l.id) + ", " + price + ")")
  busy.value = false
  if (!ok) { toast("Preço inválido.", "error"); return }
  priceEdit[l.id] = null
  refreshListings()
}
function askRemoveListing(l) {
  confirmBox.value = {
    title: "Remover anúncio", danger: true, yes: "Remover",
    text: "Tirar " + l.niceName + " do marketplace? As propostas recebidas serão perdidas.",
    run: async () => { await callT(MP + ".removeVehicleListing(" + Number(l.id) + ")"); await refreshListings(); await refreshSellable() },
  }
}
async function declineOffer(o) {
  busy.value = true
  await callT(MP + ".declineOfferById(" + luaValue(o.id) + ")")
  busy.value = false
  refreshListings()
}
function askAcceptOffer(l, o) {
  confirmBox.value = {
    title: "Vender carro", yes: "Vender por " + dollars(o.value),
    text: "Vender " + l.niceName + " para " + (o.buyerPersonality?.name || "o comprador") + " por " + dollars(o.value) + "? O carro sai da sua garagem e o dinheiro entra no seu saldo.",
    run: async () => {
      busy.value = true
      const ok = await callT(MP + ".acceptOfferById(" + luaValue(o.id) + ")")
      busy.value = false
      if (!ok) toast("Essa proposta não pode ser aceita agora.", "error")
      setTimeout(() => { if (alive && sellActive) { refreshListings(); refreshSellable() } }, 1200)
    },
  }
}

/* ================================================================
   Purchase
   ================================================================ */
const pd = ref(null)
const pLoaded = ref(false)
const pFailed = ref(false)
const makeDelivery = ref(false)
const garageId = ref("")
const quotes = ref({})
const quotesLoading = ref(false)
const plate = reactive({ on: false, text: "", valid: false, checking: false })
const inventoryEmpty = ref(false)
let plateTimer = null

const vi = computed(() => pd.value?.vehicleInfo || {})
const tradeIn = computed(() => pd.value?.tradeInVehicleInfo || {})
const isCarMeet = computed(() => vi.value.source === "carMeet")
const rtFleet = computed(() => pd.value?.racingTeamFleetPurchase === true)
const isOnlinePurchase = computed(() => ["factory", "remanufactured"].includes(vi.value.salesChannel || pd.value?.salesChannel))
const deliveryPossible = computed(() => !!pd.value && pd.value.garageDeliveryAllowed === true && pd.value.deliveryGarages.length > 0 && !pd.value.forceNoDelivery && !isCarMeet.value)
const spendable = computed(() => rtFleet.value ? Number(pd.value?.racingTeamBusinessMoney) || 0 : Number(pd.value?.playerMoney) || 0)
const quote = computed(() => quotes.value[garageId.value] || null)
const deliveryOn = computed(() => makeDelivery.value && !!quote.value && !quote.value.disabled)
const insuranceId = computed(() => Number(pd.value?.insuranceOptions?.insuranceId ?? -1))
const insuranceName = computed(() => {
  const m = /"(.+)"/.exec(String(pd.value?.insuranceOptions?.spendingReason || ""))
  return "Seguro " + (m ? m[1] : "selecionado")
})
const plateCost = computed(() => plate.on && !rtFleet.value ? Number(pd.value?.prices?.customLicensePlate) || 0 : 0)
// Same total as the RLS purchase store (insurance and delivery are added on top of finalPrice).
const total = computed(() => {
  const p = pd.value
  if (!p) return 0
  let t = Number(p.prices.finalPrice) || 0
  if (rtFleet.value) return t
  t += plateCost.value
  if (insuranceId.value > 0) t += Number(p.insuranceOptions.priceMoney) || 0
  if (deliveryOn.value) t += Number(quote.value.finalPrice) || 0
  return t
})
const subtotal = computed(() => total.value - (Number(pd.value?.prices?.taxes) || 0) - plateCost.value - (deliveryOn.value ? Number(quote.value.finalPrice) || 0 : 0))
const taxLabel = computed(() => {
  const taxes = Number(pd.value?.prices?.taxes) || 0
  if (taxes <= 0) return " (isento)"
  const rate = Number(vi.value.tax)
  return " (" + (isFinite(rate) && rate > 0 ? Math.round(rate * 1000) / 10 : 7) + "%)"
})
const fitsInventory = computed(() => {
  const p = pd.value
  if (!p) return false
  if (vi.value.takesNoInventorySpace) return true
  return !!p.inventoryHasFreeSlot || (!!tradeIn.value.niceName && !tradeIn.value.takesNoInventorySpace)
})
const blockers = computed(() => {
  const p = pd.value
  if (!p) return []
  const out = []
  if (total.value > spendable.value) out.push((rtFleet.value ? "Saldo da equipe insuficiente" : "Saldo insuficiente") + ": faltam " + dollars(total.value - spendable.value, true) + ".")
  if (!rtFleet.value && p.garageAvailability === "none") out.push("Você precisa comprar ou alugar uma garagem antes de comprar um carro.")
  if (!fitsInventory.value) out.push("Sem vaga livre nas suas garagens. Venda ou guarde um carro, ou dê um na troca.")
  if (p.forceTradeIn && !tradeIn.value.niceName) out.push("Para este primeiro carro é obrigatório dar um veículo na troca.")
  if (plate.on && (!plate.text || !plate.valid || plate.checking)) out.push("Digite uma placa personalizada válida.")
  if (makeDelivery.value) {
    if (quotesLoading.value) out.push("Calculando o frete...")
    else if (!garageId.value || !quote.value) out.push("Escolha a garagem de entrega.")
    else if (quote.value.disabled) out.push(tr(quote.value.reason) || "Entrega indisponível para essa garagem.")
  } else if (p.freightAvailable === false) out.push(tr(p.freightUnavailableReason) || "Retirada indisponível para esta loja.")
  return out
})
const buyLabel = computed(() => rtFleet.value ? "Comprar para a equipe" : isOnlinePurchase.value && !makeDelivery.value ? "Encomendar para retirada"
  : isOnlinePurchase.value ? "Comprar e entregar" : "Confirmar compra")
const pickupText = computed(() => {
  if (pd.value?.purchaseType === "inspect") return "Você sai dirigindo o carro que está inspecionando."
  if (isOnlinePurchase.value) return "O carro fica no ponto de retirada de frete e aparece em Meus veículos como retirada pendente."
  if (vi.value.sellerId === "private") return "O carro fica onde está anunciado; vá buscá-lo."
  return "O carro fica no estacionamento da concessionária."
})
const deliveryNote = computed(() => {
  const p = pd.value
  if (!p) return ""
  if (p.forceNoDelivery) return "Indisponível na compra do primeiro carro."
  if (!p.garageDeliveryAllowed) return isOnlinePurchase.value ? "Pedidos online são retirados no frete até o nível 2 de reputação com a loja." : "Libera no nível 2 de reputação com a loja."
  if (!p.deliveryGarages.length) return "Nenhuma garagem sua tem vaga livre para receber o carro."
  return "Um caminhão leva o carro até a garagem escolhida" + (p.deliveryDiscount > 0 ? " (" + Math.round(p.deliveryDiscount * 100) + "% de desconto pela sua reputação)." : ".")
})
const tradeInHint = computed(() => {
  if (!pd.value?.tradeInEnabled) return "A troca só é possível pessoalmente, na concessionária."
  if (inventoryEmpty.value) return "Você não tem carros para dar na troca."
  return "Dê um carro seu como parte do pagamento."
})
const canNegotiatePurchase = computed(() => !!pd.value && vi.value.negotiationPossible !== false && vi.value.negotiationPossible != null
  && !(Number(vi.value.discountPercentage) > 0) && !isCarMeet.value && !rtFleet.value)

function onPurchaseData(d) {
  if (!d || typeof d !== "object") return
  const first = !pd.value
  const prevDelivery = makeDelivery.value, prevGarage = garageId.value
  pd.value = {
    ...d, vehicleInfo: d.vehicleInfo || {}, prices: d.prices || {}, insuranceOptions: d.insuranceOptions || {},
    tradeInVehicleInfo: d.tradeInVehicleInfo && typeof d.tradeInVehicleInfo === "object" ? d.tradeInVehicleInfo : {},
    deliveryGarages: arr(d.deliveryGarages),
  }
  pLoaded.value = true
  busy.value = false
  const garages = pd.value.deliveryGarages
  const keep = garages.some(g => String(g.id) === prevGarage)
  makeDelivery.value = deliveryPossible.value && (first ? true : prevDelivery)
  garageId.value = keep ? prevGarage : deliveryPossible.value ? String(garages[0].id) : ""
  emit("title", vi.value.niceName || "Compra de veículo")
  loadQuotes()
}
async function loadQuotes() {
  const p = pd.value
  const ids = (p?.deliveryGarages || []).map(g => String(g.id))
  if (!ids.length || p.garageDeliveryAllowed !== true) { quotes.value = {}; return }
  quotesLoading.value = true
  const res = await runT("local out = {} for _, id in ipairs(" + luaValue(ids) + ") do local ok, q = pcall(" + VS
    + ".getDeliveryQuote, id) out[id] = ok and q or { disabled = true, reason = 'Delivery route is unavailable.' } end return out")
  quotes.value = res && typeof res === "object" ? res : {}
  quotesLoading.value = false
}
watch(() => plate.text, t => {
  clearTimeout(plateTimer)
  if (!t) { plate.valid = false; plate.checking = false; return }
  plate.checking = true
  plateTimer = setTimeout(async () => {
    const ok = await callT("career_modules_inventory.isLicensePlateValid(" + luaValue(t) + ")", 4000)
    if (plate.text === t) { plate.valid = !!ok; plate.checking = false }
  }, 300)
})

function askBuy() {
  if (blockers.value.length || busy.value) return
  confirmBox.value = {
    title: "Confirmar compra", yes: buyLabel.value,
    text: "Pagar " + dollars(total.value, true) + " pelo " + [vi.value.year, vi.value.niceName].filter(Boolean).join(" ")
      + (deliveryOn.value ? ", com entrega em " + quote.value.garageName : "") + "?",
    run: doBuy,
  }
}
function doBuy() {
  const p = pd.value
  if (!p) return
  const options = { makeDelivery: !!makeDelivery.value, insuranceId: insuranceId.value, dealershipId: p.dealershipId }
  if (makeDelivery.value) options.targetGarageId = garageId.value
  if (plate.on && plate.text && !rtFleet.value) options.licensePlateText = plate.text
  if (rtFleet.value || isCarMeet.value) options.insuranceId = -1
  busy.value = true
  luaCall(VS + ".buyFromPurchaseMenu(" + luaValue(p.purchaseType) + ", " + luaValue(options) + ")")
  // On success RLS closes the computer. Still here after a while = refused (message shown by the game).
  setTimeout(() => { if (alive && isPurchase.value) { busy.value = false; luaCall(VS + ".sendPurchaseDataToUi()") } }, 4000)
}
function backToList() {
  const type = pd.value?.purchaseType || "instant"
  busy.value = true
  if (type === "inspect") { luaCall(VS + ".cancelPurchase('inspect')"); setTimeout(() => { if (alive) busy.value = false }, 2500); return }
  // RLS only returns to the stock list while the shop UI counts as open; keep it open for this one call.
  luaRun("local vs = " + VS + " vs.setShoppingUiOpen(true) vs.cancelPurchase(" + luaValue(type) + ") vs.setShoppingUiOpen(false)")
  setTimeout(() => { if (alive) busy.value = false }, 2500)
}
function chooseTradeIn() {
  busy.value = true
  luaCall(VS + ".openInventoryMenuForTradeIn()")
  setTimeout(() => { if (alive) busy.value = false }, 2500)
}
function removeTradeIn() { busy.value = true; luaCall(VS + ".removeTradeInVehicle()"); setTimeout(() => { if (alive) busy.value = false }, 3000) }
function testDrive() { luaCall("career_modules_inspectVehicle.startTestDrive()") }

/* insurance chooser */
const ins = reactive({ open: false, loaded: false, failed: false, list: [], selected: -1, driverScore: null })
function perksOf(c) {
  return arr(c.perks).map(p => tr(typeof p === "string" ? p : p?.intro)).filter(Boolean).slice(0, 6)
}
function openInsurance() {
  const p = pd.value
  if (!p || !vi.value.insuranceClass?.id) return
  Object.assign(ins, { open: true, loaded: false, failed: false, list: [], selected: insuranceId.value })
  luaCall("career_modules_insurance_insurance.sendChooseInsuranceDataToTheUI(" + luaValue(p.purchaseType) + ", " + Number(vi.value.shopId) + ", "
    + luaValue(insuranceId.value) + ")")
  setTimeout(() => { if (alive && ins.open && !ins.loaded) ins.failed = true }, 4000)
}
function onInsuranceData(d) {
  if (!ins.open || !d || typeof d !== "object") return
  ins.list = arr(d.applicableInsurancesData).filter(c => c && c.id != null)
  ins.driverScore = d.driverScoreData?.score ?? null
  if (!ins.list.some(c => c.id === ins.selected)) ins.selected = d.defaultInsuranceId ?? -1
  ins.loaded = true
}
function confirmInsurance() {
  busy.value = true
  luaCall(VS + ".updateInsuranceSelection(" + Number(ins.selected) + ")")
  ins.open = false
  setTimeout(() => { if (alive) busy.value = false }, 1500)
}

/* ================================================================
   Negotiation (marketplace.lua phone variant: events instead of a route)
   ================================================================ */
const nego = reactive({ open: false, loading: false, pending: false, iAccepted: false, splitUsed: false, preview: 0, hint: "", ctx: null, state: {} })
const negoStatus = computed(() => nego.state.negotiationStatus || nego.state.status || "")
const negoWaiting = computed(() => negoStatus.value === "thinking" || negoStatus.value === "typing")
const negoResolved = computed(() => negoStatus.value === "accepted" || negoStatus.value === "failed" || !!nego.state.purchaseFailureReason)
const negoMyTurn = computed(() => !nego.loading && !nego.pending && !negoWaiting.value && !negoResolved.value)
const negoOpening = computed(() => !!nego.state.playerStartsNegotiation && nego.state.myOffer == null && !nego.state.hasVisibleTheirOffer && !negoResolved.value)
const negoName = computed(() => nego.state.opponentName || (nego.state.amISelling ? "Comprador" : nego.ctx?.sellerName || "Vendedor"))
const negoMarket = computed(() => { if (nego.state.hideMarketValue) return null; const v = Number(nego.state.actualVehicleValue); return isFinite(v) && v > 0 ? v : null })
const negoLimits = computed(() => {
  const s = nego.state
  if (s.amISelling) return { min: Number(s.theirOffer) || 0, max: s.myOffer != null ? Number(s.myOffer) : Infinity }
  return { min: s.myOffer != null ? Number(s.myOffer) : 0, max: s.hasVisibleTheirOffer ? Number(s.theirOffer) || 0 : Infinity }
})
const negoSplitOk = computed(() => isFinite(negoLimits.value.min) && isFinite(negoLimits.value.max) && negoLimits.value.max > negoLimits.value.min)
// Mirrors marketplace.isOfferAllowed, minus the no-op of repeating the last number.
function negoAllowed(price) {
  const s = nego.state
  if (!(price > 0)) return false
  if (s.amISelling) return price > (Number(s.theirOffer) || 0) && (s.myOffer == null || price < Number(s.myOffer))
  if (s.hasVisibleTheirOffer && price >= (Number(s.theirOffer) || 0)) return false
  if (s.myOffer != null && price <= Number(s.myOffer)) return false
  return true
}
const negoCanSend = computed(() => negoMyTurn.value && negoStatus.value !== "counterOfferLastChance" && negoAllowed(Math.round(Number(nego.preview) || 0)))
const negoCanTake = computed(() => negoMyTurn.value && !!nego.state.hasVisibleTheirOffer)
const negoHint = computed(() => {
  if (nego.hint) return nego.hint
  if (!negoMyTurn.value) return ""
  const s = nego.state, p = Number(nego.preview) || 0
  if (negoStatus.value === "counterOfferLastChance") return "Essa é a oferta final: aceite ou desista."
  if (!s.amISelling && s.hasVisibleTheirOffer && p >= Number(s.theirOffer)) return "Esse é o preço pedido. Baixe o valor para fazer uma contraproposta, ou aceite."
  if (s.amISelling && p <= Number(s.theirOffer)) return "Peça mais do que a oferta atual do comprador, ou aceite."
  if (s.myOffer != null && p === Number(s.myOffer)) return s.amISelling ? "Baixe do seu último preço para negociar." : "Suba da sua última oferta para negociar."
  if (!s.amISelling && s.myOffer != null && p < Number(s.myOffer)) return "Você não pode oferecer menos que a sua última oferta."
  if (s.amISelling && s.myOffer != null && p > Number(s.myOffer)) return "Você não pode pedir mais do que já pediu."
  return ""
})
const negoMarketDiff = computed(() => {
  const m = negoMarket.value, p = Number(nego.preview) || 0
  if (m == null || !p || negoResolved.value) return null
  const d = Math.round((p / m - 1) * 100)
  const good = nego.state.amISelling ? d >= 0 : d <= 0
  return { good, text: d === 0 ? "No valor de mercado" : Math.abs(d) + "% " + (d < 0 ? "abaixo" : "acima") + " do mercado" }
})
const negoPatience = computed(() => Math.max(0, Math.min(1, Number(nego.state.patience) || 0)))
const negoPatiencePct = computed(() => Math.round(negoPatience.value * 100))
const negoPatienceClass = computed(() => negoPatience.value > 0.66 ? "good" : negoPatience.value > 0.33 ? "mid" : "low")
const negoPatienceText = computed(() => {
  if (negoStatus.value === "counterOfferLastChance") return "Oferta final"
  if (negoStatus.value === "failed") return "Desistiu"
  return negoPatience.value > 0.66 ? "Paciente" : negoPatience.value > 0.33 ? "Ficando impaciente" : "Quase desistindo"
})
const negoTurnText = computed(() => {
  const who = nego.state.amISelling ? "O comprador" : "O vendedor"
  if (nego.loading) return "Conectando..."
  if (nego.pending) return "Concluindo..."
  if (negoWaiting.value) return who + " está pensando..."
  if (negoStatus.value === "accepted") return "Negócio fechado"
  if (negoStatus.value === "failed") return who + " desistiu"
  return "Sua vez"
})
const negoTurnClass = computed(() => negoWaiting.value || nego.loading ? "wait" : negoStatus.value === "failed" ? "bad" : negoStatus.value === "accepted" ? "done" : "mine")
const negoMessages = computed(() => {
  const s = nego.state
  const selling = s.amISelling === true
  let seenMine = false, seenTheirs = false
  const rows = arr(s.offerHistory).map((it, i) => {
    const mine = it.myOffer != null
    const price = mine ? it.myOffer : it.theirOffer
    const st = String(it.negotiationStatus || "")
    let lbl
    if (st === "accepted") lbl = mine ? "Você aceitou" : "Aceitou"
    else if (st === "failed") lbl = "Desistiu"
    else if (st === "refused") lbl = "Recusou"
    else if (mine) lbl = seenMine ? "Sua contraproposta" : selling ? "Seu preço" : "Sua primeira oferta"
    else if (st === "counterOfferLastChance") lbl = "Oferta final"
    else lbl = seenTheirs ? "Contraproposta" : selling ? "Oferta do comprador" : "Preço pedido"
    if (mine) seenMine = true; else seenTheirs = true
    return {
      key: i + "-" + (mine ? "m" : "t"), mine, label: lbl, price: st === "failed" ? null : price,
      tone: st === "accepted" ? "ok" : st === "failed" ? "bad" : "",
      note: st === "failed" ? "Perdeu a paciência." : st === "counterOfferLastChance" ? "É pegar ou largar." : st === "refused" ? "Essa oferta nem mereceu resposta." : "",
    }
  })
  if (rows.length && nego.state.opponentQuote) { const f = rows.find(r => !r.mine); if (f && !f.note) f.note = nego.state.opponentQuote }
  return rows
})
const negoResolvedTitle = computed(() => {
  if (nego.state.purchaseFailureReason) return "Não deu certo"
  if (negoStatus.value === "failed") return "Sem acordo"
  if (nego.state.amISelling) return nego.iAccepted ? "Venda concluída por " + dollars(nego.state.theirOffer) : "Proposta aceita: " + dollars(nego.state.theirOffer)
  return "Negócio fechado em " + dollars(nego.state.theirOffer)
})
const negoResolvedText = computed(() => {
  const s = nego.state
  if (s.purchaseFailureReason) return tr(s.purchaseFailureReason)
  if (negoStatus.value === "failed") return s.amISelling ? negoName.value + " perdeu a paciência e foi embora. Seu anúncio continua no ar." : negoName.value + " perdeu a paciência. Este carro não pode mais ser negociado."
  if (s.amISelling) return nego.iAccepted ? "O carro saiu da sua garagem e o dinheiro já está no seu saldo." : "Conclua a venda: o carro sai da sua garagem."
  if (nego.ctx?.fromPurchase) return "O preço combinado entra nesta compra."
  return nego.ctx?.canBuy ? "Continue para concluir a compra por esse preço." : "O preço fica guardado para você. Vá até a loja para concluir a compra."
})
const negoResolvedAction = computed(() => {
  if (nego.state.purchaseFailureReason || negoStatus.value === "failed") return "Fechar"
  if (nego.state.amISelling) return nego.iAccepted ? "Fechar" : "Concluir venda"
  if (nego.ctx?.fromPurchase) return "Aplicar preço"
  return nego.ctx?.canBuy ? "Ir para a compra" : "Guardar preço"
})
watch(() => negoMessages.value.length + (negoWaiting.value ? 1 : 0), () => nextTick(() => { if (chatEl.value) chatEl.value.scrollTop = chatEl.value.scrollHeight }))

function resetNego(ctx) {
  Object.assign(nego, { open: true, loading: true, pending: false, iAccepted: false, splitUsed: false, preview: 0, hint: "", ctx, state: {} })
}
function applyNegoState(s) {
  if (!s || typeof s !== "object") return
  const prevHistory = arr(nego.state.offerHistory)
  const next = { ...nego.state, ...s, purchaseFailureReason: s.purchaseFailureReason ?? nego.state.purchaseFailureReason ?? null }
  next.offerHistory = s.offerHistory ? arr(s.offerHistory) : prevHistory
  if (s.saleCompleted) {
    nego.pending = false
    nego.iAccepted = true
    next.negotiationStatus = "accepted"
    next.purchaseFailureReason = null
    next.offerHistory = [...next.offerHistory, { myOffer: next.theirOffer, negotiationStatus: "accepted" }]
  }
  if (next.purchaseFailureReason) nego.pending = false
  nego.state = next
  nego.loading = false
  nego.hint = ""
  if (negoOpening.value) {
    if (!(Number(nego.preview) > 0)) nego.preview = negoMarket.value ? Math.round(negoMarket.value * 0.85 / 50) * 50 : 0
  } else {
    const base = next.myOffer != null ? next.myOffer : next.startingPrice
    if (isFinite(Number(base))) nego.preview = Number(base)
  }
}
function onNegoData(s) { if (nego.open) applyNegoState(s) }
async function startBuyNego(v, fromPurchase = false) {
  if (nego.open || busy.value) return
  const shopId = Number(v.shopId)
  resetNego({ kind: "buy", shopId, fromPurchase, canBuy: fromPurchase || canBuyHere(v) || v.sellerId === "private", sellerName: v.sellerName })
  const ok = await callT(MP + ".startNegotiateSellingOffer(" + shopId + ", true)", 5000)
  if (!alive || !nego.open) return
  if (!ok) { nego.open = false; toast("Este carro não pode ser negociado agora.", "warning"); return }
  if (nego.loading) {
    const s = await callT(MP + ".getNegotiationState()", 5000)
    if (s?.active) applyNegoState(s)
    else if (nego.loading) { nego.open = false; toast("Não foi possível abrir a negociação.", "warning") }
  }
}
async function startSellNego(l, o) {
  if (nego.open || busy.value) return
  resetNego({ kind: "sell", listingId: l.id, offerId: o.id })
  const ok = await callT(MP + ".startNegotiateBuyingOfferById(" + luaValue(o.id) + ", true)", 5000)
  if (!ok) { nego.open = false; toast("Essa proposta não está mais disponível.", "warning"); refreshListings(); return }
  // A spawned listing syncs its damage first; the data event can take a moment.
  setTimeout(async () => {
    if (!alive || !nego.open || !nego.loading) return
    const s = await callT(MP + ".getNegotiationState()", 5000)
    if (!nego.loading) return
    if (s?.active) applyNegoState(s)
    else { nego.open = false; toast("Não foi possível negociar (o carro pode ter sido danificado depois do anúncio).", "warning"); refreshListings() }
  }, 2500)
}
function negoNudge(delta) {
  const { min, max } = negoLimits.value
  const next = Math.min(max, Math.max(min, Math.max(0, Math.round(((Number(nego.preview) || 0) + delta) / 50) * 50)))
  nego.hint = next === Number(nego.preview) ? "Não dá para " + (delta > 0 ? "subir" : "descer") + " mais nesta negociação." : ""
  nego.preview = next
}
function negoSplit() {
  if (!negoSplitOk.value || nego.splitUsed) return
  const { min, max } = negoLimits.value
  nego.preview = Math.min(max, Math.max(min, Math.round(((min + max) / 2) / 50) * 50))
  nego.splitUsed = true
  nego.hint = ""
}
async function negoSend() {
  if (!negoCanSend.value) return
  const price = Math.round(Number(nego.preview) || 0)
  nego.hint = ""
  const ok = await callT(MP + ".makeNegotiationOffer(" + price + ")", 5000)
  if (!ok) nego.hint = "Essa oferta não é aceita nesta negociação."
}
function failedResult(r) { return r && (r.ok === false || r.ok === 0) }
function markAccepted() {
  nego.iAccepted = true
  nego.state = { ...nego.state, negotiationStatus: "accepted", status: "accepted", purchaseFailureReason: null,
    offerHistory: [...arr(nego.state.offerHistory), { myOffer: nego.state.theirOffer, negotiationStatus: "accepted" }] }
}
async function negoTake() {
  if (!negoCanTake.value) return
  const r = await callT(MP + ".takeTheirOffer()", 6000)
  if (r === undefined) { nego.hint = "O jogo não respondeu. Tente de novo."; return }
  if (failedResult(r)) { nego.state = { ...nego.state, purchaseFailureReason: r.reason || "Purchase could not be completed." }; return }
  if (r?.pending) { nego.pending = true; return }
  markAccepted()
}
async function negoFinish() {
  if (nego.pending) return
  if (negoStatus.value === "accepted" && !nego.iAccepted) {
    const r = await callT(MP + ".takeTheirOffer()", 6000)
    if (r === undefined) { nego.hint = "O jogo não respondeu. Tente de novo."; return }
    if (failedResult(r)) { nego.state = { ...nego.state, purchaseFailureReason: r.reason || "Purchase could not be completed." }; return }
    if (r?.pending) { nego.pending = true; return }
    nego.iAccepted = true
    if (nego.state.amISelling) { markAccepted(); return }
  }
  const ctx = nego.ctx || {}, price = nego.state.theirOffer
  await callT(MP + ".dismissNegotiation()", 4000)
  nego.open = false
  if (ctx.kind === "sell") { toast("Venda concluída por " + dollars(price) + "."); refreshListings(); refreshSellable(); return }
  if (ctx.fromPurchase) { busy.value = true; luaCall(VS + ".sendPurchaseDataToUi()"); toast("Preço combinado: " + dollars(price) + "."); setTimeout(() => { if (alive) busy.value = false }, 3000); return }
  if (ctx.canBuy) {
    toast("Preço combinado: " + dollars(price) + ". Abrindo a compra...")
    busy.value = true
    luaCall(VS + ".openPurchaseMenu('instant', " + Number(ctx.shopId) + ")")
    setTimeout(() => { if (alive) busy.value = false }, 2500)
    return
  }
  toast("Preço combinado: " + dollars(price) + ". Vá até " + (ctx.sellerName || "a loja") + " para concluir a compra.")
  loadShop()
}
async function negoExit() {
  if (nego.pending) return
  if (nego.state.purchaseFailureReason || negoStatus.value === "accepted") await callT(MP + ".dismissNegotiation()", 4000)
  else await callT(MP + ".cancelNegotiation()", 4000)
  const ctx = nego.ctx || {}
  nego.open = false
  if (ctx.kind === "sell") refreshListings()
  else if (ctx.fromPurchase || isPurchase.value) luaCall(VS + ".sendPurchaseDataToUi()")
  else loadShop()
}
function negoAskExit() {
  if (nego.pending) return
  const s = nego.state, st = negoStatus.value
  const risky = (st === "accepted" && !nego.iAccepted && !s.purchaseFailureReason)
    || (!negoResolved.value && !s.amISelling && s.myOffer != null)
    || (!negoResolved.value && s.amISelling && arr(s.offerHistory).length > 2)
  if (!risky) { negoExit(); return }
  confirmBox.value = {
    title: "Sair da negociação", danger: true, yes: "Sair",
    text: st === "accepted" ? "O acordo ainda não foi fechado. Se sair agora, ele é desfeito."
      : "Se você desistir agora, " + (s.amISelling ? "este comprador não vai negociar de novo." : "o vendedor não vai negociar este carro de novo."),
    run: negoExit,
  }
}

/* ================================================================
   Window / lifecycle
   ================================================================ */
async function requestClose() {
  if (!hosted.value) { emit("close"); return }
  if (nego.open && !nego.pending) await negoExit()
  if (isPurchase.value) {
    if (pd.value?.purchaseType === "inspect") { luaCall(VS + ".cancelPurchase('inspect')"); return }
    luaRun("local vs = " + VS + " vs.onShoppingMenuClosed() vs.requestExit()")
    return
  }
  stopSell()
  luaRun("local vs = " + VS + " vs.onShoppingMenuClosed() vs.requestExit()")
}
defineExpose({ requestClose })

watch(tab, (t, old) => {
  if (old === "sell" && t !== "sell") stopSell()
  if (t === "sell") startSell()
  if (t === "home") loadTravel()
  page.value = 1
})
watch([tab, stockName, loaded], () => {
  if (!hosted.value || isPurchase.value) return
  emit("title", tab.value === "stock" ? stockName.value : tab.value === "sell" ? "Vender meu carro" : tab.value === "all" ? "Todos os carros" : "Concessionárias")
})

onMounted(async () => {
  if (!hosted.value) return
  timer = setInterval(() => { now.value = Date.now() }, 1000)
  offs.push(onGameEvent("negotiationData", onNegoData))
  if (isPurchase.value) {
    offs.push(onGameEvent("vehiclePurchaseData", onPurchaseData))
    offs.push(onGameEvent("chooseInsuranceData", onInsuranceData))
    emit("title", "Compra de veículo")
    luaCall(VS + ".sendPurchaseDataToUi()")
    luaCall("career_modules_inventory.isEmpty()").then(e => { inventoryEmpty.value = !!e })
    setTimeout(() => { if (alive && !pLoaded.value) pFailed.value = true }, 6000)
    return
  }
  offs.push(onGameEvent("vehicleShopDelta", applyDelta))
  offs.push(onGameEvent("vehicleShoppingData", setData))
  luaCall(VS + ".setShoppingUiOpen(true)")
  try { await loadShop() } finally { loaded.value = true }
  if (!alive) return
  const t = initialTab()
  if (t === tab.value) { if (t === "home") loadTravel(); else if (t === "sell") startSell() }
  tab.value = t
})
onUnmounted(() => {
  alive = false
  clearInterval(timer)
  clearTimeout(plateTimer)
  offs.forEach(off => off()); offs = []
  typing(false)
  if (!hosted.value) return
  if (nego.open && !nego.pending) luaCall(MP + (negoStatus.value === "accepted" ? ".dismissNegotiation()" : ".cancelNegotiation()"))
  if (isPurchase.value) { luaCall("career_modules_inspectVehicle.onPurchaseMenuClosed()"); return }
  stopSell()
  luaCall(VS + ".setShoppingUiOpen(false)")
  // Like the RLS view: moving between the shop's own screens keeps the session alive.
  const next = window.vueRouter?.currentRoute?.value?.name
  if (!(typeof next === "string" && (next === R_SHOP || next.startsWith(R_SHOP + ".")))) luaCall(VS + ".onShoppingMenuClosed()")
})
</script>

<style scoped>
.small { font-size: 11.5px; }
.between { justify-content: space-between; }
.dl-root { position: relative; height: 100%; }
.dl-launch .dl-intro { display: flex; gap: 18px; padding: 10px 4px; }
.dl-intro-icon { width: 84px; height: 84px; border-radius: 16px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 46px; color: #fff;
  background: linear-gradient(135deg, #ff7a3d, #b8360f); box-shadow: 0 3px 8px rgba(0,0,0,.25); }
.dl-center { margin-top: 12px; }
.dl { height: 100%; display: flex; flex-direction: column; background: #f3f5f8; }
.dl-pad { padding-left: 16px; padding-right: 16px; }

/* site header */
.dl-site { display: flex; align-items: center; gap: 16px; padding: 10px 16px; flex-wrap: wrap; color: #fff;
  background: linear-gradient(180deg, #c8461a 0%, #a73810 60%, #8e2e0b 100%); border-bottom: 3px solid #ffb02e; }
.dl-logo { display: flex; align-items: baseline; gap: 6px; }
.dl-logo :deep(.bng-icon), .dl-logo > :first-child { font-size: 22px; align-self: center; }
.dl-logo b { font: bold 22px "Trebuchet MS", Tahoma, sans-serif; letter-spacing: -.5px; }
.dl-logo b span { color: #ffd36b; }
.dl-logo small { font-size: 11px; opacity: .85; margin-left: 4px; }
.dl-search { flex: 1; min-width: 260px; display: flex; align-items: center; gap: 6px; padding: 3px 3px 3px 10px; background: #fff; border-radius: 3px; color: #6d7d90; }
.dl-search input { flex: 1; border: 0; outline: 0; font: 13px Tahoma, sans-serif; padding: 5px 2px; color: #111; background: transparent; user-select: text; }
.dl-wallet { margin-left: auto; text-align: right; display: flex; flex-direction: column; }
.dl-wallet small { font-size: 10.5px; opacity: .85; text-transform: uppercase; letter-spacing: 1px; }
.dl-wallet b { font-size: 17px; color: #fff3c4; }
.dl-tabs { margin: 0; padding: 6px 12px 0; background: #ece9d8; }
.dl-count { margin-left: 6px; background: #c62d1f; color: #fff; border-radius: 8px; padding: 0 6px; font-size: 11px; font-weight: normal; }
.dl-scroll { flex: 1; min-height: 0; overflow: auto; padding-bottom: 14px; }
.dl-status { display: flex; gap: 18px; flex-wrap: wrap; padding: 4px 12px; font-size: 11.5px; color: #333; background: #ece9d8; border-top: 1px solid #aca899; }
.dl-warn { margin: 8px 0; padding: 7px 10px; border: 1px solid #e8c76c; background: #fff8dc; border-radius: 3px; color: #6b4b00; }
.dl-sec-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; flex-wrap: wrap; margin: 12px 0 8px; }
.dl-sec-head .rl-h1 { margin: 0; }
.dl-noimg { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 40px; color: #9aaabd; background: linear-gradient(135deg, #e7eef6, #cfd9e5); }

/* dealers */
.dl-dealers { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px; }
.dl-dealer { display: flex; flex-direction: column; background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; overflow: hidden; }
.dl-dealer:hover { border-color: #e07b3a; box-shadow: 0 2px 8px rgba(110,50,20,.15); }
.dl-dealer.locked { background: #f4f4f4; }
.dl-dealer.locked h3 { color: #6d7d90; }
.dl-dealer.offline .dl-dealer-photo img { filter: grayscale(.6); }
.dl-dealer-photo { position: relative; height: 130px; background: #e7eef6; }
.dl-dealer-photo > img { width: 100%; height: 100%; object-fit: cover; display: block; }
.dl-channel { position: absolute; left: 8px; top: 8px; padding: 2px 8px; border-radius: 3px; font-size: 10.5px; font-weight: bold; color: #fff; background: rgba(30,50,80,.85); }
.dl-channel.factory { background: rgba(20,90,160,.9); } .dl-channel.remanufactured { background: rgba(30,120,90,.9); } .dl-channel.private { background: rgba(120,70,20,.9); }
.dl-thumbs { position: absolute; right: 6px; bottom: 6px; display: flex; gap: 3px; }
.dl-thumbs img { width: 46px; height: 30px; object-fit: cover; border: 1px solid #fff; border-radius: 2px; box-shadow: 0 1px 3px rgba(0,0,0,.4); }
.dl-dealer-body { padding: 10px 12px; display: flex; flex-direction: column; gap: 6px; flex: 1; }
.dl-dealer-body h3 { margin: 0; font-size: 15px; color: #8e2e0b; }
.dl-desc { margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.dl-badges { display: flex; gap: 4px; flex-wrap: wrap; }
.dl-dealer-actions { margin-top: auto; padding-top: 4px; }
.dl-rep { display: flex; flex-direction: column; gap: 2px; }
.dl-rep-bar { height: 7px; border-radius: 4px; background: #e2e8f0; overflow: hidden; }
.dl-rep-bar i { display: block; height: 100%; background: linear-gradient(90deg, #f0a43a, #e0682a); }
.dl-rep small { font-size: 11px; color: #5f7186; }

/* hero */
.dl-hero { display: flex; gap: 14px; padding: 12px 16px; background: #fff; border-bottom: 1px solid #d6dde6; flex-wrap: wrap; }
.dl-hero-photo { width: 240px; height: 135px; flex-shrink: 0; border-radius: 4px; overflow: hidden; background: #e7eef6; }
.dl-hero-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.dl-hero-body { flex: 1; min-width: 260px; display: flex; flex-direction: column; gap: 6px; }
.dl-hero-body .dl-sec-head { margin: 0; }

/* toolbar & list */
.dl-toolbar { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; padding: 6px 16px; background: #ece9d8; border-bottom: 1px solid #aca899; position: sticky; top: 0; z-index: 2; }
.dl-toolbar .rl-input { padding: 4px 6px; }
.dl-num { width: 120px; }
.dl-year { width: 78px; }
.dl-check { display: flex; align-items: center; gap: 5px; font-size: 12px; cursor: pointer; }
.dl-listhead { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin: 10px 0 6px; font-size: 12.5px; color: #23476f; }
.dl-ads { display: flex; flex-direction: column; gap: 10px; }
.dl-ad { display: flex; flex-wrap: wrap; background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; overflow: hidden; }
.dl-ad:hover { border-color: #e07b3a; box-shadow: 0 2px 8px rgba(110,50,20,.12); }
.dl-ad.sold { opacity: .7; }
.dl-ad-photo { position: relative; flex: 0 0 210px; height: 128px; background: #e7eef6; }
.dl-ad-photo > img { width: 100%; height: 100%; object-fit: cover; display: block; }
.dl-sold { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%) rotate(-12deg); padding: 3px 12px; border: 3px solid #c62d1f; color: #c62d1f;
  background: rgba(255,255,255,.85); font: bold 16px Tahoma, sans-serif; letter-spacing: 2px; }
.dl-flag { position: absolute; left: 6px; top: 6px; padding: 1px 7px; border-radius: 3px; background: #2f8a22; color: #fff; font-size: 10.5px; font-weight: bold; }
.dl-ad-info { flex: 1 1 260px; padding: 9px 12px; display: flex; flex-direction: column; gap: 5px; min-width: 0; }
.dl-ad-info h4 { margin: 0; font-size: 14.5px; color: #12407c; }
.dl-ad-info p { margin: 0; }
.dl-chips { display: flex; gap: 4px; flex-wrap: wrap; }
.dl-chips span { padding: 1px 7px; border: 1px solid #d3dce7; border-radius: 10px; font-size: 11px; color: #34495e; background: #f6f9fd; }
.dl-seller { display: flex; align-items: center; gap: 5px; font-size: 12px; color: #2c4a6e; }
.dl-ad-side { flex: 0 0 220px; padding: 9px 12px; display: flex; flex-direction: column; align-items: flex-end; gap: 4px; background: #fafbfd; border-left: 1px solid #e3e8ee; }
.dl-price { font: bold 20px "Trebuchet MS", Tahoma, sans-serif; color: #1d5c1a; }
.dl-price.bad { color: #b0281a; }
.dl-price.sold { color: #7d8a99; text-decoration: line-through; }
.dl-actions { display: flex; flex-wrap: wrap; gap: 4px; justify-content: flex-end; margin-top: auto; }
.dl-actions .rl-btn { padding: 4px 9px; }
.dl-reason { font-size: 11px; color: #8a5a00; text-align: right; }
.dl-pager { display: flex; justify-content: center; align-items: center; gap: 12px; margin: 12px 0; font-size: 12px; }
.dl-soldgrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 8px; }
.dl-soldcard { display: flex; flex-direction: column; gap: 2px; background: #fff; border: 1px solid #d6dde6; border-radius: 3px; padding: 4px; font-size: 11.5px; }
.dl-soldphoto { position: relative; height: 70px; background: #e7eef6; overflow: hidden; }
.dl-soldphoto img { width: 100%; height: 100%; object-fit: cover; filter: grayscale(.7); }
.dl-soldphoto .dl-sold { font-size: 11px; padding: 1px 6px; border-width: 2px; }

/* sell */
.rl-h2.first { margin-top: 0; }
.dl-newlisting { background: #fffdf6; border-color: #ead9a8; }
.dl-newlisting-row { display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }
.dl-newlisting-row label { display: flex; flex-direction: column; gap: 3px; font-size: 12px; color: #2c4a6e; }
.dl-newlisting-row select { min-width: 240px; }
.dl-mini { width: 96px; height: 56px; object-fit: cover; border-radius: 3px; border: 1px solid #c9d7e8; flex-shrink: 0; }
.dl-listing { background: #fff; }
.dl-listing.off { border-color: #e6a19a; }
.dl-listing-head { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.dl-listing-title { flex: 1; display: flex; flex-direction: column; gap: 2px; min-width: 200px; }
.dl-listing-title b { font-size: 14px; color: #12407c; }
.dl-listing-price { display: flex; flex-direction: column; align-items: flex-end; }
.dl-listing-price small { font-size: 11px; color: #5f7186; }
.dl-listing-price b { font-size: 18px; color: #1d5c1a; }
.dl-listing-actions { margin: 8px 0; }
.pos { color: #236b1a !important; } .neg { color: #b0281a !important; }
.dl-offers { display: flex; flex-direction: column; gap: 6px; border-top: 1px solid #e3e8ee; padding-top: 8px; }
.dl-offer { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; padding: 6px 8px; border: 1px solid #dfe6ee; border-radius: 3px; background: #f9fbfd; }
.dl-offer.expired { opacity: .6; }
.dl-offer-text { flex: 1; min-width: 180px; display: flex; flex-direction: column; }
.dl-offer-text small { font-style: italic; }
.dl-offer-value { display: flex; flex-direction: column; align-items: flex-end; min-width: 110px; }
.dl-offer-value b { font-size: 15px; }
.dl-offer-value small { font-size: 11px; }
.dl-avatar { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font: bold 11px Tahoma, sans-serif; flex-shrink: 0; }
.dl-avatar.big { width: 40px; height: 40px; font-size: 14px; }

/* purchase */
.dl-buy { display: flex; gap: 16px; padding: 14px 16px; align-items: flex-start; flex-wrap: wrap; }
.dl-buy-main { flex: 1 1 420px; display: flex; flex-direction: column; gap: 10px; min-width: 0; }
.dl-buy-side { flex: 0 0 320px; display: flex; flex-direction: column; gap: 8px; position: sticky; top: 0; }
.dl-buy-hero { display: flex; gap: 14px; flex-wrap: wrap; background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; padding: 10px; }
.dl-buy-photo { width: 240px; height: 140px; border-radius: 3px; overflow: hidden; background: #e7eef6; flex-shrink: 0; }
.dl-buy-photo img { width: 100%; height: 100%; object-fit: cover; display: block; }
.dl-buy-title { flex: 1; min-width: 220px; display: flex; flex-direction: column; gap: 6px; align-items: flex-start; }
.dl-buy-title h2 { margin: 0; font: 300 22px "Trebuchet MS", Tahoma, sans-serif; color: #12407c; }
.dl-sec { background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; padding: 4px 12px 10px; }
.dl-sec .rl-h2 { display: flex; align-items: center; gap: 6px; margin: 8px 0; }
.dl-opt { display: flex; gap: 8px; align-items: flex-start; padding: 7px 9px; margin: 4px 0; border: 1px solid #d6dde6; border-radius: 3px; cursor: pointer; }
.dl-opt.on { border-color: #316ac5; background: #eef4fd; }
.dl-opt.off { opacity: .6; cursor: default; }
.dl-opt span { display: flex; flex-direction: column; gap: 2px; }
.dl-opt small { color: #5f7186; }
.dl-garages { display: flex; flex-direction: column; gap: 4px; margin: 4px 0 4px 22px; }
.dl-garage { display: flex; gap: 8px; align-items: center; padding: 6px 8px; border: 1px solid #dfe6ee; border-radius: 3px; cursor: pointer; flex-wrap: wrap; }
.dl-garage.on { border-color: #316ac5; background: #f3f8ff; }
.dl-garage.off { opacity: .65; cursor: default; }
.dl-garage-name { flex: 1; min-width: 150px; display: flex; flex-direction: column; }
.dl-garage-name small { color: #5f7186; }
.dl-garage-price { display: flex; flex-direction: column; align-items: flex-end; font-size: 12px; }
.dl-garage-price s { color: #8c99a8; font-size: 11px; }
.dl-garage-price small { color: #5f7186; font-size: 11px; }
.dl-line { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; }
.dl-line > div:first-child { display: flex; flex-direction: column; gap: 2px; }
.dl-plate { margin-top: 6px; }
.dl-plate-input { width: 150px; text-transform: uppercase; font-family: "Courier New", monospace; letter-spacing: 2px; }
.dl-receipt { background: #fffef7; border: 1px solid #d8cfa8; border-radius: 3px; padding: 10px 12px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
.dl-receipt h3 { margin: 0 0 6px; font-size: 14px; color: #5a4a12; border-bottom: 2px dashed #d8cfa8; padding-bottom: 6px; }
.dl-receipt table { width: 100%; border-collapse: collapse; font-size: 12px; }
.dl-receipt td { padding: 3px 0; vertical-align: top; }
.dl-receipt td:last-child { text-align: right; white-space: nowrap; padding-left: 8px; }
.dl-receipt tr.sub td { color: #6d7d90; font-size: 11.5px; }
.dl-receipt tr.good td { color: #236b1a; }
.dl-receipt tr.line td { border-top: 1px dotted #b9ad80; padding-top: 5px; font-weight: bold; }
.dl-receipt tr.total td { border-top: 2px solid #5a4a12; padding-top: 6px; font: bold 16px "Trebuchet MS", Tahoma, sans-serif; color: #1d5c1a; }
.dl-receipt tr.bad td { color: #b0281a; font-weight: bold; }
.dl-blockers { margin: 0; padding: 7px 10px 7px 26px; border: 1px solid #e6a19a; background: #fde6e4; border-radius: 3px; color: #8e2318; font-size: 12px; display: flex; flex-direction: column; gap: 3px; }
.dl-buy-btn { padding: 10px; font-size: 13.5px; }
.dl-back-btn { padding: 7px; }

/* modals */
.dl-modal { position: absolute; inset: 0; z-index: 30; display: flex; align-items: center; justify-content: center; background: rgba(20,30,50,.35); padding: 12px; }
.dl-modal.top { z-index: 40; }
.dl-dialog { width: min(560px, 100%); max-height: 100%; display: flex; flex-direction: column; background: #ece9d8; border: 3px solid #0831d9; border-top: 0; border-radius: 8px 8px 3px 3px; box-shadow: 4px 6px 18px rgba(0,0,0,.45); overflow: hidden; }
.dl-dialog.wide { width: min(980px, 100%); }
.dl-dialog.small { width: min(430px, 100%); }
.dl-dialog.nego { width: min(620px, 100%); height: min(640px, 100%); }
.dl-dialog-title { display: flex; align-items: center; gap: 6px; height: 28px; flex-shrink: 0; padding: 0 4px 0 8px; color: #fff; font: bold 13px "Trebuchet MS", Tahoma, sans-serif; text-shadow: 1px 1px #0a1f69;
  background: linear-gradient(180deg, #0997ff 0%, #0053ee 8%, #0050ee 40%, #06f 88%, #003dd7 100%); }
.dl-dialog-title button { margin-left: auto; width: 21px; height: 21px; border: 1px solid #fff; border-radius: 3px; color: #fff; cursor: pointer; padding: 0; font: bold 15px Tahoma, sans-serif;
  background: radial-gradient(circle at 30% 30%, #f09a73, #d2421f 70%); }
.dl-dialog-body { flex: 1; min-height: 0; overflow: auto; padding: 12px 14px; background: #fff; }
.dl-dialog-foot { display: flex; justify-content: flex-end; gap: 6px; padding: 8px 10px; border-top: 1px solid #aca899; }
.dl-confirm-text { margin: 4px 0; line-height: 1.5; font-size: 13px; }
.dl-ins-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 10px; }
.dl-ins { display: flex; flex-direction: column; gap: 6px; padding: 10px; text-align: left; cursor: pointer; font: 12px Tahoma, sans-serif; color: #1b2733;
  border: 1px solid #c9d7e8; border-top: 5px solid #7f8ea3; border-radius: 4px; background: #fff; }
.dl-ins:hover { box-shadow: 0 2px 8px rgba(30,60,110,.15); }
.dl-ins.on { outline: 2px solid #316ac5; background: #f3f8ff; }
.dl-ins-head { display: flex; align-items: center; gap: 8px; }
.dl-ins-head img { width: 34px; height: 34px; object-fit: contain; }
.dl-ins-head b { font-size: 14px; }
.dl-ins ul { margin: 0; padding-left: 16px; display: flex; flex-direction: column; gap: 2px; color: #34495e; }
.dl-ins-price { display: flex; gap: 12px; flex-wrap: wrap; margin-top: auto; padding-top: 6px; border-top: 1px solid #e3e8ee; }
.dl-ins-price span { display: flex; flex-direction: column; }
.dl-ins-price small { font-size: 10.5px; color: #5f7186; }
.dl-ins-price b { font-size: 13px; color: #12407c; }

/* negotiation */
.dl-nego-who { display: flex; align-items: center; gap: 10px; padding: 8px 12px; background: #fff; border-bottom: 1px solid #d6dde6; }
.dl-nego-whotext { flex: 1; display: flex; flex-direction: column; }
.dl-nego-whotext small { color: #5f7186; }
.dl-nego-market { display: flex; flex-direction: column; align-items: flex-end; }
.dl-nego-market small { font-size: 10.5px; color: #5f7186; text-transform: uppercase; }
.dl-chat { flex: 1; min-height: 120px; overflow: auto; padding: 10px 12px; display: flex; flex-direction: column; gap: 8px; background: #e9eef4; }
.dl-chat-intro { margin: auto; color: #5f7186; font-size: 12px; text-align: center; }
.dl-msg { display: flex; flex-direction: column; align-items: flex-start; max-width: 78%; }
.dl-msg.mine { align-self: flex-end; align-items: flex-end; }
.dl-msg > small { font-size: 10px; text-transform: uppercase; letter-spacing: .6px; color: #5f7186; margin: 0 4px 2px; }
.dl-bubble { padding: 7px 11px; border-radius: 12px 12px 12px 3px; background: #fff; border: 1px solid #cfd8e3; display: flex; flex-direction: column; gap: 3px; }
.dl-msg.mine .dl-bubble { border-radius: 12px 12px 3px 12px; background: #dcf1d2; border-color: #a9d69a; }
.dl-bubble b { font-size: 17px; }
.dl-bubble i { font-size: 11.5px; color: #4e6276; }
.dl-bubble.ok { background: #e3f7e0; border-color: #6cc35a; }
.dl-bubble.bad { background: #fde6e4; border-color: #e6a19a; }
.dl-bubble.typing { flex-direction: row; gap: 4px; padding: 10px 12px; }
.dl-bubble.typing span { width: 7px; height: 7px; border-radius: 50%; background: #8c99a8; animation: dl-dot 1.2s infinite ease-in-out; }
.dl-bubble.typing span:nth-child(2) { animation-delay: .2s; } .dl-bubble.typing span:nth-child(3) { animation-delay: .4s; }
@keyframes dl-dot { 0%, 80%, 100% { opacity: .3; transform: translateY(0); } 40% { opacity: 1; transform: translateY(-3px); } }
.dl-nego-foot { padding: 8px 12px 10px; background: #ece9d8; border-top: 1px solid #aca899; display: flex; flex-direction: column; gap: 6px; }
.dl-turn { display: flex; justify-content: space-between; align-items: center; }
.dl-turn-tag { padding: 2px 8px; border-radius: 3px; font-size: 11.5px; font-weight: bold; background: #dfe6ee; color: #34495e; }
.dl-turn-tag.mine { background: #e3f7e0; color: #236b1a; } .dl-turn-tag.bad { background: #fde6e4; color: #8e2318; } .dl-turn-tag.done { background: #e3f7e0; color: #236b1a; }
.dl-patience-text { font-size: 11.5px; font-weight: bold; }
.dl-patience-text.good { color: #2f8a22; } .dl-patience-text.mid { color: #c27a00; } .dl-patience-text.low { color: #c62d1f; }
.dl-patience { height: 8px; border: 1px solid #8c99a8; border-radius: 2px; background: #fff; overflow: hidden; }
.dl-patience i { display: block; height: 100%; transition: width .3s; }
.dl-patience i.good { background: #4cae3a; } .dl-patience i.mid { background: #f0a43a; } .dl-patience i.low { background: #d9412b; }
.dl-offer-row { display: flex; align-items: flex-end; gap: 4px; flex-wrap: wrap; }
.dl-offer-row .rl-btn { padding: 5px 8px; }
.dl-offer-input { display: flex; flex-direction: column; flex: 1; min-width: 120px; }
.dl-offer-input small { font-size: 10.5px; color: #4e6276; }
.dl-offer-input input { font-size: 15px; font-weight: bold; text-align: center; }
.dl-nego-diff, .dl-nego-hint { margin: 0; font-size: 11.5px; }
.dl-nego-hint { color: #8a5a00; }
.dl-nego-actions { justify-content: flex-end; }
.dl-resolved { padding: 8px 10px; border: 1px solid #9fd696; background: #e3f7e0; border-radius: 3px; }
.dl-resolved.bad { border-color: #e6a19a; background: #fde6e4; }
.dl-resolved b { font-size: 14px; }
.dl-resolved p { margin: 4px 0 0; }
</style>
