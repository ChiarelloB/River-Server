<template>
  <PhoneWrapper app-name="RiverLife" status-font-color="#ffffff">
    <div class="rlphone" @focusin="typingFocus" @focusout="typingBlur">
      <nav class="rp-tabs">
        <button v-for="t in tabs" :key="t.id" :class="{ on: tab === t.id }" @click="tab = t.id">
          <BngIcon :type="t.icon" /><span>{{ t.label }}</span><i v-if="t.badge">{{ t.badge }}</i>
        </button>
      </nav>
      <section class="rp-body">
        <div v-if="!rl.view.careerActive" class="rl-empty"><b>Abra sua carreira</b>O RiverLife funciona dentro da carreira RLS.</div>
        <template v-else-if="tab === 'home'">
          <div class="rp-hero">
            <b>{{ me.name || "Motorista" }}</b>
            <span>{{ money(rl.view.money) }} · {{ rl.view.mode === "BeamMP" ? (rl.view.connected ? "online" : "conectando...") : "solo" }}</span>
          </div>
          <FirstSteps compact @go="g => (tab = g === 'classificados' ? 'market' : g)" @open="openFromApp" />
          <div v-if="nearCar" class="rl-box nearcar">
            <b>{{ nearCar.title }} — {{ money(nearCar.price) }}</b>
            <p class="rl-muted">{{ nearCar.storeName ? "Pátio da " + nearCar.storeName : "Particular" }} · {{ km(nearCar.mileage) }}</p>
            <button class="rl-btn primary" @click="focus = nearCar.id; tab = 'market'">Fazer proposta</button>
          </div>
          <p v-if="!attention.length" class="rl-muted center">Nada pendente agora.</p>
          <button v-for="a in attention" :key="a.kind + a.id" class="rp-alert" @click="go(a)">{{ a.text }}<small>Abrir</small></button>
          <div v-if="near" class="rl-box">
            <b>{{ near.label }}</b>
            <p class="rl-muted">{{ near.text }}</p>
            <button class="rl-btn primary" @click="tab = near.tab">Abrir</button>
          </div>
          <div class="rp-quick">
            <button @click="tab = 'market'"><BngIcon type="carStarred" />Classificados</button>
            <button @click="tab = 'deals'"><BngIcon type="calendar" />Negociar</button>
            <button @click="tab = 'store'"><BngIcon type="carDealer" />Minha loja</button>
            <button @click="tab = 'shop'"><BngIcon type="houseWrench" />Oficina</button>
            <button @click="tab = 'jobs'"><BngIcon type="badge" />Bicos</button>
            <button @click="tab = 'news'"><BngIcon type="documentOutline" />Jornal</button>
            <button v-if="myStore" @click="request('gps', { position: myStore.position })"><BngIcon type="gps" />GPS loja</button>
            <button v-if="myShop" @click="request('gps', { position: myShop.position })"><BngIcon type="gps" />GPS oficina</button>
          </div>
        </template>
        <AppAgenda v-else-if="tab === 'deals'" @open="openFromApp" />
        <AppMarket v-else-if="tab === 'market'" :focus="focus" @open="openFromApp" />
        <AppJobs v-else-if="tab === 'jobs'" @open="openFromApp" />
        <SiteNews v-else-if="tab === 'news'" @open="openFromApp" @go="g => (tab = g === 'classificados' ? 'market' : 'news')" />
        <AppStore v-else-if="tab === 'store'" :focus="focus" @open="openFromApp" />
        <template v-else-if="tab === 'shop'">
          <AppWorkshop v-if="myShop" :focus="focus" @open="openFromApp" />
          <SiteDirectory v-else kind="workshops" @open="openFromApp" />
        </template>
        <AppPlayers v-else-if="tab === 'players'" @open="openFromApp" />
        <AppMessages v-else-if="tab === 'mail'" @open="openFromApp" />
        <AppSell v-else-if="tab === 'sell'" :inventory-id="sellId" @open="openFromApp" />
        <AppGarage v-else-if="tab === 'garage'" @open="openFromApp" />
      </section>
      <div v-if="rl.confirm" class="rp-confirm" @pointerdown.self="answer(false)">
        <div class="rp-confirm-box"><p>{{ rl.confirm.text }}</p>
          <div class="rl-row"><button class="rl-btn" @click="answer(false)">Cancelar</button>
            <button class="rl-btn primary" @click="answer(true)">{{ rl.confirm.label }}</button></div></div>
      </div>
      <div class="rp-toasts"><div v-for="n in rl.notices.slice(-2)" :key="n.id" class="rp-toast" :class="n.kind">{{ n.text }}</div></div>
    </div>
  </PhoneWrapper>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from "vue"
import { useRoute } from "vue-router"
import { BngIcon } from "@/common/components/base"
import PhoneWrapper from "@/modules/career/views/PhoneWrapper.vue"
import { rl, wire, request, money, km, me, attention, unread, myStore, myShop, myNpcs, shopOrders, onAction, distance, myGig, typing, answer } from "./rl.js"
import AppAgenda from "./apps/AppAgenda.vue"
import AppMarket from "./apps/AppMarket.vue"
import AppStore from "./apps/AppStore.vue"
import AppWorkshop from "./apps/AppWorkshop.vue"
import AppPlayers from "./apps/AppPlayers.vue"
import AppMessages from "./apps/AppMessages.vue"
import AppSell from "./apps/AppSell.vue"
import AppGarage from "./apps/AppGarage.vue"
import FirstSteps from "./components/FirstSteps.vue"
import SiteDirectory from "./apps/SiteDirectory.vue"
import AppJobs from "./apps/AppJobs.vue"
import SiteNews from "./apps/SiteNews.vue"

const route = useRoute()
const tab = ref(String(route.query?.app || "home"))
const focus = ref(String(route.query?.focus || ""))
const sellId = ref("")
let off

const tabs = computed(() => [
  { id: "home", label: "Início", icon: "house", badge: attention.value.length || "" },
  { id: "deals", label: "Negociar", icon: "calendar", badge: attention.value.filter(a => ["visit", "offer"].includes(a.kind)).length || "" },
  { id: "market", label: "Anúncios", icon: "carStarred" },
  { id: "garage", label: "Carros", icon: "keys1" },
  { id: "store", label: "Loja", icon: "carDealer", badge: myNpcs.value.filter(n => n.status === "negotiating" && n.storeId).length || "" },
  { id: "shop", label: "Oficina", icon: "houseWrench", badge: shopOrders.value.filter(o => ["requested", "accepted"].includes(o.status)).length || "" },
  { id: "jobs", label: "Bicos", icon: "badge", badge: myGig.value ? "1" : "" },
  { id: "players", label: "Jogadores", icon: "peopleOutline" },
  { id: "news", label: "Jornal", icon: "documentOutline" },
  { id: "mail", label: "E-mail", icon: "envelope", badge: unread.value || "" },
])
const nearCar = computed(() => (rl.view.listings || []).find(l => l.id === rl.view.nearby))
watch(() => route.query, q => {
  if (q?.app) tab.value = String(q.app) === "market" ? "market" : String(q.app)
  if (q?.focus) focus.value = String(q.focus)
})
const near = computed(() => {
  const pos = rl.view.position
  if (myShop.value && distance(pos, myShop.value.position) < 40) return { label: myShop.value.name, text: "Você está na sua oficina.", tab: "shop" }
  if (myStore.value && distance(pos, myStore.value.position) < 40) return { label: myStore.value.name, text: "Você está na sua loja.", tab: "store" }
  const shop = (rl.view.workshops || []).find(w => distance(pos, w.position) < 40)
  if (shop) return { label: shop.name, text: "Oficina de " + (shop.ownerName || "outro jogador") + ". Peça um orçamento.", tab: "shop" }
  return null
})
function go(a) {
  if (a.kind === "trade") { focus.value = a.id; tab.value = "store" }
  else if (a.kind === "order") { focus.value = a.id; tab.value = "shop" }
  else if (a.kind === "quote") tab.value = "shop"
  else tab.value = "deals"
}
function openFromApp(e) {
  const app = typeof e === "object" ? e.app : e
  const props = typeof e === "object" ? e.props || {} : {}
  const map = { agenda: "deals", market: "market", internet: props.start === "oficinas" ? "shop" : "market", store: "store", workshop: "shop", mail: "mail", players: "players", sell: "sell", garage: "garage", finance: "home", jobs: "jobs", news: "news" }
  if (app === "sell") sellId.value = props.inventoryId || ""
  tab.value = map[app] || (tabs.value.some(t => t.id === app) ? app : "home")
}
onMounted(() => {
  wire()
  request("desk", { open: true, kind: "phone" })
  request("refresh")
  off = onAction(e => {
    if (e?.op === "open" && e.open && e.app) { focus.value = e.focus || ""; openFromApp(e.app) }
  })
})
// Typing in a text field must not drive the car.
let typingOn = false
function isText(el) { return el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !["checkbox", "radio", "range", "button", "submit", "color"].includes(el.type))) }
function typingFocus(e) { if (isText(e.target) && !typingOn) { typingOn = true; typing(true) } }
function typingBlur(e) { if (typingOn && !isText(e.relatedTarget)) { typingOn = false; typing(false) } }
onUnmounted(() => { off && off(); request("desk", { open: false, kind: "phone" }); if (typingOn) { typingOn = false; typing(false) } })
</script>

<style>
.rlphone { display: flex; flex-direction: column; height: 100%; font: 13px "Segoe UI", Tahoma, sans-serif; color: #1c2430; background: #f2f4f8; text-align: left; }
.rlphone * { box-sizing: border-box; }
.rp-tabs { display: flex; overflow-x: auto; gap: 2px; padding: 6px 6px 4px; background: linear-gradient(180deg, #0d5f57, #13897a); scrollbar-width: none; }
.rp-tabs button { position: relative; flex: 0 0 auto; display: grid; justify-items: center; gap: 2px; min-width: 56px; padding: 5px 4px; border: 0; border-radius: 8px; background: none; color: #d9fff7; font-size: 10.5px; cursor: pointer; }
.rp-tabs button.on { background: rgba(255,255,255,.18); color: #fff; }
.rp-tabs i { position: absolute; top: 0; right: 6px; min-width: 16px; height: 16px; border-radius: 8px; background: #ff4d3d; color: #fff; font: bold 10px sans-serif; display: flex; align-items: center; justify-content: center; padding: 0 4px; font-style: normal; }
.rp-body { flex: 1; min-height: 0; overflow: auto; }
.rp-hero { margin: 10px; padding: 14px; border-radius: 14px; color: #fff; background: linear-gradient(135deg, #13897a, #0b4f8f); display: grid; gap: 4px; }
.rp-hero b { font-size: 18px; }
.rp-alert { display: flex; justify-content: space-between; align-items: center; width: calc(100% - 20px); margin: 6px 10px; padding: 12px; border: 0; border-radius: 12px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.12); font: 13px "Segoe UI", sans-serif; text-align: left; cursor: pointer; }
.rp-alert small { color: #13897a; font-weight: bold; }
.rp-quick { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; padding: 10px; }
.rp-quick button { display: grid; justify-items: center; gap: 4px; padding: 12px 4px; border: 0; border-radius: 12px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.12); font: 11px "Segoe UI", sans-serif; cursor: pointer; }
.rp-quick button :first-child { font-size: 22px; color: #13897a; }
.rp-toasts { position: absolute; left: 10px; right: 10px; bottom: 10px; display: grid; gap: 6px; pointer-events: none; }
.rp-toast { padding: 9px 12px; border-radius: 10px; background: rgba(20,30,40,.92); color: #fff; font-size: 12px; }
.rp-toast.error { background: rgba(160,30,20,.95); }
.rlphone .center { text-align: center; }
.rlphone .rl-tabs { display: flex; gap: 4px; overflow-x: auto; margin: 4px 0 10px; }
.rlphone .rl-tabs button { flex: 0 0 auto; padding: 6px 10px; border: 0; border-radius: 14px; background: #e3e8ef; font: 12px "Segoe UI", sans-serif; cursor: pointer; }
.rlphone .rl-tabs button.on { background: #13897a; color: #fff; }
.rlphone .nearcar { margin: 10px; border: 2px solid #f0b400; background: #fff9e3; }
.rlphone .rl-page { padding: 10px; }
.rlphone .rl-h1 { font-size: 18px; margin: 4px 0; color: #0d4a44; }
.rlphone .rl-h2 { font-size: 14px; margin: 14px 0 6px; color: #0d4a44; }
.rlphone .rl-muted { color: #627080; font-size: 12px; line-height: 1.45; }
.rlphone .rl-btn { font: 12px "Segoe UI", sans-serif; padding: 8px 12px; border: 0; border-radius: 9px; background: #e3e8ef; color: #1c2430; cursor: pointer; }
.rlphone .rl-btn.primary { background: #13897a; color: #fff; font-weight: 600; }
.rlphone .rl-btn.go { background: #2f9e44; color: #fff; font-weight: 600; }
.rlphone .rl-btn.danger { background: #d9412f; color: #fff; }
.rlphone .rl-btn:disabled { opacity: .45; }
.rlphone .rp-confirm { position: absolute; inset: 0; z-index: 20; display: flex; align-items: flex-end; background: rgba(0,0,0,.35); }
.rlphone .rp-confirm-box { width: 100%; padding: 14px; border-radius: 14px 14px 0 0; background: #fff; }
.rlphone .rp-confirm-box p { margin: 0 0 12px; line-height: 1.45; }
.rlphone .rp-confirm-box .rl-row { justify-content: flex-end; }
/* The garage app inside the phone: one column. */
.rlphone .garage .car { flex-direction: column; gap: 8px; }
.rlphone .garage .shot { width: 100%; height: auto; aspect-ratio: 16 / 9; }
.rlphone .garage .gx-tools { width: 100%; } .rlphone .garage .gx-tools input { flex: 1; width: auto; }
.rlphone .garage .rl-table td, .rlphone .garage .rl-table th { padding: 5px 4px; }
.rlphone .rl-input { font: 13px "Segoe UI", sans-serif; padding: 8px 10px; border: 1px solid #c8d1dc; border-radius: 9px; background: #fff; color: #111; width: 100%; user-select: text; }
.rlphone .rl-row { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.rlphone .rl-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.rlphone .rl-card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
.rlphone .rl-box { background: #fff; border-radius: 12px; padding: 10px 12px; margin: 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
.rlphone .rl-badge { display: inline-block; font-size: 10.5px; padding: 2px 8px; border-radius: 9px; background: #e3eef9; color: #24508c; }
.rlphone .rl-badge.ok { background: #e3f7e0; color: #236b1a; } .rlphone .rl-badge.warn { background: #fff1cc; color: #7b5600; } .rlphone .rl-badge.bad { background: #fde3e0; color: #8e2318; }
.rlphone .rl-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin: 8px 0; }
.rlphone .rl-stats > div { background: #fff; border-radius: 10px; padding: 8px 10px; box-shadow: 0 1px 2px rgba(0,0,0,.08); }
.rlphone .rl-stats b { display: block; font-size: 15px; color: #0d4a44; } .rlphone .rl-stats small { font-size: 10.5px; color: #627080; }
.rlphone .rl-table { width: 100%; border-collapse: collapse; font-size: 11.5px; display: block; overflow-x: auto; }
.rlphone .rl-table td, .rlphone .rl-table th { padding: 6px; border-bottom: 1px solid #e3e8ee; text-align: left; }
.rlphone .rl-empty { text-align: center; padding: 26px 10px; color: #627080; } .rlphone .rl-empty b { display: block; font-size: 14px; color: #0d4a44; margin-bottom: 4px; }
.rlphone .rl-progress { height: 10px; border-radius: 6px; background: #e3e8ef; overflow: hidden; } .rlphone .rl-progress i { display: block; height: 100%; background: #2f9e44; }
.rlphone .rl-form { display: grid; gap: 8px; } .rlphone .rl-form label { display: grid; gap: 3px; font-size: 12px; }
.rlphone .rl-two { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.rlphone .rl-thumb { width: 100%; aspect-ratio: 16/9; object-fit: cover; display: block; background: #e3e8ef; }
.rlphone .rl-error { color: #b0281a; }
</style>
