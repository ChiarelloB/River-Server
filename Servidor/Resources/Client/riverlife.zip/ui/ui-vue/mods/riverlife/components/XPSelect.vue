<template>
  <div class="xps" :class="{ open, disabled }">
    <button ref="btn" type="button" class="xps-btn" :class="{ placeholder: !current }" :disabled="disabled" :title="title"
      :aria-label="ariaLabel || title" aria-haspopup="listbox" :aria-expanded="open" @click="toggle" @keydown="onKey">
      <span class="xps-label">{{ current ? current.label : placeholder }}</span>
      <i class="xps-arrow" aria-hidden="true"></i>
    </button>
    <!-- The game's browser never draws native <select> popups: the list is ours, on top of everything. -->
    <Teleport to="body">
      <ul v-if="open" ref="list" class="xps-list" :style="pos" role="listbox" @pointerdown.stop @wheel.stop>
        <li v-for="(o, i) in items" :key="i" role="option" :aria-selected="same(o.value, modelValue)"
          :class="{ on: same(o.value, modelValue), hi: i === hi, off: o.disabled }" @pointerenter="hi = i" @click="pick(o)">{{ o.label }}</li>
        <li v-if="!items.length" class="off">Nada para escolher</li>
      </ul>
    </Teleport>
  </div>
</template>

<script setup>
// Original code: a dropdown that works inside BeamNG's embedded browser (native <select> lists do not open there).
import { computed, nextTick, onUnmounted, ref, watch } from "vue"

const props = defineProps({
  modelValue: { default: "" },
  // [{ value, label, disabled }] or plain strings.
  options: { type: Array, default: () => [] },
  placeholder: { type: String, default: "Escolha" },
  disabled: Boolean,
  title: String,
  ariaLabel: String,
})
const emit = defineEmits(["update:modelValue", "change"])

const open = ref(false)
const hi = ref(-1)
const btn = ref(null)
const list = ref(null)
const pos = ref({})

const items = computed(() => props.options.map(o => (o && typeof o === "object" ? { value: o.value, label: String(o.label ?? o.value ?? ""), disabled: !!o.disabled }
  : { value: o, label: String(o ?? ""), disabled: false })))
const same = (a, b) => String(a ?? "") === String(b ?? "")
const current = computed(() => items.value.find(o => same(o.value, props.modelValue)))

function place() {
  const r = btn.value?.getBoundingClientRect()
  if (!r) return
  const below = innerHeight - r.bottom - 8, above = r.top - 8
  const up = below < 180 && above > below
  const max = Math.max(120, Math.min(320, up ? above : below))
  pos.value = { left: Math.max(4, Math.min(r.left, innerWidth - Math.max(r.width, 160) - 4)) + "px", minWidth: r.width + "px", maxHeight: max + "px",
    ...(up ? { bottom: (innerHeight - r.top + 2) + "px" } : { top: (r.bottom + 2) + "px" }) }
}
function outside(e) {
  if (btn.value?.contains(e.target) || list.value?.contains(e.target)) return
  close()
}
function close() {
  open.value = false
  window.removeEventListener("pointerdown", outside, true)
  window.removeEventListener("resize", close)
  window.removeEventListener("wheel", close, true)
}
function show() {
  if (props.disabled || open.value) return
  place()
  open.value = true
  hi.value = Math.max(0, items.value.findIndex(o => same(o.value, props.modelValue)))
  window.addEventListener("pointerdown", outside, true)
  window.addEventListener("resize", close)
  // Scrolling the page under an open list would leave it floating in the wrong place.
  window.addEventListener("wheel", close, true)
  nextTick(() => list.value?.children[hi.value]?.scrollIntoView({ block: "nearest" }))
}
function toggle() { open.value ? close() : show() }
function pick(o) {
  if (!o || o.disabled) return
  close()
  if (!same(o.value, props.modelValue)) { emit("update:modelValue", o.value); emit("change", o.value) }
  btn.value?.focus()
}
function move(d) {
  const n = items.value.length
  if (!n) return
  let i = hi.value
  for (let k = 0; k < n; k++) { i = (i + d + n) % n; if (!items.value[i].disabled) break }
  hi.value = i
  nextTick(() => list.value?.children[i]?.scrollIntoView({ block: "nearest" }))
}
function onKey(e) {
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault()
    if (!open.value) { show(); return }
    move(e.key === "ArrowDown" ? 1 : -1)
  } else if (e.key === "Enter" || e.key === " ") {
    e.preventDefault()
    if (open.value) pick(items.value[hi.value]); else show()
  } else if (e.key === "Escape" && open.value) {
    e.preventDefault(); e.stopPropagation(); close()
  } else if (e.key === "Tab") close()
}
watch(() => props.disabled, d => { if (d) close() })
onUnmounted(close)
</script>

<style>
.xps { position: relative; display: inline-flex; min-width: 0; vertical-align: middle; }
.xps-btn { display: flex; align-items: center; gap: 8px; width: 100%; min-width: 120px; min-height: 28px; padding: 4px 6px 4px 8px; text-align: left; cursor: pointer;
  font: 12.5px Tahoma, Verdana, sans-serif; color: #111; background: #fff; border: 1px solid #7f9db9; border-radius: 2px; }
.xps-btn:hover:not(:disabled) { border-color: #316ac5; }
.xps-btn:focus { outline: 1px solid #316ac5; }
.xps-btn:disabled { color: #8a8a8a; background: #f4f3ee; cursor: default; }
.xps-btn.placeholder .xps-label { color: #6d7a88; }
.xps-label { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.xps-arrow { flex-shrink: 0; width: 17px; height: 17px; margin: -2px -4px -2px 0; border-radius: 2px; position: relative;
  background: linear-gradient(180deg, #c6d8fb, #a4c1f4 50%, #8db1f0); border: 1px solid #a5bce8; }
.xps-arrow::after { content: ""; position: absolute; left: 4px; top: 6px; border: 4px solid transparent; border-top: 4px solid #4d6185; border-bottom: 0; }
.xps.open .xps-btn { border-color: #316ac5; }
.xps-list { position: fixed; z-index: 2147483000; margin: 0; padding: 1px 0; list-style: none; overflow-y: auto; background: #fff; border: 1px solid #000;
  box-shadow: 2px 3px 8px rgba(0,0,0,.35); font: 12.5px Tahoma, Verdana, sans-serif; color: #111; user-select: none; }
.xps-list li { padding: 4px 10px; white-space: nowrap; cursor: default; }
.xps-list li.on { font-weight: bold; }
.xps-list li.hi { background: #316ac5; color: #fff; }
.xps-list li.off { color: #9a9a9a; }
.xps-list li.off.hi { background: #e8edf5; color: #9a9a9a; }
</style>
