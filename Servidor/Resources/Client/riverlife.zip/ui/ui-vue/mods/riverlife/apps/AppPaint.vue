<template>
  <div class="pnt">
    <!-- Sem sessão do RLS: escolher o carro desta garagem -->
    <div v-if="!route" class="rl-page">
      <h2 class="rl-h1">Cabine de pintura</h2>
      <p class="rl-muted">Escolha o carro que vai para a cabine. Você troca as três cores, o acabamento e o verniz vendo o resultado no carro antes de pagar.</p>
      <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>A pintura usa a cabine da garagem onde o carro está estacionado.</div>
      <div v-else-if="!launchVehicles.length" class="rl-empty"><b>Nenhum carro nesta garagem</b>Estacione um carro perto do computador e tente de novo.</div>
      <article v-for="v in launchVehicles" :key="v.inventoryId" class="lv rl-card">
        <img v-if="v.thumbnail" :src="v.thumbnail" alt="" />
        <div class="lv-main">
          <b>{{ v.niceName || v.vehicleName || "Veículo" }}</b>
          <small class="rl-muted">{{ v.fn ? (v.fn.disabled ? reasonText(v.fn) : "Pronto para pintar") : "Esta garagem não tem cabine de pintura" }}</small>
        </div>
        <button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button>
      </article>
    </div>

    <template v-else>
      <header class="bar">
        <span class="bar-ico"><BngIcon type="sprayCan" /></span>
        <div class="bar-txt"><b>Pintura</b><small>{{ vehicleName || "Cabine de pintura" }}</small></div>
        <span v-if="changed" class="rl-badge warn">{{ changedCount }} cor(es) alterada(s)</span>
      </header>

      <div v-if="error" class="body"><div class="rl-empty"><b>Não deu para abrir a pintura</b>{{ error }}</div></div>
      <div v-else-if="!ready" class="body"><div class="rl-empty"><b>Preparando a cabine…</b>Levando o carro para a pintura.</div></div>
      <div v-else class="body">
        <nav class="slots" aria-label="Cores do carro">
          <button v-for="(p, i) in paints" :key="i" :class="{ on: sel === i }" @click="sel = i">
            <i class="dot" :style="{ background: cssRgb(p.rgb) }"></i>{{ SLOT_NAMES[i] }}<em v-if="pkg[i].paintClass">*</em>
          </button>
        </nav>

        <section class="grp">
          <h4>Acabamento <small>{{ SLOT_NAMES[sel] }}</small></h4>
          <div class="classes">
            <button v-for="c in CLASSES" :key="c.id" class="cls" :class="{ on: cur.cls === c.id }" :title="c.hint" @click="pickClass(c.id)">
              <i class="ball" :style="ballStyle(c.id)"></i>
              <span>{{ c.label }}</span>
              <small>{{ dollars(classPrice(c.id)) }}</small>
            </button>
          </div>
          <p v-if="pendingHint" class="hint">{{ pendingHint }}</p>
        </section>

        <section v-if="cur.cls === 'factory'" class="grp">
          <h4>Cores de fábrica</h4>
          <div v-if="factory.length" class="swatches">
            <button v-for="f in factory" :key="f.name" class="sw" :class="{ on: sameColor(f.paint) }" :title="f.name"
              :style="{ background: cssRgb(f.paint.rgb) }" @click="applyFactory(f)"></button>
          </div>
          <p v-else class="rl-muted">Este modelo não tem cores de fábrica cadastradas. Escolha outro acabamento.</p>
          <p v-if="factoryName" class="rl-muted sel-name">Cor escolhida: <b>{{ factoryName }}</b></p>
        </section>

        <template v-else>
          <section class="grp">
            <h4>Cor</h4>
            <div class="color-row">
              <i class="preview" :style="ballStyle(cur.cls, cp)"></i>
              <div class="hexbox">
                <label>Hex</label>
                <input v-model="hexText" class="rl-input hex" maxlength="7" spellcheck="false"
                  @focus="typing(true)" @blur="typing(false); commitHex()" @keydown.enter.prevent="commitHex()" />
              </div>
              <button class="rl-btn sm" :disabled="!pkg[sel].paintClass" title="Volta esta cor ao que o carro tem hoje" @click="resetSlot(sel)">
                <BngIcon type="undo" /> Original
              </button>
            </div>
            <div class="swatches">
              <button v-for="c in PALETTE" :key="c.hex" class="sw" :class="{ on: hexOf(cp.rgb) === c.hex }" :title="c.name"
                :style="{ background: c.hex }" @click="setRgb(fromHex(c.hex))"></button>
            </div>
            <div class="sliders">
              <label>Matiz <output>{{ Math.round(cp.hsl[0] * 360) }}°</output></label>
              <input type="range" class="sl" min="0" max="360" step="1" :value="Math.round(cp.hsl[0] * 360)" :style="{ '--track': hueTrack }"
                @input="setHsl(0, $event.target.value / 360)" />
              <label>Saturação <output>{{ Math.round(cp.hsl[1] * 100) }}%</output></label>
              <input type="range" class="sl" min="0" max="100" step="1" :value="Math.round(cp.hsl[1] * 100)" :style="{ '--track': satTrack }"
                @input="setHsl(1, $event.target.value / 100)" />
              <label>Luminosidade <output>{{ Math.round(cp.hsl[2] * 100) }}%</output></label>
              <input type="range" class="sl" min="0" max="100" step="1" :value="Math.round(cp.hsl[2] * 100)" :style="{ '--track': lumTrack }"
                @input="setHsl(2, $event.target.value / 100)" />
            </div>
          </section>

          <section v-if="cur.cls === 'custom'" class="grp">
            <h4>Material</h4>
            <div class="sliders">
              <template v-for="m in MATERIAL" :key="m.key">
                <label :title="m.hint">{{ m.label }} <output>{{ Math.round(cp[m.key] * 100) }}%</output></label>
                <input type="range" class="sl" min="0" max="100" step="1" :value="Math.round(cp[m.key] * 100)"
                  @input="setMaterial(m.key, $event.target.value / 100)" />
              </template>
            </div>
          </section>

          <section v-else class="grp">
            <h4>Verniz</h4>
            <label class="check">
              <input type="checkbox" :checked="cur.clearCoat" @change="setClearCoat($event.target.checked)" />
              Aplicar verniz <small class="rl-muted">(+{{ dollars(ccBase) }})</small>
            </label>
            <div v-if="cur.clearCoat" class="sliders">
              <label>Polimento do verniz <output>{{ Math.round(cur.polish * 100) }}% · +{{ dollars(ccPolish * cur.polish) }}</output></label>
              <input type="range" class="sl" min="0" max="100" step="1" :value="Math.round(cur.polish * 100)" @input="setPolish($event.target.value / 100)" />
            </div>
          </section>
        </template>

        <section class="grp">
          <h4>Orçamento</h4>
          <table v-if="lines.length" class="rl-table cart">
            <tr v-for="(l, k) in lines" :key="k" :class="{ sub: !l.top }">
              <td class="act"><button v-if="l.top" class="mini" title="Desfazer esta cor" @click="resetSlot(l.i)"><BngIcon type="abandon" /></button></td>
              <td>{{ l.name }}</td>
              <td class="num">{{ dollars(l.price) }}</td>
            </tr>
          </table>
          <p v-else class="rl-muted">Nada alterado ainda. Escolha um acabamento ou uma cor para ver o preço.</p>
        </section>
      </div>

      <footer class="foot">
        <div class="tot">
          <span>Total <b>{{ dollars(total) }}</b></span>
          <span class="rl-muted">Saldo {{ playerMoney === null ? "—" : dollars(playerMoney) }}</span>
        </div>
        <p v-if="changed && canPay === false" class="rl-error low">Saldo insuficiente para esta pintura.</p>
        <div class="btns">
          <button class="rl-btn" :disabled="!changed || busy" @click="resetAll">Restaurar original</button>
          <span class="grow"></span>
          <button class="rl-btn" :disabled="busy" @click="requestClose">Cancelar</button>
          <button class="rl-btn go" :disabled="!changed || canPay === false || busy || !ready" @click="buy">Comprar pintura</button>
        </div>
      </footer>

      <div v-if="confirm" class="cfm-mask">
        <div class="cfm" role="dialog">
          <b>{{ confirm.title }}</b>
          <p>{{ confirm.text }}</p>
          <div class="btns">
            <button v-for="b in confirm.buttons" :key="b.label" class="rl-btn" :class="b.kind" @click="b.action">{{ b.label }}</button>
          </div>
        </div>
      </div>
      <div v-if="busy" class="busy"><span>{{ busyText }}</span></div>
    </template>
  </div>
</template>

<script>
// Edits survive a minimize/restore of the window (the component remounts while the RLS session stays open).
const MEMO = new Map()
// While minimized nothing of ours is mounted: this router hook still cleans up if the painting route is left meanwhile.
let routeGuard = null
function dropGuard() { if (routeGuard) { routeGuard(); routeGuard = null } }
</script>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaRun, luaValue, onGameEvent, dollars, arr, typing, toast } from "../rl.js"
import { desk } from "../desk.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])

const ROUTE = "career.computer.painting"
const SLOT_NAMES = ["Primária", "Secundária", "Terciária"]
const CLASSES = [
  { id: "factory", label: "De fábrica", hint: "Uma das cores originais do modelo, com o acabamento de fábrica" },
  { id: "semiGloss", label: "Semibrilho", hint: "Brilho suave" },
  { id: "gloss", label: "Brilhante", hint: "Brilho alto, sem metal" },
  { id: "matte", label: "Fosca", hint: "Sem brilho" },
  { id: "semiMetallic", label: "Semimetálica", hint: "Um toque de metal" },
  { id: "metallic", label: "Metálica", hint: "Partículas metálicas" },
  { id: "chrome", label: "Cromada", hint: "Efeito espelho" },
  { id: "custom", label: "Personalizada", hint: "Você ajusta metal, rugosidade e verniz" },
]
const CLASS_NAME = Object.fromEntries(CLASSES.map(c => [c.id, c.label]))
const MATERIAL = [
  { key: "metallic", label: "Metal", hint: "Quanto a tinta reflete como metal" },
  { key: "roughness", label: "Rugosidade", hint: "0% espelhado, 100% fosco" },
  { key: "clearcoat", label: "Verniz", hint: "Camada de verniz por cima da cor" },
  { key: "clearcoatRoughness", label: "Rugosidade do verniz", hint: "0% verniz polido" },
]
const PALETTE = [
  { name: "Branco polar", hex: "#F4F5F2" }, { name: "Branco pérola", hex: "#E8E2D2" }, { name: "Prata", hex: "#B9BDC1" },
  { name: "Cinza grafite", hex: "#55595E" }, { name: "Cinza chumbo", hex: "#2E3135" }, { name: "Preto", hex: "#0C0D0F" },
  { name: "Vermelho", hex: "#C1121F" }, { name: "Vinho", hex: "#5C0B16" }, { name: "Laranja", hex: "#E8611A" },
  { name: "Amarelo", hex: "#F2C200" }, { name: "Dourado", hex: "#B8913A" }, { name: "Cobre", hex: "#9C5B33" },
  { name: "Bege", hex: "#C8B48A" }, { name: "Marrom", hex: "#4E3220" }, { name: "Verde inglês", hex: "#0F3D2E" },
  { name: "Verde militar", hex: "#4B5320" }, { name: "Verde limão", hex: "#8CC63F" }, { name: "Turquesa", hex: "#18A5A7" },
  { name: "Azul petróleo", hex: "#0F5560" }, { name: "Azul celeste", hex: "#5DA9E9" }, { name: "Azul royal", hex: "#1B4DB1" },
  { name: "Azul marinho", hex: "#13213F" }, { name: "Roxo", hex: "#4B2A7B" }, { name: "Rosa", hex: "#E5679A" },
]

const paints = ref([])
const pkg = reactive([{}, {}, {}])
const slotUi = reactive([0, 1, 2].map(() => ({ cls: "factory", clearCoat: false, polish: 0, factoryName: "" })))
let original = []
const sel = ref(0)
const prices = ref({})
const classData = ref({})
const factory = ref([])
const gIndex = ref(1)
const total = ref(0)
const canPay = ref(null)
const playerMoney = ref(null)
const vehicleName = ref("")
const error = ref("")
const busy = ref(false)
const busyText = ref("")
const confirm = ref(null)
const hexText = ref("")
const loaded = ref(false)
let offs = []
let sendTimer = null
let sendDirty = false
let busyTimer = null
let started = false

const memoKey = computed(() => String(props.nonce ?? props.route ?? ""))
const ready = computed(() => paints.value.length > 0 && !!prices.value.basePrices)
const cur = computed(() => slotUi[sel.value])
const cp = computed(() => paints.value[sel.value] || paints.value[0])
const changed = computed(() => pkg.some(p => !!p.paintClass))
const changedCount = computed(() => pkg.filter(p => !!p.paintClass).length)
const factoryName = computed(() => cur.value.cls === "factory" && pkg[sel.value].paintClass === "factory" ? cur.value.factoryName : "")
const pendingHint = computed(() => {
  const committed = pkg[sel.value].paintClass
  if (cur.value.cls === "factory" && committed !== "factory") return committed ? "Escolha uma cor de fábrica abaixo para trocar o acabamento." : "Escolha uma cor de fábrica abaixo."
  if (cur.value.cls === "custom" && committed !== "custom") return "Mexa na cor ou no material para aplicar a pintura personalizada."
  return ""
})

// ---- launcher (no RLS session) ----
const launchVehicles = computed(() => arr(rl.view.computer?.vehicles).map(v => ({
  ...v, fn: rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.painting,
})))
function reasonText(fn) { const r = fn?.reason; return (typeof r?.label === "string" ? r.label : r?.label?.txt) || "Indisponível agora" }
function launch(v) { request("native", { buttonId: "painting", inventoryId: v.inventoryId }) }

// ---- colour helpers ----
const clamp01 = v => Math.min(1, Math.max(0, Number(v) || 0))
const r4 = v => Math.round((Number(v) || 0) * 10000) / 10000
function hue2rgb(p, q, t) {
  if (t < 0) t += 1
  if (t > 1) t -= 1
  if (t < 1 / 6) return p + (q - p) * 6 * t
  if (t < 1 / 2) return q
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
  return p
}
function hslToRgb(h, s, l) {
  if (s === 0) return [l, l, l]
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s
  const p = 2 * l - q
  return [hue2rgb(p, q, h + 1 / 3), hue2rgb(p, q, h), hue2rgb(p, q, h - 1 / 3)]
}
function rgbToHsl(r, g, b) {
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2
  if (max === min) return [0, 0, l]
  const d = max - min
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
  let h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4
  return [h / 6, s, l]
}
function hexOf(rgb) { return "#" + rgb.map(v => Math.round(clamp01(v) * 255).toString(16).padStart(2, "0")).join("").toUpperCase() }
function fromHex(t) {
  const m = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(String(t || "").trim())
  if (!m) return null
  let h = m[1]
  if (h.length === 3) h = h.split("").map(c => c + c).join("")
  return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16) / 255)
}
function cssRgb(rgb, k = 0) {
  const c = (rgb || [1, 1, 1]).map(v => clamp01(v))
  const adj = k >= 0 ? c.map(v => v + (1 - v) * k) : c.map(v => v * (1 + k))
  return "rgb(" + adj.map(v => Math.round(v * 255)).join(",") + ")"
}
function mkPaint(rgb, a, metallic, roughness, clearcoat, clearcoatRoughness) {
  const c = rgb.map(clamp01)
  return { rgb: c, hsl: rgbToHsl(...c), a: Number.isFinite(Number(a)) ? Number(a) : 1, metallic: clamp01(metallic), roughness: clamp01(roughness),
    clearcoat: clamp01(clearcoat), clearcoatRoughness: clamp01(clearcoatRoughness) }
}
// Paints arrive as {baseColor, metallic, roughness, clearcoat, clearcoatRoughness}, or as 7/8 value strings/arrays.
function parsePaint(v) {
  if (!v) return null
  if (typeof v === "string") v = v.trim().split(/\s+/).map(Number)
  if (Array.isArray(v)) {
    if (v.length >= 8) return mkPaint(v.slice(0, 3), v[3], v[4], v[5], v[6], v[7])
    if (v.length === 7) return mkPaint(v.slice(0, 3), 1, v[3], v[4], v[5], v[6])
    return null
  }
  if (typeof v === "object") {
    const bc = arr(v.baseColor).map(Number)
    if (bc.length < 3 || bc.some(n => !Number.isFinite(n))) return null
    return mkPaint(bc.slice(0, 3), bc.length > 3 ? bc[3] : 1, v.metallic, v.roughness, v.clearcoat, v.clearcoatRoughness)
  }
  return null
}
const clonePaint = p => ({ ...p, rgb: [...p.rgb], hsl: [...p.hsl] })
const paintObject = p => ({ baseColor: [...p.rgb.map(r4), r4(p.a)], metallic: r4(p.metallic), roughness: r4(p.roughness),
  clearcoat: r4(p.clearcoat), clearcoatRoughness: r4(p.clearcoatRoughness) })
function sameColor(p) { return !!cp.value && hexOf(cp.value.rgb) === hexOf(p.rgb) && Math.abs(cp.value.metallic - p.metallic) < 0.01 && Math.abs(cp.value.roughness - p.roughness) < 0.01 }

// Small sphere preview: colour plus a highlight that follows roughness/metal of the finish.
function ballStyle(cls, p) {
  const paint = p || cp.value
  const rgb = paint?.rgb || [0.6, 0.6, 0.6]
  let metal = paint?.metallic ?? 0, rough = paint?.roughness ?? 0.5
  if (!p && classData.value[cls]) { metal = classData.value[cls].metallic; rough = classData.value[cls].roughness }
  if (!p && cls === "factory") { metal = 0.3; rough = 0.3 }
  if (!p && cls === "custom") { metal = 0.6; rough = 0.25 }
  const gloss = 1 - rough
  return { background: `radial-gradient(circle at 33% 28%, rgba(255,255,255,${(0.12 + 0.75 * gloss).toFixed(2)}) 0, rgba(255,255,255,0) ${Math.round(14 + 30 * gloss)}%),`
    + ` linear-gradient(155deg, ${cssRgb(rgb, 0.18 + 0.3 * metal)}, ${cssRgb(rgb)} 50%, ${cssRgb(rgb, -0.45 - 0.3 * metal)})` }
}
const hueTrack = computed(() => "linear-gradient(90deg," + [0, 60, 120, 180, 240, 300, 360].map(h => `hsl(${h},100%,50%)`).join(",") + ")")
const satTrack = computed(() => { const [h, , l] = cp.value?.hsl || [0, 0, 0.5]; return `linear-gradient(90deg, hsl(${h * 360},0%,${l * 100}%), hsl(${h * 360},100%,${l * 100}%))` })
const lumTrack = computed(() => { const [h, s] = cp.value?.hsl || [0, 0]; return `linear-gradient(90deg, #000, hsl(${h * 360},${s * 100}%,50%), #fff)` })

// ---- prices ----
const money = c => Number(c?.money?.amount) || 0
function classPrice(id) { return Math.floor(money(prices.value.basePrices?.[id]) * gIndex.value) }
const ccBase = computed(() => Math.floor(money(prices.value.clearcoatBase) * gIndex.value))
const ccPolish = computed(() => money(prices.value.clearcoatPolishFactor) * gIndex.value)
const lines = computed(() => {
  const out = []
  pkg.forEach((p, i) => {
    if (!p.paintClass) return
    out.push({ top: true, i, name: SLOT_NAMES[i] + ": " + (CLASS_NAME[p.paintClass] || p.paintClass), price: classPrice(p.paintClass) })
    if (p.clearCoat) {
      out.push({ name: "Verniz", price: ccBase.value })
      if (p.clearCoatPolish > 0) out.push({ name: "Polimento do verniz (" + Math.round(p.clearCoatPolish * 100) + "%)", price: ccPolish.value * p.clearCoatPolish })
    }
  })
  return out
})

// ---- sending the preview to the car ----
function plainPkg(p) { return p.paintClass ? { paintClass: p.paintClass, clearCoat: !!p.clearCoat, clearCoatPolish: Number(p.clearCoatPolish) || 0 } : {} }
function sendNow() {
  sendDirty = false
  if (!paints.value.length) return
  luaCall("career_modules_painting.setPaints(" + luaValue(paints.value.map(paintObject)) + "," + luaValue([0, 1, 2].map(i => plainPkg(pkg[i]))) + ")")
}
// Slider drags fire many events: send at most every ~90 ms, always ending with the latest state.
function queueSend() {
  sendDirty = true
  if (sendTimer) return
  sendNow()
  sendTimer = setTimeout(function tick() {
    sendTimer = null
    if (sendDirty) queueSend()
  }, 90)
}
function flushSend() {
  if (sendTimer) { clearTimeout(sendTimer); sendTimer = null }
  if (sendDirty) sendNow()
}
function commit(i = sel.value) {
  const ui = slotUi[i]
  const coat = ui.cls !== "factory" && ui.cls !== "custom" && ui.clearCoat
  pkg[i] = { paintClass: ui.cls, clearCoat: coat, clearCoatPolish: coat ? ui.polish : 0 }
  queueSend()
}

// ---- edits (same rules as the RLS painting screen) ----
function pickClass(id) {
  const ui = cur.value
  if (ui.cls === id) return
  ui.cls = id
  if (id === "factory" || id === "custom") { ui.clearCoat = false; ui.polish = 0; return }
  const data = classData.value[id] || {}
  const p = cp.value
  p.metallic = clamp01(data.metallic)
  p.roughness = clamp01(data.roughness)
  ui.clearCoat = false
  ui.polish = 0
  p.clearcoat = 0
  commit()
}
function applyFactory(f) {
  paints.value[sel.value] = clonePaint(f.paint)
  hexText.value = hexOf(f.paint.rgb)
  cur.value.factoryName = f.name
  commit()
}
function setRgb(rgb) {
  if (!rgb) return
  const p = cp.value
  const hsl = rgbToHsl(...rgb)
  if (hsl[1] === 0) hsl[0] = p.hsl[0]
  p.rgb = rgb.map(clamp01)
  p.hsl = hsl
  hexText.value = hexOf(p.rgb)
  commit()
}
function setHsl(k, v) {
  const p = cp.value
  const hsl = [...p.hsl]
  hsl[k] = clamp01(v)
  p.hsl = hsl
  p.rgb = hslToRgb(...hsl)
  hexText.value = hexOf(p.rgb)
  commit()
}
function commitHex() {
  const rgb = fromHex(hexText.value)
  if (rgb) { if (hexOf(rgb) !== hexOf(cp.value.rgb)) setRgb(rgb); else hexText.value = hexOf(rgb) }
  else hexText.value = hexOf(cp.value.rgb)
}
function setMaterial(key, v) { cp.value[key] = clamp01(v); commit() }
function setClearCoat(on) {
  const ui = cur.value
  ui.clearCoat = !!on
  ui.polish = 0
  cp.value.clearcoatRoughness = 0.13
  cp.value.clearcoat = on ? 1 : 0
  commit()
}
function setPolish(v) {
  cur.value.polish = clamp01(v)
  cp.value.clearcoatRoughness = 0.13 - 0.13 * cur.value.polish
  commit()
}
function resetSlot(i) {
  if (!original[i]) return
  pkg[i] = {}
  paints.value[i] = clonePaint(original[i])
  Object.assign(slotUi[i], { cls: "factory", clearCoat: false, polish: 0, factoryName: "" })
  if (i === sel.value) hexText.value = hexOf(paints.value[i].rgb)
  queueSend()
}
function resetAll() { for (let i = 0; i < paints.value.length; i++) resetSlot(i) }
watch(sel, () => { if (cp.value) hexText.value = hexOf(cp.value.rgb) })

// ---- Lua events ----
function parsePresets(raw) {
  const out = []
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    for (const [name, val] of Object.entries(raw)) { const p = parsePaint(val); if (p) out.push({ name, paint: p }) }
  }
  // Colours first (by hue), greys last (dark to light), like the RLS presets.
  const key = f => { const [h, s, l] = f.paint.hsl; return s <= 0.3 ? 10 + l : h * 6 }
  return out.sort((a, b) => key(a) - key(b))
}
function onPaintingData(d) {
  if (!d) return
  prices.value = d.prices || {}
  classData.value = d.colorClassData || {}
  factory.value = parsePresets(d.factoryPaint)
  const colors = arr(d.colors).map(parsePaint).filter(Boolean)
  if (!colors.length) {
    if (!paints.value.length) error.value = "Não foi possível ler as cores atuais deste carro. Feche e abra a pintura de novo."
    return
  }
  error.value = ""
  if (loaded.value) return // keep what the player is editing
  original = colors.slice(0, 3)
  paints.value = original.map(clonePaint)
  loaded.value = true
  hexText.value = hexOf(paints.value[0].rgb)
}
function onCartData(d) {
  total.value = Number(d?.totalPrice?.money?.amount) || 0
  canPay.value = d?.canPay !== false
}

async function loadExtras() {
  const [m, g] = await Promise.all([
    luaCall("career_modules_playerAttributes.getAttributeValue('money')"),
    luaRun("return career_modules_globalEconomy and career_modules_globalEconomy.getGlobalIndex and career_modules_globalEconomy.getGlobalIndex() or 1"),
  ])
  if (Number.isFinite(Number(m))) playerMoney.value = Number(m)
  if (Number(g) > 0) gIndex.value = Number(g)
  // The painting module seats the player in the car; its name goes in the window title.
  setTimeout(async () => {
    const name = await luaRun("local id = career_modules_inventory.getCurrentVehicle() local v = id and career_modules_inventory.getVehicles()[id] return v and v.niceName or nil")
    if (typeof name === "string" && name) { vehicleName.value = name; emit("title", name) }
  }, 800)
}

function start() {
  if (started || !props.route) return
  started = true
  dropGuard()
  offs.push(onGameEvent("paintingData", onPaintingData))
  offs.push(onGameEvent("sendPaintingShoppingCartData", onCartData))
  const memo = MEMO.get(memoKey.value)
  if (memo) {
    original = memo.original
    paints.value = memo.paints
    memo.pkg.forEach((p, i) => (pkg[i] = p))
    memo.slotUi.forEach((s, i) => Object.assign(slotUi[i], s))
    sel.value = memo.sel
    total.value = memo.total
    canPay.value = memo.canPay
    vehicleName.value = memo.vehicleName
    prices.value = memo.prices
    classData.value = memo.classData
    factory.value = memo.factory
    loaded.value = true
    hexText.value = hexOf(cp.value.rgb)
    if (vehicleName.value) emit("title", vehicleName.value)
  } else {
    luaCall("career_modules_painting.onUIOpened()")
  }
  luaCall("career_modules_painting.sendPaintingDataToUI()")
  loadExtras()
}

// ---- leaving ----
function setBusy(text, ms) {
  busy.value = true
  busyText.value = text
  clearTimeout(busyTimer)
  busyTimer = setTimeout(() => { busy.value = false; toast("O RLS não respondeu. Tente de novo.", "error") }, ms)
}
function buy() {
  if (!changed.value || canPay.value === false) return
  flushSend()
  setBusy("Pintando o carro…", 6000)
  luaCall("career_modules_painting.apply()")
}
function leave() {
  confirm.value = null
  flushSend()
  setBusy("Saindo da cabine…", 5000)
  luaCall("career_modules_painting.close()")
}
function requestClose() {
  if (!props.route) { emit("close"); return }
  if (busy.value) return
  if (!changed.value) { leave(); return }
  confirm.value = {
    title: "Sair sem pintar?",
    text: "As cores novas não foram compradas. O carro volta para a pintura atual.",
    buttons: [
      { label: "Sair sem pintar", kind: "danger", action: leave },
      { label: "Continuar pintando", kind: "", action: () => (confirm.value = null) },
    ],
  }
}
defineExpose({ requestClose })

// Still on the painting route with our window open (minimized windows are unmounted by the desktop).
const stillHere = () => window.vueRouter?.currentRoute?.value?.name === ROUTE && desk.windows.some(w => w.props && w.props.nonce === props.nonce)
onMounted(start)
watch(() => props.route, r => { if (r) start() })
onUnmounted(() => {
  for (const off of offs) off()
  offs = []
  clearTimeout(busyTimer)
  if (!started) return
  if (stillHere() && loaded.value) {
    flushSend()
    // Window minimized/rebuilt while the RLS session is open: keep the edits for the remount.
    MEMO.set(memoKey.value, { original, paints: paints.value, pkg: pkg.map(p => ({ ...p })), slotUi: slotUi.map(s => ({ ...s })), sel: sel.value,
      total: total.value, canPay: canPay.value, vehicleName: vehicleName.value, prices: prices.value, classData: classData.value, factory: factory.value })
    const key = memoKey.value
    dropGuard()
    if (window.vueRouter?.afterEach) {
      routeGuard = window.vueRouter.afterEach(to => {
        if (to?.name === ROUTE) return
        dropGuard()
        MEMO.delete(key)
        luaCall("career_modules_painting.cleanup()")
      })
    }
    return
  }
  if (sendTimer) { clearTimeout(sendTimer); sendTimer = null }
  MEMO.delete(memoKey.value)
  // Same as the RLS view: restore camera, input and the car when the screen goes away.
  luaCall("career_modules_painting.cleanup()")
})
</script>

<style scoped>
.pnt { position: relative; height: 100%; display: flex; flex-direction: column; background: #fff; font-size: 12px; }
.bar { flex: none; display: flex; align-items: center; gap: 8px; padding: 6px 10px; background: linear-gradient(180deg, #f7f6f0, #ece9d8); border-bottom: 1px solid #aca899; }
.bar-ico { width: 30px; height: 30px; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 19px; background: linear-gradient(135deg, #ff8f6b, #c2381b); box-shadow: inset 0 1px 0 rgba(255,255,255,.4); }
.bar-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.bar-txt b { font-size: 13px; color: #12407c; } .bar-txt small { color: #5f7186; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.body { flex: 1; min-height: 0; overflow-y: auto; padding: 8px 10px 12px; }
.slots { display: flex; gap: 2px; border-bottom: 1px solid #919b9c; margin-bottom: 8px; }
.slots button { flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px; font: 12px Tahoma, sans-serif; padding: 6px 4px; border: 1px solid #919b9c; border-bottom: 0; border-radius: 4px 4px 0 0; background: linear-gradient(180deg, #fff, #ecebe5); cursor: pointer; position: relative; top: 1px; }
.slots button.on { background: #fff; border-top: 2px solid #f8b636; font-weight: bold; padding-top: 5px; }
.slots em { color: #c2381b; font-style: normal; font-weight: bold; }
.dot { width: 14px; height: 14px; border-radius: 3px; border: 1px solid rgba(0,0,0,.35); box-shadow: inset 0 1px 0 rgba(255,255,255,.4); }
.grp { border: 1px solid #c9d7e8; border-radius: 4px; padding: 8px 10px 10px; margin-bottom: 8px; background: #fbfcfe; }
.grp h4 { margin: 0 0 8px; font: bold 12px Tahoma, sans-serif; color: #1d3f69; display: flex; align-items: baseline; gap: 6px; }
.grp h4 small { font-weight: normal; color: #6a7b8f; }
.classes { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; }
.cls { display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 6px 2px 5px; border: 1px solid #c3cfdd; border-radius: 4px; background: linear-gradient(180deg, #fff, #f0f3f7); cursor: pointer; font: 11.5px Tahoma, sans-serif; color: #1b2733; }
.cls:hover { border-color: #f8b636; }
.cls.on { border: 2px solid #316ac5; padding: 5px 1px 4px; background: #e8f1fd; }
.cls small { color: #3b6b2a; font-size: 10.5px; }
.ball { width: 26px; height: 26px; border-radius: 50%; border: 1px solid rgba(0,0,0,.3); }
.hint { margin: 7px 0 0; padding: 4px 7px; background: #fff8dc; border: 1px solid #e8d48a; border-radius: 3px; color: #6b5500; }
.swatches { display: flex; flex-wrap: wrap; gap: 4px; margin: 2px 0 6px; }
.sw { width: 24px; height: 24px; border: 1px solid rgba(0,0,0,.35); border-radius: 3px; cursor: pointer; padding: 0; box-shadow: inset 0 1px 0 rgba(255,255,255,.35); }
.sw:hover { transform: scale(1.12); }
.sw.on { outline: 2px solid #316ac5; outline-offset: 1px; }
.sel-name { margin: 2px 0 0; }
.color-row { display: flex; align-items: flex-end; gap: 10px; margin-bottom: 8px; }
.preview { width: 46px; height: 46px; border-radius: 50%; border: 1px solid rgba(0,0,0,.35); flex: none; box-shadow: 0 2px 4px rgba(0,0,0,.2); }
.hexbox { display: flex; flex-direction: column; gap: 2px; } .hexbox label { font-size: 11px; color: #5f7186; }
.hex { width: 90px; font-family: Consolas, "Courier New", monospace !important; text-transform: uppercase; }
.sliders { display: grid; grid-template-columns: 1fr; gap: 1px; }
.sliders label { display: flex; justify-content: space-between; color: #2c4a6e; margin-top: 4px; }
.sliders output { color: #5f7186; font-size: 11px; }
.sl { -webkit-appearance: none; appearance: none; width: 100%; height: 20px; margin: 0; background: transparent; cursor: pointer; }
.sl:focus { outline: none; }
.sl::-webkit-slider-runnable-track { height: 6px; border: 1px solid #8c9aab; border-radius: 3px; background: var(--track, linear-gradient(180deg, #e2e6ec, #fff)); box-shadow: inset 1px 1px 1px rgba(0,0,0,.15); }
.sl::-webkit-slider-thumb { -webkit-appearance: none; width: 11px; height: 18px; margin-top: -7px; border: 1px solid #45679e; border-radius: 3px 3px 6px 6px; background: linear-gradient(180deg, #fff, #dfe7f3 55%, #b9c9e2); box-shadow: 0 1px 2px rgba(0,0,0,.3); }
.sl:hover::-webkit-slider-thumb { border-color: #e8a200; }
.check { display: flex; align-items: center; gap: 6px; cursor: pointer; }
.cart { margin: 0; }
.cart td { padding: 4px 6px; }
.cart tr.sub td { color: #5f7186; padding-left: 18px; }
.cart .act { width: 26px; padding: 2px; }
.cart .num { text-align: right; white-space: nowrap; }
.mini { width: 20px; height: 20px; padding: 0; display: flex; align-items: center; justify-content: center; border: 1px solid #a33; border-radius: 3px; background: linear-gradient(180deg, #fff, #f6dcd8); color: #a33; cursor: pointer; font-size: 13px; }
.foot { flex: none; border-top: 1px solid #aca899; background: #ece9d8; padding: 7px 10px 8px; }
.tot { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
.tot b { font-size: 16px; color: #164a8c; margin-left: 4px; }
.low { margin: 0 0 6px; font-size: 11.5px; }
.btns { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.grow { flex: 1; }
.rl-btn.sm { padding: 3px 8px; font-size: 11.5px; display: inline-flex; align-items: center; gap: 4px; }
.cfm-mask { position: absolute; inset: 0; background: rgba(40,60,90,.25); display: flex; align-items: center; justify-content: center; z-index: 5; }
.cfm { width: 86%; max-width: 380px; background: #ece9d8; border: 2px solid #0831d9; border-radius: 6px; padding: 12px 14px; box-shadow: 3px 4px 14px rgba(0,0,0,.35); }
.cfm b { color: #12407c; font-size: 13px; } .cfm p { margin: 6px 0 12px; line-height: 1.45; }
.cfm .btns { justify-content: flex-end; }
.busy { position: absolute; inset: 0; z-index: 6; background: rgba(255,255,255,.55); display: flex; align-items: center; justify-content: center; cursor: progress; }
.busy span { padding: 8px 14px; background: #ffffe1; border: 1px solid #7a7a5a; border-radius: 4px; box-shadow: 2px 2px 6px rgba(0,0,0,.25); }
.lv { display: flex; align-items: center; gap: 10px; padding: 8px; margin: 8px 0; }
.lv img { width: 96px; height: 54px; object-fit: contain; background: #eef2f7; border-radius: 3px; flex: none; }
.lv-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.lv-main b { color: #1b3355; font-size: 13px; }
</style>
