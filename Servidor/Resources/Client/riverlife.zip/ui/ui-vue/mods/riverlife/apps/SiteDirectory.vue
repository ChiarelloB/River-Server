<template>
  <div class="dir">
    <header class="dir-head" :class="kind">
      <div><b>{{ kind === "stores" ? "lojas" : "oficinas" }}</b>.river<small>{{ kind === "stores" ? "Concessionárias dos jogadores da cidade" : "Mecânicos de confiança perto de você" }}</small></div>
      <button class="rl-btn" @click="$emit('open', kind === 'stores' ? 'store' : 'workshop')">{{ kind === "stores" ? (myStore ? "Minha loja" : "Abrir minha loja") : (myShop ? "Minha oficina" : "Abrir minha oficina") }}</button>
    </header>

    <section v-if="kind === 'workshops' && myOrders.length" class="rl-page orders">
      <h3 class="rl-h2">Meus serviços</h3>
      <article v-for="o in myOrders" :key="o.id" class="rl-box">
        <div class="rl-row between">
          <b>{{ o.vehicle?.niceName || o.vehicle?.model }} · {{ o.shopName }}</b>
          <span class="rl-badge" :class="badgeClass(o.status)">{{ status(o.status) }}</span>
        </div>
        <p class="rl-muted">Diagnóstico: {{ o.diagnosis?.notes || "—" }} · peças estimadas {{ money(o.diagnosis?.partsCost) }}</p>
        <table v-if="o.quote" class="rl-table">
          <tr v-for="(it, i) in o.quote.items" :key="i"><td>{{ it.label }}</td><td class="r">{{ money(it.amount) }}</td></tr>
          <tr><td><b>Total</b> · prazo {{ o.quote.minutes }} min</td><td class="r"><b>{{ money(o.quote.total) }}</b></td></tr>
        </table>
        <div v-if="o.status === 'in_progress'" class="rl-progress"><i :style="{ width: progress(o) + '%' }"></i></div>
        <div class="rl-row">
          <button v-if="o.status === 'quoted'" class="rl-btn go" :disabled="rl.busy.serviceAccept"
            @click="ask('Aprovar o orçamento e pagar ' + money(o.quote.total) + '?', () => request('serviceAccept', { orderId: o.id }), 'Aprovar e pagar')">Aprovar e pagar {{ money(o.quote.total) }}</button>
          <button v-if="['requested', 'quoted', 'accepted'].includes(o.status)" class="rl-btn" @click="request('serviceDecline', { orderId: o.id })">Cancelar</button>
          <button class="rl-btn" @click="request('gps', { position: o.position })">GPS da oficina</button>
          <template v-if="o.status === 'completed' && !o.rating">
            <span class="rl-muted">Avalie:</span>
            <button v-for="s in 5" :key="s" class="star" @click="request('rateShop', { orderId: o.id, stars: s })">★</button>
          </template>
        </div>
      </article>
    </section>

    <section class="rl-page">
      <div class="rl-row"><input v-model="search" class="rl-input grow" :placeholder="kind === 'stores' ? 'Buscar loja...' : 'Buscar oficina...'" aria-label="Buscar" />
        <label class="rl-muted"><input v-model="openOnly" type="checkbox" /> Só abertas agora</label></div>
      <div v-if="!items.length" class="rl-empty"><b>{{ kind === "stores" ? "Nenhuma loja por aqui" : "Nenhuma oficina por aqui" }}</b>Quando um jogador abrir uma, ela aparece nesta lista e no mapa.</div>
      <article v-for="b in items" :key="b.id" class="biz rl-card">
        <div class="biz-icon" :class="kind"><BngIcon :type="kind === 'stores' ? 'carDealer' : 'houseWrench'" /></div>
        <div class="biz-main">
          <div class="rl-row between"><h3>{{ b.name }}</h3><span class="rl-badge" :class="isOpen(b) ? 'ok' : 'bad'">{{ isOpen(b) ? "Aberta" : "Fechada" }}</span></div>
          <p class="rl-muted">de {{ b.ownerName || "?" }} · {{ b.opensAt }}h às {{ b.closesAt }}h · {{ distanceText(distance(rl.view.position, b.position)) }} · ★ {{ ((b.reputation || 0) / 20).toFixed(1) }}</p>
          <p v-if="kind === 'stores'" class="rl-muted">{{ b.stock || 0 }} carro(s) no estoque · {{ b.sales || 0 }} venda(s) · {{ b.capacity }} vagas</p>
          <p v-else class="rl-muted">{{ b.bays }} elevador(es), {{ b.busyBays || 0 }} ocupado(s) · {{ services(b) }} · {{ b.jobs || 0 }} serviço(s) feitos</p>
          <div v-if="kind === 'stores' && stockOf(b).length" class="stock">
            <span v-for="l in stockOf(b)" :key="l.id" class="stock-item">{{ l.title }} · <b>{{ money(l.price) }}</b></span>
          </div>
          <div class="rl-row">
            <button class="rl-btn" @click="request('gps', { position: b.position })">Marcar no GPS</button>
            <button v-if="b.owner !== me.id" class="rl-btn" @click="$emit('open', { app: 'mail', props: { to: b.owner } })">Mensagem</button>
            <button v-if="kind === 'stores' && (b.stock || 0) > 0" class="rl-btn" @click="$emit('go', 'classificados')">Ver estoque</button>
            <button v-if="kind === 'workshops' && b.owner !== me.id" class="rl-btn primary" :disabled="!isOpen(b)" @click="requestFor = b.id">Solicitar serviço</button>
          </div>
          <form v-if="requestFor === b.id" class="rl-box rl-form" @submit.prevent="send(b)">
            <b>Pedir orçamento à {{ b.name }}</b>
            <p class="rl-muted">Estacione o carro na oficina. O mecânico avalia o diagnóstico do seu carro e envia o orçamento.</p>
            <label>Veículo<XPSelect v-model="car" placeholder="Escolha o carro" :options="garage.map(v => ({ value: v.inventoryId, disabled: !v.spawned,
              label: v.niceName + (v.needsRepair ? ' · precisa de reparo (' + money(v.repairCost) + ')' : '') + (v.spawned ? '' : ' · na garagem') }))" /></label>
            <label>O que precisa ser feito?<textarea v-model="notes" class="rl-input" rows="2" maxlength="600" placeholder="Ex.: barulho na suspensão, pintura do para-choque..."></textarea></label>
            <div class="rl-row"><button class="rl-btn primary" :disabled="!car || rl.busy.serviceRequest">Enviar pedido</button><button type="button" class="rl-btn" @click="requestFor = ''">Cancelar</button></div>
          </form>
        </div>
      </article>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, money, status, distance, distanceText, me, myStore, myShop, myOrders, ask } from "../rl.js"

const props = defineProps({ kind: { type: String, default: "stores" } })
defineEmits(["open", "go"])
const search = ref(""), openOnly = ref(false), requestFor = ref(""), car = ref(""), notes = ref("")
const now = ref(Date.now() / 1000)
let ticker
onMounted(() => { ticker = setInterval(() => { now.value = Date.now() / 1000 }, 1000) })
onUnmounted(() => clearInterval(ticker))

const garage = computed(() => rl.view.garage || [])
const items = computed(() => {
  const q = search.value.toLowerCase()
  let list = (props.kind === "stores" ? rl.view.stores : rl.view.workshops) || []
  if (q) list = list.filter(b => (b.name + " " + (b.ownerName || "")).toLowerCase().includes(q))
  if (openOnly.value) list = list.filter(isOpen)
  return [...list].sort((a, b) => distance(rl.view.position, a.position) - distance(rl.view.position, b.position))
})
function isOpen(b) {
  if (!b.open) return false
  const h = rl.view.hour ?? 12
  if (b.opensAt === b.closesAt) return true
  return b.opensAt < b.closesAt ? h >= b.opensAt && h < b.closesAt : h >= b.opensAt || h < b.closesAt
}
function services(b) {
  const names = { repair: "reparos", maintenance: "revisão", paint: "pintura", tuning: "preparação" }
  return Object.entries(b.services || {}).filter(([, v]) => v).map(([k]) => names[k] || k).join(", ") || "serviços gerais"
}
function stockOf(b) { return (rl.view.listings || []).filter(l => l.storeId === b.id && l.status === "active").slice(0, 4) }
function badgeClass(s) { return s === "completed" ? "ok" : ["declined", "rejected", "expired"].includes(s) ? "bad" : "warn" }
function progress(o) {
  return Math.max(0, Math.min(100, ((now.value - o.startedAt) / Math.max(1, o.finishesAt - o.startedAt)) * 100))
}
function send(b) {
  request("serviceRequest", { workshopId: b.id, inventoryId: Number(car.value), notes: notes.value || undefined })
  requestFor.value = ""; notes.value = ""
}
</script>

<style scoped>
.dir { min-height: 100%; background: #f4f6f9; }
.dir-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; color: #fff; }
.dir-head.stores { background: linear-gradient(90deg, #8f1b1b, #d34a2a); } .dir-head.workshops { background: linear-gradient(90deg, #233447, #4c6582); }
.dir-head b { font: bold 24px "Trebuchet MS", Tahoma, sans-serif; } .dir-head small { display: block; font-size: 11.5px; opacity: .85; }
.grow { flex: 1; min-width: 200px; }
.between { justify-content: space-between; }
.biz { display: flex; gap: 14px; padding: 12px 14px; margin: 10px 0; }
.biz-icon { width: 54px; height: 54px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 30px; color: #fff; flex-shrink: 0; }
.biz-icon.stores { background: linear-gradient(135deg, #ff7a7a, #b51f1f); } .biz-icon.workshops { background: linear-gradient(135deg, #9aa7b8, #3c4b60); }
.biz-main { flex: 1; min-width: 0; } .biz-main h3 { margin: 0; font-size: 16px; color: #1b3355; } .biz-main p { margin: 3px 0; }
.stock { display: flex; flex-wrap: wrap; gap: 6px; margin: 6px 0; }
.stock-item { font-size: 11.5px; background: #fff3ef; border: 1px solid #f1c3b5; border-radius: 10px; padding: 2px 8px; }
.r { text-align: right; }
.star { border: 0; background: none; color: #f0b000; font-size: 18px; cursor: pointer; }
</style>
