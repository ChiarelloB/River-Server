<template>
  <div class="rl-page store">
    <template v-if="!store">
      <div class="intro">
        <div class="intro-icon"><BngIcon type="carDealer" /></div>
        <div>
          <h2 class="rl-h1">Abra sua loja de carros</h2>
          <p class="rl-muted">Fique de frente para o terreno onde os carros vão ficar expostos e abra a loja exatamente onde você está.
            Os carros do estoque ficam estacionados no pátio com a placa de preço; clientes NPC e jogadores chegam, olham e fazem proposta ali.
            Contrate vendedores para a loja vender até quando você não está.</p>
          <div class="rl-stats">
            <div><b>{{ money(costs.store) }}</b><small>Para abrir</small></div>
            <div><b>{{ money(costs.storeRent) }}</b><small>Despesas por dia</small></div>
            <div><b>4 → 12</b><small>Vagas no pátio</small></div>
            <div><b>1,5%</b><small>Taxa por venda</small></div>
          </div>
          <form class="rl-row" @submit.prevent="request('openStore', { name: name })">
            <input v-model.trim="name" class="rl-input grow" maxlength="64" required placeholder="Nome da loja (ex.: River Motors)" />
            <button class="rl-btn primary" :disabled="rl.busy.openStore || (rl.view.money || 0) < costs.store">Abrir loja aqui</button>
          </form>
          <p v-if="(rl.view.money || 0) < costs.store" class="rl-error">Saldo insuficiente: faltam {{ money(costs.store - (rl.view.money || 0)) }}.</p>
        </div>
      </div>
    </template>

    <template v-else>
      <div class="rl-row between head">
        <div><h2 class="rl-h1">{{ store.name }}</h2>
          <p class="rl-muted">{{ isOpen ? "Aberta agora" : "Fechada" }} · {{ store.opensAt }}h às {{ store.closesAt }}h · a {{ distanceText(distance(rl.view.position, store.position)) }} daqui</p></div>
        <div class="rl-row">
          <button class="rl-btn" @click="request('gps', { position: store.position })">GPS da loja</button>
        </div>
      </div>
      <nav class="rl-tabs">
        <button v-for="t in TABS" :key="t.id" :class="{ on: tab === t.id }" @click="tab = t.id">{{ t.label }}<span v-if="t.badge?.()" class="tabbadge">{{ t.badge() }}</span></button>
      </nav>
      <p v-if="store.rentOverdue" class="rl-box rl-error">Despesas atrasadas: {{ money(store.rentOverdue) }}. A loja está fechada.
        <button class="rl-btn primary" :disabled="rl.busy.store" @click="ask('Pagar as despesas atrasadas e reabrir a loja?', () => request('store', { storeId: store.id, payRent: true, open: true }), 'Pagar e reabrir')">Pagar e reabrir</button></p>

      <!-- Overview -->
      <section v-if="tab === 'home'">
        <div class="rl-stats">
          <div><b>{{ lotCars.length }} / {{ Math.min(store.capacity, (store.lot || []).length) || store.capacity }}</b><small>Carros no pátio</small></div>
          <div><b>{{ store.sales || 0 }}</b><small>Vendas</small></div>
          <div><b>{{ store.purchases || 0 }}</b><small>Compras</small></div>
          <div><b>{{ money((store.revenue || 0) - (store.spent || 0)) }}</b><small>Resultado</small></div>
          <div><b>★ {{ ((store.reputation || 0) / 20).toFixed(1) }}</b><small>Reputação</small></div>
          <div><b>{{ staff.length }}</b><small>Funcionários</small></div>
        </div>
        <div v-if="!(store.lot || []).length" class="rl-box warnbox">
          <b>Marque as vagas do pátio.</b> Fique de frente para a área livre da loja e use <i>Pátio → Marcar vagas automaticamente</i>,
          ou ande até cada vaga e use <i>Marcar vaga onde estou</i>.
        </div>
        <h3 class="rl-h2">Movimento recente</h3>
        <ul class="feed">
          <li v-for="m in storeNews" :key="m.id"><small>{{ ago(m.createdAt) }}</small> <b>{{ m.subject }}</b> — {{ m.body }}</li>
          <li v-if="!storeNews.length" class="rl-muted">Nada por enquanto.</li>
        </ul>
      </section>

      <!-- Lot -->
      <section v-else-if="tab === 'lot'">
        <div class="rl-box">
          <div class="rl-row between">
            <div><b>Vagas do pátio: {{ (store.lot || []).length }}</b> <small class="rl-muted">(capacidade da loja: {{ store.capacity }})</small>
              <p class="rl-muted small">Vagas livres aparecem no chão quando você está na loja. Os carros ficam virados para onde você estiver olhando + 180°.</p></div>
            <div class="rl-row">
              <button class="rl-btn primary" :disabled="rl.busy.lotAuto" @click="request('lotAuto', { storeId: store.id })">Marcar vagas automaticamente</button>
              <button class="rl-btn" :disabled="rl.busy.lotMark || (store.lot || []).length >= 12" @click="request('lotMark', { storeId: store.id })">Marcar vaga onde estou</button>
              <button class="rl-btn danger" :disabled="lotCars.length > 0" @click="request('lotClear', { storeId: store.id })">Limpar vagas</button>
            </div>
          </div>
        </div>

        <h3 class="rl-h2">Colocar carro no pátio</h3>
        <form class="rl-box rl-form" @submit.prevent="stockIn">
          <p class="rl-muted small">Traga o carro até a loja. Ele sai da sua garagem e fica exposto na próxima vaga livre, com a placa de preço.</p>
          <div class="rl-two">
            <label>Carro
              <XPSelect v-model="draft.inventoryId" placeholder="Escolha um carro" :options="garageCars.map(g => ({ value: g.inventoryId, disabled: !g.spawned || g.locked,
                label: g.niceName + ' — ' + km(g.mileage) + (!g.spawned ? ' (na garagem)' : '') + (g.locked ? ' (anunciado)' : '') }))" />
            </label>
            <label>Preço na placa ($)<input v-model.number="draft.price" class="rl-input" type="number" min="1" required /></label>
          </div>
          <label>Título (opcional)<input v-model.trim="draft.title" class="rl-input" maxlength="100" :placeholder="chosen?.niceName" /></label>
          <div class="rl-row"><button class="rl-btn primary" :disabled="rl.busy.stockIn || !(store.lot || []).length">Colocar no pátio</button>
            <small v-if="chosen?.value" class="rl-muted">Valor de tabela: {{ money(chosen.value) }}</small></div>
        </form>

        <h3 class="rl-h2">No pátio</h3>
        <table v-if="lotCars.length" class="rl-table">
          <tr><th>Vaga</th><th>Carro</th><th>Placa</th><th>Situação</th><th>Visitas</th><th></th></tr>
          <tr v-for="l in lotCars" :key="l.id">
            <td>#{{ l.lotSpot }}</td>
            <td><b>{{ l.title }}</b><br /><small class="rl-muted">{{ km(l.mileage) }}<template v-if="l.value"> · tabela {{ money(l.value * 100) }}</template></small></td>
            <td>
              <form class="rl-row tight" @submit.prevent="setPrice(l)">
                <input v-model.number="prices[l.id]" class="rl-input price" type="number" min="1" :placeholder="Math.round(l.price / 100)" />
                <button class="rl-btn" :disabled="l.reserved">OK</button>
              </form>
              <small>{{ money(l.price) }}</small>
            </td>
            <td>{{ l.reserved ? "Cliente negociando" : "Exposto" }}</td>
            <td>{{ l.views || 0 }}</td>
            <td><button class="rl-btn" :disabled="l.reserved" @click="request('stockOut', { listingId: l.id })">Retirar</button></td>
          </tr>
        </table>
        <p v-else class="rl-muted">Pátio vazio.</p>
        <template v-if="oldStock.length">
          <h3 class="rl-h2">Anúncios antigos da loja</h3>
          <div v-for="l in oldStock" :key="l.id" class="rl-row between rl-box"><span>{{ l.title }} · {{ money(l.price) }}</span>
            <button class="rl-btn" :disabled="l.reserved" @click="request('cancel', { listingId: l.id })">Retirar</button></div>
        </template>
      </section>

      <!-- Staff -->
      <section v-else-if="tab === 'staff'">
        <h3 class="rl-h2">Equipe</h3>
        <table v-if="staff.length" class="rl-table">
          <tr><th>Nome</th><th>Função</th><th>Habilidade</th><th>Salário/dia</th><th>Comissão</th><th>Negócios</th><th>Ganhou</th><th></th></tr>
          <tr v-for="m in staff" :key="m.id">
            <td><b>{{ m.name }}</b><br /><small class="rl-muted">{{ m.kind === "player" ? "Jogador(a)" : "NPC" }}</small></td>
            <td>{{ m.label || ROLES[m.role] }}</td>
            <td class="stars">{{ m.kind === "npc" ? skillStars(m.skill) : "—" }}</td>
            <td>{{ money(m.wage) }}</td><td>{{ m.commission }}%</td><td>{{ m.sales || 0 }}</td><td>{{ money(m.earned) }}</td>
            <td><button class="rl-btn danger" @click="fire(m)">Demitir</button></td>
          </tr>
        </table>
        <p v-else class="rl-muted">Ninguém contratado. Um vendedor responde propostas e vende o pátio mesmo com você longe ou offline;
          um comprador avalia e compra carros de clientes e repõe o pátio.</p>

        <h3 class="rl-h2">Política de vendas e compras</h3>
        <form class="rl-box rl-form" @submit.prevent="savePolicy">
          <label class="check"><input v-model="policy.autoSell" type="checkbox" /> Vendedores respondem propostas e fecham negócio sozinhos</label>
          <label>Desconto máximo que o vendedor pode dar: <b>{{ 100 - policy.minPct }}%</b>
            <input v-model.number="policy.minPct" type="range" min="70" max="100" step="1" /></label>
          <label class="check"><input v-model="policy.autoBuy" type="checkbox" /> Comprador compra carros de clientes e repõe o pátio</label>
          <div class="rl-two">
            <label>Comprador paga até <b>{{ policy.buyPct }}%</b> da tabela<input v-model.number="policy.buyPct" type="range" min="40" max="90" step="1" /></label>
            <label>Margem na placa dos carros comprados: <b>{{ policy.markupPct }}%</b><input v-model.number="policy.markupPct" type="range" min="0" max="80" step="1" /></label>
          </div>
          <button class="rl-btn primary">Salvar política</button>
        </form>

        <h3 class="rl-h2">Candidatos de hoje</h3>
        <p class="rl-muted small">A lista muda todo dia. O primeiro dia de salário é pago na contratação; depois, junto com as despesas diárias.</p>
        <div class="cands">
          <article v-for="c in candidates" :key="c.id" class="rl-box cand">
            <b>{{ c.name }}</b><small class="rl-muted">{{ c.label }}</small>
            <span class="stars">{{ skillStars(c.skill) }}</span>
            <small>{{ money(c.wage) }}/dia · {{ c.commission }}% de comissão</small>
            <button class="rl-btn primary" :disabled="rl.busy.hire || hired(c)" @click="request('hire', { businessId: store.id, candidateId: c.id })">{{ hired(c) ? "Contratado" : "Contratar" }}</button>
          </article>
        </div>

        <h3 class="rl-h2">Vagas para jogadores</h3>
        <form class="rl-box rl-form" @submit.prevent="postVacancy">
          <p class="rl-muted small">Outro jogador que aceitar a vaga passa a responder propostas da loja e ganha a comissão de cada venda que fechar.</p>
          <div class="rl-two">
            <label>Função<XPSelect v-model="vacancy.role" :options="[{ value: 'vendedor', label: 'Vendedor(a)' }]" /></label>
            <label>Comissão (%)<input v-model.number="vacancy.commission" class="rl-input" type="number" min="0" max="50" /></label>
          </div>
          <div class="rl-two">
            <label>Salário por dia ($)<input v-model.number="vacancy.wage" class="rl-input" type="number" min="0" /></label>
            <label>Recado<input v-model.trim="vacancy.note" class="rl-input" maxlength="280" placeholder="Ex.: preciso de alguém à noite" /></label>
          </div>
          <button class="rl-btn primary">Publicar vaga</button>
        </form>
        <div v-for="v in myVacancies" :key="v.id" class="rl-row between rl-box"><span>{{ v.label }} · {{ v.commission }}% · {{ money(v.wage) }}/dia</span>
          <button class="rl-btn" @click="request('closeVacancy', { vacancyId: v.id })">Encerrar vaga</button></div>
      </section>

      <!-- NPC customers -->
      <section v-else-if="tab === 'clients'">
        <div v-if="!npcs.length" class="rl-muted">Nenhum cliente agora. Com a loja aberta e você por perto, clientes chegam a cada poucos minutos
          (com um vendedor contratado, a loja também vende quando você não está).</div>
        <article v-for="n in npcs" :key="n.id" class="rl-box npc" :class="{ focus: n.id === focus }">
          <div class="rl-row between">
            <b>{{ n.name }} <small class="rl-muted">· {{ n.personality }}</small></b>
            <span class="rl-badge" :class="n.status === 'negotiating' ? 'warn' : ''">{{ n.kind === "seller" ? "Quer vender" : "Quer comprar" }} · {{ status(n.status) }}</span>
          </div>
          <template v-if="n.kind === 'buyer'">
            <p class="rl-muted">Interessado em: <b>{{ listingTitle(n.listingId) }}</b>. Negocie pela Agenda quando ele chegar.</p>
            <div class="rl-row"><button class="rl-btn primary" :disabled="n.status !== 'negotiating'" @click="$emit('open', 'agenda')">Abrir negociação</button>
              <button class="rl-btn" @click="request('dismissNpc', { npcId: n.id })">Dispensar</button></div>
          </template>
          <template v-else>
            <p>Está oferecendo um <b>{{ n.vehicle?.niceName || n.vehicle?.model }}</b>{{ n.vehicle?.year ? " " + n.vehicle.year : "" }} ·
              {{ km(n.vehicle?.mileage) }} · estado {{ n.vehicle?.condition || "?" }}% · tabela {{ money(n.vehicle?.value) }}</p>
            <p>Pede <b class="ask">{{ money(n.asking) }}</b>{{ n.status === "travelling" ? " — a caminho, vistorie o carro quando chegar." : "" }}</p>
            <form v-if="n.status === 'negotiating'" class="rl-form" @submit.prevent="offer(n)">
              <div class="rl-row">
                <input v-model.number="offers[n.id]" class="rl-input" type="number" min="1" placeholder="Sua oferta ($)" required />
                <button class="rl-btn primary" :disabled="rl.busy.tradeOffer">Fazer oferta</button>
                <button type="button" class="rl-btn go" :disabled="rl.busy.tradeOffer || (rl.view.money || 0) < n.asking" @click="accept(n)">Pagar {{ money(n.asking) }}</button>
                <button type="button" class="rl-btn" @click="request('dismissNpc', { npcId: n.id })">Recusar</button>
              </div>
              <label class="check"><input v-model="toLot[n.id]" type="checkbox" :disabled="!freeSpots" /> Mandar direto para o pátio ({{ freeSpots }} vaga(s) livre(s))</label>
            </form>
            <p v-if="n.status === 'sold'" class="rl-badge ok">Comprado!</p>
          </template>
        </article>
      </section>

      <!-- Settings -->
      <section v-else>
        <form class="rl-box rl-form" @submit.prevent="saveSettings">
          <div class="rl-two">
            <label>Nome<input v-model.trim="settings.name" class="rl-input" maxlength="64" required /></label>
            <label>Orçamento para comprar carros de clientes ($)<input v-model.number="settings.tradeBudget" class="rl-input" type="number" min="0" /></label>
          </div>
          <div class="rl-two">
            <label>Abre às<input v-model.number="settings.opensAt" class="rl-input" type="number" min="0" max="23" /></label>
            <label>Fecha às<input v-model.number="settings.closesAt" class="rl-input" type="number" min="0" max="23" /></label>
          </div>
          <label class="check"><input v-model="settings.npcEnabled" type="checkbox" /> Receber compradores NPC</label>
          <label class="check"><input v-model="settings.npcSellersEnabled" type="checkbox" /> Receber NPCs querendo vender o carro (troca/compra)</label>
          <div class="rl-row">
            <button class="rl-btn primary">Salvar</button>
            <button type="button" class="rl-btn" @click="request('store', { storeId: store.id, open: !store.open })">{{ store.open ? "Fechar as portas" : "Abrir as portas" }}</button>
            <button type="button" class="rl-btn" :disabled="store.capacity >= 12 || rl.busy.store"
              @click="ask('Ampliar o pátio em 2 vagas por ' + money(store.capacity * 500000) + '?', () => request('store', { storeId: store.id, upgrade: true }), 'Ampliar')">+2 vagas · {{ money(store.capacity * 500000) }}</button>
            <button type="button" class="rl-btn danger" @click="confirmClose">Vender o ponto</button>
          </div>
          <p class="rl-muted">Despesas diárias de {{ money(store.rent) }} + salários são cobradas automaticamente. Ao vender o ponto, você recebe 50% do valor de abertura.</p>
        </form>
      </section>
    </template>
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, money, km, ago, status, distance, distanceText, myStore, myNpcs, listingTitle, toast, ROLES, skillStars, me, ask } from "../rl.js"

const props = defineProps({ focus: String, nonce: Number, start: String })
defineEmits(["open"])
const TABS = [
  { id: "home", label: "Visão geral" },
  { id: "lot", label: "Pátio" },
  { id: "staff", label: "Equipe" },
  { id: "clients", label: "Clientes", badge: () => npcs.value.filter(n => n.status === "negotiating").length || "" },
  { id: "settings", label: "Configurações" },
]
const tab = ref(props.start || "home")
const name = ref("")
const offers = reactive({})
const toLot = reactive({})
const prices = reactive({})
const settings = reactive({})
const policy = reactive({ autoSell: true, minPct: 90, autoBuy: true, buyPct: 65, markupPct: 25 })
const draft = reactive({ inventoryId: "", price: null, title: "" })
const vacancy = reactive({ role: "vendedor", commission: 5, wage: 0, note: "" })
const closing = ref(false)

const store = computed(() => myStore.value)
const costs = computed(() => rl.view.costs || { store: 2500000, storeRent: 25000 })
const lotCars = computed(() => (rl.view.listings || []).filter(l => store.value && l.storeId === store.value.id && l.status === "active" && l.lot)
  .sort((a, b) => (a.lotSpot || 0) - (b.lotSpot || 0)))
const oldStock = computed(() => (rl.view.listings || []).filter(l => store.value && l.storeId === store.value.id && l.status === "active" && !l.lot))
const npcs = computed(() => myNpcs.value.filter(n => store.value && n.storeId === store.value.id && !["leaving"].includes(n.status)))
const staff = computed(() => Object.values(store.value?.staff || {}))
const candidates = computed(() => store.value?.candidates || [])
const myVacancies = computed(() => (rl.view.vacancies || []).filter(v => v.businessId === store.value?.id))
const garageCars = computed(() => (rl.view.garage || []).filter(g => !g.locked || g.inventoryId === draft.inventoryId))
const chosen = computed(() => (rl.view.garage || []).find(g => g.inventoryId === draft.inventoryId))
const freeSpots = computed(() => Math.max(0, Math.min(store.value?.capacity || 0, (store.value?.lot || []).length) - lotCars.value.length))
const storeNews = computed(() => (rl.view.messages || []).filter(m => m.to === me.value.id).slice(0, 8))
const isOpen = computed(() => {
  const s = store.value
  if (!s || !s.open) return false
  const h = rl.view.hour ?? 12
  return s.opensAt === s.closesAt || (s.opensAt < s.closesAt ? h >= s.opensAt && h < s.closesAt : h >= s.opensAt || h < s.closesAt)
})
// The form follows the server only when the saved settings change (not on every update),
// so nothing is overwritten while the player is still typing.
watch(() => store.value && JSON.stringify([store.value.id, store.value.name, store.value.opensAt, store.value.closesAt,
  store.value.npcEnabled, store.value.npcSellersEnabled, store.value.tradeBudget, store.value.policy]), () => {
  const s = store.value
  if (!s) return
  Object.assign(settings, { name: s.name, opensAt: s.opensAt, closesAt: s.closesAt, npcEnabled: s.npcEnabled,
    npcSellersEnabled: s.npcSellersEnabled, tradeBudget: Math.round((s.tradeBudget || 0) / 100) })
  if (s.policy) Object.assign(policy, s.policy)
}, { immediate: true })
watch(chosen, g => { if (g && !draft.price && g.value) draft.price = Math.round(g.value * 1.15 / 100) })
watch(() => [props.start, props.nonce], () => { if (props.start) tab.value = props.start })

function hired(c) { return staff.value.some(m => m.candidateId === c.id) }
function stockIn() {
  request("stockIn", { storeId: store.value.id, inventoryId: Number(draft.inventoryId), price: Math.round((draft.price || 0) * 100),
    title: draft.title || undefined })
  draft.inventoryId = ""; draft.price = null; draft.title = ""
}
function setPrice(l) {
  const v = prices[l.id]
  if (!v) return
  request("price", { listingId: l.id, price: Math.round(v * 100) })
  prices[l.id] = null
}
function savePolicy() {
  request("policy", { businessId: store.value.id, autoSell: policy.autoSell, minPct: policy.minPct, autoBuy: policy.autoBuy,
    buyPct: policy.buyPct, markupPct: policy.markupPct })
}
function postVacancy() {
  request("postVacancy", { businessId: store.value.id, role: vacancy.role, commission: vacancy.commission,
    wage: Math.round((vacancy.wage || 0) * 100), note: vacancy.note || undefined })
}
function fire(m) { ask("Demitir " + m.name + "? Quem é demitido não volta para a lista de candidatos hoje.", () => request("fire", { businessId: store.value.id, staffId: m.id }), "Demitir") }
function saveSettings() {
  request("store", { storeId: store.value.id, name: settings.name, opensAt: settings.opensAt, closesAt: settings.closesAt,
    npcEnabled: settings.npcEnabled, npcSellersEnabled: settings.npcSellersEnabled, tradeBudget: Math.round((settings.tradeBudget || 0) * 100) })
}
function offer(n) { request("tradeOffer", { npcId: n.id, price: Math.round((offers[n.id] || 0) * 100), toLot: !!toLot[n.id] }) }
function accept(n) { request("tradeOffer", { npcId: n.id, price: n.asking, toLot: !!toLot[n.id] }) }
function confirmClose() {
  if (!closing.value) { closing.value = true; toast("Clique de novo em \"Vender o ponto\" para confirmar.", "warning"); setTimeout(() => { closing.value = false }, 5000); return }
  closing.value = false
  request("closeStore", { storeId: store.value.id })
}
</script>

<style scoped>
.between { justify-content: space-between; }
.grow { flex: 1; min-width: 220px; }
.intro { display: flex; gap: 18px; padding: 10px 4px; }
.intro-icon { width: 84px; height: 84px; border-radius: 16px; background: linear-gradient(135deg, #ff7a7a, #b51f1f); color: #fff; font-size: 48px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.head { align-items: flex-start; }
.npc.focus { border-color: #f0a500; box-shadow: 0 0 0 2px #ffd36b inset; }
.ask { color: #b5420e; }
.check { display: flex !important; flex-direction: row; align-items: center; gap: 6px; }
.small { font-size: 11.5px; }
.warnbox { background: #fff7d6; border-color: #e8c35a; }
.feed { margin: 0; padding-left: 16px; display: flex; flex-direction: column; gap: 4px; }
.price { width: 110px; }
.tight { gap: 4px; flex-wrap: nowrap; }
.stars { color: #d79a00; letter-spacing: 1px; white-space: nowrap; }
.cands { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 8px; }
.cand { display: flex; flex-direction: column; gap: 4px; }
.tabbadge { margin-left: 5px; background: #e8322c; color: #fff; border-radius: 8px; padding: 0 5px; font-size: 11px; }
</style>
