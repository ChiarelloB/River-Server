<template>
  <div class="ie">
    <div class="ie-menu"><span>Arquivo</span><span>Editar</span><span>Exibir</span><span>Favoritos</span><span>Ferramentas</span><span>Ajuda</span></div>
    <div class="ie-tools">
      <button :disabled="pos <= 0" @click="go(-1)"><BngIcon type="arrowLargeLeft" /> Voltar</button>
      <button :disabled="pos >= history.length - 1" @click="go(1)"><BngIcon type="arrowLargeRight" /></button>
      <button @click="refresh"><BngIcon type="sync" /></button>
      <button @click="navigate('home')"><BngIcon type="house" /> Início</button>
      <span class="ie-sep"></span>
      <button v-for="f in favorites" :key="f.site" @click="navigate(f.site)"><BngIcon :type="f.icon" /> {{ f.title }}</button>
    </div>
    <div class="ie-address">
      <span>Endereço</span>
      <div class="ie-url"><BngIcon type="globe" /><input class="rl-input" :value="url" @keydown.enter="typed($event.target.value)" aria-label="Endereço" /></div>
      <button @click="typed(url)">Ir</button>
    </div>
    <div class="ie-page">
      <SiteHome v-if="site === 'home'" @go="navigate" @open="e => $emit('open', e)" />
      <AppMarket v-else-if="site === 'classificados'" :focus="focus" @open="e => $emit('open', e)" />
      <SiteDirectory v-else-if="site === 'lojas'" kind="stores" @open="e => $emit('open', e)" @go="navigate" />
      <SiteDirectory v-else-if="site === 'oficinas'" kind="workshops" @open="e => $emit('open', e)" @go="navigate" />
      <AppPlayers v-else-if="site === 'jogadores'" @open="e => $emit('open', e)" />
      <SiteNews v-else-if="site === 'noticias'" @go="navigate" @open="e => $emit('open', e)" />
      <AppJobs v-else-if="site === 'empregos'" @open="e => $emit('open', e)" />
      <div v-else class="ie-404"><h2>Não é possível exibir a página</h2><p>O endereço <b>{{ url }}</b> não existe na RiverNet. Tente <a href="#" @click.prevent="navigate('home')">a página inicial</a>.</p></div>
    </div>
    <div class="ie-status"><span><BngIcon type="checkmark" /> Concluído</span><span>{{ rl.view.connected ? "Internet" : "Trabalhando offline" }}</span></div>
  </div>
</template>

<script setup>
import { computed, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request } from "../rl.js"
import SiteHome from "./SiteHome.vue"
import SiteDirectory from "./SiteDirectory.vue"
import AppMarket from "./AppMarket.vue"
import AppPlayers from "./AppPlayers.vue"
import SiteNews from "./SiteNews.vue"
import AppJobs from "./AppJobs.vue"

const props = defineProps({ start: { type: String, default: "home" }, focus: String, nonce: Number })
const emit = defineEmits(["open", "title"])
const SITES = { home: "portal.river", classificados: "classificados.river", lojas: "lojas.river", oficinas: "oficinas.river", jogadores: "jogadores.river",
  noticias: "noticias.river", empregos: "empregos.river" }
const favorites = [
  { site: "classificados", title: "Classificados", icon: "carStarred" },
  { site: "lojas", title: "Lojas", icon: "carDealer" },
  { site: "oficinas", title: "Oficinas", icon: "houseWrench" },
  { site: "jogadores", title: "Jogadores", icon: "peopleOutline" },
  { site: "noticias", title: "Notícias", icon: "documentOutline" },
  { site: "empregos", title: "Empregos", icon: "badge" },
]
const history = ref([props.start])
const pos = ref(0)
const site = computed(() => history.value[pos.value])
const url = computed(() => "http://www." + (SITES[site.value] || site.value) + "/")

function navigate(s) {
  history.value = history.value.slice(0, pos.value + 1)
  history.value.push(s)
  pos.value = history.value.length - 1
}
function go(d) { pos.value = Math.max(0, Math.min(history.value.length - 1, pos.value + d)) }
function refresh() { request("refresh") }
function typed(text) {
  const t = String(text || "").toLowerCase()
  const found = Object.entries(SITES).find(([k, v]) => t.includes(k) || t.includes(v.split(".")[0]))
  navigate(found ? found[0] : t.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0] || "home")
}
watch(site, s => emit("title", SITES[s] || s), { immediate: true })
watch(() => [props.start, props.nonce], ([s]) => { if (s && s !== site.value) navigate(s) })
</script>

<style scoped>
.ie { display: flex; flex-direction: column; height: 100%; background: #ece9d8; }
.ie-menu { display: flex; gap: 14px; padding: 3px 8px; font-size: 12px; border-bottom: 1px solid #d0cdbd; }
.ie-tools { display: flex; align-items: center; gap: 3px; padding: 3px 6px; border-bottom: 1px solid #d0cdbd; flex-wrap: wrap; }
.ie-tools button, .ie-address > button { display: flex; align-items: center; gap: 4px; border: 1px solid transparent; background: none; padding: 3px 7px; cursor: pointer; font: 12px Tahoma, sans-serif; border-radius: 3px; color: #111; }
.ie-tools button:hover:not(:disabled), .ie-address > button:hover { border-color: #aac0e0; background: #f4f8fd; }
.ie-tools button:disabled { opacity: .4; }
.ie-sep { width: 1px; height: 22px; background: #c5c2b2; margin: 0 4px; }
.ie-address { display: flex; align-items: center; gap: 6px; padding: 3px 8px; border-bottom: 1px solid #d0cdbd; font-size: 12px; color: #555; }
.ie-url { flex: 1; display: flex; align-items: center; gap: 4px; background: #fff; border: 1px solid #7f9db9; padding: 0 4px; }
.ie-url input { flex: 1; border: 0 !important; outline: 0 !important; padding: 4px 2px !important; }
.ie-page { flex: 1; min-height: 0; overflow: auto; background: #fff; }
.ie-status { display: flex; justify-content: space-between; padding: 3px 8px; font-size: 11px; color: #444; border-top: 1px solid #d0cdbd; }
.ie-404 { padding: 30px 40px; } .ie-404 h2 { font: normal 20px Tahoma, sans-serif; color: #1c3f74; }
</style>
