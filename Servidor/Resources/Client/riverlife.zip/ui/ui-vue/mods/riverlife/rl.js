// RiverLife UI store. Original code.
// One reactive view model shared by the RiverOS computer and the phone app.
import { reactive, computed } from "vue"
import { lua, useBridge } from "@/bridge"

const LIST_KEYS = ["listings", "stores", "workshops", "visits", "offers", "receipts", "npcs", "orders", "messages", "accounts", "garage", "players",
  "gigs", "vacancies", "jobs", "feed"]

export const rl = reactive({
  view: { careerActive: false },
  photos: {},
  notices: [],
  busy: {},
  lastAction: null,
  capturing: false,
  confirm: null,
  uploads: {},
})

const chunks = {}
const requestedPhotos = new Set()
const listeners = new Set()
// The mod runtime re-evaluates modules on reload (e.g. when the server copy of the
// mod mounts); listeners live on window so a reload replaces them instead of
// stacking a second set (which uploaded every photo twice).
const WIRE_KEY = "__riverLifeWire"

export function onAction(fn) { listeners.add(fn); return () => listeners.delete(fn) }

function uuid() {
  if (window.crypto?.randomUUID) return window.crypto.randomUUID()
  return "id-" + Date.now() + "-" + Math.random().toString(16).slice(2)
}

// Mod extensions are not in the UI's static Lua signatures: call them through
// engineLua with the JSON inside a Lua long string (no escaping needed).
export function luaString(text) {
  let eq = ""
  // A trailing "]" would merge with the closing bracket (JSON arrays end with one).
  while (text.includes("]" + eq + "]") || text.endsWith("]" + eq)) eq += "="
  return "[" + eq + "[" + text + "]" + eq + "]"
}
export function engineLua(code) {
  const { api } = useBridge()
  api.engineLua(code)
}
// Call any game Lua expression and get its return value (RLS APIs for the PC apps).
// A Lua error means no answer at all, so give up after timeoutMs and resolve undefined.
export function luaCall(expr, timeoutMs = 15000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(undefined), timeoutMs)
    const done = v => { clearTimeout(timer); resolve(v) }
    try { useBridge().api.engineLua(expr, done) } catch (err) { done(undefined) }
  })
}
export function luaRun(code) { return luaCall("(function() " + code + " end)()") }
// Run a Lua statement and learn whether it really ran (true) or failed / timed out (false).
export async function luaDo(stmt, timeoutMs) { return (await luaCall("(function() " + stmt + " return true end)()", timeoutMs)) === true }
// A JS value as a Lua expression: scalars inline, tables decoded from JSON inside a long string.
export function luaValue(v) {
  if (v === null || v === undefined) return "nil"
  if (typeof v === "boolean") return v ? "true" : "false"
  if (typeof v === "number") return isFinite(v) ? String(v) : "nil"
  if (typeof v === "string") return luaString(v)
  return "jsonDecode(" + luaString(JSON.stringify(v)) + ")"
}
// Listen to a guihooks event while a component is mounted.
export function onGameEvent(name, fn) {
  const { events } = useBridge()
  events.on(name, fn)
  return () => events.off(name, fn)
}
// Background operations: no busy state and no error balloon.
const QUIET_OPS = ["refresh", "gps", "gpsPlayer", "gpsTo", "photoGet", "photoData", "close", "native", "spawn", "capture", "walkTo", "desk", "displayPhoto",
  "desktopPrefs", "wallpapers", "partPhotos"]
const SILENT_ERRORS = ["displayPhoto", "desk"]
// A button stays busy until the answer to ITS request arrives (or 45 s pass), so a click
// can never be sent twice while the first one is still on its way.
const inflight = {}
function settle(op) {
  if (!op || Object.values(inflight).includes(op)) return
  delete rl.busy[op]
  rl.busy = { ...rl.busy }
}
export function request(op, payload = {}) {
  const id = uuid()
  if (!QUIET_OPS.includes(op)) {
    rl.busy[op] = true
    inflight[id] = op
    setTimeout(() => {
      if (!inflight[id]) return
      delete inflight[id]
      settle(op)
      toast("O jogo demorou a responder. Confira e tente de novo.", "warning")
    }, 45000)
  }
  engineLua("if riverLife then riverLife.uiRequest(" + luaString(JSON.stringify({ id, op, payload })) + ") end")
  return id
}

// Paid or destructive actions ask first (shown by the desktop and the phone).
export function ask(text, yes, label = "Confirmar") { rl.confirm = { text, yes, label } }
export function answer(ok) {
  const c = rl.confirm
  rl.confirm = null
  if (ok && c) c.yes()
}

export function toast(text, kind = "info") {
  const n = { id: uuid(), text, kind }
  rl.notices.push(n)
  setTimeout(() => {
    const i = rl.notices.findIndex(x => x.id === n.id)
    if (i >= 0) rl.notices.splice(i, 1)
  }, 7000)
}

export const STATUS = {
  active: "Publicado", sold: "Vendido", cancelled: "Cancelado", expired: "Expirado", scheduled: "Agendada", arrived: "No local",
  completed: "Concluído", travelling: "A caminho", negotiating: "Negociando", purchased: "Comprou", leaving: "Foi embora",
  declined: "Recusado", rejected: "Recusado", requested: "Aguardando orçamento", quoted: "Orçamento enviado", accepted: "Aprovado",
  in_progress: "No elevador", waiting: "Aguardando serviço", served: "Atendido", pending: "Pendente", superseded: "Substituída",
}
export const ERRORS = {
  not_owner: "Este veículo não é seu.", photos_required: "Adicione pelo menos duas fotos.", invalid_photo: "Aguarde o envio das fotos.",
  spawn_vehicle_first: "Traga o veículo da garagem antes.", visit_required: "Comprador, vendedor e carro precisam estar no local.",
  seller_absent: "O vendedor ainda não chegou ao local.", vehicle_absent: "O carro precisa estar no local.",
  already_reserved: "Este carro já está reservado para outra visita.", insufficient_funds: "Saldo insuficiente na carreira.",
  listing_locked: "O anúncio está reservado para uma visita.", outside_store: "Vá até a sua loja para isso.",
  store_full: "Todas as vagas da loja estão ocupadas.", store_already_owned: "Você já tem uma loja.", wrong_map: "Entre no mesmo mapa do anúncio.",
  server_timeout: "O servidor demorou a responder. Atualize para conferir.", identity_required: "Não foi possível identificar sua carreira no servidor.",
  wallet_revision: "O saldo será reconciliado ao reconectar.", offer_unavailable: "Essa proposta expirou ou já foi respondida.",
  listed_elsewhere: "Retire o carro do outro serviço de venda antes.", rent_overdue: "Pague as despesas pendentes para reabrir.",
  too_early: "Aguarde o horário marcado.", vehicle_data_too_large: "O estado deste veículo excede o limite de transferência.",
  invalid_time: "Escolha um horário nas próximas 2 horas.", store_too_close: "Já existe uma loja muito perto daqui.",
  shop_too_close: "Já existe uma oficina muito perto daqui.",
  garage_full: "Sua garagem está cheia. Venda ou guarde um carro, ou compre outra garagem, antes de comprar.", too_close_to_store: "Muito perto de uma loja de carros.",
  too_close_to_workshop: "Muito perto de uma oficina.", shop_already_owned: "Você já tem uma oficina.", shop_closed: "A oficina está fechada agora.",
  outside_shop: "Leve o carro até a oficina.", order_exists: "Já existe um pedido aberto para este carro.", bays_full: "Todos os elevadores estão ocupados.",
  order_not_accepted: "O cliente ainda não aprovou o orçamento.", service_running: "O serviço ainda está em andamento.",
  store_has_stock: "Retire os carros do estoque antes de fechar.", shop_has_jobs: "Termine os serviços em andamento antes de fechar.",
  multiplayer_unavailable: "Sem conexão com o servidor.", server_unreachable: "Conectando ao servidor...", not_ready: "Carregando seus dados...",
  invalid_price: "Valor fora do permitido.", npc_slot_expired: "O cliente desistiu da visita.", over_trade_budget: "Acima do orçamento de compras da loja.",
  own_listing: "Esse anúncio é seu.", own_shop: "Essa oficina é sua.", recipient_missing: "Jogador não encontrado.", career_import_disabled: "Este servidor não aceita carreiras importadas.",
  invalid_quote: "Revise os itens do orçamento.", invalid_vehicle: "Veículo inválido.", already_rated: "Você já avaliou este serviço.",
  storage_unavailable: "O servidor não conseguiu salvar. Tente de novo.", npc_not_arrived: "O cliente ainda não estacionou.",
  lot_not_set: "Marque as vagas do pátio antes (aba Pátio).", spot_taken: "Essa vaga já tem carro.", invalid_spots: "Vagas inválidas: fique dentro do terreno da loja.",
  lot_in_use: "Há carros nessas vagas. Retire-os antes.", no_room: "Não achei espaço livre aqui. Vire-se para uma área aberta e tente de novo.",
  staff_full: "Equipe completa para essa função.", candidate_missing: "Esse candidato não está mais disponível.", already_hired: "Já contratado.",
  business_missing: "Negócio não encontrado.", vacancy_exists: "Já existe uma vaga aberta para essa função.", vacancy_closed: "Essa vaga já foi preenchida.",
  own_business: "Esse negócio é seu.", staff_missing: "Funcionário não encontrado.", gig_unavailable: "Esse bico já foi pego por outra pessoa.",
  gig_in_progress: "Termine (ou desista) do bico atual primeiro.", own_gig: "Você não pode pegar o próprio bico.", gig_missing: "Bico não encontrado.",
  not_at_destination: "Estacione o carro no destino marcado.", already_inspected: "Esse anúncio já tem vistoria.", gig_exists: "Já existe um pedido de vistoria.",
  too_far: "Chegue mais perto do carro.", invalid_policy: "Valor fora do permitido.", invalid_role: "Função inválida.", listing_unavailable: "Anúncio indisponível.",
  visit_missing: "Negociação não encontrada.", not_counterparty: "Aguarde a resposta da outra parte.",
  account_missing: "Conta não encontrada. Reabra o RiverLife.", already_listed: "Este carro já está anunciado.",
  already_sold: "Este carro já foi vendido.", hello_required: "Reconectando ao servidor... tente de novo em instantes.",
  invalid_balance: "Saldo inválido. Reabra a carreira.", invalid_config: "Configuração do carro inválida.",
  invalid_damage: "Dados de dano inválidos.", invalid_description: "Descrição longa demais (até 1600 caracteres).",
  invalid_diagnosis: "Diagnóstico inválido. Leve o carro à oficina de novo.", invalid_hours: "Horário de funcionamento inválido.",
  invalid_map: "Mapa inválido.", invalid_model: "Modelo de carro inválido.", invalid_name: "Nome inválido.",
  invalid_npc: "Cliente inválido.", invalid_rating: "Avaliação inválida (1 a 5 estrelas).", invalid_request: "Pedido inválido.",
  invalid_text: "Texto inválido ou longo demais.", invalid_title: "Título inválido (até 100 caracteres).",
  listing_missing: "Anúncio não encontrado.", location_unavailable: "Não foi possível medir sua posição. Tente de novo.",
  not_negotiable: "Este anúncio tem preço fechado: pague o valor pedido.", npc_busy: "O cliente está ocupado agora.",
  npc_missing: "O cliente já foi embora.", order_closed: "Este serviço já foi encerrado.", order_missing: "Serviço não encontrado.",
  order_not_started: "O serviço ainda não começou.",
  overpriced: "Preço muito acima do valor do carro: os clientes não se interessam.",
  ownership_changed: "O carro mudou de dono.", photos_full: "O anúncio já tem fotos suficientes.",
  receipt_missing: "Recibo não encontrado.", request_id_reused: "Pedido repetido. Atualize a tela.",
  server_only: "Só o servidor pode fazer isso.", shop_max_bays: "A oficina já tem o máximo de elevadores.",
  shop_missing: "Oficina não encontrada.", shop_unavailable: "A oficina não está atendendo agora.",
  store_closed: "A loja está fechada neste horário.", store_max_capacity: "O pátio já está no tamanho máximo.",
  store_missing: "Loja não encontrada.", store_unavailable: "A loja não está atendendo agora.",
  too_many_offers: "Muitas propostas nesta negociação. Combine o preço com o vendedor.",
  too_many_visits: "Você já tem 2 visitas marcadas. Conclua ou desmarque uma antes.",
  unknown_operation: "Função indisponível nesta versão. Atualize o RiverLife.", vacancy_missing: "Vaga não encontrada.",
  vehicle_data_missing: "Os dados do carro não foram encontrados.", vehicle_locked: "Este carro está bloqueado (anunciado ou em serviço).",
  visit_closed: "Esta visita já foi encerrada.",
  invalid_minimum: "O preço mínimo deve ficar entre metade do preço e o preço pedido.", street_full: "Você já tem 2 carros à venda na rua.", private_area: "Tire o carro da garagem ou da concessionária: a venda na rua precisa de um lugar aberto.",
  starter_used: "Você já recebeu seu primeiro bico.", no_spots: "Ainda não há pontos de bico mapeados aqui. Dirija um pouco e tente de novo.",
  too_fast: "Rápido demais! Leve o carro pelo caminho até o destino.", rate_limited: "Calma: muitas ações seguidas. Tente de novo em um segundo.", wallet_busy: "Sincronizando o saldo... tente de novo em instantes.",
}
export const ROLES = { vendedor: "Vendedor(a)", comprador: "Comprador(a)", mecanico: "Mecânico(a)", owner: "Dono(a)" }
export const PROFESSIONS = {
  translado: { label: "Motorista de translado", icon: "steeringWheelCommon" }, vistoria: { label: "Vistoriador(a)", icon: "search" },
  vendedor: { label: "Vendedor(a) de carros", icon: "carDealer" }, mecanico: { label: "Mecânico(a)", icon: "wrench" },
  comprador: { label: "Comprador(a)", icon: "carStarred" },
}

// RLS computer functions as RiverOS shows them (each opens a RiverOS app).
export const RLS_FUNCTIONS = {
  vehicleInventory: { name: "Meus veículos", icon: "keys1", app: "garage" },
  vehicleShop: { name: "Concessionárias", icon: "carDealer", app: "dealer" },
  partInventory: { name: "Minhas peças", icon: "engine", app: "myparts" },
  insurances: { name: "Seguros", icon: "shieldCheckmark", app: "insurance" },
  loans: { name: "Banco River", icon: "banknotes", app: "loans" },
  sleep: { name: "Dormir", icon: "calendar", app: "sleep" },
  painting: { name: "Pintura", icon: "documentOutline", app: "paint" },
  tuning: { name: "Tuning", icon: "gearTuningOutline", app: "tuning" },
  partShop: { name: "Peças", icon: "engine", app: "parts" },
  repair: { name: "Reparo", icon: "wrench", app: "repair" },
  maintenance: { name: "Manutenção", icon: "wrench", app: "maintenance" },
  enginePackages: { name: "Motor", icon: "engine", app: "engine" },
  performanceIndex: { name: "Desempenho", icon: "chartBars", app: "performance" },
  playerAbstract: { name: "Ficha do motorista", icon: "documentOutline", app: "abstract" },
}
export function rlsName(f) {
  const l = f?.label
  return RLS_FUNCTIONS[f?.id]?.name || (typeof l === "string" ? l : l?.txt || l?.label) || "Serviço"
}
export function errorText(code) { return ERRORS[code] || ("Não foi possível concluir: " + code) }
export function money(c) {
  return new Intl.NumberFormat((window.__rlLocale || "pt-BR"), { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format((Number(c) || 0) / 100)
}
// RLS amounts are plain dollars (not RiverLife cents).
export function dollars(v, cents = false) {
  const n = Number(v) || 0
  const digits = cents || (n !== 0 && Math.abs(n) < 100) ? 2 : 0
  return new Intl.NumberFormat((window.__rlLocale || "pt-BR"), { style: "currency", currency: "USD", minimumFractionDigits: digits, maximumFractionDigits: digits }).format(n)
}
// Lua sends arrays as arrays, maps (or empty tables) as objects; screens want arrays.
export function arr(x) { return Array.isArray(x) ? x : x && typeof x === "object" ? Object.values(x) : [] }
// Text fields must tell the game to stop treating keys as driving controls.
export function typing(on) { try { lua.setCEFTyping(!!on) } catch (err) { /* ignore */ } }
export function km(m) { return new Intl.NumberFormat((window.__rlLocale || "pt-BR"), { maximumFractionDigits: 0 }).format((Number(m) || 0) / 1000) + " km" }
export function dateTime(t) { return t ? new Date(t * 1000).toLocaleString((window.__rlLocale || "pt-BR"), { dateStyle: "short", timeStyle: "short" }) : "" }
export function ago(t) {
  if (!t) return ""
  const s = Math.max(0, Math.floor(Date.now() / 1000 - t))
  if (s < 60) return "agora"
  if (s < 3600) return Math.floor(s / 60) + " min"
  if (s < 86400) return Math.floor(s / 3600) + " h"
  return Math.floor(s / 86400) + " d"
}
export function status(s) { return STATUS[s] || s }
export function distance(a, b) {
  if (!a || !b) return Infinity
  return Math.hypot(a.x - b.x, a.y - b.y, (a.z || 0) - (b.z || 0))
}
export function distanceText(m) {
  if (!isFinite(m)) return "—"
  return m < 1000 ? Math.round(m) + " m" : (m / 1000).toFixed(1).replace(".", ",") + " km"
}

// Derived data shared by the screens.
export const me = computed(() => rl.view.me || {})
export const myStore = computed(() => (rl.view.stores || []).find(s => s.owner === me.value.id))
export const myShop = computed(() => (rl.view.workshops || []).find(w => w.owner === me.value.id))
export const unread = computed(() => (rl.view.messages || []).filter(m => m.to === me.value.id && !m.read).length)
export const myListings = computed(() => (rl.view.listings || []).filter(l => l.seller === me.value.id))
export const activeListings = computed(() => (rl.view.listings || []).filter(l => l.status === "active"))
export const myNpcs = computed(() => (rl.view.npcs || []).filter(n => n.owner === me.value.id))
export const shopOrders = computed(() => (rl.view.orders || []).filter(o => o.shopOwner === me.value.id))
export const myOrders = computed(() => (rl.view.orders || []).filter(o => o.customer === me.value.id))
export const openVisits = computed(() => (rl.view.visits || []).filter(v => ["scheduled", "arrived"].includes(v.status)))
// Businesses where I work for someone else (player staff).
export const staffStore = computed(() => (rl.view.stores || []).find(s => s.myRole === "vendedor"))
export const staffShop = computed(() => (rl.view.workshops || []).find(w => w.myRole === "mecanico"))
export const myGig = computed(() => (rl.view.gigs || []).find(g => g.taker === me.value.id && g.status === "taken"))
export const openGigs = computed(() => (rl.view.gigs || []).filter(g => g.status === "open"))
export function skillStars(n) { return "★".repeat(n || 0) + "☆".repeat(Math.max(0, 5 - (n || 0))) }
export const attention = computed(() => {
  const out = []
  for (const v of openVisits.value) if (v.status === "arrived") out.push({ kind: "visit", id: v.id, text: (v.buyer === me.value.id ? "Você está no local da visita" : "Comprador no local") })
  for (const o of rl.view.offers || []) if (o.status === "pending" && o.from !== me.value.id) out.push({ kind: "offer", id: o.id, text: "Proposta recebida: " + money(o.price) })
  for (const o of shopOrders.value) if (o.status === "requested") out.push({ kind: "order", id: o.id, text: "Pedido de orçamento: " + (o.vehicle?.niceName || o.vehicle?.model) })
  for (const o of myOrders.value) if (o.status === "quoted") out.push({ kind: "quote", id: o.id, text: "Orçamento recebido: " + money(o.quote?.total) })
  for (const n of myNpcs.value) if (n.status === "negotiating" && n.kind === "seller") out.push({ kind: "trade", id: n.id, text: n.name + " quer vender um " + (n.vehicle?.niceName || "carro") })
  return out
})

export function photo(id) { return rl.photos[id] || (rl.view.photos || {})[id] || "" }
export function photoList(listing) {
  const p = listing?.photos
  return Array.isArray(p) ? p : Object.values(p || {})
}
// The picture a listing card shows: its first photo, else the catalog picture of the car.
export function cover(listing) {
  const first = photoList(listing)[0]
  return (first && photo(first)) || listing?.cover || ""
}
function requestPhoto(id) {
  if (!id || photo(id) || requestedPhotos.has(id)) return
  requestedPhotos.add(id)
  request("photoGet", { photoId: id })
  // A lost download may be asked again later.
  setTimeout(() => { if (!photo(id)) requestedPhotos.delete(id) }, 30000)
}
export function loadPhotos(listing) { for (const id of photoList(listing)) requestPhoto(id) }
// Lists only need the cover picture of each ad.
export function loadCover(listing) { requestPhoto(photoList(listing)[0]) }
export function listingTitle(id) {
  return (rl.view.listings || []).find(l => l.id === id)?.title || (rl.view.receipts || []).find(r => r.listingId === id)?.title || id
}

function receiveView(s) {
  for (const key of LIST_KEYS) s[key] = Array.isArray(s[key]) ? s[key] : Object.values(s[key] || {})
  // Empty Lua tables arrive as {}; lists the screens iterate must be arrays.
  for (const l of s.listings) if (!Array.isArray(l.photos)) l.photos = Object.values(l.photos || {})
  for (const st of s.stores) if (st.lot && !Array.isArray(st.lot)) st.lot = Object.values(st.lot)
  for (const st of s.stores) if (st.candidates && !Array.isArray(st.candidates)) st.candidates = Object.values(st.candidates)
  for (const w of s.workshops) if (w.candidates && !Array.isArray(w.candidates)) w.candidates = Object.values(w.candidates)
  rl.view = s
}
// Automatic shots of display cars are dropped when washed out or too dark.
async function photoUsable(url) {
  try {
    const img = new Image()
    img.src = url
    await img.decode()
    const c = document.createElement("canvas")
    c.width = 64; c.height = 36
    const g = c.getContext("2d")
    g.drawImage(img, 0, 0, 64, 36)
    const d = g.getImageData(0, 0, 64, 36).data
    let sum = 0
    for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]
    const mean = sum / (d.length / 4)
    return mean > 12 && mean < 215
  } catch (err) {
    return true
  }
}
async function capturedPhoto(p) {
  if (!p.display) rl.capturing = false
  if (p.display && !(await photoUsable(p.url))) return
  rl.photos[p.photoId] = p.url
  if (!(p.mp ?? rl.view.mode === "BeamMP")) {
    if (p.display) request("displayPhoto", { listingId: p.display, photoId: p.photoId })
    else emit({ op: "photoReady", photoId: p.photoId, inventoryId: p.inventoryId })
    return
  }
  try {
    // Uploads are JPEG, 960x540, chunked; "Z" is remapped to dodge a launcher bug.
    const img = new Image()
    img.src = p.url
    await img.decode()
    const canvas = document.createElement("canvas")
    canvas.width = 960; canvas.height = 540
    canvas.getContext("2d").drawImage(img, 0, 0, 960, 540)
    const base64 = canvas.toDataURL("image/jpeg", 0.8).split(",")[1].replaceAll("Z", "_")
    const bytes = new Uint8Array(16)
    if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes)
    else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256)
    const uploadId = Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("")
    rl.uploads[uploadId] = { sourceId: p.photoId, url: p.url, inventoryId: p.inventoryId, display: p.display }
    for (let offset = 0; offset < base64.length; offset += 12000) {
      request("photoData", { sourceId: p.photoId, uploadId, total: base64.length, offset: offset + 1, chunk: base64.slice(offset, offset + 12000), mime: "image/jpeg" })
      await new Promise(r => setTimeout(r, 75))
    }
  } catch (e) {
    if (!p.display) toast("Não foi possível enviar a foto: " + e.message, "error")
  }
}
function uploadedPhoto(p) {
  const u = rl.uploads[p.uploadId]
  if (!u) return
  rl.photos[p.photoId] = u.url
  delete rl.uploads[p.uploadId]
  // Photos of a display car go straight onto its ad (the server checks this client hosts it).
  if (u.display) request("displayPhoto", { listingId: u.display, photoId: p.photoId })
  else emit({ op: "photoReady", photoId: p.photoId, inventoryId: u.inventoryId })
}
function photoChunk(p) {
  let c = chunks[p.photoId]
  if (!c) c = chunks[p.photoId] = { parts: {}, total: p.total, mime: p.mime }
  c.parts[p.offset] = p.chunk
  let n = 0, data = ""
  for (const k of Object.keys(c.parts).map(Number).sort((a, b) => a - b)) {
    if (k !== n + 1) return
    data += c.parts[k]; n += c.parts[k].length
  }
  if (n === c.total) { rl.photos[p.photoId] = "data:" + c.mime + ";base64," + data.replaceAll("_", "Z"); delete chunks[p.photoId] }
}
function emit(e) { for (const fn of listeners) { try { fn(e) } catch (err) { console.error(err) } } }
function action(p) {
  const op = p?.id && inflight[p.id]
  if (op) delete inflight[p.id]
  settle(op)
  settle(p?.op)
  rl.lastAction = p
  if (p?.result && !p.result.ok && !SILENT_ERRORS.includes(p.op)) toast(errorText(p.result.error), "error")
  emit(p)
}

export function wire() {
  const prev = window[WIRE_KEY]
  if (prev?.owner === rl) return
  unwire(true)
  const { events } = useBridge()
  const handlers = [
    ["RiverLifeView", receiveView],
    ["RiverLifeNotice", p => toast(p.text, p.kind)],
    ["RiverLifeError", p => {
      if (p?.id) { const op = inflight[p.id]; delete inflight[p.id]; settle(op); return }
      // A general failure (e.g. the wallet sync): nothing in flight will be answered.
      for (const k of Object.keys(inflight)) delete inflight[k]
      rl.busy = {}
      toast(errorText(p?.error), "error")
    }],
    ["RiverLifeAction", action],
    ["RiverLifePhotoCaptured", capturedPhoto],
    ["RiverLifePhotoUploaded", uploadedPhoto],
    ["RiverLifePhotoChunk", photoChunk],
    ["RiverLifeOpen", p => emit({ op: "open", ...p })],
  ]
  for (const [name, fn] of handlers) events.on(name, fn)
  window[WIRE_KEY] = { owner: rl, events, handlers }
  request("refresh")
}

export function unwire(any = false) {
  const prev = window[WIRE_KEY]
  if (!prev || (!any && prev.owner !== rl)) return
  for (const [name, fn] of prev.handlers) prev.events.off(name, fn)
  delete window[WIRE_KEY]
}
