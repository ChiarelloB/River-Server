<template>
  <!-- Opened from the desktop: pick a car at this garage and start the RLS engine package session. -->
  <div v-if="!hosted" class="rl-page">
    <header class="ap-head">
      <span class="ap-tile"><BngIcon type="engine" /></span>
      <div><h2 class="rl-h1">Pacotes de motor</h2><p class="rl-muted">Guarde o motor de um carro como pacote e instale-o em outro.</p></div>
    </header>
    <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>Os pacotes de motor do RLS só funcionam em um computador de garagem.</div>
    <div v-else-if="!launchList.length" class="rl-empty"><b>Nenhum veículo nesta garagem</b>Retire o carro na garagem para mexer no motor.</div>
    <table v-else class="rl-table"><tbody>
      <tr><th>Veículo</th><th>Situação</th><th></th></tr>
      <tr v-for="v in launchList" :key="v.inventoryId">
        <td><b>{{ v.name }}</b></td>
        <td><span v-if="!v.fn" class="rl-muted">Só em garagens que são suas</span>
          <span v-else-if="v.fn.disabled" class="rl-muted">{{ reasonText(v.fn.reason?.label) || "Indisponível agora" }}</span>
          <span v-else class="rl-badge ok">Disponível</span></td>
        <td class="ap-right"><button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button></td>
      </tr>
    </tbody></table>
  </div>

  <div v-else class="en">
    <div class="en-body">
      <header class="ap-head">
        <span class="ap-tile"><BngIcon type="engine" /></span>
        <div><h2 class="rl-h1">Pacotes de motor</h2>
          <p class="rl-muted">{{ vehicleName ? "Veículo selecionado: " + vehicleName + " · " : "" }}Um pacote junta o motor e as peças dele para trocar de carro sem perder nada.</p></div>
      </header>

      <div v-if="message" class="en-banner" :class="message.success ? 'ok' : 'bad'">
        <BngIcon :type="message.success ? 'checkmark' : 'danger'" /> {{ msg(message.message) }}
        <button class="en-x" title="Fechar" @click="message = null">×</button>
      </div>
      <div v-if="data.busy" class="en-banner busy"><span class="en-spin"></span> Atualizando o pacote de motor... aguarde.</div>

      <fieldset v-if="!data.currentPackageId && data.hasInstalledEngine" class="xp-group en-create">
        <legend>Empacotar o motor instalado</legend>
        <p class="rl-muted">O motor continua no carro até você trocá-lo. Uma foto do motor isolado é tirada para o pacote.</p>
        <form class="rl-row" @submit.prevent="createPackage">
          <input v-model="createName" class="rl-input en-name" maxlength="48" placeholder="Nome do pacote (opcional)" :disabled="data.busy"
            @focus="typing(true)" @blur="typing(false)" />
          <button class="rl-btn primary" :disabled="data.busy"><BngIcon type="plus" /> Criar pacote</button>
        </form>
      </fieldset>
      <div v-else-if="data.currentPackageId" class="rl-box en-note">O motor instalado já faz parte de um pacote. Instalar outro pacote guarda este automaticamente.</div>
      <div v-else-if="!data.hasInstalledEngine" class="rl-box en-note">Não há motor instalado neste carro. Instale um pacote guardado compatível abaixo, ou monte outro motor em Peças e personalização.</div>

      <div v-if="!loaded" class="rl-empty"><b>{{ stalled ? "Os pacotes não carregaram" : "Carregando pacotes..." }}</b>{{ stalled ? "" : "Lendo os motores guardados." }}
        <div v-if="stalled" class="rl-row" style="justify-content:center;margin-top:8px"><button class="rl-btn" @click="askData">Tentar de novo</button></div></div>
      <div v-else-if="!packages.length && !data.busy" class="rl-empty"><b>Nenhum pacote ainda</b>Crie um a partir do motor instalado neste carro.</div>

      <article v-for="pkg in packages" :key="pkg.id" class="en-card" :class="{ current: pkg.id === data.currentPackageId }">
        <div class="en-shot">
          <img v-if="thumbUrl(pkg)" :src="thumbUrl(pkg)" alt="" />
          <span v-else class="en-nothumb"><BngIcon type="engine" /><small>Sem foto ainda</small></span>
          <span class="rl-badge en-status" :class="statusTone(pkg)">{{ statusLabel(pkg) }}</span>
        </div>
        <div class="en-main">
          <div class="en-head">
            <div v-if="renameId !== pkg.id"><h3>{{ pkg.name }}</h3>
              <small class="rl-muted">{{ pkg.rootEngineNiceName || pkg.rootEngineName }}{{ pkg.installedVehicleName ? " · instalado em " + pkg.installedVehicleName : "" }}</small></div>
            <form v-else class="rl-row en-rename" @submit.prevent="commitRename(pkg)">
              <input v-model="renameName" class="rl-input en-name" maxlength="48" :disabled="data.busy" placeholder="Nome do pacote"
                @focus="typing(true)" @blur="typing(false)" @keydown.esc.prevent="cancelRename" />
              <button class="rl-btn primary" :disabled="data.busy || !renameName.trim()">Salvar</button>
              <button type="button" class="rl-btn" :disabled="data.busy" @click="cancelRename">Cancelar</button>
            </form>
          </div>

          <div class="en-stats">
            <span><small>Peças</small><b>{{ pkg.partCount || 0 }}</b></span>
            <span v-if="pkg.tuningCount"><small>Ajustes de tuning</small><b>{{ pkg.tuningCount }}</b></span>
            <span><small>Rodagem</small><b>{{ km(pkg.odometer) }}</b></span>
            <span class="en-int"><small>Integridade {{ integrity(pkg) }}%</small>
              <div class="en-bar" :class="intTone(pkg)"><i :style="{ width: integrity(pkg) + '%' }"></i></div></span>
          </div>

          <div v-if="pkg.status === 'stored'" class="en-compat" :class="pkg.compatible ? 'ok' : 'bad'">
            <BngIcon :type="pkg.compatible ? 'checkmark' : 'abandon'" /> {{ pkg.compatible ? "Compatível com este carro" : msg(pkg.compatibilityReason) || "Não é compatível com este carro" }}
          </div>
          <div v-else-if="pkg.status === 'incomplete'" class="en-compat bad">
            <BngIcon type="abandon" /> Não pode ser instalado: {{ pkg.missingCount ? pkg.missingCount + " peça(s) original(is) não estão mais disponíveis" : "faltam peças originais" }}.
          </div>

          <div v-if="confirmDismantleId === pkg.id" class="rl-box en-confirm">
            <b>Desmontar “{{ pkg.name }}”? As peças voltam para Minhas peças e o pacote deixa de existir.</b>
            <div class="rl-row">
              <button class="rl-btn danger" :disabled="data.busy" @click="dismantlePackage(pkg)">Desmontar</button>
              <button class="rl-btn" :disabled="data.busy" @click="confirmDismantleId = null">Cancelar</button>
            </div>
          </div>
          <div v-else class="rl-row en-actions">
            <button v-if="pkg.status === 'stored'" class="rl-btn primary" :disabled="!pkg.canInstall || data.busy" @click="installPackage(pkg)">Instalar neste carro</button>
            <button v-if="pkg.canStore" class="rl-btn primary" :disabled="data.busy" @click="storePackage(pkg)">Guardar (tirar do carro)</button>
            <button v-if="renameId !== pkg.id" class="rl-btn" :disabled="data.busy" @click="startRename(pkg)">Renomear</button>
            <button class="rl-btn" :disabled="data.busy || pkg.canDismantle === false" @click="askDismantle(pkg)"><BngIcon type="trashBin1" /> Desmontar</button>
          </div>
        </div>
      </article>
    </div>

    <footer class="ap-foot">
      <span class="ap-status">{{ data.busy ? "Trabalhando no motor... não feche agora." : packages.length + " pacote(s)" }}</span>
      <button class="rl-btn" :disabled="data.busy" @click="requestClose">Fechar</button>
    </footer>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaString, onGameEvent, arr, typing, toast, km } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const MOD = "career_modules_enginePackages"

const MESSAGES = {
  "This engine is already grouped as a package.": "Este motor já faz parte de um pacote.",
  "Engine package not found.": "Pacote de motor não encontrado.",
  "Enter a package name.": "Digite um nome para o pacote.",
  "Renamed engine package.": "Pacote renomeado.",
  "Dismantled engine package. Its parts are available in My Parts again.": "Pacote desmontado. As peças voltaram para Minhas peças.",
  "Only the selected vehicle's installed engine package can be stored.": "Só dá para guardar o pacote instalado no carro selecionado.",
  "The installed engine could not be read.": "Não foi possível ler o motor instalado.",
  "The installed engine package could not be refreshed.": "Não foi possível atualizar o pacote instalado.",
  "The engine package is missing one or more parts.": "Faltam peças neste pacote.",
  "The package is missing one or more parts.": "Faltam peças neste pacote.",
  "Only stored engine packages can be installed.": "Só pacotes guardados podem ser instalados.",
  "The selected vehicle is no longer available.": "O carro selecionado não está mais disponível.",
  "An engine package part became unavailable during the swap.": "Uma peça do pacote ficou indisponível durante a troca.",
  "The engine swap failed and was rolled back.": "A troca de motor falhou e foi desfeita.",
  "Storing the engine failed and was rolled back.": "Guardar o motor falhou e foi desfeito.",
  "No vehicle is selected.": "Nenhum carro selecionado.",
  "The selected vehicle is not owned.": "O carro selecionado não é seu.",
  "The selected vehicle is not accessible.": "O carro selecionado está indisponível agora.",
  "The selected vehicle is not spawned.": "O carro precisa estar retirado da garagem (na rua).",
  "Insurance is still loading. Reopen the garage computer.": "O seguro ainda está carregando. Abra o computador de novo.",
  "Repair this vehicle before managing engine packages.": "Conserte o carro antes de mexer nos pacotes de motor.",
  "Vehicle modification is not allowed.": "Modificar este carro não é permitido.",
  "Electric vehicles cannot swap engines.": "Carros elétricos não trocam de motor.",
  "This engine package does not fit the selected vehicle.": "Este motor não serve neste carro.",
  "More than one compatible engine slot was found.": "Há mais de um encaixe de motor compatível neste carro.",
  "The vehicle must be owned, accessible, and spawned.": "O carro precisa ser seu, estar disponível e retirado da garagem.",
}

const hosted = computed(() => !!props.route)
const data = ref({ busy: false, currentInventoryId: null, currentPackageId: null, hasInstalledEngine: false, packages: [] })
const loaded = ref(false), stalled = ref(false)
const message = ref(null)
const createName = ref("")
const renameId = ref(null)
const renameName = ref("")
const confirmDismantleId = ref(null)
// RLS can briefly omit a thumbnail while it re-checks the capture; keep the last good one.
const thumbnailCache = new Map()
let messageTimer = null
let offs = []

function msg(m) {
  if (!m) return ""
  if (MESSAGES[m]) return MESSAGES[m]
  let r = /^Created engine package (.*)\.$/.exec(m)
  if (r) return "Pacote de motor “" + r[1] + "” criado."
  r = /^Stored (.*)\. Use Part Customization to build another engine\.$/.exec(m)
  if (r) return "“" + r[1] + "” guardado. Use Peças e personalização para montar outro motor."
  r = /^Installed (.*?)\.(?: The outgoing engine was stored as (.*)\.)?$/.exec(m)
  if (r) return "“" + r[1] + "” instalado." + (r[2] ? " O motor que saiu foi guardado como “" + r[2] + "”." : "")
  return m
}
function reasonText(l) { return typeof l === "string" ? msg(l) : l?.txt || "" }

const packages = computed(() => arr(data.value.packages))
const vehicleName = computed(() => {
  const id = data.value.currentInventoryId
  if (id == null) return ""
  const inst = packages.value.find(p => Number(p.installedInventoryId) === Number(id))
  if (inst?.installedVehicleName) return inst.installedVehicleName
  const v = arr(rl.view.computer?.vehicles).find(x => Number(x.inventoryId) === Number(id))
  return v ? (v.vehicleName || v.niceName || "") : ""
})

function updateData(payload) {
  const incoming = arr(payload?.packages)
  const ids = new Set()
  const list = incoming.map(x => {
    const pkg = { ...(x || {}) }
    const id = String(pkg.id || "")
    if (id) ids.add(id)
    if (pkg.thumbnail) thumbnailCache.set(id, { thumbnail: pkg.thumbnail, dirtyDate: pkg.dirtyDate || 0 })
    else {
      const c = thumbnailCache.get(id)
      if (c) { pkg.thumbnail = c.thumbnail; pkg.dirtyDate = c.dirtyDate }
    }
    return pkg
  })
  for (const id of Array.from(thumbnailCache.keys())) if (!ids.has(id)) thumbnailCache.delete(id)
  data.value = { busy: false, currentInventoryId: null, currentPackageId: null, hasInstalledEngine: false, ...(payload || {}), packages: list }
  loaded.value = true
  if (vehicleName.value) emit("title", vehicleName.value)
}
function handleResult(payload) {
  message.value = payload || null
  clearTimeout(messageTimer)
  if (payload?.success) {
    createName.value = ""
    renameId.value = null
    renameName.value = ""
    confirmDismantleId.value = null
    messageTimer = setTimeout(() => { message.value = null }, 5000)
  }
}
async function requestData() {
  const result = await luaCall(MOD + ".requestData()")
  if (result) updateData(result)
}

function createPackage() {
  if (data.value.busy || data.value.currentPackageId) return
  typing(false)
  luaCall(MOD + ".createFromCurrent(" + luaString(createName.value.trim()) + ")")
}
function startRename(pkg) {
  if (data.value.busy) return
  renameId.value = pkg.id
  renameName.value = pkg.name || ""
  confirmDismantleId.value = null
}
function cancelRename() { renameId.value = null; renameName.value = ""; typing(false) }
function commitRename(pkg) {
  if (data.value.busy || !renameName.value.trim()) return
  typing(false)
  luaCall(MOD + ".renamePackage(" + luaString(String(pkg.id)) + ", " + luaString(renameName.value.trim()) + ")")
}
function installPackage(pkg) {
  if (data.value.busy || !pkg.canInstall) return
  confirmDismantleId.value = null
  luaCall(MOD + ".installPackage(" + luaString(String(pkg.id)) + ")")
}
function storePackage(pkg) {
  if (data.value.busy || !pkg.canStore) return
  confirmDismantleId.value = null
  luaCall(MOD + ".storeInstalledPackage(" + luaString(String(pkg.id)) + ")")
}
function askDismantle(pkg) {
  if (data.value.busy) return
  confirmDismantleId.value = pkg.id
  renameId.value = null
}
function dismantlePackage(pkg) {
  if (data.value.busy) return
  luaCall(MOD + ".dismantlePackage(" + luaString(String(pkg.id)) + ")")
}

function statusLabel(pkg) { return pkg.status === "stored" ? "Guardado" : pkg.status === "installed" ? "Instalado" : "Incompleto" }
function statusTone(pkg) {
  if (pkg.status === "installed") return "ok"
  if (pkg.status === "incomplete") return "bad"
  if (pkg.status === "stored" && pkg.compatible === false) return "warn"
  return ""
}
function integrity(pkg) { return Math.max(0, Math.min(100, Math.round(Number(pkg.integrity || 0) * 100))) }
function intTone(pkg) { const i = integrity(pkg); return i < 35 ? "bad" : i < 75 ? "warn" : "ok" }
function thumbUrl(pkg) { return pkg?.thumbnail ? pkg.thumbnail + "?" + (pkg.dirtyDate || 0) : "" }

// Launcher
const launchList = computed(() => {
  const c = rl.view.computer
  if (!c) return []
  return arr(c.vehicles).map(v => ({
    inventoryId: v.inventoryId, name: v.vehicleName || v.niceName || "Veículo",
    fn: c.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.enginePackages || null,
  }))
})
function launch(v) { request("native", { buttonId: "enginePackages", inventoryId: v.inventoryId }) }

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  if (data.value.busy) { toast("Aguarde o pacote de motor terminar de atualizar.", "warning"); return }
  luaCall(MOD + ".closeMenu()")
}
defineExpose({ requestClose })

onMounted(() => {
  if (!hosted.value) return
  offs.push(onGameEvent("enginePackagesData", updateData))
  offs.push(onGameEvent("enginePackagesActionResult", handleResult))
  askData()
})
// Data comes by event; ask again if it does not arrive, then offer a retry.
function askData() {
  stalled.value = false
  requestData()
  setTimeout(() => { if (!loaded.value) requestData() }, 4000)
  setTimeout(() => { if (!loaded.value) stalled.value = true }, 12000)
}
onUnmounted(() => {
  offs.forEach(off => off()); offs = []
  clearTimeout(messageTimer)
  typing(false)
})
</script>

<style scoped>
.ap-head { display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }
.ap-head .rl-h1 { margin: 0; }
.ap-head p { margin: 2px 0 0; }
.ap-tile { width: 44px; height: 44px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #fff;
  background: linear-gradient(135deg, #ff8a6a, #a8321a); box-shadow: 0 2px 4px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.45); flex-shrink: 0; }
.ap-right { text-align: right; }
.en { display: flex; flex-direction: column; min-height: 100%; }
.en-body { flex: 1; padding: 14px 18px; }
.en-banner { position: relative; display: flex; gap: 6px; align-items: center; padding: 7px 28px 7px 10px; margin: 6px 0; border-radius: 3px; border: 1px solid #a7c1e0; background: #e8f1fd; color: #24508c; }
.en-banner.ok { border-color: #9fd696; background: #e3f7e0; color: #236b1a; }
.en-banner.bad { border-color: #e6a19a; background: #fde6e4; color: #8e2318; }
.en-x { position: absolute; right: 6px; top: 5px; border: 0; background: none; cursor: pointer; font: bold 15px Tahoma, sans-serif; color: inherit; }
.en-spin { width: 12px; height: 12px; border-radius: 50%; border: 2px solid #a7c1e0; border-top-color: #24508c; animation: en-rot .8s linear infinite; }
@keyframes en-rot { to { transform: rotate(360deg); } }
.xp-group { margin: 10px 0; padding: 6px 14px 12px; border: 1px solid #d0d0bf; border-radius: 4px; background: #fff; }
.xp-group legend { color: #0046d5; font-weight: bold; font-size: 12px; padding: 0 4px; }
.xp-group p { margin: 2px 0 8px; }
.en-name { width: 260px; }
.en-note { color: #3d4b5c; }
.rl-btn { display: inline-flex; gap: 5px; align-items: center; }
.en-card { display: flex; gap: 14px; margin: 10px 0; padding: 10px; border: 1px solid #c9d7e8; border-radius: 4px; background: #fff; }
.en-card.current { border-color: #6cae5f; box-shadow: inset 3px 0 0 #36a12c; }
.en-shot { position: relative; width: 220px; height: 124px; flex-shrink: 0; border-radius: 3px; overflow: hidden; background: linear-gradient(180deg, #2a313c, #151a21); }
.en-shot img { width: 100%; height: 100%; object-fit: contain; }
.en-nothumb { position: absolute; inset: 0; display: grid; place-content: center; justify-items: center; gap: 4px; color: #9aa7b8; font-size: 30px; }
.en-nothumb small { font-size: 11px; }
.en-status { position: absolute; left: 6px; bottom: 6px; }
.en-main { flex: 1; min-width: 0; display: grid; gap: 8px; align-content: start; }
.en-head h3 { margin: 0; font-size: 15px; color: #1b3355; }
.en-stats { display: flex; flex-wrap: wrap; gap: 8px 22px; }
.en-stats span { display: grid; gap: 2px; }
.en-stats small { font-size: 11px; color: #64768b; }
.en-stats b { font-size: 13px; color: #1b3355; }
.en-int { min-width: 160px; }
.en-bar { height: 10px; border: 1px solid #8f9aa6; border-radius: 2px; padding: 1px; background: #fff; }
.en-bar i { display: block; height: 100%; background: #36c13c; }
.en-bar.warn i { background: #e8b42a; } .en-bar.bad i { background: #d9452f; }
.en-compat { display: flex; gap: 6px; align-items: center; font-size: 12px; padding: 4px 8px; border-radius: 3px; }
.en-compat.ok { color: #236b1a; background: #eef9ec; }
.en-compat.bad { color: #8e2318; background: #fdf0ee; }
.en-confirm { display: grid; gap: 8px; margin: 0; border-color: #e6a19a; background: #fff6f4; }
.ap-foot { position: sticky; bottom: 0; display: flex; gap: 8px; align-items: center; padding: 8px 14px; background: #ece9d8; border-top: 1px solid #aca899; }
.ap-status { flex: 1; font-size: 12px; color: #3d4b5c; }
</style>
