<template>
  <div class="ps">
    <header class="ps-head">
      <div class="ps-logo"><BngIcon type="engine" /><b>River<span>Peças</span></b><small>{{ route ? (vehicleName || "Peças para o seu carro") : "Peças com foto para o seu carro" }}</small></div>
      <div v-if="route" class="ps-search"><BngIcon type="search" color="#8a8f98" />
        <input v-model.trim="query" placeholder="Buscar peça ou encaixe (ex.: turbo, para-choque, roda)" @focus="typing(true)" @blur="typing(false)" />
      </div>
      <div class="ps-wallet"><small>Seu saldo</small><b>{{ playerMoney === null ? money(rl.view.money) : dollars(playerMoney) }}</b></div>
    </header>

    <!-- No RLS session yet: pick a car parked at this garage. -->
    <div v-if="!route" class="ps-launch">
      <h2 class="rl-h1">Escolha o carro</h2>
      <p class="rl-muted">A RiverPeças mostra só as peças que servem no carro escolhido, cada uma com foto. As peças vão para o carrinho e
        são montadas no carro na hora; você paga ao finalizar a compra.</p>
      <div v-if="launchFailed" class="ps-warn">O computador não abriu a loja de peças. Confira se o carro está estacionado na garagem e tente de novo.</div>
      <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>As peças são montadas no carro estacionado na garagem.</div>
      <div v-else-if="!launchVehicles.length" class="rl-empty"><b>Nenhum carro nesta garagem</b>Traga um carro para perto do computador.</div>
      <div v-else class="ps-cars">
        <article v-for="v in launchVehicles" :key="v.inventoryId" class="ps-car">
          <div class="ps-car-photo"><img v-if="v.thumbnail" :src="v.thumbnail" alt="" /><BngIcon v-else type="carStarred" color="#9aa9bb" /></div>
          <div class="ps-car-body">
            <b>{{ v.niceName || v.vehicleName || "Veículo" }}</b>
            <small class="rl-muted">{{ v.fn ? (v.fn.disabled ? reasonText(v.fn) : "Pronto para receber peças") : "Esta garagem não vende peças" }}</small>
            <button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled || launching" @click="launch(v)">{{ launching ? "Abrindo…" : "Ver peças para este carro" }}</button>
          </div>
        </article>
      </div>
    </div>

    <div v-else class="ps-main">
      <aside class="ps-side">
        <button v-for="c in categoryList" :key="c.id" class="ps-cat" :class="{ on: cat === c.id && !query }" @click="pickCat(c.id)">
          <BngIcon :type="c.icon" :color="cat === c.id && !query ? '#8a3a0f' : '#5a6b80'" /><span>{{ c.label }}</span><small>{{ c.count }}</small>
        </button>
      </aside>

      <section ref="listEl" class="ps-list">
        <div v-if="!data" class="rl-empty"><b>Abrindo a loja…</b>Lendo as peças que servem neste carro.</div>
        <template v-else>
          <div class="ps-bar">
            <b>{{ query ? "Resultados para “" + query + "”" : catLabel(cat) }}</b>
            <span class="rl-muted">{{ filtered.length }} peça(s)</span>
            <span class="grow"></span>
            <button v-if="shootable.length" class="rl-btn" :disabled="blocked" title="A tela some por alguns segundos enquanto as peças montadas no carro são fotografadas"
              @click="shootPage"><BngIcon type="camera3Fourth1" color="#333" /> Fotografar {{ shootable.length }} peça(s)</button>
            <label class="ps-check"><input v-model="hideInstalled" type="checkbox" /> Esconder as instaladas</label>
            <XPSelect v-model="sort" aria-label="Ordenar" :options="SORTS" />
          </div>
          <p v-if="restoring" class="ps-warn">Restaurando o carrinho salvo… {{ restoreProgress.current }}/{{ restoreProgress.total }}</p>
          <div v-if="!filtered.length" class="rl-empty"><b>Nada por aqui</b>{{ query ? "Nenhuma peça com esse nome." : "Nenhuma peça desta categoria serve neste carro." }}</div>

          <template v-for="g in pageGroups" :key="g.slot">
            <div class="ps-slot">
              <b>{{ g.slotName }}</b>
              <small class="rl-muted">No carro agora: {{ g.current || "vazio" }}</small>
              <button v-if="g.remove" class="ps-link" :disabled="blocked" @click="install(g.remove)">Tirar a peça deste encaixe</button>
            </div>
            <div class="ps-grid">
              <article v-for="p in g.parts" :key="partKey(p)" class="ps-card" :class="{ installed: isInstalled(p), incart: !!cartPartOf(p), off: p.disabled }">
                <div class="ps-photo">
                  <img v-if="hasPhoto(p.name)" :src="photos[p.name]" alt="" />
                  <div v-else class="ps-noimg" :class="'c-' + categoryOf(p)">
                    <BngIcon :type="catIcon(categoryOf(p))" /><small v-if="photoNote(p.name)">{{ photoNote(p.name) }}</small>
                  </div>
                  <span v-if="isInstalled(p)" class="ps-flag ok">No carro</span>
                  <span v-else-if="cartPartOf(p)" class="ps-flag cart">No carrinho</span>
                  <span v-else-if="p.partId != null" class="ps-flag stock">Do seu estoque</span>
                </div>
                <div class="ps-info">
                  <b :title="partLabel(p)">{{ partLabel(p) }}</b>
                  <small class="rl-muted">{{ slotNice(p.slot) }}<template v-if="p.partCondition?.odometer"> · {{ km(p.partCondition.odometer) }} rodados</template></small>
                  <small v-if="p.disabled && p.disabledReason" class="rl-error">{{ p.disabledReason }}</small>
                </div>
                <div class="ps-buy">
                  <span class="ps-price">{{ p.partId != null ? "grátis" : dollars(p.finalValue, true) }}</span>
                  <button class="rl-btn sm" :class="buttonOf(p).kind" :disabled="buttonOf(p).disabled" :title="buttonOf(p).title" @click="buttonOf(p).action()">{{ buttonOf(p).label }}</button>
                </div>
              </article>
            </div>
          </template>

          <div v-if="pages > 1" class="ps-pager">
            <button class="rl-btn" :disabled="page <= 1" @click="setPage(page - 1)">‹ Anterior</button>
            <span>Página {{ page }} de {{ pages }}</span>
            <button class="rl-btn" :disabled="page >= pages" @click="setPage(page + 1)">Próxima ›</button>
          </div>
        </template>
      </section>

      <aside class="ps-cart">
        <h3><BngIcon type="shoppingCart" color="#8a3a0f" /> Carrinho <small>({{ cartIn.length }})</small></h3>
        <p v-if="!cartIn.length && !cartOut.length" class="rl-muted">Vazio. As peças que você adicionar já aparecem montadas no carro.</p>
        <div class="ps-cart-list">
          <div v-for="c in cartIn" :key="'in' + c.containingSlot" class="ps-cart-row">
            <img v-if="hasPhoto(c.name)" :src="photos[c.name]" alt="" />
            <span class="ps-cart-name">{{ cartName(c) }}<small v-if="!c.sourcePart">incluída com outra peça</small></span>
            <span class="ps-cart-price">{{ c.emptyPlaceholder ? "—" : dollars(c.finalValue, true) }}</span>
            <button v-if="c.sourcePart" class="ps-x" :disabled="blocked" title="Tirar do carrinho" @click="removeSlot(c.containingSlot)">×</button>
          </div>
          <template v-if="cartOut.length">
            <p class="ps-out">Saem do carro e vão para Minhas peças:</p>
            <div v-for="(o, k) in cartOut" :key="'out' + k" class="ps-cart-row out"><span class="ps-cart-name">{{ o.description?.description || o.name }}</span></div>
          </template>
        </div>
        <div class="ps-sums">
          <span>Subtotal <b>{{ dollars(subtotal, true) }}</b></span>
          <span>Impostos <b>{{ dollars(taxes, true) }}</b></span>
          <span class="tot">Total <b>{{ dollars(total, true) }}</b></span>
          <span v-if="tooExpensive" class="rl-error">Saldo insuficiente</span>
        </div>
        <button class="rl-btn go ps-wide" :disabled="!canBuy" @click="askBuy">Finalizar compra</button>
        <button class="rl-btn ps-wide" :disabled="busy" @click="peek"><BngIcon type="carStarred" color="#333" /> Ver no carro</button>
        <div class="rl-row ps-cart-more">
          <button class="rl-btn" :disabled="!cartIn.length || restoring || busy" @click="askSave">Salvar para depois</button>
          <button class="rl-btn" :disabled="!cartIn.length || busy" @click="askDiscard">Esvaziar</button>
        </div>
        <button class="ps-link" :disabled="busy" @click="requestClose">Sair da loja</button>
      </aside>
    </div>

    <div v-if="confirm" class="ps-mask">
      <div class="ps-dialog" role="dialog">
        <b>{{ confirm.title }}</b>
        <p>{{ confirm.text }}</p>
        <div class="rl-row"><button v-for="b in confirm.buttons" :key="b.label" class="rl-btn" :class="b.kind" @click="b.action">{{ b.label }}</button></div>
      </div>
    </div>
    <div v-if="busy" class="ps-mask"><div class="ps-dialog"><b>{{ busyText }}</b></div></div>
  </div>
</template>

<script>
// The store may be unmounted while the RLS session goes on (desktop remount between part shopping routes):
// this router hook still ends the session if those routes are left meanwhile.
let routeGuard = null
function dropGuard() { if (routeGuard) { routeGuard(); routeGuard = null } }
</script>

<script setup>
// Original code: RiverPeças, a parts store with a photo of every part that fits the selected car.
// It drives the same RLS part shopping session as the 3D parts panel (cart, preview on the car, payment).
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, shallowRef, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, luaCall, luaRun, luaString, onGameEvent, dollars, money, arr, typing, toast, km } from "../rl.js"
import { desk } from "../desk.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number, launchFailed: Boolean })
const emit = defineEmits(["open", "title", "close"])

const ROUTE_PREFIX = "career.computer.partShopping"
const PAGE = 24
const SORTS = [{ value: "slot", label: "Por encaixe" }, { value: "low", label: "Menor preço" }, { value: "high", label: "Maior preço" }, { value: "name", label: "Nome" }]
// Categories by slot name (checked in this order).
const CATEGORIES = [
  { id: "wheels", label: "Rodas e pneus", icon: "wheelDisc", keys: ["wheel", "tire", "tyre", "rim", "hubcap", "spacer"] },
  { id: "brakes", label: "Freios", icon: "wheelHubLocked01", keys: ["brake", "rotor", "caliper", "abs"] },
  { id: "intake", label: "Admissão e turbo", icon: "exhaustValve", keys: ["intake", "turbo", "supercharger", "intercooler", "airbox", "throttle", "manifold", "n2o", "nitrous", "blower"] },
  { id: "exhaust", label: "Escapamento", icon: "exhaustMuffler", keys: ["exhaust", "muffler", "header", "downpipe", "catalyt"] },
  { id: "engine", label: "Motor", icon: "engine", keys: ["engine", "motor", "block", "camshaft", "piston", "crank", "oilpan", "radiator", "coolant", "flywheel", "ignition", "injector", "fuel", "ecu", "rev_limiter", "oil"] },
  { id: "drivetrain", label: "Transmissão", icon: "gearTuningOutline", keys: ["transmission", "gearbox", "diff", "clutch", "transfer", "driveshaft", "halfshaft", "axle", "finaldrive", "converter"] },
  { id: "suspension", label: "Suspensão e direção", icon: "suspension01", keys: ["suspension", "spring", "shock", "damper", "coilover", "strut", "sway", "antiroll", "arm", "hub", "steer", "knuckle", "leaf", "airbag", "subframe"] },
  { id: "lights", label: "Faróis e elétrica", icon: "headlight", keys: ["light", "lamp", "battery", "alternator", "electric", "signal", "beacon", "siren"] },
  { id: "interior", label: "Interior", icon: "steeringWheelCommon", keys: ["seat", "dash", "interior", "gauge", "radio", "shifter", "pedal", "harness", "belt", "steeringwheel", "steering_wheel", "cage"] },
  { id: "body", label: "Carroceria", icon: "doorFront", keys: ["body", "bumper", "fender", "hood", "bonnet", "door", "trunk", "tailgate", "spoiler", "wing", "skirt", "mirror", "grille", "grill", "roof", "panel", "bed", "cab", "diffuser", "splitter", "lip", "flare", "bar", "rack", "glass", "window", "paint", "skin", "plate", "decal", "livery"] },
  { id: "cargo", label: "Carga e acessórios", icon: "boxPickUp03", keys: ["cargo", "load", "trailer", "hitch", "tow", "winch", "toolbox"] },
]
const OTHER = { id: "other", label: "Outras peças", icon: "cogs" }

const data = shallowRef(null)
const cat = ref("all")
const query = ref("")
const sort = ref("slot")
const hideInstalled = ref(false)
const page = ref(1)
const working = ref(false)
const busy = ref(false)
const busyText = ref("")
const confirm = ref(null)
const launching = ref(false)
const vehicleName = ref("")
const inventoryId = ref(null)
const listEl = ref(null)
const photos = reactive({})
let offs = [], workTimer = null, busyTimer = null, photoTimer = null, started = false, firstData = true

/* ---------------- launcher ---------------- */
const launchVehicles = computed(() => arr(rl.view.computer?.vehicles).map(v => ({
  ...v, fn: rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.partShop,
})))
function reasonText(fn) { const r = fn?.reason; return (typeof r?.label === "string" ? r.label : r?.label?.txt) || "Indisponível agora" }
function launch(v) {
  desk.partsMode = "store"
  launching.value = true
  setTimeout(() => (launching.value = false), 8000)
  request("native", { buttonId: "partShop", inventoryId: v.inventoryId })
}

/* ---------------- shop data ---------------- */
const partsInShop = computed(() => arr(data.value?.partsInShop).filter(Boolean))
const niceNames = computed(() => data.value?.slotsNiceName || {})
const slotNice = s => (s && niceNames.value[s]) || s || ""
const tutorialNames = computed(() => data.value?.tutorialPartNames)
const tutorial = computed(() => tutorialNames.value !== undefined && tutorialNames.value !== null)
const restoring = computed(() => !!data.value?.restoreInProgress)
const restoreProgress = computed(() => data.value?.restoreProgress || { current: 0, total: 0 })
const playerMoney = computed(() => (data.value && data.value.playerMoney !== null && isFinite(Number(data.value.playerMoney)) ? Number(data.value.playerMoney) : null))
const blocked = computed(() => restoring.value || working.value || busy.value)

function categoryOf(p) {
  if (String(p.name || "").includes("cargo_load")) return "cargo"
  const text = (String(p.slot || "") + " " + String(niceNames.value[p.slot] || "")).toLowerCase()
  for (const c of CATEGORIES) if (c.keys.some(k => text.includes(k))) return c.id
  return "other"
}
function catLabel(id) { return id === "all" ? "Todas as peças" : (CATEGORIES.find(c => c.id === id) || OTHER).label }
function catIcon(id) { return (CATEGORIES.find(c => c.id === id) || OTHER).icon }
const sellable = computed(() => partsInShop.value.filter(p => p.slot && !p.emptyPlaceholder))
const categoryList = computed(() => {
  const counts = {}
  for (const p of sellable.value) { const c = categoryOf(p); counts[c] = (counts[c] || 0) + 1 }
  const list = [{ id: "all", label: "Todas as peças", icon: "listBig", count: sellable.value.length }]
  for (const c of [...CATEGORIES, OTHER]) if (counts[c.id]) list.push({ ...c, count: counts[c.id] })
  return list
})

const nodeByPath = computed(() => {
  const map = {}
  const walk = n => { if (!n) return; if (n.path) map[n.path] = n; for (const c of arr(n.children)) walk(c) }
  walk(data.value?.partTree)
  return map
})
function currentIn(slotPath) { const n = nodeByPath.value[slotPath]; return n && n.chosenPartName ? (n.chosenPartNiceName || n.chosenPartName) : "" }
function partKey(p) { return p.partShopId != null ? "shop-" + p.partShopId : p.partId != null ? "inv-" + p.partId : (p.containingSlot || "") + "-" + (p.name || "") }
function partLabel(p) { return (p.description?.description || p.name) + (p.partId != null ? " (estoque)" : "") }

const filtered = computed(() => {
  const q = query.value.toLowerCase()
  let list = sellable.value.filter(p => {
    if (q) return String(p.description?.description || p.name || "").toLowerCase().includes(q) || String(slotNice(p.slot)).toLowerCase().includes(q)
    return cat.value === "all" || categoryOf(p) === cat.value
  })
  if (hideInstalled.value) list = list.filter(p => !isInstalled(p))
  const price = p => (p.partId != null ? 0 : Number(p.finalValue) || 0)
  const name = p => String(p.description?.description || p.name || "")
  if (sort.value === "low") list.sort((a, b) => price(a) - price(b))
  else if (sort.value === "high") list.sort((a, b) => price(b) - price(a))
  else if (sort.value === "name") list.sort((a, b) => name(a).localeCompare(name(b)))
  else list.sort((a, b) => String(slotNice(a.slot)).localeCompare(String(slotNice(b.slot))) || (a.containingSlot || "").localeCompare(b.containingSlot || "")
    || (isInstalled(b) - isInstalled(a)) || price(a) - price(b))
  return list
})
const pages = computed(() => Math.max(1, Math.ceil(filtered.value.length / PAGE)))
const pageItems = computed(() => filtered.value.slice((page.value - 1) * PAGE, page.value * PAGE))
// Cards of the page grouped by slot, with the slot's "remove" option when the shop offers one.
const pageGroups = computed(() => {
  const groups = []
  for (const p of pageItems.value) {
    let g = sort.value === "slot" ? groups.find(x => x.slot === p.containingSlot) : groups[0]
    if (!g) {
      g = sort.value === "slot"
        ? { slot: p.containingSlot, slotName: slotNice(p.slot), current: currentIn(p.containingSlot), parts: [],
            remove: partsInShop.value.find(x => x.emptyPlaceholder && x.containingSlot === p.containingSlot && currentIn(p.containingSlot)) }
        : { slot: "all", slotName: catLabel(query.value ? "all" : cat.value), current: "", parts: [] }
      groups.push(g)
    }
    g.parts.push(p)
  }
  return groups.map(g => (sort.value === "slot" ? g : { ...g, current: null }))
})
function pickCat(id) { cat.value = id; query.value = ""; setPage(1) }
function setPage(n) { page.value = n; nextTick(() => { if (listEl.value) listEl.value.scrollTop = 0 }) }
watch([query, sort, hideInstalled], () => setPage(1))

/* ---------------- photos ---------------- */
function askPhotos() {
  clearTimeout(photoTimer)
  photoTimer = setTimeout(() => {
    if (inventoryId.value == null) return
    const want = pageItems.value.filter(p => photos[p.name] === undefined).map(p => ({ name: p.name, slot: p.containingSlot }))
    if (want.length) request("partPhotos", { inventoryId: Number(inventoryId.value), parts: want, reset: true })
  }, 250)
}
watch(() => [pageItems.value.map(p => p.name).join("|"), inventoryId.value], askPhotos)
// photos[name]: a url, "shoot" (mounted, no photo yet), "try" (not mounted: photographed once added to the
// cart) or false (nothing to see). undefined while the game answers.
function onPhoto(e) {
  if (!e || !e.name) return
  photos[e.name] = e.url ? e.url : e.notMounted ? "try" : e.missing ? "shoot" : false
}
function hasPhoto(name) { const v = photos[name]; return typeof v === "string" && v !== "try" && v !== "shoot" }
function photoNote(name) {
  const v = photos[name]
  return v === "try" ? "Adicione para ver a foto" : v === "shoot" ? "Sem foto ainda" : ""
}
const shootable = computed(() => pageItems.value.filter(p => photos[p.name] === "shoot"))
function shoot(parts) {
  if (inventoryId.value == null || !parts.length) return
  for (const p of parts) photos[p.name] = undefined
  request("partPhotos", { inventoryId: Number(inventoryId.value), parts: parts.map(p => ({ name: p.name, slot: p.containingSlot })), shoot: true })
}
function shootPage() { shoot(shootable.value) }
// Parts the cart just mounted on the car get their photo right away.
function retryMounted() {
  const names = new Set(cartIn.value.map(c => c.name))
  const parts = []
  for (const p of partsInShop.value) {
    if (names.has(p.name) && !hasPhoto(p.name) && photos[p.name] !== false) { parts.push(p); names.delete(p.name) }
  }
  shoot(parts)
}

/* ---------------- cart ---------------- */
const cart = computed(() => data.value?.shoppingCart || {})
const cartIn = computed(() => arr(cart.value.partsInList).filter(Boolean))
const cartOut = computed(() => arr(cart.value.partsOutList).filter(Boolean))
const total = computed(() => Number(cart.value.total) || 0)
const taxes = computed(() => Number(cart.value.taxes) || 0)
const subtotal = computed(() => total.value - taxes.value)
const tooExpensive = computed(() => total.value > 0 && playerMoney.value !== null && total.value > playerMoney.value)
const canBuy = computed(() => cartIn.value.length > 0 && !tooExpensive.value && !blocked.value)
const sameId = (a, b) => (a ?? null) === (b ?? null)
function cartPartOf(p) { return cartIn.value.find(c => sameId(c.partId, p.partId) && c.name === p.name && c.containingSlot === p.containingSlot) || null }
function cartName(c) { return c.emptyPlaceholder ? "Tirar: " + (slotNice(c.slot) || "peça") : (c.description?.description || c.name) + (c.partId != null ? " (estoque)" : "") }
function isInstalled(p) {
  const own = data.value?.vehicleSlotToPartMap?.[p.containingSlot]
  return !!own && !!p.description?.description && own.description?.description === p.description.description && !cartPartOf(p)
}
function buttonOf(p) {
  const inCart = cartPartOf(p)
  const removable = !!inCart && !!inCart.sourcePart
  const tut = tutorial.value && (!tutorialNames.value[p.name] || removable)
  const disabled = blocked.value || !!p.disabled || tut || (!!inCart && !inCart.sourcePart)
  if (removable) return { label: "Tirar do carrinho", kind: "", disabled, title: "", action: () => removeSlot(p.containingSlot) }
  if (inCart) return { label: "Incluída", kind: "", disabled: true, title: "Vem junto com outra peça do carrinho", action: () => {} }
  if (isInstalled(p)) return { label: "Instalada", kind: "", disabled: true, title: "Esta peça já está no carro", action: () => {} }
  return { label: "Adicionar", kind: "primary", disabled, title: p.disabledReason || "Monta no carro e põe no carrinho", action: () => install(p) }
}
function startWork() {
  working.value = true
  clearTimeout(workTimer)
  workTimer = setTimeout(() => (working.value = false), 8000)
}
function install(p) {
  if (p?.partShopId == null) return
  startWork()
  luaCall("career_modules_partShopping.installPartByPartShopId(" + Number(p.partShopId) + ")")
}
function removeSlot(containingSlot) {
  startWork()
  luaCall("career_modules_partShopping.removePartBySlot(" + luaString(String(containingSlot)) + ")")
}
function setBusy(text, ms) {
  busy.value = true
  busyText.value = text
  clearTimeout(busyTimer)
  busyTimer = setTimeout(() => { busy.value = false; toast("O RLS não respondeu. Tente de novo.", "error") }, ms)
}
const keepShopping = () => (confirm.value = null)
function askBuy() {
  if (!canBuy.value) return
  confirm.value = { title: "Finalizar a compra?", text: "Você paga " + dollars(total.value, true) + " e as peças ficam no carro. As peças trocadas vão para Minhas peças.",
    buttons: [{ label: "Pagar " + dollars(total.value, true), kind: "go", action: buy }, { label: "Voltar", kind: "", action: keepShopping }] }
}
function buy() {
  confirm.value = null
  setBusy("Pagando e instalando as peças…", 12000)
  luaCall("career_modules_partShopping.applyShopping()")
}
function discard() {
  confirm.value = null
  setBusy("Devolvendo o carro como estava…", 12000)
  luaCall("career_modules_partShopping.discardShopping()")
}
function saveForLater() {
  confirm.value = null
  setBusy("Guardando o carrinho…", 12000)
  luaCall("career_modules_partShopping.saveCartForLater()")
}
function askDiscard() {
  if (!cartIn.value.length) return
  confirm.value = { title: "Esvaziar o carrinho?", text: "As peças do carrinho saem do carro e ele volta a ser como era.",
    buttons: [{ label: "Esvaziar", kind: "danger", action: discard }, { label: "Voltar", kind: "", action: keepShopping }] }
}
function askSave() {
  if (!cartIn.value.length || restoring.value) return
  confirm.value = { title: "Salvar o carrinho para depois?", text: "O carrinho fica guardado para este carro e ele volta ao estado atual. Na próxima visita as peças voltam para o carrinho.",
    buttons: [{ label: "Salvar e sair", kind: "primary", action: saveForLater }, { label: "Voltar", kind: "", action: keepShopping }] }
}
function peek() { desk.peek = true }
// Tab X, "Sair da loja" and the game's back key: leave, asking what to do with a non-empty cart.
function requestClose() {
  if (!props.route) { emit("close"); return }
  if (busy.value) return
  if (!cartIn.value.length) { discard(); return }
  const buttons = [{ label: "Esvaziar e sair", kind: "danger", action: discard }]
  if (!restoring.value) buttons.push({ label: "Salvar e sair", kind: "primary", action: saveForLater })
  buttons.push({ label: "Continuar comprando", kind: "", action: keepShopping })
  confirm.value = { title: "Sair da RiverPeças?", text: "O carrinho ainda não foi pago. Você pode esvaziar o carrinho ou guardá-lo para a próxima visita.", buttons }
}
defineExpose({ requestClose })

/* ---------------- RLS session ---------------- */
function onData(d) {
  if (!d || typeof d !== "object") return
  data.value = d
  working.value = false
  clearTimeout(workTimer)
  // The car is rebuilt after each cart change: give it a moment before shooting the new parts.
  setTimeout(retryMounted, 1500)
  if (firstData) {
    firstData = false
    findVehicle(d)
  }
}
async function findVehicle(d) {
  const owned = Object.values(d.vehicleSlotToPartMap || {}).find(p => p && p.location != null)
  const id = owned?.location
  if (id == null) return
  inventoryId.value = id
  let name = arr(rl.view.computer?.vehicles).find(v => String(v.inventoryId) === String(id))?.niceName
  if (!name) name = await luaRun("local v = career_modules_inventory.getVehicles()[" + Number(id) + "] return v and v.niceName or nil")
  if (typeof name === "string" && name) { vehicleName.value = name; emit("title", name) }
}
function start() {
  if (started || !props.route) return
  started = true
  dropGuard()
  offs.push(onGameEvent("partShoppingData", onData))
  offs.push(onGameEvent("partShoppingRequestExit", requestClose))
  luaCall("career_modules_partShopping.sendShoppingDataToUI()")
}
onMounted(() => {
  offs.push(onGameEvent("RiverLifePartPhoto", onPhoto))
  start()
})
watch(() => props.route, r => { if (r) start() })
onUnmounted(() => {
  for (const off of offs) off()
  offs = []
  clearTimeout(workTimer); clearTimeout(busyTimer); clearTimeout(photoTimer)
  typing(false)
  if (!started) return
  // Like the RLS view: the session ends when the screen goes away; a desktop remount between part
  // shopping routes keeps it (the tab is still there).
  const now = String(window.vueRouter?.currentRoute?.value?.name || "")
  const tabAlive = desk.tabs.some(t => t.history.some(pg => pg.props && pg.props.nonce === props.nonce))
  if (!(now.startsWith(ROUTE_PREFIX) && tabAlive)) {
    desk.peek = false
    luaCall("career_modules_partShopping.cancelShopping()")
    return
  }
  dropGuard()
  if (window.vueRouter?.afterEach) {
    routeGuard = window.vueRouter.afterEach(to => {
      if (String(to?.name || "").startsWith(ROUTE_PREFIX)) return
      dropGuard()
      desk.peek = false
      luaCall("career_modules_partShopping.cancelShopping()")
    })
  }
})
</script>

<style scoped>
.ps { display: flex; flex-direction: column; height: 100%; min-height: 100%; background: #f3f5f8; font: 13px Tahoma, Verdana, sans-serif; color: #1b2733; position: relative; }
.ps-head { display: flex; align-items: center; gap: 16px; padding: 10px 18px; color: #fff; background: linear-gradient(180deg, #e8742c, #c4501b); border-bottom: 3px solid #ffb36b; }
.ps-logo { display: flex; align-items: baseline; gap: 8px; font-size: 22px; white-space: nowrap; }
.ps-logo b { font: bold 24px "Trebuchet MS", Tahoma, sans-serif; letter-spacing: -1px; } .ps-logo b span { color: #ffe08a; }
.ps-logo small { font-size: 11.5px; opacity: .9; }
.ps-search { flex: 1; display: flex; align-items: center; gap: 6px; background: #fff; color: #555; border-radius: 3px; padding: 0 8px; max-width: 640px; }
.ps-search input { flex: 1; border: 0; outline: 0; padding: 7px 2px; font: 13px Tahoma, sans-serif; color: #111; user-select: text; }
.ps-wallet { margin-left: auto; text-align: right; } .ps-wallet small { display: block; font-size: 10.5px; text-transform: uppercase; opacity: .85; } .ps-wallet b { font-size: 17px; }
.ps-launch { padding: 20px 26px; overflow: auto; }
.ps-warn { margin: 10px 0; padding: 8px 12px; border: 1px solid #e8c76c; background: #fff7d6; color: #6b4b00; border-radius: 3px; }
.ps-cars { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; margin-top: 14px; }
.ps-car { background: #fff; border: 1px solid #d5dde8; border-radius: 6px; overflow: hidden; display: flex; flex-direction: column; }
.ps-car-photo { aspect-ratio: 16/9; background: #e7edf5; display: flex; align-items: center; justify-content: center; font-size: 48px; color: #9aa9bb; }
.ps-car-photo img { width: 100%; height: 100%; object-fit: cover; }
.ps-car-body { display: flex; flex-direction: column; gap: 6px; padding: 10px 12px; } .ps-car-body .rl-btn { align-self: flex-start; }
.ps-main { flex: 1; min-height: 0; display: grid; grid-template-columns: 210px 1fr 290px; }
.ps-side { overflow: auto; padding: 10px 8px; background: #fff; border-right: 1px solid #dde3ec; }
.ps-cat { width: 100%; display: flex; align-items: center; gap: 8px; padding: 7px 9px; border: 0; border-radius: 4px; background: none; cursor: pointer; font: 12.5px Tahoma, sans-serif; color: #1b2733; text-align: left; }
.ps-cat span { flex: 1; } .ps-cat small { color: #7a8796; font-size: 11px; }
.ps-cat:hover { background: #eef3fa; } .ps-cat.on { background: #fde6d4; color: #8a3a0f; font-weight: bold; } .ps-cat.on small { color: #8a3a0f; }
.ps-list { overflow: auto; padding: 12px 16px 20px; }
.ps-bar { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; flex-wrap: wrap; }
.ps-bar > b { font-size: 16px; color: #8a3a0f; } .grow { flex: 1; }
.ps-check { display: flex; align-items: center; gap: 5px; font-size: 12px; }
.ps-slot { display: flex; align-items: baseline; gap: 10px; margin: 14px 0 6px; padding-bottom: 4px; border-bottom: 1px solid #e1e6ee; flex-wrap: wrap; }
.ps-slot b { font-size: 13.5px; color: #1d3f69; }
.ps-link { border: 0; background: none; color: #0645ad; cursor: pointer; font: 12px Tahoma, sans-serif; padding: 0; text-decoration: underline; }
.ps-link:disabled { color: #999; cursor: default; }
.ps-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 10px; }
.ps-card { display: flex; flex-direction: column; background: #fff; border: 1px solid #d5dde8; border-radius: 6px; overflow: hidden; transition: box-shadow .12s; }
.ps-card:hover { box-shadow: 0 3px 10px rgba(40,60,90,.16); border-color: #b9c7da; }
.ps-card.installed { border-color: #9fd696; } .ps-card.incart { border-color: #f0a35e; box-shadow: 0 0 0 2px #fde2c6; } .ps-card.off { opacity: .6; }
.ps-photo { position: relative; aspect-ratio: 4/3; background: radial-gradient(circle at 50% 40%, #fdfdfd, #dfe5ee); overflow: hidden; }
/* Shots are taken without extra lights (garages can be dim): lift them a little. */
.ps-photo img { width: 100%; height: 100%; object-fit: cover; display: block; filter: brightness(1.35) contrast(1.08) saturate(1.1); }
.ps-noimg { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; color: #9aa9bb; font-size: 40px; }
.ps-noimg small { font-size: 11px; }
/* Category artwork while there is no photo: the category icon on its own color. */
.ps-noimg { font-size: 54px; color: rgba(255,255,255,.92); background: linear-gradient(145deg, #8a9bb3, #4d5f78); }
.ps-noimg.c-wheels { background: linear-gradient(145deg, #5b6573, #262c35); } .ps-noimg.c-brakes { background: linear-gradient(145deg, #e0675a, #8e2318); }
.ps-noimg.c-intake { background: linear-gradient(145deg, #6fb7e8, #1d5f99); } .ps-noimg.c-exhaust { background: linear-gradient(145deg, #a0a0a0, #4a4a4a); }
.ps-noimg.c-engine { background: linear-gradient(145deg, #f0a35e, #b2410f); } .ps-noimg.c-drivetrain { background: linear-gradient(145deg, #9b8be0, #4b3a99); }
.ps-noimg.c-suspension { background: linear-gradient(145deg, #7cc78a, #2f7a3c); } .ps-noimg.c-lights { background: linear-gradient(145deg, #f6d36b, #c08a00); }
.ps-noimg.c-interior { background: linear-gradient(145deg, #c59bff, #6b2fc0); } .ps-noimg.c-body { background: linear-gradient(145deg, #5fa0e6, #1b4f96); }
.ps-noimg.c-cargo { background: linear-gradient(145deg, #c7a77a, #7a5a2b); }
.ps-noimg small { color: #fff; text-shadow: 0 1px 2px rgba(0,0,0,.4); }
.ps-noimg.loading { background: linear-gradient(100deg, transparent 30%, rgba(255,255,255,.7) 50%, transparent 70%) #e3e9f1; background-size: 200% 100%; animation: ps-shine 1.2s linear infinite; }
@keyframes ps-shine { from { background-position: 150% 0; } to { background-position: -50% 0; } }
.ps-flag { position: absolute; left: 6px; top: 6px; padding: 2px 7px; border-radius: 9px; font-size: 10.5px; font-weight: bold; color: #fff; }
.ps-flag.ok { background: #2f8a22; } .ps-flag.cart { background: #e46a00; } .ps-flag.stock { background: #2a5db0; }
.ps-info { display: flex; flex-direction: column; gap: 2px; padding: 7px 9px 4px; min-height: 52px; }
.ps-info b { font-size: 12.5px; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.ps-info small { font-size: 11px; }
.ps-buy { display: flex; align-items: center; justify-content: space-between; gap: 6px; padding: 6px 9px 9px; margin-top: auto; }
.ps-price { font: bold 15px Tahoma, sans-serif; color: #b2410f; }
.rl-btn.sm { padding: 4px 9px; font-size: 11.5px; }
.ps-pager { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 16px 0 4px; }
.ps-cart { display: flex; flex-direction: column; gap: 8px; padding: 12px; overflow: auto; background: #fff; border-left: 1px solid #dde3ec; }
.ps-cart h3 { display: flex; align-items: center; gap: 6px; margin: 0; font-size: 15px; color: #8a3a0f; }
.ps-cart-list { display: flex; flex-direction: column; gap: 6px; }
.ps-cart-row { display: flex; align-items: center; gap: 6px; padding: 5px; border: 1px solid #e6ebf2; border-radius: 4px; font-size: 12px; }
.ps-cart-row img { width: 42px; height: 32px; object-fit: cover; border-radius: 2px; }
.ps-cart-name { flex: 1; min-width: 0; } .ps-cart-name small { display: block; color: #7a8796; font-size: 10.5px; }
.ps-cart-price { font-weight: bold; white-space: nowrap; }
.ps-cart-row.out { color: #6a7685; border-style: dashed; }
.ps-out { margin: 6px 0 0; font-size: 11.5px; color: #6a7685; }
.ps-x { width: 20px; height: 20px; border: 0; border-radius: 3px; background: #f1f3f6; cursor: pointer; font: bold 13px Tahoma, sans-serif; color: #555; }
.ps-x:hover:not(:disabled) { background: #d2421f; color: #fff; }
.ps-sums { display: flex; flex-direction: column; gap: 3px; padding: 8px 0; border-top: 1px solid #e1e6ee; font-size: 12.5px; }
.ps-sums span { display: flex; justify-content: space-between; } .ps-sums .tot { font-size: 15px; color: #8a3a0f; }
.ps-wide { width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; }
.ps-cart-more { justify-content: space-between; } .ps-cart-more .rl-btn { flex: 1; }
.ps-mask { position: absolute; inset: 0; z-index: 5; display: flex; align-items: center; justify-content: center; background: rgba(20, 30, 50, .25); }
.ps-dialog { max-width: 420px; padding: 16px 18px; background: #fff; border: 1px solid #0b3aa1; border-radius: 6px; box-shadow: 4px 6px 18px rgba(0,0,0,.35); }
.ps-dialog p { line-height: 1.5; } .ps-dialog .rl-row { justify-content: flex-end; }
@media (max-width: 1100px) { .ps-main { grid-template-columns: 170px 1fr 240px; } }
</style>
