<template>
  <div class="rl-page agenda">
    <h2 class="rl-h1">Agenda e negociações</h2>
    <p class="rl-muted">A compra só fecha com comprador, vendedor e carro juntos no local. Propostas valem 5 minutos.</p>
    <div class="tabs rl-row">
      <button v-for="t in tabs" :key="t.id" class="rl-btn" :class="{ primary: tab === t.id }" @click="tab = t.id">{{ t.label }} <span v-if="t.count">({{ t.count }})</span></button>
    </div>

    <template v-if="tab === 'open'">
      <div v-if="!open.length" class="rl-empty"><b>Agenda livre</b>Marque uma visita num anúncio ou coloque carros no estoque da sua loja.</div>
      <article v-for="v in open" :key="v.id" class="rl-box visit" :class="{ live: v.status === 'arrived' }">
        <div class="rl-row between">
          <b>{{ listingTitle(v.listingId) }}</b>
          <span class="rl-badge" :class="v.status === 'arrived' ? 'ok' : 'warn'">{{ status(v.status) }}</span>
        </div>
        <p class="rl-muted">{{ v.buyer === me.id ? "Você vai comprar" : (v.npc ? "Cliente NPC" : "Comprador: " + nameOf(v.buyer)) }} · {{ dateTime(v.scheduledAt) }}
          · {{ distanceText(distance(rl.view.position, v.position)) }} do local · reserva {{ money(v.deposit) }} · expira {{ dateTime(v.expiresAt) }}</p>
        <div class="rl-row">
          <button class="rl-btn" @click="request('gps', { position: v.position })">Marcar GPS</button>
          <button v-if="v.buyer === me.id && v.status === 'scheduled'" class="rl-btn go" @click="request('arrive', { visitId: v.id })">Cheguei</button>
          <button class="rl-btn" @click="request('cancelVisit', { visitId: v.id })">Cancelar visita</button>
        </div>
        <template v-if="v.status === 'arrived'">
          <p v-if="v.seller !== me.id && v.buyer !== me.id" class="rl-badge">Você atende pela loja (comissão na venda)</p>
          <div v-for="o in offersOf(v.id)" :key="o.id" class="offer" :class="{ theirs: theirs(v, o) }">
            <span>{{ !theirs(v, o) ? "Proposta do nosso lado" : "Proposta de " + (v.npc ? "cliente" : nameOf(o.from)) }}: <b>{{ money(o.price) }}</b>
              <small class="rl-muted">· {{ status(o.status) }}</small></span>
            <button v-if="o.status === 'pending' && theirs(v, o)" class="rl-btn go" :disabled="rl.busy.accept" @click="request('accept', { offerId: o.id })">Aceitar e fechar negócio</button>
          </div>
          <form class="rl-row" @submit.prevent="counter(v)">
            <input v-model.number="prices[v.id]" class="rl-input" type="number" min="1" placeholder="Seu valor ($)" required />
            <button class="rl-btn primary" :disabled="rl.busy.offer">{{ offersOf(v.id).length ? "Contraproposta" : "Fazer proposta" }}</button>
            <span class="rl-muted">Anunciado por {{ money(listingPrice(v.listingId)) }}</span>
          </form>
        </template>
      </article>
    </template>

    <template v-else-if="tab === 'services'">
      <div v-if="!myOrders.length" class="rl-empty"><b>Nenhum serviço</b>Leve seu carro a uma oficina pelo site oficinas.river.</div>
      <article v-for="o in myOrders" :key="o.id" class="rl-box">
        <div class="rl-row between"><b>{{ o.vehicle?.niceName }} · {{ o.shopName }}</b><span class="rl-badge">{{ status(o.status) }}</span></div>
        <p v-if="o.quote" class="rl-muted">Orçamento {{ money(o.quote.total) }} · prazo {{ o.quote.minutes }} min</p>
        <div class="rl-row">
          <button v-if="o.status === 'quoted'" class="rl-btn go" @click="request('serviceAccept', { orderId: o.id })">Aprovar {{ money(o.quote.total) }}</button>
          <button v-if="['requested', 'quoted', 'accepted'].includes(o.status)" class="rl-btn" @click="request('serviceDecline', { orderId: o.id })">Cancelar</button>
          <button class="rl-btn" @click="$emit('open', { app: 'internet', props: { start: 'oficinas' } })">Ver detalhes</button>
        </div>
      </article>
    </template>

    <template v-else>
      <table class="rl-table">
        <tr><th>Quando</th><th>Carro</th><th>Com</th><th>Resultado</th></tr>
        <tr v-for="v in history" :key="v.id"><td>{{ dateTime(v.createdAt || v.scheduledAt) }}</td><td>{{ listingTitle(v.listingId) }}</td>
          <td>{{ v.buyer === me.id ? "vendedor " + nameOf(v.seller) : (v.npc ? "cliente NPC" : nameOf(v.buyer)) }}</td><td>{{ status(v.status) }}</td></tr>
      </table>
      <p v-if="!history.length" class="rl-muted">Sem histórico ainda.</p>
    </template>
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch } from "vue"
import { rl, request, money, status, dateTime, distance, distanceText, me, listingTitle, myOrders, openVisits } from "../rl.js"
const props = defineProps({ focus: String, nonce: Number })
defineEmits(["open"])
const tab = ref("open")
const prices = reactive({})
const open = computed(() => [...openVisits.value].sort((a, b) => (b.status === "arrived") - (a.status === "arrived") || a.scheduledAt - b.scheduledAt))
const history = computed(() => (rl.view.visits || []).filter(v => !["scheduled", "arrived"].includes(v.status)).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)))
const tabs = computed(() => [
  { id: "open", label: "Visitas abertas", count: open.value.length },
  { id: "services", label: "Meus serviços", count: myOrders.value.filter(o => !["completed", "declined", "rejected", "expired"].includes(o.status)).length },
  { id: "history", label: "Histórico" },
])
// The buyer's side is the buyer; the seller's side is the seller or the store's staff.
function theirs(v, o) { return v.buyer === me.value.id ? o.from !== me.value.id : o.from === v.buyer }
function offersOf(id) { return (rl.view.offers || []).filter(o => o.visitId === id && ["pending", "accepted"].includes(o.status)) }
function nameOf(id) {
  return (rl.view.accounts || []).find(a => a.id === id)?.name || (rl.view.npcs || []).find(n => n.id === id)?.name || "jogador"
}
function listingPrice(id) { return (rl.view.listings || []).find(l => l.id === id)?.price || 0 }
function counter(v) { request("offer", { visitId: v.id, price: Math.round((prices[v.id] || 0) * 100) }) }
watch(() => props.nonce, () => { tab.value = "open" })
</script>

<style scoped>
.between { justify-content: space-between; }
.tabs { margin: 10px 0; }
.visit.live { border-color: #3aa53a; background: #f2fbf0; }
.offer { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 8px 10px; margin: 6px 0; border: 1px solid #d5e0ec; border-radius: 4px; background: #fff; }
.offer.theirs { border-color: #f0c460; background: #fffaf0; }
</style>
