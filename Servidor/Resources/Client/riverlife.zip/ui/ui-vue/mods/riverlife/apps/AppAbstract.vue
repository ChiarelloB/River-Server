<template>
  <div class="rl-page">
    <h2 class="rl-h1">Ficha do motorista</h2>
    <p class="rl-muted">Seu histórico como motorista: pontuação usada pelas seguradoras, consertos e quanto você já gastou.</p>
    <div v-if="!route" class="rl-box rl-row between">
      <span>Abra a ficha pelo computador da garagem.</span>
      <button class="rl-btn primary" :disabled="!fn || fn.disabled" @click="request('native', { buttonId: 'playerAbstract' })">Abrir</button>
    </div>
    <div v-else-if="!data" class="rl-empty"><b>Carregando...</b></div>
    <template v-else>
      <div class="rl-stats">
        <div><b>{{ fmt(data.driverScore) }}</b><small>Pontuação de motorista</small></div>
        <div><b>{{ tierName }}</b><small>Categoria</small></div>
        <div><b>{{ km(data.totalDistanceDriven) }}</b><small>Distância dirigida</small></div>
        <div><b>{{ data.financialSummary?.vehiclesInsuredCount ?? 0 }}</b><small>Carros segurados</small></div>
      </div>
      <h3 class="rl-h2">Consertos</h3>
      <table class="rl-table">
        <tr><th>Tipo</th><th>Quantidade</th></tr>
        <tr><td>Pelo seguro</td><td>{{ data.repairHistory?.insuranceRepairs ?? 0 }}</td></tr>
        <tr><td>Particulares</td><td>{{ data.repairHistory?.privateRepairs ?? 0 }}</td></tr>
      </table>
      <h3 class="rl-h2">Resumo financeiro</h3>
      <table class="rl-table">
        <tr><td>Prêmios de seguro pagos</td><td>{{ dollars(f.totalPremiumPaid) }}</td></tr>
        <tr><td>Franquias pagas</td><td>{{ dollars(f.totalDeductiblePaid) }}</td></tr>
        <tr><td>Consertos particulares</td><td>{{ dollars(f.totalPrivateRepairsPaid) }}</td></tr>
        <tr><td>Danos cobertos pelo seguro</td><td>{{ dollars(f.damageCoveredByInsurance) }}</td></tr>
        <tr><th>Total pago</th><th>{{ dollars(f.totalPaid) }}</th></tr>
      </table>
      <div v-if="data.driverScoreReset" class="rl-box">
        <b>Limpar a ficha</b>
        <p class="rl-muted">Volta a pontuação para {{ fmt(data.driverScoreReset.resetTo) }} por {{ dollars(data.driverScoreReset.resetCost) }}.</p>
        <div v-if="!confirming" class="rl-row"><button class="rl-btn" :disabled="busy" @click="confirming = true">Limpar ficha</button></div>
        <div v-else class="rl-row"><b>Confirmar o pagamento?</b><button class="rl-btn primary" :disabled="busy" @click="reset">Sim</button><button class="rl-btn" @click="confirming = false">Não</button></div>
      </div>
      <div class="rl-row"><button class="rl-btn" @click="requestClose">Voltar</button></div>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue"
import { rl, request, luaCall, onGameEvent, dollars, km } from "../rl.js"
const props = defineProps({ route: String, routeProps: Object, nonce: Number })
defineEmits(["open", "title", "close"])
const data = ref(null), busy = ref(false), confirming = ref(false)
const fn = computed(() => rl.view.computer?.computerFunctions?.general?.playerAbstract)
const f = computed(() => data.value?.financialSummary || {})
const tierName = computed(() => { const t = data.value?.driverScoreTier; return t?.name || t?.label || t?.tier || "—" })
let off
function fmt(v) { const n = Number(v); return isFinite(n) ? n.toLocaleString("pt-BR", { maximumFractionDigits: 0 }) : "—" }
async function load() { data.value = await luaCall("career_modules_playerAbstract.getPlayerAbstractData()") }
async function reset() {
  busy.value = true
  await luaCall("career_modules_insurance_insurance.resetDriverScore()")
  await load(); busy.value = false; confirming.value = false
}
function requestClose() { luaCall("career_modules_playerAbstract.closePlayerAbstractMenu()") }
defineExpose({ requestClose })
onMounted(() => {
  if (!props.route) return
  off = onGameEvent("playerAbstractData", d => { data.value = d })
  load()
})
onUnmounted(() => off && off())
</script>

<style scoped>
.between { justify-content: space-between; }
</style>
