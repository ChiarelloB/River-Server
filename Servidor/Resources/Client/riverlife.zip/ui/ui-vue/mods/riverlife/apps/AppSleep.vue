<template>
  <div v-if="!hosted" class="rl-page sl-launch">
    <div class="sl-intro">
      <div class="sl-intro-icon"><BngIcon type="calendar" /></div>
      <div>
        <h2 class="rl-h1">Dormir</h2>
        <p class="rl-muted">Descanse até a hora que quiser. Você acorda na garagem mais próxima, com o relógio do jogo ajustado.</p>
        <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>O descanso só está disponível nos computadores das suas garagens.</div>
        <template v-else-if="fn">
          <button class="rl-btn primary" :disabled="fn.disabled" @click="launch">Escolher horário para acordar</button>
          <p v-if="fn.disabled && reasonText(fn)" class="rl-error">{{ reasonText(fn) }}</p>
        </template>
        <div v-else class="rl-empty"><b>Indisponível aqui</b>Este computador não tem a opção de dormir.</div>
      </div>
    </div>
  </div>

  <div v-else class="sl">
    <div class="sl-sky" :style="{ background: sky.bg }">
      <div class="sl-stars" :class="{ on: sky.night }"></div>
      <svg ref="dial" class="sl-dial" viewBox="0 0 200 200" @pointerdown="dialDown" aria-label="Relógio de 24 horas">
        <defs>
          <linearGradient id="slDay" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#8fd0ff" /><stop offset="1" stop-color="#ffe9a8" />
          </linearGradient>
          <linearGradient id="slNight" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#26407a" /><stop offset="1" stop-color="#0b1633" />
          </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="94" fill="#f4f1e6" stroke="#7f8ea3" stroke-width="2" />
        <path d="M 14 100 A 86 86 0 0 1 186 100 Z" fill="url(#slDay)" />
        <path d="M 14 100 A 86 86 0 0 0 186 100 Z" fill="url(#slNight)" />
        <g v-for="t in ticks" :key="t.h">
          <line :x1="t.x1" :y1="t.y1" :x2="t.x2" :y2="t.y2" :stroke="t.night ? '#c9d6f2' : '#3b4a5e'" :stroke-width="t.major ? 2.2 : 1" />
          <text v-if="t.major" :x="t.tx" :y="t.ty" class="sl-dial-num" :fill="t.night ? '#e8eefc' : '#1f2d40'">{{ t.label }}</text>
        </g>
        <line v-if="nowMinutes != null" x1="100" y1="100" :x2="pointAt(nowMinutes, 60).x" :y2="pointAt(nowMinutes, 60).y" stroke="#9aa6b6" stroke-width="3" stroke-linecap="round" stroke-dasharray="4 3" />
        <line x1="100" y1="100" :x2="hand.x" :y2="hand.y" stroke="#c0392b" stroke-width="4" stroke-linecap="round" />
        <circle :cx="hand.x" :cy="hand.y" r="9" :fill="sky.night ? '#e9eef8' : '#ffd23f'" :stroke="sky.night ? '#8da2c8' : '#e08a00'" stroke-width="2" />
        <circle cx="100" cy="100" r="5" fill="#2b3a4f" />
      </svg>
      <div class="sl-readout">
        <small>Acordar às</small>
        <b>{{ fmt(selMinutes) }}</b>
        <span>{{ periodLabel(selMinutes) }}</span>
        <span v-if="nowMinutes != null" class="sl-dur">Agora no jogo: {{ fmt(nowMinutes) }} · {{ durationText }}</span>
      </div>
    </div>

    <div class="sl-body">
      <div v-if="!loaded" class="rl-empty"><b>Lendo o relógio...</b>Carregando o horário do jogo.</div>
      <template v-else>
        <h3 class="rl-h2">Atalhos</h3>
        <div class="sl-presets">
          <button v-for="p in PRESETS" :key="p.id" class="sl-preset" :class="{ on: Math.abs(tod - p.tod) < 0.0005 }" @click="setTod(p.tod)">
            <span class="sl-swatch" :style="{ background: p.color }"></span>
            <b>{{ p.label }}</b><small>{{ fmt(toMinutes(p.tod)) }}</small>
          </button>
        </div>

        <h3 class="rl-h2">Ajuste fino</h3>
        <div class="sl-slider">
          <input v-model.number="sliderMinutes" type="range" min="0" max="1435" step="5" aria-label="Hora de acordar" />
          <div class="sl-scale"><span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>23:55</span></div>
        </div>
        <div class="rl-row sl-adjust">
          <button class="rl-btn" @click="shift(-60)">−1 h</button>
          <button class="rl-btn" @click="shift(-10)">−10 min</button>
          <button class="rl-btn" @click="shift(10)">+10 min</button>
          <button class="rl-btn" @click="shift(60)">+1 h</button>
        </div>

        <label class="sl-cycle rl-box">
          <input v-model="cycle" type="checkbox" :disabled="busy" @change="toggleCycle" />
          <span><b>Ciclo de dia e noite</b><small class="rl-muted">Com o ciclo ligado, o relógio do jogo continua andando depois que você acorda. Desligado, o horário fica parado.</small></span>
        </label>
      </template>
    </div>

    <footer class="sl-foot">
      <span class="rl-muted">Você acorda na garagem mais próxima.</span>
      <div class="rl-row">
        <button class="rl-btn" :disabled="busy" @click="requestClose">Cancelar</button>
        <button class="rl-btn go sl-go" :disabled="busy || !loaded" @click="sleepNow"><BngIcon type="calendar" /> Dormir até {{ fmt(selMinutes) }}</button>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaRun, toast } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])

// RLS time of day: 0 = noon, 0.5 = midnight (one hour = 1/24).
const PRESETS = [
  { id: "sunrise", label: "Amanhecer", tod: 0.77, color: "linear-gradient(180deg,#ffb36b,#7fb2ef)" },
  { id: "noon", label: "Meio-dia", tod: 0, color: "linear-gradient(180deg,#5aa2ee,#cfeaff)" },
  { id: "sunset", label: "Pôr do sol", tod: 0.22, color: "linear-gradient(180deg,#ff8c5a,#5a3f86)" },
  { id: "midnight", label: "Meia-noite", tod: 0.5, color: "linear-gradient(180deg,#0b1633,#26407a)" },
]

const hosted = computed(() => !!props.route)
const fn = computed(() => rl.view.computer?.computerFunctions?.general?.sleep)
const tod = ref(0)
const nowTod = ref(null)
const cycle = ref(true)
const loaded = ref(false)
const busy = ref(false)
const dial = ref(null)

// engineLua callbacks never fire when the Lua side errors: never wait forever.
function callT(expr, ms = 8000) { return Promise.race([luaCall(expr), new Promise(r => setTimeout(() => r(undefined), ms))]) }
function label(l) { return typeof l === "string" ? l : l?.txt || l?.label || "" }
function reasonText(f) { return label(f?.reason?.label) || label(f?.reason) }
function launch() { request("native", { buttonId: "sleep" }) }

function toMinutes(t) { return Math.round((((Number(t) || 0) * 24 + 12) % 24) * 60) % 1440 }
function toTod(minutes) { return ((((minutes / 60) - 12) / 24) % 1 + 1) % 1 }
function fmt(m) { return String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0") }
function periodLabel(m) {
  const h = m / 60
  if (h >= 5 && h < 7.5) return "Amanhecer"
  if (h >= 7.5 && h < 12) return "Manhã"
  if (h >= 12 && h < 17) return "Tarde"
  if (h >= 17 && h < 19.5) return "Fim de tarde"
  return "Noite"
}

const selMinutes = computed(() => toMinutes(tod.value))
const nowMinutes = computed(() => nowTod.value == null ? null : toMinutes(nowTod.value))
const sliderMinutes = computed({
  get: () => Math.round(selMinutes.value / 5) * 5 % 1440,
  set: v => { tod.value = toTod(Number(v) || 0) },
})
const durationText = computed(() => {
  if (nowMinutes.value == null) return ""
  const d = (selMinutes.value - nowMinutes.value + 1440) % 1440
  if (d === 0) return "mesmo horário de agora"
  const h = Math.floor(d / 60), m = d % 60
  return "descanso de " + (h ? h + " h" : "") + (h && m ? " " : "") + (m ? m + " min" : "")
})

// 24 h dial: midnight at the bottom, noon at the top, sunrise on the left.
function pointAt(minutes, r) {
  const a = (minutes / 1440) * 2 * Math.PI + Math.PI / 2
  return { x: 100 + r * Math.cos(a), y: 100 + r * Math.sin(a) }
}
const hand = computed(() => pointAt(selMinutes.value, 70))
const ticks = computed(() => Array.from({ length: 24 }, (_, h) => {
  const major = h % 6 === 0
  const a = pointAt(h * 60, 86), b = pointAt(h * 60, major ? 74 : 80), t = pointAt(h * 60, 62)
  return { h, major, label: String(h).padStart(2, "0"), x1: a.x, y1: a.y, x2: b.x, y2: b.y, tx: t.x, ty: t.y + 4, night: h < 6 || h > 18 }
}))
const sky = computed(() => {
  const h = selMinutes.value / 60
  if (h >= 5 && h < 7.5) return { bg: "linear-gradient(180deg,#f6a36b 0%,#f7c98d 35%,#8fbbe9 100%)", night: false }
  if (h >= 7.5 && h < 17) return { bg: "linear-gradient(180deg,#3d8ee6 0%,#7fbaf0 55%,#d6edff 100%)", night: false }
  if (h >= 17 && h < 19.5) return { bg: "linear-gradient(180deg,#5a3f86 0%,#d0687a 55%,#ffad6b 100%)", night: false }
  return { bg: "linear-gradient(180deg,#081230 0%,#16295a 60%,#2b467f 100%)", night: true }
})

function setTod(t) { tod.value = ((Number(t) || 0) % 1 + 1) % 1 }
function shift(minutes) { tod.value = toTod((selMinutes.value + minutes + 1440) % 1440) }

let dragging = false
function pointerToMinutes(e) {
  const box = dial.value?.getBoundingClientRect()
  if (!box) return null
  const x = (e.clientX - box.left) / box.width * 200 - 100
  const y = (e.clientY - box.top) / box.height * 200 - 100
  if (Math.hypot(x, y) < 8) return null
  let a = Math.atan2(y, x) - Math.PI / 2
  a = ((a % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)
  return Math.round((a / (2 * Math.PI)) * 1440 / 5) * 5 % 1440
}
function dialMove(e) {
  if (!dragging) return
  const m = pointerToMinutes(e)
  if (m != null) tod.value = toTod(m)
}
function dialUp() {
  dragging = false
  window.removeEventListener("pointermove", dialMove)
  window.removeEventListener("pointerup", dialUp)
}
function dialDown(e) {
  dragging = true
  dialMove(e)
  window.addEventListener("pointermove", dialMove)
  window.addEventListener("pointerup", dialUp)
}

async function load() {
  const r = await callT("career_modules_sleep.getDayNightCycle()")
  cycle.value = r?.play ?? true
  const t = Number(r?.time)
  nowTod.value = Number.isFinite(t) ? ((t % 1) + 1) % 1 : null
  setTod(nowTod.value ?? 0)
  loaded.value = true
}
async function toggleCycle() {
  busy.value = true
  await callT("career_modules_sleep.toggleDayNightCycle(" + (cycle.value ? "true" : "false") + ")")
  busy.value = false
}
async function sleepNow() {
  if (busy.value) return
  busy.value = true
  const t = Math.max(0, Math.min(0.99999, tod.value)).toFixed(5)
  // Same order as the RLS menu: leave the computer, then fade out and sleep.
  luaRun("career_modules_sleep.closeAllMenus() career_modules_sleep.sleep(" + t + ")")
  setTimeout(() => { busy.value = false }, 3000)
}

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  luaCall("career_modules_sleep.closeMenu()")
}
defineExpose({ requestClose })

onMounted(async () => {
  if (!hosted.value) return
  emit("title", "Escolha a hora de acordar")
  try { await load() } catch (err) { loaded.value = true; toast("Não foi possível ler o relógio do jogo.", "error") }
})
onUnmounted(dialUp)
</script>

<style scoped>
.sl-launch .sl-intro { display: flex; gap: 18px; padding: 10px 4px; }
.sl-intro-icon { width: 84px; height: 84px; border-radius: 16px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 46px; color: #fff;
  background: linear-gradient(135deg, #26407a, #0b1633); box-shadow: 0 3px 8px rgba(0,0,0,.25); }
.sl { height: 100%; display: flex; flex-direction: column; background: #fff; }
.sl-sky { position: relative; display: flex; align-items: center; gap: 22px; padding: 16px 22px; border-bottom: 1px solid #aca899; overflow: hidden; transition: background .4s; }
.sl-stars { position: absolute; inset: 0; opacity: 0; transition: opacity .4s; pointer-events: none;
  background-image: radial-gradient(1.5px 1.5px at 12% 22%, #fff, transparent), radial-gradient(1px 1px at 34% 68%, #fff, transparent),
    radial-gradient(1.5px 1.5px at 58% 18%, #fff, transparent), radial-gradient(1px 1px at 76% 44%, #fff, transparent),
    radial-gradient(1.2px 1.2px at 88% 14%, #fff, transparent), radial-gradient(1px 1px at 92% 74%, #fff, transparent); }
.sl-stars.on { opacity: .9; }
.sl-dial { position: relative; width: 190px; height: 190px; flex-shrink: 0; cursor: pointer; touch-action: none; filter: drop-shadow(0 3px 6px rgba(0,0,0,.35)); }
.sl-dial-num { font: bold 11px Tahoma, sans-serif; text-anchor: middle; pointer-events: none; }
.sl-readout { position: relative; display: flex; flex-direction: column; gap: 2px; color: #fff; text-shadow: 0 1px 3px rgba(0,0,0,.55); }
.sl-readout small { font-size: 12px; text-transform: uppercase; letter-spacing: 1.5px; opacity: .9; }
.sl-readout b { font: 300 58px "Trebuchet MS", Tahoma, sans-serif; line-height: 1; letter-spacing: -1px; }
.sl-readout span { font-size: 14px; }
.sl-readout .sl-dur { margin-top: 6px; font-size: 12px; opacity: .92; }
.sl-body { flex: 1; min-height: 0; overflow: auto; padding: 4px 22px 14px; }
.sl-presets { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 8px; }
.sl-preset { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; padding: 8px 10px; border: 1px solid #b9c7da; border-radius: 4px; cursor: pointer; text-align: left;
  font: 12px Tahoma, sans-serif; color: #1b2733; background: linear-gradient(180deg, #fff, #eef3fa); }
.sl-preset:hover { border-color: #f8b636; box-shadow: inset 0 0 0 1px #f8b636; }
.sl-preset.on { border-color: #316ac5; background: #e3edfb; box-shadow: inset 0 0 0 1px #316ac5; }
.sl-preset small { color: #5f7186; }
.sl-swatch { width: 100%; height: 22px; border-radius: 3px; margin-bottom: 4px; border: 1px solid rgba(0,0,0,.15); }
.sl-slider input { width: 100%; accent-color: #316ac5; }
.sl-scale { display: flex; justify-content: space-between; font-size: 10.5px; color: #6d7d90; }
.sl-adjust { margin-top: 8px; }
.sl-cycle { display: flex !important; gap: 10px; align-items: flex-start; cursor: pointer; margin-top: 16px; }
.sl-cycle span { display: flex; flex-direction: column; gap: 3px; }
.sl-foot { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; padding: 8px 14px; background: #ece9d8; border-top: 1px solid #aca899; }
.sl-go { display: inline-flex; align-items: center; gap: 6px; padding: 7px 16px; }
</style>
