<template>
  <div class="rlw" :class="'rlw-' + kind + (kind === 'theme' ? ' rlw-t-' + theme : '')" :style="style" aria-hidden="true">
    <template v-if="kind === 'theme' && theme === 'bliss'">
      <div class="rlw-sun"></div><div class="rlw-cloud c1"></div><div class="rlw-cloud c2"></div><div class="rlw-cloud c3"></div>
      <div class="rlw-hill h1"></div><div class="rlw-hill h2"></div><div class="rlw-hill h3"></div>
    </template>
    <template v-else-if="kind === 'theme' && theme === 'sunset'">
      <div class="rlw-sunset-sun"></div><div class="rlw-sea"></div>
    </template>
    <template v-else-if="kind === 'theme' && theme === 'ocean'">
      <div class="rlw-ocean-sun"></div><div class="rlw-waves"></div>
    </template>
    <template v-else-if="kind === 'theme' && theme === 'highway'">
      <div class="rlw-hw-sun"></div><div class="rlw-hw-hills"></div><div class="rlw-road"><i></i></div>
    </template>
  </div>
</template>

<script setup>
// Original code: RiverOS wallpapers (CSS-drawn themes, a solid color, or a picture from the game).
import { computed } from "vue"

const props = defineProps({ value: Object })
const w = computed(() => props.value && typeof props.value === "object" ? props.value : { kind: "theme", value: "bliss" })
const kind = computed(() => (["theme", "color", "image"].includes(w.value.kind) ? w.value.kind : "theme"))
const theme = computed(() => (kind.value === "theme" ? w.value.value || "bliss" : ""))
const style = computed(() => {
  if (kind.value === "color") return { background: w.value.value }
  if (kind.value === "image") {
    const center = w.value.fit === "center"
    return { backgroundColor: "#1c2533", backgroundImage: "url('" + String(w.value.value).replace(/'/g, "%27") + "')",
      backgroundSize: center ? "auto" : "cover", backgroundPosition: "center", backgroundRepeat: "no-repeat" }
  }
  return {}
})
</script>

<style>
.rlw { position: absolute; inset: 0; overflow: hidden; }
/* Colinas (Bliss) */
.rlw-t-bliss { background: linear-gradient(180deg, #2f7fe3 0%, #5aa2ee 30%, #9fd0f6 58%, #d9eefc 66%); }
.rlw-sun { position: absolute; right: 18%; top: 12%; width: 14%; aspect-ratio: 1; border-radius: 50%; background: radial-gradient(circle, #fffbe6 0%, #fff3b0 40%, rgba(255,243,176,0) 70%); }
.rlw-cloud { position: absolute; height: 5%; border-radius: 40px; background: rgba(255,255,255,.85); filter: blur(1px); box-shadow: 40px -14px 0 6px rgba(255,255,255,.8), 90px 4px 0 -2px rgba(255,255,255,.75); }
.rlw-cloud.c1 { width: 9%; left: 12%; top: 14%; } .rlw-cloud.c2 { width: 12%; left: 46%; top: 8%; opacity: .8; } .rlw-cloud.c3 { width: 7%; left: 70%; top: 26%; opacity: .7; }
.rlw-hill { position: absolute; border-radius: 50%; }
.rlw-hill.h1 { left: -20%; right: 25%; bottom: -55%; height: 105%; background: radial-gradient(ellipse at 50% 18%, #8fd14f 0%, #4f9e2d 45%, #2f6e1b 100%); }
.rlw-hill.h2 { left: 30%; right: -30%; bottom: -62%; height: 100%; background: radial-gradient(ellipse at 45% 15%, #7cc444 0%, #3f8c24 50%, #255b14 100%); }
.rlw-hill.h3 { left: 10%; right: 20%; bottom: -78%; height: 95%; background: radial-gradient(ellipse at 50% 10%, #9bdc5d 0%, #56a832 50%, #2c6a18 100%); opacity: .9; }
/* Azul RiverOS */
.rlw-t-azure { background: radial-gradient(ellipse at 72% 28%, #6aa8ef 0%, #2f6fcd 40%, #163f8c 78%, #0e2c66 100%); }
.rlw-t-azure::after { content: ""; position: absolute; inset: 0; background: repeating-radial-gradient(circle at 72% 28%, rgba(255,255,255,.05) 0 2px, transparent 2px 60px); }
/* Pôr do sol */
.rlw-t-sunset { background: linear-gradient(180deg, #24184a 0%, #5d2a6e 26%, #b7466a 48%, #f08a4b 62%, #ffc879 68%, #ffc879 68.5%, #3c2a4a 69%, #1b1428 100%); }
.rlw-sunset-sun { position: absolute; left: 50%; top: 52%; width: 16%; aspect-ratio: 1; transform: translateX(-50%); border-radius: 50%;
  background: radial-gradient(circle, #fff6cf 0%, #ffd27a 45%, rgba(255,160,80,0) 72%); }
.rlw-sea { position: absolute; left: 0; right: 0; top: 69%; bottom: 0; background: repeating-linear-gradient(180deg, rgba(255,190,120,.18) 0 2px, transparent 2px 9px);
  -webkit-mask-image: radial-gradient(ellipse 30% 70% at 50% 0%, #000 0%, transparent 100%); mask-image: radial-gradient(ellipse 30% 70% at 50% 0%, #000 0%, transparent 100%); }
/* Noite estrelada */
.rlw-t-night { background-color: #050813;
  background-image: radial-gradient(1.5px 1.5px at 20px 30px, #fff, transparent), radial-gradient(1px 1px at 90px 120px, #dfe8ff, transparent),
    radial-gradient(1.5px 1.5px at 160px 60px, #fff, transparent), radial-gradient(1px 1px at 230px 170px, #cfd9ff, transparent),
    radial-gradient(1px 1px at 300px 40px, #fff, transparent), radial-gradient(1.5px 1.5px at 340px 210px, #fff8e0, transparent),
    radial-gradient(ellipse at 50% 120%, #22427a 0%, #0c1834 52%, #050813 100%);
  background-size: 360px 240px, 360px 240px, 360px 240px, 360px 240px, 360px 240px, 360px 240px, 100% 100%; }
/* Oceano */
.rlw-t-ocean { background: linear-gradient(180deg, #4fb3f0 0%, #9fdcff 48%, #e9f8ff 55%, #1690c4 55.5%, #0a6a9c 72%, #04395c 100%); }
.rlw-ocean-sun { position: absolute; right: 22%; top: 16%; width: 9%; aspect-ratio: 1; border-radius: 50%; background: radial-gradient(circle, #fff 0%, #fffbe0 40%, rgba(255,255,255,0) 70%); }
.rlw-waves { position: absolute; left: 0; right: 0; top: 56%; bottom: 0; background: repeating-linear-gradient(170deg, rgba(255,255,255,.10) 0 3px, transparent 3px 26px); }
/* River Highway */
.rlw-t-highway { background: linear-gradient(180deg, #ff8d5c 0%, #ffbd7a 30%, #ffe1a8 47%, #9fb3c4 48%, #5c6f80 70%, #2f3b47 100%); }
.rlw-hw-sun { position: absolute; left: 50%; top: 30%; width: 12%; aspect-ratio: 1; transform: translateX(-50%); border-radius: 50%; background: radial-gradient(circle, #fff3c4 0%, #ffd27a 50%, rgba(255,170,90,0) 72%); }
.rlw-hw-hills { position: absolute; left: 0; right: 0; top: 40%; height: 9%; background: linear-gradient(180deg, #48606f, #6f8796);
  clip-path: polygon(0 100%, 0 45%, 8% 30%, 17% 55%, 28% 20%, 39% 60%, 50% 35%, 61% 58%, 72% 18%, 83% 50%, 92% 28%, 100% 42%, 100% 100%); }
.rlw-road { position: absolute; left: 0; right: 0; top: 48%; bottom: 0; background: #2b2f35; clip-path: polygon(48.5% 0, 51.5% 0, 85% 100%, 15% 100%); }
.rlw-road i { position: absolute; left: 50%; top: 0; bottom: 0; width: 1.2%; transform: translateX(-50%);
  background: repeating-linear-gradient(180deg, #ffd34d 0 22px, transparent 22px 48px); clip-path: polygon(45% 0, 55% 0, 100% 100%, 0 100%); }
/* Grafite */
.rlw-t-graphite { background: radial-gradient(circle at 30% 20%, #485162 0%, #262b35 55%, #14171d 100%); }
</style>
