<template>
  <div v-if="data" class="rlos rlp">
    <section class="rlp-win" role="dialog" aria-label="Escolha sua carreira">
      <header class="rlp-title">Escolha sua carreira</header>
      <div class="rlp-body">
        <p class="rlp-lead"><b>{{ data.serverName || "Este servidor" }}</b> · {{ mapName(data.level) }}</p>
        <button class="rlp-card main" :disabled="busy" @click="choose({ server: true })">
          <b>Carreira deste servidor</b>
          <span v-if="data.serverSave">{{ describe(data.serverSave) }}</span>
          <span v-else>Começa uma carreira nova, salva só para este servidor.</span>
        </button>
        <template v-if="profiles.length">
          <div class="rlp-sub">Suas outras carreiras</div>
          <div class="rlp-list">
            <button v-for="p in profiles" :key="p.id" class="rlp-card" :disabled="busy" @click="choose({ profile: p.id })">
              <b>{{ p.name }}</b>
              <span>{{ p.empty ? "Sem dados salvos" : describe(p) }}</span>
            </button>
          </div>
        </template>
        <p class="rlp-note">A carreira escolhida abre neste mapa. Carros e garagens de outros mapas continuam no save.</p>
        <div class="rlp-actions">
          <button :disabled="busy" @click="choose({ new: true })">Nova carreira</button>
          <button :disabled="busy" @click="choose({ freeroam: true })">Só freeroam</button>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
// RiverLife career picker. Original code.
// Shown on joining a BeamMP server that lets players choose their career save (server option
// "careerSaves": "choose", or the player's "chooseCareer" setting).
import { computed, onMounted, onUnmounted, ref } from "vue"
import { useBridge } from "@/bridge"
import { engineLua, luaValue } from "../rl.js"

const data = ref(null)
const busy = ref(false)
const profiles = computed(() => (Array.isArray(data.value?.profiles) ? data.value.profiles : Object.values(data.value?.profiles || {})))
const MAPS = { west_coast_usa: "West Coast USA", river_highway: "River Highway", east_coast_usa: "East Coast USA", italy: "Italy", utah: "Utah" }

function locale() { return window.__rlLocale || (window.__rlLocale || "pt-BR") }
function mapName(id) { return MAPS[id] || id || "" }
function describe(p) {
  const parts = []
  if (typeof p.money === "number") parts.push("$" + Math.round(p.money).toLocaleString(locale()))
  if (typeof p.vehicles === "number") parts.push(p.vehicles + " carro(s)")
  if (p.level) parts.push(mapName(p.level))
  const d = p.date && new Date(p.date)
  if (d && !isNaN(d)) parts.push(d.toLocaleDateString(locale()))
  return parts.join(" · ")
}
function choose(choice) {
  if (busy.value) return
  busy.value = true
  engineLua("if riverLife and riverLife.chooseMultiplayerCareer then riverLife.chooseMultiplayerCareer(" + luaValue(choice) + ") end")
}
function onPicker(p) {
  busy.value = false
  data.value = p && p.open ? p : null
}

let events
onMounted(() => {
  events = useBridge().events
  events.on("RiverLifeCareerPicker", onPicker)
  // The game may ask before this screen is loaded: ask it to say it again.
  engineLua("if riverLife and riverLife.resendCareerPicker then riverLife.resendCareerPicker() end")
})
onUnmounted(() => { if (events) events.off("RiverLifeCareerPicker", onPicker) })
</script>

<style scoped>
.rlp { position: fixed; inset: 0; z-index: 2000; display: flex; align-items: center; justify-content: center; background: rgba(8, 20, 40, .55); font: 13px Tahoma, "Segoe UI", sans-serif; color: #1c2430; pointer-events: auto; }
.rlp-win { width: min(560px, calc(100vw - 32px)); max-height: calc(100vh - 60px); display: flex; flex-direction: column; background: #ece9d8; border: 3px solid #0831d9; border-top: 0; border-radius: 8px 8px 3px 3px; box-shadow: 4px 6px 18px rgba(0,0,0,.45); }
.rlp-title { height: 30px; display: flex; align-items: center; padding: 0 10px; color: #fff; border-radius: 6px 6px 0 0; font: bold 13px "Trebuchet MS", Tahoma, sans-serif; text-shadow: 1px 1px #0a1f69; background: linear-gradient(180deg, #0997ff 0%, #0053ee 8%, #0050ee 40%, #06f 88%, #005bff 95%, #003dd7 96%); }
.rlp-body { padding: 14px; overflow-y: auto; display: grid; gap: 8px; }
.rlp-lead { margin: 0 0 4px; }
.rlp-card { display: grid; gap: 3px; width: 100%; padding: 10px 12px; text-align: left; border: 1px solid #a5b4c8; border-radius: 4px; background: #fff; font: 13px Tahoma, sans-serif; color: #1c2430; cursor: pointer; }
.rlp-card span { color: #4f5b6b; font-size: 12px; }
.rlp-card:hover:not(:disabled) { border-color: #316ac5; background: #f1f6ff; }
.rlp-card.main { border: 2px solid #2e9e48; background: #f2fbf3; }
.rlp-card:disabled, .rlp-actions button:disabled { opacity: .6; cursor: default; }
.rlp-sub { margin-top: 6px; font-weight: bold; color: #0b3d91; }
.rlp-list { display: grid; gap: 6px; max-height: 38vh; overflow-y: auto; }
.rlp-note { margin: 4px 0 0; color: #4f5b6b; font-size: 12px; }
.rlp-actions { display: flex; gap: 8px; justify-content: flex-end; }
.rlp-actions button { min-width: 110px; padding: 5px 12px; border: 1px solid #003c74; border-radius: 3px; background: linear-gradient(180deg, #fff, #ecebe6 86%, #d6d0c5); font: 12px Tahoma, sans-serif; cursor: pointer; }
</style>
