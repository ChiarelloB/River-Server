<template>
  <div class="rl-page garage">
    <header class="gx-head">
      <div>
        <h2 class="rl-h1">{{ heading }}</h2>
        <p class="rl-muted">{{ hosted ? (picker ? "Clique no veículo que deseja usar." : "Retire, entregue, guarde, personalize e anuncie os carros da sua carreira.")
          : "Sua garagem da carreira e seus anúncios no RiverLife." }}</p>
      </div>
      <div class="gx-tools">
        <input v-model.trim="search" class="rl-input" placeholder="Buscar veículo" @focus="typing(true)" @blur="typing(false)" />
        <XPSelect v-model="filter" aria-label="Filtrar carros" :options="[{ value: '', label: 'Todos' }, { value: 'here', label: 'Nesta garagem' },
          { value: 'repair', label: 'Precisam de reparo' }, { value: 'sale', label: 'À venda' }, { value: 'busy', label: 'Indisponíveis' }]" />
      </div>
    </header>

    <div v-if="picker" class="gx-picker"><BngIcon type="keys1" /> Escolha um veículo para: <b>{{ pickerLabel }}</b></div>

    <div class="rl-stats">
      <div><b>{{ cars.length }}</b><small>Veículos</small></div>
      <div><b>{{ dollars(totalValue) }}</b><small>Valor estimado</small></div>
      <div v-if="hosted"><b>{{ inv.numberOfFreeSlots ?? "—" }}</b><small>Vagas livres nas garagens</small></div>
      <div><b>{{ cars.filter(v => v.needsRepair).length }}</b><small>Precisam de reparo</small></div>
      <div v-if="hosted"><b>{{ dollars(inv.playerMoney) }}</b><small>Seu saldo</small></div>
    </div>

    <div v-if="hosted && !loaded" class="rl-empty"><b>Abrindo a garagem...</b>Carregando seus veículos.</div>
    <div v-else-if="!cars.length" class="rl-empty"><b>Garagem vazia</b>Compre um carro nas concessionárias ou nos classificados.</div>

    <section v-for="g in groups" :key="g.id" class="gx-group">
      <button class="gx-group-head" @click="collapsed[g.id] = !collapsed[g.id]">
        <BngIcon :type="collapsed[g.id] ? 'plus' : 'minus'" /><b>{{ g.name }}</b>
        <span class="rl-muted">{{ g.count }}{{ g.capacity ? " / " + g.capacity + " vagas" : " veículo(s)" }}</span>
        <span v-if="g.current" class="rl-badge ok">Você está aqui</span>
      </button>
      <template v-if="!collapsed[g.id]">
        <article v-for="v in g.vehicles" :key="v.id" class="car rl-card" :class="{ off: picker && !v.pickable }">
          <div class="shot">
            <img v-if="v.thumbnail" :src="v.thumbnail" alt="" />
            <span v-if="v.favorite" class="fav" title="Favorito"><BngIcon type="star" /></span>
            <span v-if="v.lock" class="lock">{{ v.lock }}</span>
          </div>
          <div class="car-main">
            <div class="rl-row between">
              <h3>{{ v.niceName }}</h3>
              <div class="rl-row badges">
                <span v-if="v.loaner" class="rl-badge">Emprestado</span>
                <span v-if="v.listedForSale" class="rl-badge warn">À venda (RLS)</span>
                <span v-if="v.rlLocked" class="rl-badge warn">Anunciado no RiverLife</span>
                <span v-if="hosted && !v.isInsured && !v.loaner" class="rl-badge bad">Sem seguro</span>
                <span v-if="v.needsRepair" class="rl-badge bad">Precisa de reparo</span>
                <span v-else-if="!v.lock" class="rl-badge ok">Disponível</span>
              </div>
            </div>
            <p class="rl-muted">
              {{ v.plate ? "Placa " + v.plate + " · " : "" }}{{ km(v.mileage) }} · {{ v.loaner ? "carro emprestado" : "valor " + dollars(v.value) }}
              <template v-if="v.valueRepaired && v.valueRepaired > v.value"> (consertado: {{ dollars(v.valueRepaired) }})</template>
              · {{ v.where }}
              <template v-if="v.insurance"> · Seguro: {{ v.insurance }}</template>
              <template v-if="v.power && v.power !== 'N/A'"> · {{ v.power }} cv · {{ v.weight }} kg</template>
            </p>

            <div v-if="picker" class="rl-row">
              <button v-for="b in v.choose" :key="b.index" class="rl-btn primary" :disabled="!b.ok || busy" :title="b.reason" @click="choose(v, b)">{{ b.label }}</button>
              <span v-if="!v.pickable" class="rl-muted">{{ v.choose[0]?.reason || "Indisponível" }}</span>
            </div>
            <div v-else class="rl-row">
              <button v-for="b in v.choose.filter(b => b.ok && b.main)" :key="b.index" class="rl-btn primary" :disabled="busy" @click="choose(v, b)">{{ b.label }}</button>
              <template v-if="hosted && v.atCurrentGarage">
                <button v-if="active.storingEnabled && !v.inStorage" class="rl-btn" :disabled="busy || !v.raw.storePermission?.allow" @click="store(v)">Guardar</button>
                <button v-if="active.repairEnabled && v.delayReason !== 'repair'" class="rl-btn" :disabled="!v.raw.repairPermission?.allow" @click="repair(v)">Consertar</button>
                <button v-if="v.delayReason === 'repair' && v.raw.expediteRepairCost" class="rl-btn" :disabled="v.raw.expediteRepairCost > inv.playerMoney"
                  @click="ask(v, 'Acelerar o conserto por ' + dollars(v.raw.expediteRepairCost) + '?', () => expedite(v))">Acelerar conserto</button>
                <button v-if="active.favoriteEnabled" class="rl-btn" :disabled="v.favorite || !v.raw.favoritePermission?.allow" @click="favorite(v)">Favorito</button>
                <button class="rl-btn" :disabled="!v.raw.licensePlateChangePermission?.allow" @click="openEdit(v, 'plate')">Placa</button>
                <button class="rl-btn" @click="openEdit(v, 'name')">Renomear</button>
                <button v-if="active.sellEnabled && !v.listedForSale" class="rl-btn" :disabled="!v.raw.sellPermission?.allow" @click="openEdit(v, 'sell')">Vender (RLS)</button>
                <button v-if="active.sellEnabled && v.listedForSale" class="rl-btn" @click="marketplace()">Ver ofertas</button>
                <button v-if="active.returnLoanerEnabled && v.raw.returnLoanerPermission?.allow" class="rl-btn"
                  @click="ask(v, 'Devolver este carro emprestado ao dono?', () => returnLoaner(v))">Devolver</button>
              </template>
              <button v-if="!hosted" class="rl-btn" :disabled="v.spawned || !!v.timeToAccess" @click="request('spawn', { inventoryId: v.id })">Trazer</button>
              <button v-if="!v.loaner" class="rl-btn" :disabled="v.rlLocked || !!v.timeToAccess" @click="$emit('open', { app: 'sell', props: { inventoryId: v.id } })">Anunciar no RiverLife</button>
              <button v-if="v.position" class="rl-btn" @click="request('gps', { position: v.position })">GPS</button>
            </div>
            <div v-if="!picker && services(v.id).length" class="rl-row svc">
              <span class="rl-muted">Serviços:</span>
              <button v-for="f in services(v.id)" :key="f.id" class="rl-btn small" :disabled="f.disabled" :title="f.reason?.label || ''"
                @click="request('native', { buttonId: f.id, inventoryId: v.id })"><BngIcon :type="SERVICE_ICON[f.id] || 'cogs'" /> {{ SERVICE_NAME[f.id] || label(f.label) }}</button>
            </div>

            <form v-if="edit?.id === v.id" class="rl-box gx-edit" @submit.prevent="saveEdit(v)">
              <template v-if="edit.kind === 'plate'">
                <label>Texto da placa (até 10 caracteres) — custa {{ dollars(300) }}
                  <input v-model="edit.text" class="rl-input" maxlength="10" required @focus="typing(true)" @blur="typing(false)" /></label>
              </template>
              <template v-else-if="edit.kind === 'name'">
                <label>Nome do veículo<input v-model="edit.text" class="rl-input" maxlength="30" required @focus="typing(true)" @blur="typing(false)" /></label>
              </template>
              <template v-else>
                <label>Preço pedido no marketplace do RLS ($) — valor de mercado {{ dollars(v.raw.marketSellValue || v.value) }}
                  <input v-model.number="edit.price" class="rl-input" type="number" min="1" required @focus="typing(true)" @blur="typing(false)" /></label>
                <p class="rl-muted">Compradores NPC mandam ofertas; você aceita ou negocia em Concessionárias → Vender meu carro.</p>
              </template>
              <p v-if="edit.error" class="rl-error">{{ edit.error }}</p>
              <div class="rl-row"><button class="rl-btn primary" :disabled="busy">Salvar</button><button type="button" class="rl-btn" @click="edit = null">Cancelar</button></div>
            </form>
            <div v-if="confirmBox?.id === v.id" class="rl-box gx-confirm">
              <b>{{ confirmBox.text }}</b>
              <div class="rl-row"><button class="rl-btn primary" @click="confirmBox.yes(); confirmBox = null">Sim</button><button class="rl-btn" @click="confirmBox = null">Não</button></div>
            </div>
          </div>
        </article>
      </template>
    </section>

    <template v-if="!picker">
      <h3 class="rl-h2">Meus anúncios no RiverLife</h3>
      <table v-if="myListings.length" class="rl-table">
        <tr><th>Anúncio</th><th>Preço</th><th>Situação</th><th>Visitas</th><th></th></tr>
        <tr v-for="l in myListings" :key="l.id">
          <td><b>{{ l.title }}</b><br /><small class="rl-muted">{{ l.storeName || "Particular" }} · {{ dateTime(l.createdAt) }}</small></td>
          <td>{{ money(l.price) }}</td>
          <td><span class="rl-badge" :class="l.status === 'sold' ? 'ok' : l.status === 'active' ? '' : 'bad'">{{ l.reserved ? "Visita marcada" : status(l.status) }}</span></td>
          <td>{{ l.views || 0 }}</td>
          <td class="actions">
            <template v-if="l.status === 'active' && l.street">
              <button class="rl-btn" :disabled="l.reserved" @click="askConfirm('Tirar o carro da rua? Ele volta para você no lugar onde está.', () => request('stockOut', { listingId: l.id }), 'Tirar da rua')">Tirar da rua</button>
            </template>
            <template v-else-if="l.status === 'active'">
              <button class="rl-btn" :disabled="l.reserved" @click="editListing(l)">Editar</button>
              <button class="rl-btn" @click="request('cancel', { listingId: l.id })">Retirar</button>
            </template>
            <button class="rl-btn" @click="request('gps', { position: l.position })">Local</button>
          </td>
        </tr>
      </table>
      <p v-else class="rl-muted">Você não tem anúncios. Use "Anunciar no RiverLife" em um dos carros acima.</p>

      <form v-if="editing" class="rl-box rl-form" @submit.prevent="saveListing">
        <b>Editar anúncio</b>
        <label>Título<input v-model.trim="editing.title" class="rl-input" maxlength="100" required /></label>
        <label>Preço ($)<input v-model.number="editing.price" class="rl-input" type="number" min="1" required /></label>
        <label>Descrição<textarea v-model="editing.description" class="rl-input" maxlength="1600" rows="3"></textarea></label>
        <label class="check"><input v-model="editing.negotiable" type="checkbox" /> Aceitar propostas</label>
        <div class="rl-row"><button class="rl-btn primary">Salvar</button><button type="button" class="rl-btn" @click="editing = null">Cancelar</button></div>
      </form>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, money, dollars, km, status, dateTime, myListings, luaCall, luaRun, luaValue, onGameEvent, typing, toast, distanceText, RLS_FUNCTIONS, ask as askConfirm } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number, launchFailed: Boolean })
const emit = defineEmits(["open", "title", "close"])

const SERVICE_NAME = Object.fromEntries(Object.entries(RLS_FUNCTIONS).map(([k, f]) => [k, f.name]))
const SERVICE_ICON = Object.fromEntries(Object.entries(RLS_FUNCTIONS).map(([k, f]) => [k, f.icon]))
const TEXTS = { "Retrieve": "Retirar", "Replace current vehicle": "Retirar e substituir o atual", "Deliver": "Trazer para esta garagem",
  "Deliver and replace": "Trazer e substituir o atual", "Trade-In": "Usar na troca", "Choose vehicle": "Escolher", "List for sale": "Anunciar este" }

const hosted = computed(() => !!props.route)
const inv = ref({})
const loaded = ref(false)
const capacities = ref({})
const search = ref(""), filter = ref("")
const collapsed = reactive({})
const busy = ref(false)
const edit = ref(null), confirmBox = ref(null), editing = ref(null)
let offs = []

const active = computed(() => inv.value.buttonsActive || {})
const chooseButtons = computed(() => Array.isArray(inv.value.chooseButtonsData) ? inv.value.chooseButtonsData : Object.values(inv.value.chooseButtonsData || {}))
// Only one custom action and no management buttons: RLS opened the inventory as a picker.
const picker = computed(() => hosted.value && !Object.values(active.value).includes(true) && chooseButtons.value.length === 1)
const pickerLabel = computed(() => buttonLabel(chooseButtons.value[0] || {}))
const heading = computed(() => picker.value ? "Escolher veículo" : "Meus veículos")

function label(l) { return typeof l === "string" ? l : l?.txt || l?.label || "Ação" }
function buttonLabel(b) {
  const t = String(b.buttonText || "")
  if (b.retrievalAction && b.requiredOtherVehicleInGarage) return "Retirar e substituir o atual"
  if (b.retrievalAction) return "Retirar"
  if (/performance/i.test(t)) return "Certificar desempenho"
  return TEXTS[t] || t || "Escolher"
}
function services(id) {
  const fns = rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(id)] || {}
  return Object.values(fns).filter(f => !(hosted.value && f.id === "repair")).sort((a, b) => (a.order || 0) - (b.order || 0))
}
// Same availability rules as the RLS inventory list.
function chooseState(v, b) {
  const data = inv.value
  const deliver = b.buttonText === "Deliver" || b.buttonText === "Deliver and replace"
  const hereSpace = data.currentGarageHasSpace === undefined ? true : !!data.currentGarageHasSpace
  const anySpace = data.hasGlobalGarageSpace === undefined ? true : !!data.hasGlobalGarageSpace
  const deliverOk = !deliver ? true : typeof v.deliverPermission?.allow === "boolean" ? v.deliverPermission.allow : (!v.atCurrentGarage && (hereSpace || anySpace))
  let reason = ""
  if (v.timeToAccess) reason = "Indisponível agora"
  else if (v.missingFile) reason = "Arquivo do veículo ausente"
  else if (!deliverOk) reason = "Sem vaga para entregar aqui"
  else if (!deliver && b.requiredVehicleNotInGarage && v.inGarage) reason = "Já está na garagem"
  else if (b.requiredOtherVehicleInGarage && !v.otherVehicleInGarage) reason = "Não há outro carro na garagem"
  else if (b.ownedRequired && !v.owned) reason = "O carro não é seu"
  else if (b.repairRequired && v.needsRepair) reason = "Precisa de reparo"
  else if (b.notForSaleRequired && v.listedForSale) reason = "Já está à venda"
  else if (b.requireAtCurrentGarage && !v.atCurrentGarage) reason = "Está em outra garagem"
  else if (b.requireAtDifferentGarage && v.atCurrentGarage) reason = "Já está nesta garagem"
  else if (!v.atCurrentGarage && !hereSpace && !anySpace) reason = "Garagens cheias"
  else if (deliver && (data.playerMoney || 0) < 5000) reason = "Saldo insuficiente"
  return { ok: !reason, reason }
}
function lockText(v) {
  if (v.missingFile) return "Arquivo ausente"
  if (!v.timeToAccess) return ""
  const eta = Math.floor(v.timeToAccess / 60) + ":" + String(Math.floor(v.timeToAccess % 60)).padStart(2, "0")
  return (v.delayReason === "bought" ? "Em entrega " : v.delayReason === "repair" ? "No conserto " : "Disponível em ") + eta
}

const rlGarage = computed(() => rl.view.garage || [])
const cars = computed(() => {
  const list = []
  if (hosted.value) {
    for (const v of Object.values(inv.value.vehicles || {})) {
      const id = Number(v.id ?? v.inventoryId)
      const mine = rlGarage.value.find(g => g.inventoryId === id)
      // Retrieve/deliver are the garage's own actions; the rest (e.g. performance) are listed under Serviços.
      const choose = chooseButtons.value.map((b, index) => ({ index, label: buttonLabel(b), raw: b, main: !!b.retrievalAction || /^Deliver/.test(b.buttonText || ""), ...chooseState(v, b) }))
        .map(b => b.raw.retrievalAction && b.ok && !v.retrievalFree ? { ...b, label: b.label + (v.retrievalCoveredByInsurance ? " (guincho do seguro)" : " (" + dollars(v.retrievalCost || 0) + ")") } : b)
        .map(b => (b.raw.buttonText === "Deliver" || b.raw.buttonText === "Deliver and replace") ? { ...b, label: b.label + " (" + dollars(5000) + ")" } : b)
      list.push({
        id, raw: v, niceName: v.niceName, thumbnail: v.thumbnail, value: v.marketSellValue || v.value || 0, valueRepaired: v.valueRepaired,
        mileage: v.mileage || 0, plate: v.config?.licenseName, favorite: v.favorite, needsRepair: v.needsRepair, timeToAccess: v.timeToAccess,
        delayReason: v.delayReason, missingFile: v.missingFile, listedForSale: v.listedForSale, loaner: !!v.returnLoanerPermission?.allow,
        isInsured: v.isInsured, insurance: v.insuranceInfo?.name, power: v.power, weight: v.weight, atCurrentGarage: v.atCurrentGarage,
        inStorage: v.inStorage, location: v.location ?? "storage", rlLocked: mine?.locked, position: mine?.spawned ? mine.position : null,
        where: v.inStorage ? (v.niceLocation || "Depósito") : v.distance != null ? "a " + distanceText(v.distance) : (v.niceLocation || ""),
        lock: lockText(v), choose, pickable: choose.some(b => b.ok),
      })
    }
  } else {
    for (const v of rlGarage.value) {
      list.push({ id: v.inventoryId, raw: v, niceName: v.niceName, thumbnail: v.thumbnail, value: (v.value || 0) / 100, mileage: v.mileage,
        plate: v.plate, needsRepair: v.needsRepair, timeToAccess: v.timeToAccess, rlLocked: v.locked, spawned: v.spawned,
        position: v.spawned ? v.position : null, location: "rl", where: v.spawned ? "na rua" : "guardado na garagem",
        lock: v.timeToAccess ? "Indisponível" : "", choose: [], pickable: true })
    }
  }
  const q = search.value.toLowerCase()
  return list.filter(v => !q || (v.niceName || "").toLowerCase().includes(q) || (v.plate || "").toLowerCase().includes(q))
    .filter(v => !filter.value || (filter.value === "here" ? v.atCurrentGarage : filter.value === "repair" ? v.needsRepair
      : filter.value === "sale" ? (v.listedForSale || v.rlLocked) : !!v.lock))
    .sort((a, b) => (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0) || String(a.niceName).localeCompare(String(b.niceName)))
})
const totalValue = computed(() => cars.value.reduce((s, v) => s + (v.loaner ? 0 : v.value || 0), 0))
const groups = computed(() => {
  if (!hosted.value) return cars.value.length ? [{ id: "rl", name: "Garagem da carreira", count: cars.value.length, vehicles: cars.value }] : []
  const out = [], by = {}
  for (const v of cars.value) {
    const key = String(v.location)
    if (!by[key]) {
      const cap = capacities.value?.[key]
      by[key] = { id: key, name: v.raw.niceLocation || cap?.name || "Garagem", capacity: cap?.capacity, vehicles: [], current: false }
      out.push(by[key])
    }
    by[key].vehicles.push(v)
    if (v.atCurrentGarage) by[key].current = true
  }
  for (const g of out) g.count = g.vehicles.length
  return out.sort((a, b) => (b.current ? 1 : 0) - (a.current ? 1 : 0))
})

async function refresh() { await luaCall("career_modules_inventory.sendDataToUi()") }
function ask(v, text, yes) { confirmBox.value = { id: v.id, text, yes } }
function choose(v, b) {
  const go = async () => {
    busy.value = true
    await luaCall("career_modules_inventory.chooseVehicleFromMenu(" + Number(v.id) + ", " + (b.index + 1) + ", false)")
    busy.value = false
  }
  const raw = b.raw
  if (raw.retrievalAction && !v.raw.retrievalFree && !v.raw.retrievalCoveredByInsurance && (v.raw.retrievalCost || 0) > 0)
    return ask(v, "Retirar este veículo pagando " + dollars(v.raw.retrievalCost) + " de guincho?", go)
  if (raw.retrievalAction && v.raw.retrievalCoveredByInsurance) return ask(v, "Retirar este veículo usando um guincho do seguro?", go)
  if (raw.buttonText === "Deliver" || raw.buttonText === "Deliver and replace") return ask(v, "Trazer este veículo para esta garagem por " + dollars(5000) + "?", go)
  go()
}
function store(v) {
  const go = async () => {
    busy.value = true
    await luaCall("career_modules_inventory.storeVehicleAtClosestGarage(" + Number(v.id) + ")")
    await refresh(); busy.value = false
  }
  if (v.raw.storageTowRequired) return ask(v, "Rebocar até esta garagem e guardar" + (v.raw.storageTowCoveredByInsurance ? " usando um guincho do seguro?" : " pagando " + dollars(v.raw.storageTowCost) + "?"), go)
  go()
}
function repair(v) {
  luaRun("local d = career_modules_inventory.getVehicleUiData(" + Number(v.id) + ") if d then career_modules_insurance_repairScreen.openRepairMenu(d, "
    + luaValue(inv.value.originComputerId || rl.view.computer?.computerId || null) + ") end")
}
async function expedite(v) { await luaCall("career_modules_inventory.expediteRepairFromInventory(" + Number(v.id) + ", " + Number(v.raw.expediteRepairCost) + ")") }
async function favorite(v) { await luaCall("career_modules_inventory.setFavoriteVehicle(" + Number(v.id) + ")"); refresh() }
async function returnLoaner(v) { await luaCall("career_modules_inventory.returnLoanedVehicleFromInventory(" + Number(v.id) + ")") }
function marketplace() { luaCall("career_modules_marketplace.openMenu(" + luaValue(inv.value.originComputerId || rl.view.computer?.computerId || null) + ")") }
function openEdit(v, kind) {
  confirmBox.value = null
  const suggested = Math.max(50, Math.round((v.raw.marketSellValue || v.value || 0) / 50) * 50)
  edit.value = { id: v.id, kind, text: kind === "plate" ? (v.plate || "") : kind === "name" ? v.niceName : "", price: suggested, error: "" }
}
async function saveEdit(v) {
  const e = edit.value
  busy.value = true
  try {
    if (e.kind === "plate") {
      if (!(await luaCall("career_modules_inventory.isLicensePlateValid(" + luaValue(e.text) + ")"))) { e.error = "Caractere inválido na placa."; return }
      if ((inv.value.playerMoney || 0) < 300) { e.error = "Saldo insuficiente."; return }
      await luaCall("career_modules_inventory.purchaseLicensePlateText(" + Number(v.id) + ", " + luaValue(e.text) + ", 300)")
      toast("Placa personalizada: " + e.text)
    } else if (e.kind === "name") {
      if (!(await luaCall("career_modules_inventory.isVehicleNameValid(" + luaValue(e.text) + ")"))) { e.error = "Nome com caracteres inválidos."; return }
      await luaCall("career_modules_inventory.renameVehicle(" + Number(v.id) + ", " + luaValue(e.text) + ")")
    } else {
      const price = Math.round(Number(e.price) || 0)
      if (price <= 0) { e.error = "Informe um preço válido."; return }
      const requestId = "rl_list_" + Date.now()
      const ok = await new Promise(resolve => {
        let done = false
        const off = onGameEvent("marketplaceListVehiclesFinished", p => { if (p?.requestId === requestId && !done) { done = true; off(); resolve(!!p.ok) } })
        luaCall("career_modules_marketplace.listVehicles(" + luaValue([{ inventoryId: Number(v.id), value: price }]) + ", " + luaValue(requestId) + ")")
        setTimeout(() => { if (!done) { done = true; off(); resolve(false) } }, 8000)
      })
      if (!ok) { e.error = "O RLS não aceitou o anúncio agora."; return }
      toast("Carro anunciado no marketplace do RLS por " + dollars(price) + ".")
    }
    edit.value = null
    refresh()
  } finally { busy.value = false }
}
function editListing(l) { editing.value = { listingId: l.id, title: l.title, price: l.price / 100, description: l.description || "", negotiable: l.negotiable } }
function saveListing() { request("edit", { ...editing.value, price: Math.round(editing.value.price * 100) }); editing.value = null }

// Back/X: same as the RLS Back button (returns to where the picker was opened from).
function requestClose() { luaCall("extensions.ui_router.back()") }
defineExpose({ requestClose })

// Opened from the desktop at a garage computer: start the RLS garage session so every action is available.
let tried = false
function launchIfPossible() {
  const f = rl.view.computer?.computerFunctions?.general?.vehicleInventory
  if (tried || hosted.value || props.launchFailed || !f || f.disabled || Date.now() - (window.__riverGarageLaunch || 0) < 4000) return
  // Only from the computer (the phone shows the RiverLife garage).
  if (!String(window.vueRouter?.currentRoute?.value?.name || "").startsWith("career.computer")) return
  tried = true
  window.__riverGarageLaunch = Date.now()
  request("native", { buttonId: "vehicleInventory" })
}
watch(() => rl.view.computer, () => launchIfPossible())

onMounted(async () => {
  if (!hosted.value) { launchIfPossible(); return }
  offs.push(onGameEvent("vehicleInventoryData", d => { inv.value = d || {}; loaded.value = true }))
  refresh()
  capacities.value = (await luaCall("career_modules_garageManager.getGarageCapacityData()")) || {}
})
onUnmounted(() => {
  offs.forEach(off => off()); offs = []
  if (hosted.value) luaCall("extensions.hook('onExitVehicleInventory')")
})
</script>

<style scoped>
.between { justify-content: space-between; }
.gx-head { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; flex-wrap: wrap; }
.gx-tools { display: flex; gap: 6px; }
.gx-tools input { width: 190px; }
.gx-picker { display: flex; gap: 8px; align-items: center; padding: 8px 12px; margin: 8px 0; border: 1px solid #e8c76c; background: #fff8dc; border-radius: 3px; }
.gx-group { margin: 10px 0 4px; }
.gx-group-head { width: 100%; display: flex; gap: 8px; align-items: center; padding: 6px 10px; border: 1px solid #aca899; border-radius: 3px; cursor: pointer;
  background: linear-gradient(180deg, #fdfcf8, #ece9d8); font: 12.5px Tahoma, sans-serif; color: #1b3355; text-align: left; }
.car { display: flex; gap: 14px; padding: 10px; margin: 8px 0; }
.car.off { opacity: .55; }
.shot { position: relative; width: 190px; height: 107px; flex-shrink: 0; background: #eef2f7; border-radius: 3px; overflow: hidden; }
.shot img { width: 100%; height: 100%; object-fit: cover; }
.fav { position: absolute; left: 5px; top: 4px; color: #f5c400; font-size: 18px; text-shadow: 0 1px 2px #0008; }
.lock { position: absolute; left: 0; right: 0; bottom: 0; padding: 3px 6px; background: rgba(20,30,50,.75); color: #fff; font-size: 11px; }
.car-main { flex: 1; min-width: 0; } .car-main h3 { margin: 0; font-size: 15px; color: #1b3355; } .car-main p { margin: 4px 0 8px; }
.badges { gap: 4px; }
.svc { margin-top: 6px; }
.rl-btn.small { padding: 3px 8px; font-size: 11.5px; display: inline-flex; gap: 4px; align-items: center; }
.gx-edit, .gx-confirm { display: grid; gap: 8px; max-width: 560px; }
.gx-edit label { display: grid; gap: 4px; font-size: 12px; color: #2c4a6e; }
.actions { white-space: nowrap; } .actions .rl-btn { margin-right: 4px; }
.check { display: flex !important; flex-direction: row; align-items: center; gap: 6px; }
</style>
