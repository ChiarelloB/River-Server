<template>
  <div class="nf">
    <h2>Não é possível exibir a página</h2>
    <p>O endereço <b>{{ url }}</b> não existe na RiverNet.</p>
    <p>Tente um destes:</p>
    <ul>
      <li v-for="s in sites" :key="s.app"><a href="#" @click.prevent="$emit('open', s.app)">{{ s.host }}</a> — {{ s.title }}</li>
    </ul>
  </div>
</template>

<script setup>
// Original code: the browser's "page not found" for addresses typed by hand.
defineProps({ url: String, sites: { type: Array, default: () => [] } })
defineEmits(["open"])
</script>

<style scoped>
.nf { padding: 30px 40px; font: 13px Tahoma, sans-serif; color: #222; }
.nf h2 { font: normal 20px Tahoma, sans-serif; color: #1c3f74; margin: 0 0 12px; }
.nf ul { line-height: 1.9; }
.nf a { color: #0645ad; }
</style>
