<template>
  <div class="rl-page shop">
    <template v-if="!shop">
      <div class="intro">
        <div class="intro-icon"><BngIcon type="houseWrench" /></div>
        <div>
          <h2 class="rl-h1">Abra sua oficina mecânica</h2>
          <p class="rl-muted">Monte a oficina onde você está. Clientes NPC chegam com o carro precisando de reparo, revisão ou pintura; jogadores trazem o carro deles
            e você manda o orçamento. Você compra as peças e fica com a mão de obra.</p>
          <div class="rl-stats">
            <div><b>{{ money(costs.shop) }}</b><small>Para abrir</small></div>
            <div><b>{{ money(costs.shopRent) }}</b><small>Despesas por dia</small></div>
            <div><b>2 → 6</b><small>Elevadores</small></div>
            <div><b>Peças + mão de obra</b><small>Você define o preço</small></div>
          </div>
          <form class="rl-row" @submit.prevent="request('openShop', { name: name })">
            <input v-model.trim="name" class="rl-input grow" maxlength="64" required placeholder="Nome da oficina (ex.: Auto Center do Zé)" />
            <button class="rl-btn primary" :disabled="rl.busy.openShop || (rl.view.money || 0) < costs.shop">Abrir oficina aqui</button>
          </form>
          <p v-if="(rl.view.money || 0) < costs.shop" class="rl-error">Saldo insuficiente: faltam {{ money(costs.shop - (rl.view.money || 0)) }}.</p>
        </div>
      </div>
    </template>

    <template v-else>
      <div class="rl-row between">
        <div><h2 class="rl-h1">{{ shop.name }} <small v-if="!owner" class="rl-badge">Você trabalha aqui como mecânico(a)</small></h2>
          <p class="rl-muted">{{ shop.open ? "Aberta" : "Fechada" }} · {{ shop.opensAt }}h às {{ shop.closesAt }}h · {{ shop.bays }} elevador(es) · a {{ distanceText(distance(rl.view.position, shop.position)) }}</p></div>
        <button class="rl-btn" @click="request('gps', { position: shop.position })">GPS da oficina</button>
      </div>
      <p v-if="shop.rentOverdue" class="rl-box rl-error">Despesas atrasadas: {{ money(shop.rentOverdue) }}. A oficina está fechada.
        <button class="rl-btn primary" :disabled="rl.busy.shop" @click="ask('Pagar as despesas atrasadas e reabrir a oficina?', () => request('shop', { workshopId: shop.id, payRent: true, open: true }), 'Pagar e reabrir')">Pagar e reabrir</button></p>
      <div class="rl-stats">
        <div><b>{{ busy }} / {{ shop.bays }}</b><small>Elevadores ocupados</small></div>
        <div><b>{{ shop.jobs || 0 }}</b><small>Serviços feitos</small></div>
        <div><b>{{ money((shop.revenue || 0) - (shop.partsSpent || 0)) }}</b><small>Lucro (receita − peças)</small></div>
        <div><b>★ {{ ((shop.reputation || 0) / 20).toFixed(1) }}</b><small>Reputação</small></div>
      </div>

      <div class="bays">
        <div v-for="i in shop.bays" :key="i" class="bay" :class="{ on: bayJob(i - 1) }">
          <small>Elevador {{ i }}</small>
          <template v-if="bayJob(i - 1)">
            <b>{{ bayJob(i - 1).vehicle?.niceName || bayJob(i - 1).vehicle?.model }}</b>
            <div class="rl-progress"><i :style="{ width: progress(bayJob(i - 1)) + '%' }"></i></div>
            <small>{{ remaining(bayJob(i - 1)) }}</small>
          </template>
          <span v-else class="rl-muted">Livre</span>
        </div>
      </div>

      <h3 class="rl-h2">Ordens de serviço</h3>
      <div v-if="!queue.length" class="rl-muted">Nenhum pedido. Com a oficina aberta e você por perto, clientes NPC aparecem; jogadores pedem orçamento pelo site oficinas.river.</div>
      <article v-for="o in queue" :key="o.id" class="rl-box order" :class="{ focus: o.customer === focus || o.id === focus }">
        <div class="rl-row between">
          <b>{{ o.vehicle?.niceName || o.vehicle?.model }} <small class="rl-muted">· {{ o.customerName }}{{ o.npc ? " (cliente)" : " (jogador)" }}</small></b>
          <span class="rl-badge" :class="o.status === 'completed' ? 'ok' : ['declined', 'rejected', 'expired'].includes(o.status) ? 'bad' : 'warn'">{{ status(o.status) }}</span>
        </div>
        <p class="rl-muted">Problema: {{ o.diagnosis?.notes || o.notes || "avaliar" }} · {{ o.diagnosis?.brokenParts || 0 }} peça(s) danificada(s) · peças estimadas <b>{{ money(o.diagnosis?.partsCost) }}</b>
          <template v-if="npcOf(o)"> · {{ npcOf(o).status === "travelling" ? "cliente a caminho" : "cliente na oficina" }}</template></p>
        <p v-if="o.notes && !o.npc" class="note">"{{ o.notes }}"</p>

        <form v-if="['requested', 'quoted'].includes(o.status)" class="quote" @submit.prevent="sendQuote(o)">
          <div class="rl-two">
            <label>Peças ($)<input v-model.number="draft(o).parts" class="rl-input" type="number" min="0" /></label>
            <label>Mão de obra ($)<input v-model.number="draft(o).labor" class="rl-input" type="number" min="1" /></label>
          </div>
          <div class="rl-two">
            <label>Prazo (minutos)<input v-model.number="draft(o).minutes" class="rl-input" type="number" min="1" max="240" /></label>
            <label>Serviço<input v-model.trim="draft(o).label" class="rl-input" maxlength="80" /></label>
          </div>
          <div class="rl-row">
            <b>Total: {{ money(((draft(o).parts || 0) + (draft(o).labor || 0)) * 100) }}</b>
            <button class="rl-btn primary" :disabled="rl.busy.serviceQuote">{{ o.status === "quoted" ? "Reenviar orçamento" : "Enviar orçamento" }}</button>
            <button type="button" class="rl-btn" @click="request('serviceDecline', { orderId: o.id })">Recusar serviço</button>
          </div>
          <p v-if="o.quote" class="rl-muted">Último orçamento: {{ money(o.quote.total) }} — aguardando o cliente.</p>
        </form>
        <div v-else-if="o.status === 'accepted'" class="rl-row">
          <span>Aprovado: <b>{{ money(o.paid) }}</b> · você paga {{ money(o.quote?.parts) }} em peças ao começar.</span>
          <button class="rl-btn go" :disabled="busy >= shop.bays || rl.busy.serviceStart" @click="request('serviceStart', { orderId: o.id })">Colocar no elevador</button>
          <button class="rl-btn" @click="request('serviceDecline', { orderId: o.id })">Cancelar e devolver</button>
        </div>
        <div v-else-if="o.status === 'in_progress'">
          <div class="rl-progress"><i :style="{ width: progress(o) + '%' }"></i></div>
          <p class="rl-muted">{{ remaining(o) }} · ao terminar você recebe {{ money(o.paid) }}.</p>
        </div>
      </article>

      <template v-if="owner">
      <h3 class="rl-h2">Equipe</h3>
      <table v-if="staff.length" class="rl-table">
        <tr><th>Nome</th><th>Habilidade</th><th>Salário/dia</th><th>Comissão</th><th>Serviços</th><th>Ganhou</th><th></th></tr>
        <tr v-for="m in staff" :key="m.id">
          <td><b>{{ m.name }}</b><br /><small class="rl-muted">{{ m.kind === "player" ? "Jogador(a)" : "NPC" }}</small></td>
          <td class="stars">{{ m.kind === "npc" ? skillStars(m.skill) : "—" }}</td>
          <td>{{ money(m.wage) }}</td><td>{{ m.commission }}% da mão de obra</td><td>{{ m.sales || 0 }}</td><td>{{ money(m.earned) }}</td>
          <td><button class="rl-btn danger" :disabled="rl.busy.fire" @click="ask('Demitir ' + m.name + '?', () => request('fire', { businessId: shop.id, staffId: m.id }), 'Demitir')">Demitir</button></td>
        </tr>
      </table>
      <p v-else class="rl-muted">Sem mecânicos. Com mecânicos contratados, a oficina orça e executa os serviços sozinha (até um por elevador),
        inclusive quando você está longe ou offline.</p>
      <form class="rl-box rl-form" @submit.prevent="savePolicy">
        <label class="check"><input v-model="policy.autoQuote" type="checkbox" /> Mecânicos orçam e começam os serviços sozinhos</label>
        <label>Margem sobre o custo das peças: <b>{{ policy.markupPct }}%</b><input v-model.number="policy.markupPct" type="range" min="0" max="120" step="1" /></label>
        <button class="rl-btn primary">Salvar política</button>
      </form>
      <div class="cands">
        <article v-for="c in candidates" :key="c.id" class="rl-box cand">
          <b>{{ c.name }}</b><small class="rl-muted">{{ c.label }}</small>
          <span class="stars">{{ skillStars(c.skill) }}</span>
          <small>{{ money(c.wage) }}/dia · {{ c.commission }}% da mão de obra</small>
          <button class="rl-btn primary" :disabled="rl.busy.hire || hired(c)" @click="request('hire', { businessId: shop.id, candidateId: c.id })">{{ hired(c) ? "Contratado" : "Contratar" }}</button>
        </article>
      </div>
      <form class="rl-box rl-form" @submit.prevent="request('postVacancy', { businessId: shop.id, role: 'mecanico', commission: vacancy.commission, wage: Math.round((vacancy.wage || 0) * 100) })">
        <b>Vaga para jogador mecânico</b>
        <div class="rl-two">
          <label>Comissão sobre a mão de obra (%)<input v-model.number="vacancy.commission" class="rl-input" type="number" min="0" max="50" /></label>
          <label>Salário por dia ($)<input v-model.number="vacancy.wage" class="rl-input" type="number" min="0" /></label>
        </div>
        <button class="rl-btn primary">Publicar vaga</button>
      </form>

      <h3 class="rl-h2">Configurações</h3>
      <form class="rl-box rl-form" @submit.prevent="saveSettings">
        <div class="rl-two">
          <label>Nome<input v-model.trim="settings.name" class="rl-input" maxlength="64" required /></label>
          <label>Hora de mão de obra sugerida ($)<input v-model.number="settings.laborRate" class="rl-input" type="number" min="10" /></label>
        </div>
        <div class="rl-two">
          <label>Abre às<input v-model.number="settings.opensAt" class="rl-input" type="number" min="0" max="23" /></label>
          <label>Fecha às<input v-model.number="settings.closesAt" class="rl-input" type="number" min="0" max="23" /></label>
        </div>
        <label>Margem sobre peças (%)<input v-model.number="settings.markup" class="rl-input" type="number" min="0" max="200" /></label>
        <div class="rl-row">
          <label v-for="(t, k) in serviceNames" :key="k" class="check"><input v-model="settings.services[k]" type="checkbox" /> {{ t }}</label>
        </div>
        <label class="check"><input v-model="settings.npcEnabled" type="checkbox" /> Receber clientes NPC</label>
        <div class="rl-row">
          <button class="rl-btn primary">Salvar</button>
          <button type="button" class="rl-btn" @click="request('shop', { workshopId: shop.id, open: !shop.open })">{{ shop.open ? "Fechar as portas" : "Abrir as portas" }}</button>
          <button type="button" class="rl-btn" :disabled="shop.bays >= 6 || rl.busy.shop"
            @click="ask('Instalar mais um elevador por ' + money(shop.bays * 900000) + '?', () => request('shop', { workshopId: shop.id, upgrade: true }), 'Instalar')">+1 elevador · {{ money(shop.bays * 900000) }}</button>
          <button type="button" class="rl-btn danger" @click="confirmClose">Vender a oficina</button>
        </div>
      </form>
      </template>
      <div v-else class="rl-row"><button class="rl-btn" :disabled="rl.busy.quitJob" @click="ask('Pedir demissão desta oficina?', () => request('quitJob', { businessId: shop.id }), 'Pedir demissão')">Pedir demissão</button></div>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, money, status, distance, distanceText, myShop, myNpcs, toast, staffShop, skillStars, ask } from "../rl.js"

const props = defineProps({ focus: String, nonce: Number })
defineEmits(["open"])
const name = ref("")
const drafts = reactive({})
const settings = reactive({ services: {} })
const closing = ref(false)
const now = ref(Date.now() / 1000)
const serviceNames = { repair: "Reparos", maintenance: "Revisão", paint: "Pintura", tuning: "Preparação" }
let ticker

const shop = computed(() => myShop.value || staffShop.value)
const owner = computed(() => !!myShop.value && shop.value === myShop.value)
const staff = computed(() => Object.values(shop.value?.staff || {}))
const candidates = computed(() => shop.value?.candidates || [])
const policy = reactive({ autoQuote: true, markupPct: 30 })
const vacancy = reactive({ commission: 10, wage: 0 })
function hired(c) { return staff.value.some(m => m.candidateId === c.id) }
function savePolicy() { request("policy", { businessId: shop.value.id, autoQuote: policy.autoQuote, markupPct: policy.markupPct }) }
const costs = computed(() => rl.view.costs || { shop: 4000000, shopRent: 30000 })
const queue = computed(() => (rl.view.orders || []).filter(o => shop.value && o.workshopId === shop.value.id)
  .filter(o => !["completed", "declined", "rejected", "expired", "cancelled"].includes(o.status) || now.value - (o.completedAt || o.createdAt) < 1800)
  .sort((a, b) => b.createdAt - a.createdAt))
const running = computed(() => queue.value.filter(o => o.status === "in_progress"))
const busy = computed(() => running.value.length)
function bayJob(i) { return running.value[i] }
function npcOf(o) { return myNpcs.value.find(n => n.id === o.customer) }
function progress(o) { return Math.max(0, Math.min(100, ((now.value - o.startedAt) / Math.max(1, o.finishesAt - o.startedAt)) * 100)) }
function remaining(o) {
  const s = Math.max(0, Math.round(o.finishesAt - now.value))
  return s > 0 ? "faltam " + Math.floor(s / 60) + " min " + (s % 60) + " s" : "finalizando..."
}
function draft(o) {
  if (!drafts[o.id]) {
    const parts = Math.round((o.diagnosis?.partsCost || 0) * (1 + (shop.value?.markup || 25) / 100) / 100)
    const minutes = o.diagnosis?.minutes || Math.min(60, 3 + (o.diagnosis?.brokenParts || 0) * 2)
    const labor = Math.round((shop.value?.laborRate || 12000) / 100 * Math.max(1, minutes / 6))
    drafts[o.id] = { parts, labor, minutes, label: o.diagnosis?.notes || "Serviço completo" }
  }
  return drafts[o.id]
}
function sendQuote(o) {
  const d = draft(o)
  const items = []
  if (d.parts > 0) items.push({ label: "Peças", amount: Math.round(d.parts * 100), kind: "parts" })
  items.push({ label: d.label || "Mão de obra", amount: Math.round(Math.max(1, d.labor) * 100), kind: "labor" })
  request("serviceQuote", { orderId: o.id, items, minutes: Math.max(1, Math.min(240, Math.round(d.minutes || 5))) })
}
// Follow the server only when the saved settings change, so typing is never overwritten.
watch(() => shop.value && JSON.stringify([shop.value.id, shop.value.name, shop.value.opensAt, shop.value.closesAt,
  shop.value.npcEnabled, shop.value.markup, shop.value.laborRate, shop.value.services, shop.value.policy]), () => {
  const s = shop.value
  if (!s) return
  Object.assign(settings, { name: s.name, opensAt: s.opensAt, closesAt: s.closesAt, npcEnabled: s.npcEnabled, markup: s.markup,
    laborRate: Math.round((s.laborRate || 12000) / 100), services: { ...(s.services || {}) } })
  if (s.policy) Object.assign(policy, s.policy)
}, { immediate: true })
function saveSettings() {
  request("shop", { workshopId: shop.value.id, name: settings.name, opensAt: settings.opensAt, closesAt: settings.closesAt,
    npcEnabled: settings.npcEnabled, markup: settings.markup, laborRate: Math.round(settings.laborRate * 100), services: settings.services })
}
function confirmClose() {
  if (!closing.value) { closing.value = true; toast("Clique de novo em \"Vender a oficina\" para confirmar.", "warning"); setTimeout(() => { closing.value = false }, 5000); return }
  closing.value = false
  request("closeShop", { workshopId: shop.value.id })
}
onMounted(() => { ticker = setInterval(() => { now.value = Date.now() / 1000 }, 1000) })
onUnmounted(() => clearInterval(ticker))
</script>

<style scoped>
.between { justify-content: space-between; }
.grow { flex: 1; min-width: 220px; }
.intro { display: flex; gap: 18px; padding: 10px 4px; }
.intro-icon { width: 84px; height: 84px; border-radius: 16px; background: linear-gradient(135deg, #9aa7b8, #3c4b60); color: #fff; font-size: 48px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.bays { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 8px; margin: 8px 0; }
.bay { border: 2px dashed #b9c6d6; border-radius: 6px; padding: 10px; display: grid; gap: 4px; background: #f8fafc; }
.bay.on { border-style: solid; border-color: #3d7fd6; background: #eef5ff; }
.order.focus { border-color: #f0a500; box-shadow: 0 0 0 2px #ffd36b inset; }
.note { font-style: italic; color: #445; margin: 4px 0; }
.quote { display: grid; gap: 8px; margin-top: 6px; }
.quote label { display: grid; gap: 3px; font-size: 12px; }
.check { display: flex !important; flex-direction: row; align-items: center; gap: 6px; }
.stars { color: #d79a00; letter-spacing: 1px; white-space: nowrap; }
.cands { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 8px; }
.cand { display: flex; flex-direction: column; gap: 4px; }
</style>
