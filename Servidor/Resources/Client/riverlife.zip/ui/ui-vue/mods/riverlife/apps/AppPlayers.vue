<template>
  <div class="rl-page players">
    <h2 class="rl-h1">Jogadores</h2>
    <p v-if="rl.view.mode !== 'BeamMP'" class="rl-muted">Você está na carreira solo. No servidor River esta tela mostra quem está online, o que está dirigindo e onde está.</p>
    <template v-else>
      <p class="rl-muted">{{ online.length }} jogador(es) online em {{ rl.view.serverName || "este servidor" }}. Toque em "GPS" para encontrar alguém no mapa.</p>
      <article v-for="p in online" :key="p.pid" class="player rl-card">
        <div class="avatar" :style="{ background: color(p.name) }">{{ (p.name || "?").slice(0, 1).toUpperCase() }}</div>
        <div class="info">
          <div class="rl-row between">
            <b>{{ p.name }}{{ p.account === me.id ? " (você)" : "" }}</b>
            <span class="rl-badge" :class="p.walking ? '' : 'ok'">{{ p.walking ? "A pé" : (p.speed > 5 ? p.speed + " km/h" : "Parado") }}</span>
          </div>
          <p class="rl-muted">{{ p.walking ? "Caminhando" : "Dirigindo " + (p.niceName || p.model || "um carro") }}{{ p.activity ? " · " + p.activity : "" }}
            · {{ p.position ? distanceText(distance(rl.view.position, p.position)) + " de você" : "posição indisponível" }}</p>
          <p class="rl-muted">
            <span v-if="p.store">Loja: <b>{{ p.store.name }}</b> · </span>
            <span v-if="p.workshop">Oficina: <b>{{ p.workshop.name }}</b> · </span>
            ★ {{ ((p.reputation || 0) / 20).toFixed(1) }} · {{ p.sales || 0 }} venda(s)
          </p>
          <div v-if="p.account !== me.id" class="rl-row">
            <button class="rl-btn primary" :disabled="!p.position" @click="request('gpsPlayer', { pid: p.pid })">GPS até {{ p.name }}</button>
            <button v-if="p.account" class="rl-btn" @click="$emit('open', { app: 'mail', props: { to: p.account } })">Mensagem</button>
            <button v-if="p.store" class="rl-btn" @click="$emit('open', { app: 'internet', props: { start: 'lojas' } })">Ver loja</button>
            <button v-if="p.workshop" class="rl-btn" @click="$emit('open', { app: 'internet', props: { start: 'oficinas' } })">Ver oficina</button>
          </div>
        </div>
      </article>
      <h3 class="rl-h2">Já jogaram aqui</h3>
      <div class="known">
        <span v-for="a in offline" :key="a.id" class="rl-badge">{{ a.name }} · visto {{ ago(a.lastSeen) }}</span>
      </div>
    </template>
  </div>
</template>

<script setup>
import { computed } from "vue"
import { rl, request, ago, distance, distanceText, me } from "../rl.js"
defineEmits(["open"])
const online = computed(() => [...(rl.view.players || [])].sort((a, b) => distance(rl.view.position, a.position) - distance(rl.view.position, b.position)))
const offline = computed(() => (rl.view.accounts || []).filter(a => !online.value.some(p => p.account === a.id)))
function color(name) {
  let h = 0
  for (const c of String(name || "")) h = (h * 31 + c.charCodeAt(0)) % 360
  return `linear-gradient(135deg, hsl(${h},70%,60%), hsl(${(h + 40) % 360},70%,40%))`
}
</script>

<style scoped>
.between { justify-content: space-between; }
.player { display: flex; gap: 12px; padding: 10px 12px; margin: 8px 0; }
.avatar { width: 48px; height: 48px; border-radius: 50%; color: #fff; font: bold 22px Tahoma, sans-serif; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.info { flex: 1; min-width: 0; } .info p { margin: 3px 0; }
.known { display: flex; flex-wrap: wrap; gap: 6px; }
</style>
