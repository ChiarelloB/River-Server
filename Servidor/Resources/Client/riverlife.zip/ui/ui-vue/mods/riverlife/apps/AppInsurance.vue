<template>
  <!-- Opened from the desktop: start the RLS insurance session from this garage computer. -->
  <div v-if="!hosted" class="rl-page">
    <header class="ap-head">
      <span class="ap-tile"><BngIcon type="shieldCheckmark" /></span>
      <div><h2 class="rl-h1">Seguros</h2><p class="rl-muted">Apólices, coberturas, franquias e a sua pontuação de motorista.</p></div>
    </header>
    <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>A central de seguros do RLS só funciona em um computador de garagem.</div>
    <div v-else-if="!launchFn" class="rl-empty"><b>Seguros indisponíveis aqui</b>Este computador não oferece a central de seguros.</div>
    <div v-else class="rl-box ap-launch">
      <div><b>Central de seguros</b><p class="rl-muted">{{ launchFn.disabled ? (launchFn.reason?.label || "Indisponível agora.") : "Gerencie as apólices de todos os seus veículos." }}</p></div>
      <button class="rl-btn primary" :disabled="launchFn.disabled" @click="request('native', { buttonId: 'insurances' })">Abrir</button>
    </div>
  </div>

  <div v-else ref="root" class="ins">
    <div v-if="!data" class="rl-empty"><b>Carregando seguros...</b>Buscando suas apólices.</div>

    <template v-else>
      <!-- Change provider for one vehicle (wizard page). -->
      <section v-if="change.vehId != null" class="rl-page chg">
        <div class="chg-top">
          <button class="rl-btn" :disabled="change.busy" @click="closeChange"><BngIcon type="arrowLargeLeft" /> Voltar</button>
          <h2 class="rl-h1">Trocar seguradora</h2>
        </div>
        <div v-if="!change.data" class="rl-empty"><b>Consultando seguradoras...</b>Calculando reembolsos e custos.</div>
        <template v-else>
          <div class="chg-veh">
            <img v-if="change.data.vehicleInfo?.thumbnail" :src="change.data.vehicleInfo.thumbnail" alt="" />
            <div>
              <b>{{ change.data.vehicleInfo?.Name || change.name }}</b>
              <p class="rl-muted">Valor segurado {{ dollars(change.data.vehicleInfo?.Value) }} · Seguro atual: <b>{{ policyName(change.data.currentInsuranceId) }}</b>
                · Pontuação {{ change.data.driverScoreData?.score }} ({{ riskName(change.data.driverScoreData?.tier?.risk) }})</p>
            </div>
          </div>

          <div class="chg-list">
            <button v-for="o in changeOptions" :key="o.id" class="chg-opt" :class="{ on: change.selected === o.id, current: o.id === change.data.currentInsuranceId }"
              :disabled="o.id === change.data.currentInsuranceId || change.busy" @click="change.selected = o.id">
              <span class="chg-radio"></span>
              <span class="pol-logo sm" :style="{ background: o.color || (o.id === -1 ? '#9aa3ad' : '#3d7fd6') }">
                <img v-if="o.image && !badImg[o.image]" :src="'/' + o.image" alt="" @error="badImg[o.image] = true" />
                <BngIcon v-else :type="o.id === -1 ? 'abandon' : 'shieldCheckmark'" />
              </span>
              <span class="chg-opt-main">
                <b>{{ o.id === -1 ? "Sem seguro" : o.name }} <span v-if="o.id === change.data.currentInsuranceId" class="rl-badge">Atual</span></b>
                <small v-if="o.id === -1">Você paga o reparo integral. Não recomendado.</small>
                <small v-else>{{ perkList(o).map(x => x.text).join(" · ") || o.slogan }}</small>
              </span>
              <span class="chg-opt-price">
                <template v-if="o.id === -1"><small>Hoje</small><b class="good">+ {{ dollars(o.leavingInsuranceInfo?.netRefundPrice) }}</b></template>
                <template v-else-if="o.id !== change.data.currentInsuranceId">
                  <small>Novo prêmio {{ dollars(o.futurePremiumDetails?.totalPriceWithDriverScore) }}</small>
                  <b :class="(o.amountDue || 0) > 0 ? 'bad' : 'good'">{{ (o.amountDue || 0) > 0 ? "pagar " + dollars(o.amountDue) : "receber " + dollars(-(o.amountDue || 0)) }}</b>
                </template>
              </span>
            </button>
          </div>

          <fieldset v-if="selectedChange" class="xp-group chg-detail">
            <legend>{{ selectedChange.id === -1 ? "Remover cobertura" : "Mover para " + selectedChange.name }}</legend>
            <div class="chg-cols">
              <div>
                <h4>Saindo de {{ policyName(change.data.currentInsuranceId) }}</h4>
                <div class="ln"><span>Reembolso da cobertura não usada</span><b class="good">+ {{ dollars(leaving.coverageRefundPrice) }}</b></div>
                <div class="ln"><span>Multa de cancelamento (25%)</span><b class="bad">− {{ dollars(leaving.earlyTerminationPenalty) }}</b></div>
                <div class="ln strong"><span>Reembolso líquido</span><b>{{ dollars(leaving.netRefundPrice) }}</b></div>
                <div v-if="leaving.vehicleCount" class="ln"><span>Veículos na apólice</span><b>{{ leaving.vehicleCount }} → {{ leaving.newVehicleCount }}</b></div>
                <div v-if="leaving.discountTierData" class="ln"><span>Faixa de desconto multiveículo</span><b>{{ leaving.discountTierData.id || 0 }} → {{ leaving.newDiscountTierData?.id || 0 }}</b></div>
              </div>
              <div v-if="selectedChange.id !== -1">
                <h4>Entrando em {{ selectedChange.name }}</h4>
                <div class="ln"><span>Custo para incluir (proporcional ao ciclo)</span><b class="bad">{{ dollars(selectedChange.addVehiclePrice) }}</b></div>
                <div class="ln"><span>Veículos na apólice</span><b>{{ selectedChange.carsInsuredCount || 0 }} → {{ (selectedChange.carsInsuredCount || 0) + 1 }}</b></div>
                <div class="ln"><span>Faixa de desconto multiveículo</span><b>{{ selectedChange.groupDiscountData?.currentTierData?.id || 0 }} → {{ selectedChange.groupDiscountData?.futureTierData?.id || 0 }}</b></div>
                <div class="ln strong"><span>Prêmio da apólice após a troca</span><b>{{ dollars(selectedChange.futurePremiumDetails?.totalPriceWithDriverScore) }} / {{ selectedChange.renewsEvery || 50 }} km</b></div>
                <div class="ln"><span>Taxa para alterar cobertura depois</span><b>{{ dollars(selectedChange.paperworkFees) }}</b></div>
              </div>
              <div v-else>
                <h4>Sem cobertura</h4>
                <p class="rl-muted">Sem seguro, qualquer dano é pago integralmente por você no reparo particular. A pontuação do motorista não muda com reparos particulares.</p>
              </div>
            </div>
            <div class="chg-total" :class="todayAmount > 0 ? 'pay' : 'credit'">
              <span>{{ todayAmount > 0 ? "Você paga hoje" : "Você recebe hoje" }}</span><b>{{ dollars(Math.abs(todayAmount)) }}</b>
            </div>
          </fieldset>

          <div class="chg-foot">
            <span v-if="selectedChange && selectedChange.canPay === false" class="rl-error">Saldo insuficiente para essa troca.</span>
            <span v-else class="rl-muted">A troca vale na hora. O prêmio é cobrado a cada {{ selectedChange?.renewsEvery || 50 }} km rodados com carros segurados.</span>
            <button class="rl-btn" :disabled="change.busy" @click="closeChange">Cancelar</button>
            <button class="rl-btn primary" :disabled="!selectedChange || selectedChange.canPay === false || change.busy" @click="confirmChange">
              {{ !selectedChange ? "Escolha uma opção" : selectedChange.id === -1 ? "Remover cobertura" : "Mover para " + selectedChange.name }}</button>
          </div>
        </template>
      </section>

      <section v-else class="rl-page">
        <header class="ap-head">
          <span class="ap-tile"><BngIcon type="shieldCheckmark" /></span>
          <div><h2 class="rl-h1">Seguros</h2><p class="rl-muted">O prêmio de cada apólice é cobrado a cada 50 km rodados com um carro segurado por ela.</p></div>
        </header>
        <div class="rl-stats">
          <div><b>{{ insuredCount }} / {{ vehicles.length }}</b><small>Veículos segurados</small></div>
          <div><b>{{ dollars(totalPremium) }}</b><small>Prêmios por ciclo (50 km)</small></div>
          <div><b :style="{ color: scoreColor }">{{ score }}</b><small>Pontuação · {{ riskName(tier.risk) }}</small></div>
          <div><b>{{ dollars(data.careerMoney) }}</b><small>Seu saldo</small></div>
        </div>

        <div class="rl-tabs">
          <button :class="{ on: tab === 'policies' }" @click="tab = 'policies'">Minhas apólices</button>
          <button :class="{ on: tab === 'vehicles' }" @click="tab = 'vehicles'">Veículos</button>
          <button :class="{ on: tab === 'score' }" @click="openScore">Pontuação do motorista</button>
        </div>

        <!-- Policies -->
        <template v-if="tab === 'policies'">
          <div v-if="!myPolicies.length" class="rl-empty"><b>Nenhuma apólice ativa</b>Nenhum veículo seu tem seguro. Na aba Veículos, use "Contratar seguro".</div>
          <article v-for="p in myPolicies" :key="p.id" class="pol" :style="{ '--pc': p.color || '#3d7fd6' }">
            <header class="pol-head">
              <span class="pol-logo" :style="{ background: p.color || '#3d7fd6' }">
                <img v-if="p.image && !badImg[p.image]" :src="'/' + p.image" alt="" @error="badImg[p.image] = true" /><BngIcon v-else type="shieldCheckmark" />
              </span>
              <div class="pol-title"><b>{{ p.name }}</b><small>{{ p.slogan ? "“" + p.slogan + "” · " : "" }}{{ p.className }}</small></div>
              <div class="pol-premium"><b>{{ dollars(p.currentPremiumDetails?.totalPriceWithDriverScore) }}</b><small>a cada {{ p.renewsEvery || 50 }} km</small></div>
            </header>
            <div class="pol-body">
              <div class="pol-facts">
                <span><small>Veículos</small><b>{{ p.carsInsuredCount }}</b></span>
                <span><small>Valor coberto</small><b>{{ dollars(p.totalInsuranceVehsValue) }}</b></span>
                <span><small>Renova em</small><b>{{ num(p.renewsIn) }} km</b></span>
                <span><small>Desconto multiveículo</small><b>{{ tierText(p) }}</b></span>
              </div>
              <div class="rl-progress pol-cycle" :title="'Ciclo de ' + (p.renewsEvery || 50) + ' km'"><i :style="{ width: cyclePct(p) + '%' }"></i></div>
              <ul v-if="perkList(p).length" class="pol-perks">
                <li v-for="k in perkList(p)" :key="k.id" :class="{ sig: k.signature }"><BngIcon :type="k.signature ? 'star' : 'checkmark'" /> {{ k.text }}</li>
              </ul>

              <div class="pol-cov">
                <span v-for="o in arr(p.coverageOptionsData)" :key="o.key"><small>{{ optName(o) }}</small><b>{{ currentChoiceLabel(o) }}</b></span>
                <button class="rl-btn" :disabled="editing.policyId === p.id" @click="startEdit(p)"><BngIcon type="gearTuningOutline" /> Editar cobertura</button>
              </div>

              <div v-if="editing.policyId === p.id" class="xp-group pol-edit">
                <div class="xp-legend">Editar cobertura da apólice</div>
                <div v-for="o in arr(p.coverageOptionsData)" :key="o.key" class="cov-row">
                  <div class="cov-name"><b>{{ optName(o) }}</b><small v-if="perkNote(p, o.key)">{{ perkNote(p, o.key) }}</small></div>
                  <div class="seg">
                    <button v-for="c in arr(o.choices)" :key="c.id" :class="{ on: editing.options[o.key] === c.id, cur: o.currentValueId === c.id }" :disabled="c.disabled || editing.busy"
                      @click="setPolicyChoice(p, o.key, c.id)"><b>{{ choiceLabel(o.key, c) }}</b><small>{{ choicePrice(o.key, c) }}</small></button>
                  </div>
                </div>
                <table class="rl-table prem"><tbody>
                  <tr><th>Item do prêmio</th><th class="r">Atual</th><th class="r">Com as mudanças</th></tr>
                  <tr v-for="it in premiumItems(p)" :key="it.key">
                    <td>{{ it.name }}</td><td class="r">{{ dollars(it.now) }}</td>
                    <td class="r" :class="diffClass(it.next - it.now)">{{ dollars(it.next) }}</td>
                  </tr>
                  <tr><td>Fator da pontuação ({{ score }} · {{ riskName(tier.risk) }})</td><td class="r">×{{ num(tier.multiplier, 2) }}</td><td class="r">×{{ num(tier.multiplier, 2) }}</td></tr>
                  <tr class="tot"><td><b>Prêmio por ciclo</b></td><td class="r"><b>{{ dollars(p.currentPremiumDetails?.totalPriceWithDriverScore) }}</b></td>
                    <td class="r" :class="diffClass(previewTotal(p) - (p.currentPremiumDetails?.totalPriceWithDriverScore || 0))"><b>{{ dollars(previewTotal(p)) }}</b></td></tr>
                </tbody></table>
                <div class="rl-row edit-foot">
                  <span class="rl-muted">Alterar a cobertura custa a taxa administrativa de {{ dollars(p.paperworkFees) }}.</span>
                  <button class="rl-btn" :disabled="editing.busy" @click="cancelEdit">Cancelar</button>
                  <button class="rl-btn primary" :disabled="editing.busy || !policyChanged(p) || !p.canPayPaperworkFees" @click="savePolicy(p)">
                    {{ !p.canPayPaperworkFees ? "Saldo insuficiente" : "Salvar (" + dollars(p.paperworkFees) + ")" }}</button>
                </div>
              </div>

              <table class="rl-table pol-cars"><tbody>
                <tr><th>Veículo coberto</th><th>Franquia</th><th class="r">Prêmio do veículo</th><th></th></tr>
                <tr v-for="v in vehiclesOf(p)" :key="v.id">
                  <td><b>{{ v.name }}</b> <span v-if="v.needsRepair" class="rl-badge bad">Precisa de reparo</span></td>
                  <td>{{ v.deductible != null ? dollars(v.deductible) : "—" }}</td>
                  <td class="r">{{ dollars(v.premium) }}</td>
                  <td class="r"><button class="rl-btn small" @click="gotoVehicle(v)">Gerenciar</button></td>
                </tr>
              </tbody></table>
            </div>
          </article>

          <button class="others-toggle" @click="showOthers = !showOthers"><BngIcon :type="showOthers ? 'minus' : 'plus'" /> Outras seguradoras ({{ otherPolicies.length }})</button>
          <div v-if="showOthers" class="others">
            <div v-for="c in classes" :key="c.id" class="other-class">
              <h4>{{ c.name }} <small class="rl-muted">{{ classHint(c.id) }}</small></h4>
              <div class="rl-grid">
                <div v-for="p in c.insurances.filter(x => !x.carsInsuredCount)" :key="p.id" class="rl-card other">
                  <div class="pol-head mini">
                    <span class="pol-logo sm" :style="{ background: p.color || '#3d7fd6' }">
                      <img v-if="p.image && !badImg[p.image]" :src="'/' + p.image" alt="" @error="badImg[p.image] = true" /><BngIcon v-else type="shieldCheckmark" />
                    </span>
                    <div class="pol-title"><b>{{ p.name }}</b><small>{{ p.slogan }}</small></div>
                  </div>
                  <ul class="pol-perks">
                    <li v-for="k in perkList(p)" :key="k.id" :class="{ sig: k.signature }"><BngIcon :type="k.signature ? 'star' : 'checkmark'" /> {{ k.text }}</li>
                    <li v-if="!perkList(p).length" class="rl-muted">Sem benefícios extras</li>
                  </ul>
                </div>
              </div>
            </div>
            <p class="rl-muted">Para contratar uma destas, abra a aba Veículos e use "Trocar seguradora" no carro desejado (só aparecem as seguradoras da categoria do carro).</p>
          </div>
        </template>

        <!-- Vehicles -->
        <template v-else-if="tab === 'vehicles'">
          <div class="rl-row veh-tools">
            <XPSelect v-model="vehFilter" aria-label="Filtrar veículos" :options="[{ value: '', label: 'Todos os veículos' }, { value: 'insured', label: 'Segurados' }, { value: 'uninsured', label: 'Sem seguro' }]" />
            <span class="rl-muted">{{ shownVehicles.length }} veículo(s)</span>
          </div>
          <div v-if="!shownVehicles.length" class="rl-empty"><b>Nenhum veículo</b>Nada para mostrar com este filtro.</div>
          <article v-for="v in shownVehicles" :key="v.id" class="veh rl-card" :class="{ focus: focusVeh === v.id }">
            <div class="veh-row">
              <div class="veh-shot"><img v-if="v.thumbnail" :src="v.thumbnail" alt="" /></div>
              <div class="veh-main">
                <div class="rl-row">
                  <b class="veh-name">{{ v.name }}</b>
                  <span v-if="v.policy" class="rl-badge ok">{{ v.policy.name }}</span><span v-else class="rl-badge bad">Sem seguro</span>
                  <span v-if="v.needsRepair" class="rl-badge warn">Precisa de reparo</span>
                </div>
                <p class="rl-muted">Valor segurado {{ dollars(v.value) }}<template v-if="v.className"> · categoria {{ v.className }}</template>
                  <template v-if="v.policy"> · franquia {{ v.deductible != null ? dollars(v.deductible) : "—" }} · prêmio do veículo {{ dollars(v.premium) }}</template>
                  <template v-else> · sem cobertura: você paga o reparo integral</template></p>
                <div class="rl-row">
                  <button v-if="v.policy" class="rl-btn" :disabled="v.needsRepair || vEdit.vehId === v.id" :title="v.needsRepair ? 'Conserte o veículo antes' : ''"
                    @click="startVehEdit(v)">Alterar franquia</button>
                  <button class="rl-btn primary" :disabled="v.needsRepair" :title="v.needsRepair ? 'Conserte o veículo antes' : ''" @click="openChange(v)">
                    {{ v.policy ? "Trocar seguradora" : "Contratar seguro" }}</button>
                  <span v-if="v.needsRepair" class="rl-muted">Conserte o veículo antes de mudar o seguro.</span>
                </div>
              </div>
            </div>

            <div v-if="vEdit.vehId === v.id" class="xp-group veh-edit">
              <div class="xp-legend">Cobertura deste veículo</div>
              <div v-for="o in v.options" :key="o.key" class="cov-row">
                <div class="cov-name"><b>{{ optName(o) }}</b><small>{{ o.key === "deductible" ? "Quanto você paga em cada reparo pelo seguro" : "" }}</small></div>
                <div class="seg">
                  <button v-for="c in arr(o.choices)" :key="c.id" :class="{ on: vEdit.options[o.key] === c.id, cur: o.currentValueId === c.id }" :disabled="c.disabled || vEdit.busy"
                    @click="setVehChoice(v, o.key, c.id)"><b>{{ choiceLabel(o.key, c) }}</b><small>{{ choicePrice(o.key, c) }}</small></button>
                </div>
              </div>
              <div class="veh-prev">
                <span>Prêmio do veículo: <b>{{ dollars(v.premium) }}</b> → <b :class="diffClass((vEdit.vehCost ?? v.premium) - v.premium)">{{ dollars(vEdit.vehCost ?? v.premium) }}</b></span>
                <span>Prêmio da apólice: <b>{{ dollars(v.policy.currentPremiumDetails?.totalPriceWithDriverScore) }}</b> →
                  <b :class="diffClass((vEdit.policyTotal ?? 0) - (v.policy.currentPremiumDetails?.totalPriceWithDriverScore || 0))">{{ dollars(vEdit.policyTotal ?? v.policy.currentPremiumDetails?.totalPriceWithDriverScore) }}</b></span>
              </div>
              <div class="rl-row edit-foot">
                <span class="rl-muted">Taxa administrativa: {{ dollars(v.policy.paperworkFees) }}. Franquia menor = prêmio maior.</span>
                <button class="rl-btn" :disabled="vEdit.busy" @click="vEdit.vehId = null">Cancelar</button>
                <button class="rl-btn primary" :disabled="vEdit.busy || !vehChanged(v) || !v.policy.canPayPaperworkFees" @click="saveVeh(v)">
                  {{ !v.policy.canPayPaperworkFees ? "Saldo insuficiente" : "Salvar (" + dollars(v.policy.paperworkFees) + ")" }}</button>
              </div>
            </div>
          </article>
        </template>

        <!-- Driver score -->
        <template v-else>
          <div class="score-top">
            <div class="score-dial" :style="{ '--sc': scoreColor }"><b>{{ score }}</b><small>de 100</small></div>
            <div class="score-info">
              <h3>{{ riskName(tier.risk) }}</h3>
              <p class="rl-muted">{{ tierDesc(tier.description) }} · faixa {{ tier.min }}–{{ tier.max }} · seus prêmios ×{{ num(tier.multiplier, 2) }}
                ({{ tier.multiplier < 1 ? "desconto de " + Math.round((1 - tier.multiplier) * 100) + "%" : tier.multiplier > 1 ? "acréscimo de " + Math.round((tier.multiplier - 1) * 100) + "%" : "sem ajuste" }})</p>
              <div class="score-bar"><i :style="{ left: Math.max(0, Math.min(100, score)) + '%' }"></i></div>
              <p class="rl-muted">A pontuação sobe 2 pontos a cada 50 km dirigidos sem sinistro e cai a cada reparo feito pelo seguro (exceto quando um perdão de acidente é usado).</p>
            </div>
          </div>

          <fieldset class="xp-group reset">
            <legend>Redefinir pontuação</legend>
            <template v-if="resetCost > 0">
              <p>Volte para <b>{{ resetTo }}</b> pontos (na média) pagando <b>{{ dollars(resetCost) }}</b>.</p>
              <div v-if="!confirmReset" class="rl-row">
                <button class="rl-btn primary" :disabled="resetBusy || (data.careerMoney || 0) < resetCost" @click="confirmReset = true">Redefinir por {{ dollars(resetCost) }}</button>
                <span v-if="(data.careerMoney || 0) < resetCost" class="rl-error">Saldo insuficiente.</span>
              </div>
              <div v-else class="rl-box confirm">
                <b>Pagar {{ dollars(resetCost) }} para redefinir sua pontuação de {{ score }} para {{ resetTo }}?</b>
                <div class="rl-row"><button class="rl-btn primary" :disabled="resetBusy" @click="doReset">Sim, redefinir</button><button class="rl-btn" :disabled="resetBusy" @click="confirmReset = false">Não</button></div>
              </div>
            </template>
            <p v-else class="rl-muted">Sua pontuação já está na média ou acima ({{ resetTo }}+). Não há nada a redefinir.</p>
          </fieldset>

          <div v-if="abstract" class="rl-stats">
            <div><b>{{ km(abstract.totalDistanceDriven) }}</b><small>Distância dirigida</small></div>
            <div><b>{{ abstract.repairHistory?.insuranceRepairs ?? 0 }}</b><small>Reparos pelo seguro</small></div>
            <div><b>{{ abstract.repairHistory?.privateRepairs ?? 0 }}</b><small>Reparos particulares</small></div>
            <div><b>{{ dollars(abstract.financialSummary?.totalPremiumPaid) }}</b><small>Prêmios pagos</small></div>
            <div><b>{{ dollars(abstract.financialSummary?.totalDeductiblePaid) }}</b><small>Franquias pagas</small></div>
            <div><b>{{ dollars(abstract.financialSummary?.damageCoveredByInsurance) }}</b><small>Danos cobertos pelo seguro</small></div>
          </div>

          <h3 class="rl-h2">Histórico</h3>
          <table v-if="history.length" class="rl-table"><tbody>
            <tr><th>Data</th><th>Evento</th><th>Seguradora</th><th class="r">Dinheiro</th><th class="r">Pontuação</th></tr>
            <tr v-for="(h, i) in history" :key="i">
              <td>{{ h.when }}</td><td>{{ h.title }}</td><td>{{ h.insurer }}</td>
              <td class="r" :class="diffClass(-(h.money || 0))">{{ h.money ? (h.money > 0 ? "+" : "−") + dollars(Math.abs(h.money)) : "" }}</td>
              <td class="r" :class="diffClass(-(h.score || 0))">{{ h.score ? (h.score > 0 ? "+" : "") + h.score : "" }}</td>
            </tr>
          </tbody></table>
          <p v-else class="rl-muted">Nenhum evento ainda.</p>
        </template>
      </section>
    </template>
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, onUnmounted, reactive, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import XPSelect from "../components/XPSelect.vue"
import { rl, request, luaCall, luaDo, luaValue, onGameEvent, dollars, arr, toast, km } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const MOD = "career_modules_insurance_insurance"

const RISK = { "Exceptional": "Excepcional", "Excellent": "Excelente", "Very Good": "Muito boa", "Good": "Boa", "Above Average": "Acima da média",
  "Average": "Na média", "Below Average": "Abaixo da média", "Mediocre": "Medíocre", "Poor": "Ruim", "High Risk": "Alto risco",
  "Very High Risk": "Risco muito alto", "Severe Risk": "Risco severo", "Critical Risk": "Risco crítico", "Extreme Risk": "Risco extremo", "Maximum Risk": "Risco máximo" }
const TIER_DESC = { "Spotless record": "Ficha impecável", "Trusted driver": "Motorista de confiança", "Clean record": "Ficha limpa", "Reliable driver": "Motorista confiável",
  "Few incidents": "Poucos incidentes", "Standard rate": "Tarifa padrão", "Multiple claims": "Vários sinistros", "Needs improvement": "Precisa melhorar",
  "Many incidents": "Muitos incidentes", "Concerning pattern": "Histórico preocupante", "Heavy penalties": "Penalidades pesadas", "Major red flags": "Muitos alertas",
  "Extreme penalties": "Penalidades extremas", "Near uninsurable": "Quase sem seguro", "Almost rejected": "Quase recusado", "Worst possible rate": "Pior tarifa possível" }
const OPT_NAMES = { repairTime: "Tempo de reparo", deductible: "Franquia", roadsideAssistance: "Assistência na estrada", paintRepair: "Repintura no reparo" }
const CLASS_NAMES = { dailyDriver: "Uso diário", commercial: "Comercial", prestige: "Prestígio" }
const CLASS_HINTS = { dailyDriver: "carros comuns até $100 mil", commercial: "utilitários e caminhões", prestige: "carros de alto valor" }
const HISTORY = { insuranceRepairClaim: "Reparo pelo seguro", privateRepair: "Reparo particular", insuranceRenewed: "Renovação do seguro",
  insuranceChanged: "Troca de seguradora", insuranceCoverageChanged: "Cobertura alterada", driverScoreIncrease: "Direção segura",
  driverScoreReset: "Pontuação redefinida", freeRepair: "Perdão de acidente ganho", testDriveClaim: "Dano em test drive" }

const hosted = computed(() => !!props.route)
const root = ref(null)
const data = ref(null)
const tab = ref("policies")
const showOthers = ref(false)
const vehFilter = ref("")
const focusVeh = ref(null)
const badImg = reactive({})
const editing = reactive({ policyId: null, options: {}, preview: null, seq: 0, busy: false })
const vEdit = reactive({ vehId: null, options: {}, vehCost: null, policyTotal: null, seq: 0, busy: false })
const change = reactive({ vehId: null, name: "", data: null, selected: null, busy: false })
const abstract = ref(null)
const confirmReset = ref(false)
const resetBusy = ref(false)
let offs = []

function num(v, d = 0) { return new Intl.NumberFormat((window.__rlLocale || "pt-BR"), { minimumFractionDigits: d, maximumFractionDigits: d }).format(Number(v) || 0) }
function riskName(r) { return RISK[r] || r || "" }
function tierDesc(d) { return TIER_DESC[d] || d || "" }
function diffClass(d) { return d > 0.5 ? "bad" : d < -0.5 ? "good" : "" }
function className(id, fallback) { return CLASS_NAMES[id] || fallback || id }
function classHint(id) { return CLASS_HINTS[id] ? "· " + CLASS_HINTS[id] : "" }
function optName(o) { return OPT_NAMES[o.key] || o.name || o.key }

// Coverage choices (labels rebuilt in PT; RLS sends English choiceText).
function choiceLabel(key, c) {
  if (key === "repairTime") return Number(c.value) > 0 ? num(Number(c.value) / 60) + " min" : "Instantâneo"
  if (key === "deductible") return dollars(c.value)
  if (key === "roadsideAssistance") return num(c.value) + (Number(c.value) === 1 ? " reboque" : " reboques")
  if (typeof c.value === "boolean") return c.value ? "Incluída" : "Não incluída"
  return c.choiceText || String(c.value)
}
function choicePrice(key, c) {
  if (key === "deductible") return "prêmio ×" + num(c.premiumInfluence, 1)
  const p = Number(c.premiumInfluence) || 0
  return p ? "+" + dollars(p) + " / ciclo" : "sem custo"
}
function currentChoiceLabel(o) {
  const c = arr(o.choices).find(x => x.id === o.currentValueId)
  return c ? choiceLabel(o.key, c) : "—"
}
function perkText(id, p) {
  const v = Number(p?.value) || 0
  const pct = Math.round(v * 100)
  switch (id) {
    case "fuelDiscount": return pct + "% de desconto em combustível e recarga"
    case "freeTowing": return num(v) + " reboques grátis por ciclo"
    case "accidentForgivenessAtRenewal": return num(v) + (v === 1 ? " perdão" : " perdões") + " de acidente a cada renovação"
    case "instantRepair": return "Reparo instantâneo sem custo extra"
    case "freeRefuelDuringRepair": return "Tanque cheio a cada reparo"
    case "repairTimeDiscount": return pct + "% de desconto no tempo de reparo"
    case "reduceDeductible": return "Franquia " + pct + "% menor"
    case "freeRepaintDuringRepair": return "Repintura grátis no reparo"
    default: return p?.intro || id
  }
}
function perkList(p) {
  const perks = p?.perks
  if (!perks || typeof perks !== "object") return []
  const entries = Array.isArray(perks) ? perks.map((x, i) => [x?.id || String(i), x]) : Object.entries(perks)
  return entries.filter(([id]) => id !== "noInsurance").map(([id, x]) => ({ id, text: perkText(id, x), signature: !!x?.isSignaturePerk }))
    .sort((a, b) => Number(b.signature) - Number(a.signature))
}
const PERK_FOR = { repairTime: ["instantRepair", "repairTimeDiscount"], deductible: ["reduceDeductible"], roadsideAssistance: ["freeTowing"], paintRepair: ["freeRepaintDuringRepair"] }
function perkNote(p, key) {
  const perks = p?.perks || {}
  const id = (PERK_FOR[key] || []).find(k => perks[k])
  return id ? "Benefício da apólice: " + perkText(id, perks[id]) : ""
}

// Data
const score = computed(() => Math.round(Number(data.value?.driverScoreData?.score) || 0))
const tier = computed(() => data.value?.driverScoreData?.tier || {})
const scoreColor = computed(() => {
  const m = Number(tier.value.multiplier) || 1
  return m < 1 ? "#1e7a1e" : m > 1.25 ? "#b0281a" : m > 1 ? "#b06a00" : "#164a8c"
})
const classes = computed(() => Object.entries(data.value?.plClassesData || {})
  .map(([id, c]) => ({ id, name: className(id, c?.name), priority: Number(c?.priority) || 0, insurances: arr(c?.insurances).filter(Boolean) }))
  .sort((a, b) => a.priority - b.priority))
const policies = computed(() => classes.value.flatMap(c => c.insurances.map(i => ({ ...i, classId: c.id, className: c.name }))))
const myPolicies = computed(() => policies.value.filter(p => (p.carsInsuredCount || 0) > 0))
const otherPolicies = computed(() => policies.value.filter(p => !(p.carsInsuredCount > 0)))
const totalPremium = computed(() => myPolicies.value.reduce((s, p) => s + (Number(p.currentPremiumDetails?.totalPriceWithDriverScore) || 0), 0))
function policyName(id) {
  if (id == null || Number(id) === -1) return "Sem seguro"
  return policies.value.find(p => Number(p.id) === Number(id))?.name || "Seguradora " + id
}
function tierText(p) {
  const t = p.groupDiscountData?.currentTierData
  if (!t || !(t.id > 0)) return p.carsInsuredCount > 1 ? "—" : "a partir de 2 carros"
  return Math.round((t.discount || 0) * 100) + "% (economia " + dollars(p.currentPremiumDetails?.groupDiscountSavings) + ")"
}
function cyclePct(p) {
  const every = Number(p.renewsEvery) || 50
  return Math.max(0, Math.min(100, (1 - (Number(p.renewsIn) || 0) / every) * 100))
}

// Keyed by numeric inventory id in Lua: contiguous ids arrive as an array, so index by each entry's own id.
const vehUi = computed(() => {
  const map = {}
  for (const u of arr(data.value?.invVehsInsurancesData)) if (u && u.id != null) map[String(u.id)] = u
  return map
})
function vehRow(car, policy) {
  const ui = vehUi.value[String(car.id)] || {}
  const options = arr(car.insuranceData?.coverageOptionsData?.currentCoverageOptionsSanitized)
  const ded = options.find(o => o.key === "deductible")
  const dedChoice = ded && arr(ded.choices).find(c => c.id === ded.currentValueId)
  const cls = car.requiredInsuranceClass
  return {
    id: Number(car.id), name: car.name || ui.niceName || "Veículo", thumbnail: car.thumbnail || ui.thumbnail, value: car.initialValue,
    policy, needsRepair: !!(car.needsRepair ?? ui.needsRepair), premium: Number(car.insuranceData?.currentPremiumPrice ?? ui.individualRenewalPrice) || 0,
    deductible: dedChoice ? dedChoice.value : null, options, className: cls ? className(cls.id, cls.name) : "",
  }
}
const vehicles = computed(() => {
  const out = []
  for (const p of policies.value) for (const car of arr(p.carsInsured)) out.push(vehRow(car, p))
  for (const car of arr(data.value?.uninsuredVehsData?.carsUninsured)) out.push(vehRow(car, null))
  return out.sort((a, b) => String(a.name).localeCompare(String(b.name)))
})
const insuredCount = computed(() => vehicles.value.filter(v => v.policy).length)
const shownVehicles = computed(() => vehicles.value.filter(v => !vehFilter.value || (vehFilter.value === "insured" ? !!v.policy : !v.policy)))
function vehiclesOf(p) { return vehicles.value.filter(v => v.policy && Number(v.policy.id) === Number(p.id)) }
function gotoVehicle(v) {
  vehFilter.value = ""; focusVeh.value = v.id; tab.value = "vehicles"
  nextTick(() => root.value?.querySelector(".veh.focus")?.scrollIntoView({ block: "center" }))
}

// Policy-wide coverage editing with a live premium preview.
function startEdit(p) {
  editing.policyId = p.id
  editing.options = {}
  editing.preview = null
  for (const o of arr(p.coverageOptionsData)) editing.options[o.key] = o.currentValueId
}
function cancelEdit() { editing.policyId = null; editing.preview = null }
function policyChanged(p) { return arr(p.coverageOptionsData).some(o => editing.options[o.key] !== o.currentValueId) }
async function setPolicyChoice(p, key, id) {
  editing.options = { ...editing.options, [key]: id }
  const seq = ++editing.seq
  const res = await luaCall(MOD + ".calculateInsurancePremium(" + Number(p.id) + ", " + luaValue(editing.options) + ", nil)")
  if (seq === editing.seq && editing.policyId === p.id) editing.preview = res || null
}
function premiumItems(p) {
  const now = p.currentPremiumDetails?.items || {}
  const next = editing.preview?.items || now
  const keys = Array.from(new Set([...Object.keys(now), ...Object.keys(next)]))
  return keys.map(key => ({
    key, name: key === "vehsCoverage" ? "Cobertura dos veículos (com desconto multiveículo)" : OPT_NAMES[key] || now[key]?.name || key,
    now: Number(now[key]?.price) || 0, next: Number(next[key]?.price ?? now[key]?.price) || 0,
  }))
}
function previewTotal(p) { return Number(editing.preview?.totalPriceWithDriverScore ?? p.currentPremiumDetails?.totalPriceWithDriverScore) || 0 }
async function savePolicy(p) {
  if (!policyChanged(p) || editing.busy) return
  editing.busy = true
  try {
    if (await luaDo(MOD + ".saveNewInsuranceCoverageOptions(" + Number(p.id) + ", " + luaValue(editing.options) + ")"))
      toast("Cobertura de " + p.name + " atualizada (taxa de " + dollars(p.paperworkFees) + ").")
    else toast("A seguradora não confirmou a mudança. Tente de novo.", "error")
    cancelEdit()
  } finally { editing.busy = false }
}

// Vehicle-specific coverage (deductible).
async function startVehEdit(v) {
  vEdit.vehId = v.id
  vEdit.options = {}
  vEdit.vehCost = null
  vEdit.policyTotal = null
  for (const o of v.options) vEdit.options[o.key] = o.currentValueId
}
function vehChanged(v) { return v.options.some(o => vEdit.options[o.key] !== o.currentValueId) }
async function setVehChoice(v, key, id) {
  vEdit.options = { ...vEdit.options, [key]: id }
  const seq = ++vEdit.seq
  const veh = await luaCall(MOD + ".calculateVehiclePremium(" + v.id + ", nil, " + luaValue(vEdit.options) + ")")
  const pol = await luaCall(MOD + ".calculateInsurancePremium(" + Number(v.policy.id) + ", nil, " + luaValue({ [String(v.id)]: vEdit.options }) + ")")
  if (seq !== vEdit.seq || vEdit.vehId !== v.id) return
  vEdit.vehCost = veh && veh.cost != null ? Number(veh.cost) : null
  vEdit.policyTotal = pol && pol.totalPriceWithDriverScore != null ? Number(pol.totalPriceWithDriverScore) : null
}
async function saveVeh(v) {
  if (!vehChanged(v) || vEdit.busy) return
  vEdit.busy = true
  try {
    if (await luaDo(MOD + ".saveNewVehicleCoverageOptions(" + v.id + ", " + luaValue(vEdit.options) + ")")) toast("Cobertura de " + v.name + " atualizada.")
    else toast("A seguradora não confirmou a mudança. Tente de novo.", "error")
    vEdit.vehId = null
  } finally { vEdit.busy = false }
}

// Change provider (RLS "chooseInsuranceData" in change mode).
const changeOptions = computed(() => arr(change.data?.applicableInsurancesData).filter(Boolean))
const selectedChange = computed(() => changeOptions.value.find(o => o.id === change.selected) || null)
const leaving = computed(() => selectedChange.value?.leavingInsuranceInfo || {})
const todayAmount = computed(() => {
  const o = selectedChange.value
  if (!o) return 0
  if (o.id === -1) return -(Number(o.leavingInsuranceInfo?.netRefundPrice) || 0)
  return Number(o.amountDue) || 0
})
function openChange(v) {
  vEdit.vehId = null
  change.vehId = v.id
  change.name = v.name
  change.data = null
  change.selected = null
  luaCall(MOD + ".sendChangeInsuranceDataToTheUI(" + v.id + ")")
  emit("title", v.name)
}
function closeChange() { change.vehId = null; change.data = null; emit("title", "") }
function onChooseData(d) {
  if (change.vehId == null || !d) return
  const id = d.vehicleInfo?.invVehId
  if (id != null && Number(id) !== change.vehId) return
  change.data = d
  const opts = arr(d.applicableInsurancesData)
  const firstOther = opts.find(o => o && o.id !== d.currentInsuranceId && o.id !== -1)
  change.selected = firstOther ? firstOther.id : null
}
async function confirmChange() {
  const o = selectedChange.value
  if (!o || change.busy || o.canPay === false) return
  change.busy = true
  try {
    if (await luaDo(MOD + ".changeInvVehInsurance(" + change.vehId + ", " + Number(o.id) + ")"))
      toast(o.id === -1 ? "Cobertura removida de " + change.name + "." : change.name + " agora está segurado por " + o.name + ".")
    else toast("A seguradora não confirmou a troca. Tente de novo.", "error")
    focusVeh.value = change.vehId
    closeChange()
    tab.value = "vehicles"
  } finally { change.busy = false }
}

// Driver score
const resetCost = computed(() => Number(abstract.value?.driverScoreReset?.resetCost) || 0)
const resetTo = computed(() => abstract.value?.driverScoreReset?.resetTo ?? 64)
const history = computed(() => arr(data.value?.plHistory).slice(0, 25).map(h => {
  const effects = arr(h?.effects)
  const money = effects.filter(e => e?.type === "money").reduce((s, e) => s + (Number(e.changedBy) || 0), 0)
  const sc = effects.filter(e => e?.type === "driverScore").reduce((s, e) => s + (Number(e.changedBy) || 0), 0)
  return {
    when: h?.time ? new Date(h.time * 1000).toLocaleString((window.__rlLocale || "pt-BR"), { dateStyle: "short", timeStyle: "short" }) : h?.date || "",
    title: (HISTORY[h?.type] || h?.title || "Evento") + (h?.overrideText ? " (perdão de acidente usado)" : ""), insurer: h?.concernedInsuranceName ? translateInsurer(h.concernedInsuranceName) : "",
    money: Math.round(money), score: Math.round(sc),
  }
}))
function translateInsurer(n) {
  return { "Private repair": "Particular", "None": "Sem seguro", "Safe Driving": "—", "Test Drive": "Test drive", "Unknown": "—" }[n] || n
}
async function loadAbstract() { abstract.value = (await luaCall(MOD + ".getPlayerAbstractData()")) || null }
function openScore() { tab.value = "score"; confirmReset.value = false; loadAbstract() }
async function doReset() {
  resetBusy.value = true
  try {
    const ok = await luaCall(MOD + ".resetDriverScore()")
    toast(ok ? "Pontuação redefinida para " + resetTo.value + "." : "Não foi possível redefinir a pontuação.", ok ? "info" : "error")
    confirmReset.value = false
    await loadAbstract()
  } finally { resetBusy.value = false }
}

// Launcher
const launchFn = computed(() => rl.view.computer?.computerFunctions?.general?.insurances || null)

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  luaCall(MOD + ".closeMenu()")
}
defineExpose({ requestClose })

onMounted(() => {
  if (!hosted.value) return
  offs.push(onGameEvent("insurancesData", d => { data.value = d || {} }))
  offs.push(onGameEvent("chooseInsuranceData", onChooseData))
  luaCall(MOD + ".sendUIData()")
  loadAbstract()
})
onUnmounted(() => {
  offs.forEach(off => off()); offs = []
  if (hosted.value) luaCall("extensions.hook('onExitInsurancesComputerScreen')")
})
</script>

<style scoped>
.ap-head { display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }
.ap-head .rl-h1 { margin: 0; }
.ap-tile { width: 44px; height: 44px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #fff;
  background: linear-gradient(135deg, #6fb3ff, #1d5fc4); box-shadow: 0 2px 4px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.45); flex-shrink: 0; }
.ap-launch { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
.ap-launch p { margin: 4px 0 0; }
.r { text-align: right; }
.good { color: #1e7a1e; } .bad { color: #b0281a; }
.rl-btn { display: inline-flex; gap: 5px; align-items: center; }
.rl-btn.small { padding: 3px 9px; font-size: 11.5px; }
.xp-group { position: relative; margin: 10px 0; padding: 14px 14px 10px; border: 1px solid #d0d0bf; border-radius: 4px; background: #fff; }
fieldset.xp-group { padding-top: 6px; }
.xp-group legend, .xp-legend { color: #0046d5; font-weight: bold; font-size: 12px; padding: 0 4px; }
.xp-legend { position: absolute; top: -8px; left: 10px; background: #fff; }

/* Policy cards */
.pol { margin: 10px 0 14px; border: 1px solid #b9c7d8; border-radius: 5px; background: #fff; overflow: hidden; box-shadow: 0 1px 3px rgba(20,40,80,.08); }
.pol-head { display: flex; gap: 12px; align-items: center; padding: 10px 14px; border-left: 5px solid var(--pc); background: linear-gradient(180deg, #f7f9fc, #e6edf6); border-bottom: 1px solid #d0dae6; }
.pol-head.mini { border-left: 0; background: none; border-bottom: 0; padding: 8px 10px 0; }
.pol-logo { width: 42px; height: 42px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 24px; overflow: hidden; flex-shrink: 0; }
.pol-logo img { width: 100%; height: 100%; object-fit: contain; background: #fff; }
.pol-logo.sm { width: 32px; height: 32px; font-size: 18px; border-radius: 6px; }
.pol-title { flex: 1; min-width: 0; display: grid; gap: 2px; }
.pol-title b { font-size: 15px; color: #12407c; }
.pol-title small { color: #5f7186; font-style: italic; }
.pol-premium { text-align: right; }
.pol-premium b { display: block; font-size: 19px; color: #164a8c; }
.pol-premium small { color: #64768b; }
.pol-body { padding: 10px 14px 12px; }
.pol-facts { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.pol-facts span, .pol-cov span { display: grid; gap: 1px; }
.pol-facts small, .pol-cov small { font-size: 11px; color: #64768b; }
.pol-facts b { font-size: 13px; color: #1b3355; }
.pol-cycle { margin: 8px 0; height: 10px; }
.pol-perks { list-style: none; margin: 6px 0; padding: 0; display: flex; flex-wrap: wrap; gap: 4px 14px; font-size: 12px; color: #2c4a6e; }
.pol-perks li { display: inline-flex; gap: 4px; align-items: center; }
.pol-perks li.sig { color: #8a5a00; font-weight: bold; }
.pol-cov { display: flex; flex-wrap: wrap; gap: 8px 22px; align-items: center; padding: 8px 10px; margin: 8px 0; background: #f6f9fd; border: 1px solid #dbe5f1; border-radius: 3px; }
.pol-cov b { font-size: 12.5px; }
.pol-cov .rl-btn { margin-left: auto; }
.pol-cars { margin-top: 6px; }
.cov-row { display: grid; grid-template-columns: 170px 1fr; gap: 10px; align-items: center; padding: 6px 0; border-bottom: 1px dotted #e0e5eb; }
.cov-name { display: grid; gap: 2px; }
.cov-name small { color: #7b5600; font-size: 11px; }
.seg { display: flex; flex-wrap: wrap; gap: 4px; }
.seg button { display: grid; gap: 1px; min-width: 96px; padding: 5px 8px; border: 1px solid #aab8c9; border-radius: 3px; cursor: pointer; text-align: center;
  background: linear-gradient(180deg, #fff, #ecebe6); font: 11.5px Tahoma, sans-serif; }
.seg button b { font-size: 12.5px; color: #1d3f69; }
.seg button small { color: #627287; font-size: 10.5px; }
.seg button.cur { border-style: dashed; }
.seg button.on { border: 1px solid #316ac5; background: linear-gradient(180deg, #e8f1ff, #c8dcfa); box-shadow: inset 0 0 0 1px #316ac5; }
.seg button:disabled { opacity: .45; cursor: default; }
.seg button:hover:not(:disabled) { box-shadow: inset 0 0 0 2px #f8b636; }
.prem { margin-top: 8px; }
.prem .tot td { border-top: 2px solid #c9d7e8; }
.edit-foot { margin-top: 8px; justify-content: flex-end; }
.edit-foot .rl-muted { flex: 1; }
.others-toggle { display: flex; gap: 6px; align-items: center; width: 100%; padding: 6px 10px; margin-top: 6px; border: 1px solid #aca899; border-radius: 3px; cursor: pointer;
  background: linear-gradient(180deg, #fdfcf8, #ece9d8); font: 12.5px Tahoma, sans-serif; color: #1b3355; text-align: left; }
.other-class h4 { margin: 12px 0 6px; color: #1d3f69; font-size: 13px; }
.other { padding-bottom: 6px; }
.other .pol-perks { padding: 0 10px; }

/* Vehicles */
.veh-tools { margin-bottom: 6px; }
.veh { margin: 8px 0; padding: 10px; }
.veh.focus { border-color: #f8b636; box-shadow: 0 0 0 2px rgba(248,182,54,.45); }
.veh-row { display: flex; gap: 12px; }
.veh-shot { width: 150px; height: 84px; flex-shrink: 0; border-radius: 3px; overflow: hidden; background: #e7eef6; }
.veh-shot img { width: 100%; height: 100%; object-fit: cover; }
.veh-main { flex: 1; min-width: 0; }
.veh-main p { margin: 4px 0 8px; }
.veh-name { font-size: 14px; color: #1b3355; }
.veh-edit { margin-top: 12px; }
.veh-prev { display: flex; gap: 24px; flex-wrap: wrap; margin-top: 8px; font-size: 12.5px; }

/* Change provider */
.chg-top { display: flex; gap: 12px; align-items: center; }
.chg-top .rl-h1 { margin: 0; }
.chg-veh { display: flex; gap: 12px; align-items: center; margin: 10px 0; padding: 8px; border: 1px solid #c9d7e8; border-radius: 4px; background: #f6f9fd; }
.chg-veh img { width: 140px; height: 78px; object-fit: cover; border-radius: 3px; }
.chg-veh p { margin: 3px 0 0; }
.chg-list { display: grid; gap: 6px; }
.chg-opt { display: flex; gap: 10px; align-items: center; padding: 8px 12px; border: 1px solid #b9c7d8; border-radius: 4px; cursor: pointer; text-align: left;
  background: linear-gradient(180deg, #fff, #f0f3f7); font: 12px Tahoma, sans-serif; color: #1b2733; }
.chg-opt:hover:not(:disabled) { border-color: #f8b636; }
.chg-opt.on { border: 2px solid #316ac5; padding: 7px 11px; background: linear-gradient(180deg, #f4f8ff, #dde9fb); }
.chg-opt:disabled { cursor: default; opacity: .75; }
.chg-radio { width: 14px; height: 14px; border-radius: 50%; border: 1px solid #1c5180; background: #fff; position: relative; flex-shrink: 0; }
.chg-opt.on .chg-radio::after { content: ""; position: absolute; inset: 3px; border-radius: 50%; background: #2a8f2a; }
.chg-opt-main { flex: 1; min-width: 0; display: grid; gap: 2px; }
.chg-opt-main b { font-size: 13.5px; color: #12407c; }
.chg-opt-main small { color: #5f7186; }
.chg-opt-price { text-align: right; display: grid; gap: 2px; }
.chg-opt-price small { color: #64768b; }
.chg-opt-price b { font-size: 13.5px; }
.chg-detail { margin-top: 12px; }
.chg-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
.chg-cols h4 { margin: 4px 0 6px; color: #1d3f69; font-size: 12.5px; }
.ln { display: flex; justify-content: space-between; gap: 10px; padding: 4px 0; border-bottom: 1px dotted #e0e5eb; font-size: 12px; }
.ln span { color: #4b5d73; }
.ln.strong { font-weight: bold; border-bottom: 0; border-top: 1px solid #c9d7e8; }
.chg-total { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; padding: 8px 12px; border-radius: 3px; font-size: 14px; }
.chg-total.pay { background: #fde6e4; border: 1px solid #e6a19a; color: #8e2318; }
.chg-total.credit { background: #e3f7e0; border: 1px solid #9fd696; color: #236b1a; }
.chg-total b { font-size: 18px; }
.chg-foot { position: sticky; bottom: 0; display: flex; gap: 8px; align-items: center; margin: 12px -22px -18px; padding: 8px 14px; background: #ece9d8; border-top: 1px solid #aca899; }
.chg-foot > span { flex: 1; font-size: 12px; }

/* Score */
.score-top { display: flex; gap: 20px; align-items: center; padding: 12px; border: 1px solid #c9d7e8; border-radius: 4px; background: linear-gradient(180deg, #fff, #eef4fb); }
.score-dial { width: 110px; height: 110px; border-radius: 50%; flex-shrink: 0; display: grid; place-content: center; text-align: center;
  border: 6px solid var(--sc); background: #fff; box-shadow: inset 0 2px 6px rgba(0,0,0,.12); }
.score-dial b { font-size: 36px; color: var(--sc); line-height: 1; }
.score-dial small { color: #64768b; }
.score-info { flex: 1; }
.score-info h3 { margin: 0 0 4px; font-size: 18px; color: #12407c; }
.score-info p { margin: 4px 0; }
.score-bar { position: relative; height: 12px; margin: 10px 0 6px; border-radius: 6px; border: 1px solid #8a96a6;
  background: linear-gradient(90deg, #c62d1f 0%, #e8892a 30%, #e8c23a 50%, #6cc35a 70%, #2a8fd6 100%); }
.score-bar i { position: absolute; top: -4px; width: 4px; height: 18px; margin-left: -2px; background: #1b2733; border-radius: 2px; box-shadow: 0 0 0 1px #fff; }
.reset { margin-top: 14px; }
.reset p { margin: 4px 0 8px; }
.confirm { display: grid; gap: 8px; max-width: 560px; }
</style>
