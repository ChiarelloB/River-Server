// RiverLife translations (public edition). Original code.
// The UI is written in Portuguese. When the game language is English, Spanish or Russian this
// module translates the RiverOS desktop, the phone app and the dropdown lists while they are
// drawn: every text node and title/placeholder is looked up in the dictionary (exact texts and
// templates such as "{0} anúncios"), and Vue's own updates are translated again as they land.
// Portuguese players run none of this.
import { useBridge } from "@/bridge"
import DATA from "./i18n.data.js"

const ROOTS = ".rlos, .rlphone, .xps-list"
const ATTRS = ["title", "placeholder", "aria-label"]
const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "CODE"])
const LOCALES = { pt: "pt-BR", en: "en-US", es: "es-ES", ru: "ru-RU" }
const LETTER = /[A-Za-zÀ-ÿ]/

const state = { lang: "pt", exact: new Map(), tpl: [], cache: new Map(), observed: new WeakSet(), observers: [], timer: 0 }
const written = new WeakMap() // text node -> [the Portuguese original, the value we wrote]
const writtenAttr = new WeakMap() // element -> { attr: [original, value we wrote] }

export function langFromCode(code) {
  const c = String(code || "").toLowerCase()
  if (c.startsWith("pt")) return "pt"
  if (c.startsWith("es")) return "es"
  if (c.startsWith("ru")) return "ru"
  return "en"
}

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") }

function build(lang) {
  state.exact = new Map(); state.tpl = []; state.cache = new Map()
  const src = DATA.pt, dst = DATA[lang]
  if (!dst) return
  for (let i = 0; i < src.length; i++) {
    const pt = src[i], out = dst[i]
    if (!out) continue
    if (pt.includes("{0}")) {
      // "{0} de {1}" would rewrite any sentence containing " de ": a template open on both ends
      // needs a real phrase between its values
      const letters = pt.replace(/\{\d+\}/g, "").replace(/[^A-Za-zÀ-ÿ]/g, "").length
      if (/^\{\d+\}/.test(pt) && /\{\d+\}$/.test(pt) && letters < 6) continue
      const order = []
      const re = new RegExp("^" + pt.split(/(\{\d+\})/).map(p => {
        const m = /^\{(\d+)\}$/.exec(p)
        if (m) { order.push(+m[1]); return "([\\s\\S]+?)" }
        return escapeRe(p)
      }).join("") + "$")
      // more literal text first, so "Vendido por {0} em {1}" wins over "{0} em {1}"
      state.tpl.push({ re, order, out, weight: pt.replace(/\{\d+\}/g, "").length })
    } else if (out !== pt) {
      state.exact.set(pt, out)
    }
  }
  state.tpl.sort((a, b) => b.weight - a.weight)
}

function viaTemplate(key) {
  for (const t of state.tpl) {
    const m = t.re.exec(key)
    if (!m) continue
    const vals = {}
    t.order.forEach((n, i) => { const v = m[i + 1]; vals[n] = state.exact.get(v.trim()) || v })
    return t.out.replace(/\{(\d+)\}/g, (_, n) => (vals[n] !== undefined ? vals[n] : ""))
  }
  return null
}

// Titles and captions are often pieces joined by a separator ("Anunciar carro — novo anúncio - River Explorer").
const SEPARATORS = [" - ", " — ", " · ", " | "]
function lookup(key, depth) {
  let out = state.exact.get(key)
  if (out === undefined) out = viaTemplate(key)
  if (out == null && depth < 3) {
    for (const sep of SEPARATORS) {
      if (!key.includes(sep)) continue
      let changed = false
      const parts = key.split(sep).map(p => {
        const t = p.trim() && LETTER.test(p) ? lookup(p.trim(), depth + 1) : null
        if (t == null) return p
        changed = true
        return t
      })
      if (changed) { out = parts.join(sep); break }
    }
  }
  return out == null ? null : out
}

// Translate one text; null when it is not ours.
export function tr(text) {
  if (state.lang === "pt" || typeof text !== "string" || !LETTER.test(text)) return null
  const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(text)
  const key = m[2].replace(/\s+/g, " ")
  let out = state.cache.get(key)
  if (out === undefined) {
    out = lookup(key, 0)
    if (state.cache.size > 4000) state.cache.clear()
    state.cache.set(key, out)
  }
  return out == null ? null : m[1] + out + m[3]
}
export function t(text) { return tr(text) ?? text }

function skipped(el) {
  for (let e = el; e; e = e.parentElement) {
    if (SKIP.has(e.tagName) || e.isContentEditable || (e.classList && e.classList.contains("rl-notr"))) return true
    if (e.matches && e.matches(ROOTS)) return false
  }
  return false
}

function fixText(node) {
  const v = node.nodeValue
  const mine = written.get(node)
  if ((mine && mine[1] === v) || !v || !LETTER.test(v)) return
  if (skipped(node.parentElement)) return
  const out = tr(v)
  if (out != null && out !== v) { written.set(node, [v, out]); node.nodeValue = out }
}

function fixAttr(el, name) {
  const v = el.getAttribute(name)
  if (!v) return
  const mine = writtenAttr.get(el)
  if (mine && mine[name] && mine[name][1] === v) return
  const out = tr(v)
  if (out != null && out !== v) {
    const rec = mine || {}
    rec[name] = [v, out]
    writtenAttr.set(el, rec)
    el.setAttribute(name, out)
  }
}

function walk(root) {
  if (root.nodeType === 3) { fixText(root); return }
  if (root.nodeType !== 1) return
  if (root.hasAttribute) for (const a of ATTRS) if (root.hasAttribute(a)) fixAttr(root, a)
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT)
  for (let n = tw.nextNode(); n; n = tw.nextNode()) {
    if (n.nodeType === 3) fixText(n)
    else for (const a of ATTRS) if (n.hasAttribute(a)) fixAttr(n, a)
  }
}

function onMutations(list) {
  for (const r of list) {
    if (r.type === "characterData") fixText(r.target)
    else if (r.type === "attributes") fixAttr(r.target, r.attributeName)
    else for (const n of r.addedNodes) walk(n)
  }
}

function scan() {
  for (const root of document.querySelectorAll(ROOTS)) {
    if (state.observed.has(root)) continue
    state.observed.add(root)
    walk(root)
    const obs = new MutationObserver(onMutations)
    obs.observe(root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS })
    state.observers.push(obs)
  }
}

// Put back the Portuguese we replaced, so a language change translates from the source again.
function restore() {
  for (const root of document.querySelectorAll(ROOTS)) {
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT)
    for (let n = root; n; n = tw.nextNode()) {
      if (n.nodeType === 3) {
        const mine = written.get(n)
        if (mine && mine[1] === n.nodeValue) n.nodeValue = mine[0]
        written.delete(n)
      } else {
        const rec = writtenAttr.get(n)
        if (rec) for (const a in rec) if (rec[a] && n.getAttribute(a) === rec[a][1]) n.setAttribute(a, rec[a][0])
        writtenAttr.delete(n)
      }
    }
  }
}

export function setLang(lang) {
  lang = LOCALES[lang] ? lang : "en"
  window.__rlLocale = LOCALES[lang]
  if (lang === state.lang && (lang === "pt" || state.timer)) return
  for (const o of state.observers) o.disconnect()
  state.observers = []; state.observed = new WeakSet()
  clearInterval(state.timer); state.timer = 0
  if (state.lang !== "pt") restore()
  state.lang = lang
  if (lang === "pt") return
  build(lang)
  scan()
  state.timer = setInterval(scan, 400)
}

export function startI18n() {
  window.__rlI18n = { setLang, tr, t, get lang() { return state.lang } }
  window.__rlLocale = LOCALES.pt
  let forced = ""
  try { forced = localStorage.getItem("riverlife.lang") || "" } catch (err) { /* no storage */ }
  if (forced) { setLang(forced); return }
  try {
    useBridge().api.engineLua("Lua:getSelectedLanguage()", code => setLang(langFromCode(code)))
  } catch (err) {
    setLang("en")
  }
}
