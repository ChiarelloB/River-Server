<template>
  <div class="portal">
    <header class="portal-top">
      <div class="logo"><b>River</b>Net <small>o portal da cidade</small></div>
      <div class="weather">{{ hourText }} · {{ rl.view.mode === "BeamMP" ? (rl.view.players?.length || 0) + " jogador(es) online" : "Modo solo" }}</div>
    </header>
    <div class="portal-body">
      <section class="col main">
        <FirstSteps @go="g => $emit('go', g)" @open="a => $emit('open', a)" />
        <div class="hero">
          <h2>Seu próximo carro está logo ali.</h2>
          <p>Anuncie com fotos reais, receba visitas e negocie cara a cara. Abra uma loja ou uma oficina e atenda clientes de verdade.</p>
          <div class="rl-row">
            <button class="rl-btn primary" @click="$emit('go', 'classificados')">Ver classificados</button>
            <button class="rl-btn" @click="$emit('open', 'sell')">Anunciar meu carro</button>
            <button class="rl-btn" @click="$emit('go', 'oficinas')">Encontrar oficina</button>
          </div>
        </div>
        <h3 class="rl-h2">Recém-anunciados</h3>
        <div v-if="!latest.length" class="rl-empty"><b>Nenhum anúncio ainda</b>Seja o primeiro a anunciar um carro na cidade.</div>
        <div class="rl-grid">
          <article v-for="l in latest" :key="l.id" class="rl-card mini" @click="$emit('go', 'classificados')">
            <img v-if="cover(l)" class="rl-thumb" :src="cover(l)" alt="" />
            <div v-else-if="l.display" class="rl-thumb ph live">Exposto ao vivo{{ l.lot ? " · " + l.storeName : " · particular" }}</div>
            <div v-else class="rl-thumb ph">Carregando foto...</div>
            <div class="mini-body"><b>{{ l.title }}</b><span>{{ money(l.price) }}</span><small>{{ km(l.mileage) }} · {{ l.storeName || l.sellerName }}</small></div>
          </article>
        </div>
      </section>
      <aside class="col side">
        <div class="panel">
          <h4>Para você</h4>
          <p v-if="!attention.length" class="rl-muted">Nada pendente. Bons negócios!</p>
          <button v-for="a in attention.slice(0, 6)" :key="a.kind + a.id" class="alert" @click="$emit('open', a.kind === 'trade' ? 'store' : a.kind === 'order' ? 'workshop' : 'agenda')">{{ a.text }}</button>
        </div>
        <div class="panel">
          <h4>Jornal do River</h4>
          <p v-if="!news.length" class="rl-muted">Sem notícias por enquanto.</p>
          <div v-for="(e, i) in news" :key="i" class="line" @click="$emit('go', 'noticias')"><span>{{ e.text }}</span></div>
        </div>
        <div class="panel">
          <h4>Trabalho agora</h4>
          <p class="rl-muted">{{ gigs }} bico(s) e {{ vacancies }} vaga(s) abertas.</p>
          <button class="rl-btn" @click="$emit('go', 'empregos')">Ver empregos e bicos</button>
        </div>
        <div class="panel">
          <h4>Lojas de carros</h4>
          <p v-if="!stores.length" class="rl-muted">Nenhuma loja aberta. <a href="#" @click.prevent="$emit('open', 'store')">Abra a sua</a>.</p>
          <div v-for="s in stores.slice(0, 5)" :key="s.id" class="line" @click="$emit('go', 'lojas')"><b>{{ s.name }}</b><small>{{ s.stock || 0 }} carros · {{ s.ownerName }}</small></div>
        </div>
        <div class="panel">
          <h4>Oficinas</h4>
          <p v-if="!shops.length" class="rl-muted">Nenhuma oficina aberta. <a href="#" @click.prevent="$emit('open', 'workshop')">Abra a sua</a>.</p>
          <div v-for="w in shops.slice(0, 5)" :key="w.id" class="line" @click="$emit('go', 'oficinas')"><b>{{ w.name }}</b><small>★ {{ ((Number(w.reputation) || 0) / 20).toFixed(1) }} · {{ w.ownerName }}</small></div>
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup>
import { computed, watch } from "vue"
import { rl, money, km, photo, cover, loadCover, attention } from "../rl.js"
import FirstSteps from "../components/FirstSteps.vue"
defineEmits(["go", "open"])
const latest = computed(() => (rl.view.listings || []).filter(l => l.status === "active").slice(0, 6))
const stores = computed(() => rl.view.stores || [])
const shops = computed(() => rl.view.workshops || [])
const news = computed(() => (rl.view.feed || []).slice(0, 4))
const gigs = computed(() => (rl.view.gigs || []).filter(g => g.status === "open").length)
const vacancies = computed(() => (rl.view.vacancies || []).length)
const hourText = computed(() => "Hora no jogo: " + String(rl.view.hour ?? 12).padStart(2, "0") + "h")
watch(latest, list => list.forEach(loadCover), { immediate: true })
</script>

<style scoped>
.portal { min-height: 100%; background: #f3f6fb; }
.portal-top { display: flex; justify-content: space-between; align-items: flex-end; padding: 14px 22px; background: linear-gradient(90deg, #0b3f8f, #2f74d6); color: #fff; }
.logo { font: 300 28px "Trebuchet MS", Tahoma, sans-serif; } .logo b { font-weight: 700; color: #ffcb5c; } .logo small { font-size: 12px; opacity: .8; margin-left: 6px; }
.weather { font-size: 12px; opacity: .9; }
.portal-body { display: grid; grid-template-columns: 1fr 270px; gap: 16px; padding: 16px 22px; }
.hero { padding: 16px 18px; border-radius: 6px; background: linear-gradient(135deg, #fff7e1, #ffe7b8); border: 1px solid #f0cf86; }
.hero h2 { margin: 0 0 6px; font: 22px "Trebuchet MS", Tahoma, sans-serif; color: #7a4300; }
.hero p { color: #6a5530; line-height: 1.5; margin: 0 0 12px; }
.mini { cursor: pointer; } .mini-body { padding: 8px 10px; display: grid; gap: 2px; } .mini-body span { color: #c55a00; font-weight: bold; font-size: 15px; } .mini-body small { color: #627287; }
.ph { display: flex; align-items: center; justify-content: center; color: #7f8fa3; font-size: 11px; }
.ph.live { background: linear-gradient(135deg, #e8f6ea, #cfe9d4); color: #2b6a37; font-weight: bold; text-align: center; padding: 6px; }
.panel { background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; padding: 10px 12px; margin-bottom: 12px; }
.panel h4 { margin: 0 0 8px; color: #12407c; font-size: 13px; }
.alert { display: block; width: 100%; text-align: left; margin: 4px 0; padding: 6px 8px; border: 1px solid #f0cf86; background: #fff8e3; border-radius: 3px; cursor: pointer; font: 12px Tahoma, sans-serif; }
.line { padding: 5px 0; border-bottom: 1px dotted #d6dfeb; cursor: pointer; } .line small { display: block; color: #6a7c90; }
</style>
