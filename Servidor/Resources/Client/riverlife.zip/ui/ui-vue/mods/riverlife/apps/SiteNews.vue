<template>
  <div class="news">
    <header class="masthead">
      <h1>Jornal do River</h1>
      <small>{{ today }} · tudo o que acontece no {{ rl.view.serverName || "River" }}</small>
    </header>
    <div class="cols">
      <section class="main">
        <h2>Últimas notícias</h2>
        <article v-for="(e, i) in feed" :key="i" class="item" :class="e.kind">
          <span class="tag">{{ KIND[e.kind] || "Geral" }}</span>
          <p>{{ e.text }}</p>
          <small>{{ ago(e.at) }}</small>
        </article>
        <p v-if="!feed.length" class="rl-muted">Ainda sem notícias. Abra uma loja, venda um carro ou faça um bico para sair no jornal!</p>
      </section>
      <aside>
        <h2>Lojas que mais vendem</h2>
        <ol><li v-for="s in topStores" :key="s.id"><b>{{ s.name }}</b> <small>{{ s.sales || 0 }} venda(s) · {{ s.ownerName }}</small></li></ol>
        <p v-if="!topStores.length" class="rl-muted">Nenhuma loja aberta.</p>
        <h2>Oficinas mais procuradas</h2>
        <ol><li v-for="w in topShops" :key="w.id"><b>{{ w.name }}</b> <small>{{ w.jobs || 0 }} serviço(s) · ★ {{ ((w.reputation || 0) / 20).toFixed(1) }}</small></li></ol>
        <p v-if="!topShops.length" class="rl-muted">Nenhuma oficina aberta.</p>
        <h2>Vendedores de destaque</h2>
        <ol><li v-for="a in topSellers" :key="a.id"><b>{{ a.name }}</b> <small>{{ a.sales || 0 }} venda(s) · reputação {{ a.reputation || 0 }}</small></li></ol>
        <h2>Tabela FIPE do River</h2>
        <table v-if="fipe.length" class="fipe"><tr v-for="f in fipe" :key="f.key"><td>{{ f.name || f.key }}</td><td><b>{{ money(f.median) }}</b><small> · {{ f.sales }} venda(s)</small></td></tr></table>
        <p v-else class="rl-muted">Ainda sem vendas registradas. Cada carro vendido entra na tabela do modelo.</p>
        <h2>Classificados do dia</h2>
        <p>{{ adsCount }} carro(s) à venda, {{ lotCount }} em pátios de lojas e {{ npcCount }} de particulares.
          <a href="#" @click.prevent="$emit('go', 'classificados')">Ver classificados</a></p>
        <h2>Precisa de trabalho?</h2>
        <p>{{ gigsCount }} bico(s) e {{ (rl.view.vacancies || []).length }} vaga(s) abertas agora.
          <a href="#" @click.prevent="$emit('open', 'jobs')">Ver empregos</a></p>
      </aside>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted } from "vue"
import { rl, ago, money, me, request } from "../rl.js"

defineEmits(["go", "open"])
const KIND = { venda: "Negócios", loja: "Inauguração", oficina: "Inauguração", staff: "Empregos", vaga: "Classificados de emprego", bico: "Trabalho" }
const today = new Date().toLocaleDateString((window.__rlLocale || "pt-BR"), { weekday: "long", day: "numeric", month: "long" })
const feed = computed(() => (rl.view.feed || []).slice(0, 40))
const fipe = computed(() => (Array.isArray(rl.view.fipe) ? rl.view.fipe : Object.values(rl.view.fipe || {})).slice(0, 12))
// Reading the paper is one of the first steps for new players.
onMounted(() => { if (rl.view.careerActive && !me.value.firstSteps?.news) request("firstStep", { step: "news" }) })
const topStores = computed(() => (rl.view.stores || []).slice().sort((a, b) => (b.sales || 0) - (a.sales || 0)).slice(0, 5))
const topShops = computed(() => (rl.view.workshops || []).slice().sort((a, b) => (b.jobs || 0) - (a.jobs || 0)).slice(0, 5))
const topSellers = computed(() => (rl.view.accounts || []).filter(a => (a.sales || 0) > 0).sort((a, b) => (b.sales || 0) - (a.sales || 0)).slice(0, 5))
const ads = computed(() => (rl.view.listings || []).filter(l => l.status === "active"))
const adsCount = computed(() => ads.value.length)
const lotCount = computed(() => ads.value.filter(l => l.lot).length)
const npcCount = computed(() => ads.value.filter(l => l.npcSeller).length)
const gigsCount = computed(() => (rl.view.gigs || []).filter(g => g.status === "open").length)
</script>

<style scoped>
.fipe { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 8px; }
.fipe td { padding: 3px 4px; border-bottom: 1px dotted #c8c0a8; vertical-align: top; }
.fipe td:last-child { text-align: right; white-space: nowrap; }
.news { padding: 14px 18px; background: #fbf8f1; min-height: 100%; font-family: Georgia, "Times New Roman", serif; color: #222; }
.masthead { border-bottom: 3px double #333; margin-bottom: 10px; text-align: center; }
.masthead h1 { margin: 0; font-size: 34px; letter-spacing: 1px; }
.cols { display: grid; grid-template-columns: 2fr 1fr; gap: 18px; }
h2 { font-size: 15px; border-bottom: 1px solid #999; margin: 12px 0 6px; text-transform: uppercase; letter-spacing: .5px; }
.item { border-bottom: 1px dotted #bbb; padding: 7px 0; }
.item p { margin: 3px 0; font-size: 14px; }
.item small { color: #777; }
.tag { font: bold 10px Tahoma, sans-serif; text-transform: uppercase; color: #fff; background: #555; padding: 1px 6px; border-radius: 2px; }
.item.venda .tag { background: #1d7a2c; } .item.loja .tag, .item.oficina .tag { background: #b51f1f; } .item.staff .tag, .item.vaga .tag { background: #2d6ad6; }
.item.bico .tag { background: #c27c00; }
ol { margin: 0; padding-left: 18px; } li { margin: 3px 0; } li small { color: #666; display: block; }
aside p { font-size: 13px; }
</style>
