<template>
  <!-- Opened from the desktop: pick a car at this garage and start the RLS repair session. -->
  <div v-if="!hosted" class="rl-page">
    <header class="ap-head">
      <span class="ap-tile"><BngIcon type="wrench" /></span>
      <div><h2 class="rl-h1">Reparos</h2><p class="rl-muted">Conserte um carro desta garagem, pelo seguro ou pagando do seu bolso.</p></div>
    </header>
    <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>O serviço de reparo do RLS só funciona em um computador de garagem.</div>
    <div v-else-if="!launchList.length" class="rl-empty"><b>Nenhum veículo nesta garagem</b>Traga o carro até a garagem para orçar o reparo.</div>
    <table v-else class="rl-table"><tbody>
      <tr><th>Veículo</th><th>Situação</th><th></th></tr>
      <tr v-for="v in launchList" :key="v.inventoryId">
        <td><b>{{ v.name }}</b></td>
        <td><span v-if="v.fn && v.fn.disabled" class="rl-muted">{{ v.fn.reason?.label || "Indisponível agora" }}</span>
          <span v-else-if="v.fn" class="rl-badge ok">Disponível</span><span v-else class="rl-muted">Sem reparo neste computador</span></td>
        <td class="ap-right"><button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button></td>
      </tr>
    </tbody></table>
  </div>

  <div v-else class="rp">
    <div v-if="loading" class="rl-empty"><b>Calculando o orçamento...</b>Avaliando os danos do veículo.</div>
    <div v-else-if="!data" class="rl-empty"><b>Não foi possível orçar o reparo</b>{{ loadError || "O RLS não encontrou os dados deste veículo." }}
      <div class="ap-center"><button class="rl-btn" @click="load">Tentar de novo</button> <button class="rl-btn" @click="requestClose">Voltar</button></div></div>

    <template v-else>
      <div class="rp-body">
        <section class="rp-car">
          <div class="rp-shot"><img v-if="vehicle.thumbnail" :src="vehicle.thumbnail" alt="" /></div>
          <div class="rp-car-main">
            <h2 class="rl-h1">{{ vehicle.name || "Veículo" }}</h2>
            <div class="rl-row">
              <span v-if="vehicle.isInsured" class="rl-badge ok"><BngIcon type="shieldCheckmark" /> Segurado: {{ insurance?.insuranceName }}</span>
              <span v-else class="rl-badge bad">Sem seguro</span>
              <span v-if="vehicle.roadside" class="rl-badge warn">Reparo na estrada (+15%)</span>
            </div>
            <div class="rp-estimate"><small>Estimativa do dano</small><b>{{ dollars(vehicle.damageCost) }}</b></div>
          </div>
          <div class="rp-wallet"><small>Seu saldo</small><b>{{ money != null ? dollars(money) : "—" }}</b></div>
        </section>

        <h3 class="rl-h2">Como pagar o reparo</h3>
        <div class="rp-options">
          <button class="rp-opt" :class="{ on: optKey === 'insuranceRepairData' }" :disabled="!insurance" @click="pick('insuranceRepairData')">
            <span class="rp-radio"></span>
            <span class="rp-opt-ico ins"><BngIcon type="shieldCheckmark" /></span>
            <span class="rp-opt-text">
              <b>Pelo seguro</b>
              <template v-if="insurance"><small>{{ insurance.insuranceName }}</small><em>Franquia {{ dollars(insurance.deductible) }}</em></template>
              <small v-else>Este veículo não tem seguro. Contrate em Seguros.</small>
            </span>
          </button>
          <button class="rp-opt" :class="{ on: optKey === 'noInsuranceRepairData' }" @click="pick('noInsuranceRepairData')">
            <span class="rp-radio"></span>
            <span class="rp-opt-ico own"><BngIcon type="wrench" /></span>
            <span class="rp-opt-text"><b>Sem seguro (particular)</b><small>Não afeta sua apólice nem sua pontuação</small><em>Custo total do dano</em></span>
          </button>
        </div>

        <h3 class="rl-h2">Tempo de reparo</h3>
        <p v-if="useInsurance" class="rl-muted rp-note">O prazo coberto pela apólice já está pago. Para o reparo instantâneo, paga-se a diferença.</p>
        <div class="rp-times">
          <button v-for="c in choices" :key="c.id" class="rp-time" :class="{ on: timeId === c.id }" :disabled="c.disabled"
            :title="c.disabled ? 'Não disponível nesta forma de pagamento' : ''" @click="timeId = c.id">
            <b>{{ timeLabel(c) }}</b>
            <small v-if="c.disabled">Indisponível</small>
            <small v-else-if="useInsurance && !c.premiumInfluence">Incluído na apólice</small>
            <small v-else>{{ c.premiumInfluence ? "+ " + dollars(c.premiumInfluence) : "sem custo extra" }}</small>
          </button>
        </div>

        <div class="rp-two">
          <fieldset class="rp-group">
            <legend>Impacto no seguro</legend>
            <div class="rp-line"><span>Pontuação do motorista</span>
              <b v-if="useInsurance && futureScore < score" class="rp-bad">{{ score }} → {{ futureScore }}</b>
              <b v-else>Sem alteração ({{ score }})</b></div>
            <div v-if="useInsurance" class="rp-line rp-sub"><span>{{ insurance.accidentForgivenesses > 0
              ? "Perdões de acidente disponíveis: " + insurance.accidentForgivenesses + " (a pontuação não cai)"
              : "Sem perdões de acidente disponíveis" }}</span></div>
            <div v-if="insurance" class="rp-line"><span>Prêmio da apólice</span>
              <b v-if="useInsurance && Math.round(insurance.futurePremium) !== Math.round(insurance.currentPremium)" class="rp-bad">
                {{ dollars(insurance.currentPremium) }} → {{ dollars(insurance.futurePremium) }}</b>
              <b v-else>Sem alteração ({{ dollars(insurance.currentPremium) }})</b></div>
            <div v-if="useInsurance" class="rp-line rp-sub"><span>{{ insurance.insuranceName }} renova em {{ kmText(insurance.renewsIn) }}</span></div>
            <div v-if="tier" class="rp-line rp-sub"><span>Faixa atual: {{ riskName(tier.risk) }} (prêmio ×{{ num(tier.multiplier, 2) }})</span></div>
            <p v-if="!insurance" class="rl-muted">Sem seguro, o reparo particular não muda nada na sua pontuação.</p>
          </fieldset>

          <fieldset class="rp-group">
            <legend>Resumo</legend>
            <div class="rp-line"><span>Forma</span><b>{{ useInsurance ? "Pelo seguro (" + insurance.insuranceName + ")" : "Particular" }}</b></div>
            <div class="rp-line"><span>Prazo</span><b>{{ selected ? timeLabel(selected) : "—" }}<template v-if="selected"> ({{ dollars(selected.premiumInfluence || 0) }})</template></b></div>
            <div v-if="useInsurance" class="rp-line"><span>Franquia</span><b>{{ dollars(insurance.deductible) }}</b></div>
            <div v-else class="rp-line"><span>Dano do veículo</span><b>{{ dollars(vehicle.damageCost) }}</b></div>
            <div class="rp-line rp-total"><span>Total</span><b>{{ selected ? dollars(selected.totalPrice) : "—" }}</b></div>
          </fieldset>
        </div>
      </div>

      <footer class="ap-foot">
        <span class="ap-status">
          <template v-if="busy">Mandando o carro para o reparo...</template>
          <template v-else-if="!vehicle.needsRepair">Este veículo não precisa de reparo.</template>
          <template v-else-if="selected && !selected.canPay"><span class="rl-error">Saldo insuficiente para {{ dollars(selected.totalPrice) }}.</span></template>
          <template v-else-if="selected && selected.value > 0">O carro fica indisponível por {{ timeLabel(selected) }} enquanto é consertado.</template>
          <template v-else>Reparo imediato: o carro sai pronto.</template>
        </span>
        <button class="rl-btn" :disabled="busy" @click="requestClose">Cancelar</button>
        <button class="rl-btn go" :disabled="busy || !canRepair" @click="startRepair">
          <BngIcon type="wrench" /> Consertar{{ selected ? " por " + dollars(selected.totalPrice) : "" }}</button>
      </footer>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaValue, dollars, arr, toast } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const MOD = "career_modules_insurance_repairScreen"
const RISK = { "Exceptional": "Excepcional", "Excellent": "Excelente", "Very Good": "Muito boa", "Good": "Boa", "Above Average": "Acima da média",
  "Average": "Na média", "Below Average": "Abaixo da média", "Mediocre": "Medíocre", "Poor": "Ruim", "High Risk": "Alto risco",
  "Very High Risk": "Risco muito alto", "Severe Risk": "Risco severo", "Critical Risk": "Risco crítico", "Extreme Risk": "Risco extremo", "Maximum Risk": "Risco máximo" }

const hosted = computed(() => !!props.route)
const loading = ref(false)
const loadError = ref("")
const data = ref(null)
const optKey = ref("")
const timeId = ref(1)
const busy = ref(false)
let busyTimer = null

const vehicle = computed(() => data.value?.vehicleData || {})
const insurance = computed(() => data.value?.repairOptions?.insuranceRepairData || null)
const option = computed(() => data.value?.repairOptions?.[optKey.value] || null)
const useInsurance = computed(() => !!option.value?.useInsurance)
const choices = computed(() => arr(option.value?.repairTimeOptions?.choices))
const selected = computed(() => choices.value.find(c => c.id === timeId.value) || null)
const score = computed(() => Math.round(Number(data.value?.driverScore) || 0))
const futureScore = computed(() => Math.round(Number(data.value?.futureDriverScore) || 0))
const tier = computed(() => data.value?.driverScoreTierData || null)
const money = computed(() => {
  const m = data.value?.playerAttributes?.money
  const v = m && typeof m === "object" ? m.value : m
  return Number.isFinite(Number(v)) ? Number(v) : null
})
const canRepair = computed(() => !!selected.value && !selected.value.disabled && selected.value.canPay !== false && vehicle.value.needsRepair !== false)

function num(v, d = 0) { return new Intl.NumberFormat("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d }).format(Number(v) || 0) }
function kmText(k) { return num(k) + " km" }
function riskName(r) { return RISK[r] || r || "" }
function timeLabel(c) {
  const s = Number(c?.value) || 0
  if (s <= 0) return "Instantâneo"
  return s % 60 === 0 ? (s / 60) + " min" : num(s / 60, 1) + " min"
}
// Selecting a payment option resets the time to that option's default (as the RLS screen does).
function pick(key) {
  const opts = data.value?.repairOptions?.[key]
  if (!opts) return
  optKey.value = key
  const list = arr(opts.repairTimeOptions?.choices)
  const want = opts.repairTimeOptions?.currentValueId
  const first = list.find(c => c.id === want && !c.disabled) || list.find(c => !c.disabled) || list[0]
  timeId.value = first ? first.id : 1
}

async function load() {
  loading.value = true
  loadError.value = ""
  try {
    const d = await luaCall(MOD + ".getRepairData()")
    data.value = d && d.vehicleData ? d : null
    if (!data.value) loadError.value = "O veículo não está registrado no seguro do RLS."
    else {
      emit("title", data.value.vehicleData.name || "")
      // Same default as the RLS screen: the insurance option when the car is insured.
      pick(data.value.repairOptions?.insuranceRepairData ? "insuranceRepairData" : "noInsuranceRepairData")
    }
  } finally { loading.value = false }
}

function startRepair() {
  const c = selected.value
  if (!canRepair.value || busy.value || !c) return
  busy.value = true
  const payload = {
    repairTime: Number(c.value) || 0,
    isInsuranceRepair: useInsurance.value,
    cost: {
      repairTimeCost: Number(c.premiumInfluence) || 0,
      deductible: useInsurance.value ? Number(insurance.value.deductible) || 0 : Number(vehicle.value.damageCost) || 0,
    },
  }
  // RLS pays, repairs and reopens the garage computer (this window then closes).
  luaCall(MOD + ".startRepairInGarage(" + Number(vehicle.value.invVehId) + ", " + luaValue(payload) + ")")
  toast((c.value > 0 ? "Carro enviado para o reparo (" + timeLabel(c) + ")." : "Reparo iniciado.") + " Total: " + dollars(c.totalPrice))
  clearTimeout(busyTimer)
  busyTimer = setTimeout(() => { busy.value = false }, 6000)
}

// Launcher (no RLS session open).
const launchList = computed(() => {
  const c = rl.view.computer
  if (!c) return []
  return arr(c.vehicles).map(v => ({
    inventoryId: v.inventoryId, name: v.vehicleName || v.niceName || "Veículo",
    fn: c.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.repair || null,
  }))
})
function launch(v) { request("native", { buttonId: "repair", inventoryId: v.inventoryId }) }

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  if (busy.value) return
  luaCall(MOD + ".closeMenu()")
}
defineExpose({ requestClose })

onMounted(() => { if (hosted.value) load() })
onUnmounted(() => { clearTimeout(busyTimer) })
</script>

<style scoped>
.ap-head { display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }
.ap-head .rl-h1 { margin: 0; }
.ap-tile { width: 44px; height: 44px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #fff;
  background: linear-gradient(135deg, #f0a35a, #b4521b); box-shadow: 0 2px 4px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.45); flex-shrink: 0; }
.ap-right { text-align: right; }
.ap-center { margin-top: 12px; }
.rp { display: flex; flex-direction: column; min-height: 100%; }
.rp-body { flex: 1; padding: 14px 20px 10px; }
.rp-car { display: flex; gap: 16px; align-items: center; padding: 10px; border: 1px solid #c9d7e8; border-radius: 4px; background: linear-gradient(180deg, #fff, #f1f5fb); }
.rp-shot { width: 200px; height: 112px; flex-shrink: 0; border-radius: 3px; overflow: hidden; background: #e4ebf4; }
.rp-shot img { width: 100%; height: 100%; object-fit: cover; }
.rp-car-main { flex: 1; min-width: 0; display: grid; gap: 6px; }
.rp-car-main .rl-h1 { margin: 0; font-size: 21px; }
.rp-car-main .rl-badge { display: inline-flex; align-items: center; gap: 4px; }
.rp-estimate small, .rp-wallet small { display: block; font-size: 11px; color: #64768b; }
.rp-estimate b { font-size: 22px; color: #b0281a; }
.rp-wallet { text-align: right; padding: 8px 12px; border-left: 1px solid #d6dee8; }
.rp-wallet b { font-size: 16px; color: #1e6b18; }
.rp-options { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.rp-opt { display: flex; align-items: center; gap: 12px; padding: 12px 14px; text-align: left; cursor: pointer; border: 1px solid #b9c7d8; border-radius: 4px;
  background: linear-gradient(180deg, #fff, #eef2f7); font: 12px Tahoma, sans-serif; color: #1b2733; }
.rp-opt:hover:not(:disabled) { border-color: #f8b636; }
.rp-opt.on { border: 2px solid #316ac5; padding: 11px 13px; background: linear-gradient(180deg, #f4f8ff, #dde9fb); }
.rp-opt:disabled { opacity: .55; cursor: default; }
.rp-radio { width: 14px; height: 14px; border-radius: 50%; border: 1px solid #1c5180; background: #fff; flex-shrink: 0; position: relative; }
.rp-opt.on .rp-radio::after { content: ""; position: absolute; inset: 3px; border-radius: 50%; background: #2a8f2a; }
.rp-opt-ico { width: 38px; height: 38px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #fff; flex-shrink: 0; }
.rp-opt-ico.ins { background: linear-gradient(135deg, #6fb3ff, #1d5fc4); }
.rp-opt-ico.own { background: linear-gradient(135deg, #f0a35a, #b4521b); }
.rp-opt-text { display: grid; gap: 2px; }
.rp-opt-text b { font-size: 14px; color: #12407c; }
.rp-opt-text small { color: #5f7186; }
.rp-opt-text em { font-style: normal; font-weight: bold; color: #333; }
.rp-note { margin: -4px 0 8px; }
.rp-times { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px; }
.rp-time { display: grid; gap: 3px; padding: 9px 10px; border: 1px solid #b9c7d8; border-radius: 3px; cursor: pointer; text-align: center;
  background: linear-gradient(180deg, #fff, #ecebe6); font: 12px Tahoma, sans-serif; }
.rp-time b { font-size: 14px; color: #1d3f69; }
.rp-time small { color: #5f7186; }
.rp-time:hover:not(:disabled) { box-shadow: inset 0 0 0 2px #f8b636; }
.rp-time.on { border-color: #316ac5; background: linear-gradient(180deg, #e8f1ff, #c8dcfa); box-shadow: inset 0 0 0 1px #316ac5; }
.rp-time:disabled { opacity: .45; cursor: default; }
.rp-two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 14px; }
.rp-group { margin: 0; padding: 8px 14px 12px; border: 1px solid #d0d0bf; border-radius: 4px; background: #fff; }
.rp-group legend { padding: 0 4px; color: #0046d5; font-weight: bold; font-size: 12px; }
.rp-line { display: flex; justify-content: space-between; gap: 10px; padding: 5px 0; border-bottom: 1px dotted #dfe4ea; font-size: 12.5px; }
.rp-line span { color: #4b5d73; }
.rp-sub { border-bottom: 0; padding-top: 0; font-size: 11.5px; }
.rp-bad { color: #b0281a; }
.rp-total { border-bottom: 0; border-top: 2px solid #c9d7e8; margin-top: 4px; padding-top: 8px; font-size: 15px; }
.rp-total b { color: #12407c; }
.ap-foot { position: sticky; bottom: 0; display: flex; gap: 8px; align-items: center; padding: 8px 14px; background: #ece9d8; border-top: 1px solid #aca899; }
.ap-status { flex: 1; font-size: 12px; color: #3d4b5c; }
.ap-foot .rl-btn { display: inline-flex; gap: 5px; align-items: center; }
</style>
