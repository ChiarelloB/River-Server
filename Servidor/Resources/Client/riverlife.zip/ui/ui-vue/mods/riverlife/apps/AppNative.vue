<template>
  <div class="rl-page">
    <h2 class="rl-h1">Serviços da garagem</h2>
    <p class="rl-muted">Tudo o que este computador oferece: garagem, concessionárias, peças, seguros, banco e os serviços de cada carro.
      Cada serviço abre como um programa do RiverOS.</p>
    <div v-if="!general.length" class="rl-empty"><b>Sem serviços aqui</b>Abra o RiverOS a partir de um computador de garagem.</div>
    <div class="grid">
      <button v-for="f in general" :key="f.id" class="svc" :disabled="f.disabled" :title="f.reason?.label || ''" @click="request('native', { buttonId: f.id })">
        <span class="ico"><BngIcon :type="RLS_FUNCTIONS[f.id]?.icon || 'cogs'" /></span><b>{{ rlsName(f) }}</b>
        <small>{{ f.disabled ? (f.reason?.label || "Indisponível agora") : "Abrir" }}</small>
      </button>
    </div>
    <template v-if="vehicles.length">
      <h3 class="rl-h2">Carros nesta garagem</h3>
      <div v-for="v in vehicles" :key="v.inventoryId" class="rl-box veh">
        <b>{{ v.vehicleName || v.niceName }}</b>
        <div class="rl-row">
          <button v-for="f in fnsOf(v.inventoryId)" :key="f.id" class="rl-btn" :disabled="f.disabled" :title="f.reason?.label || ''"
            @click="request('native', { buttonId: f.id, inventoryId: v.inventoryId })"><BngIcon :type="RLS_FUNCTIONS[f.id]?.icon || 'cogs'" /> {{ rlsName(f) }}</button>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { computed } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, RLS_FUNCTIONS, rlsName } from "../rl.js"
const general = computed(() => Object.values(rl.view.computer?.computerFunctions?.general || {}).filter(f => f.id !== "riverLife").sort((a, b) => (a.order || 0) - (b.order || 0)))
const vehicles = computed(() => rl.view.computer?.vehicles || [])
function fnsOf(id) { return Object.values(rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(id)] || {}).sort((a, b) => (a.order || 0) - (b.order || 0)) }
</script>

<style scoped>
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 10px; margin-top: 12px; }
.svc { display: grid; justify-items: center; gap: 6px; padding: 16px 10px; border: 1px solid #c9d7e8; border-radius: 6px; background: linear-gradient(180deg, #fff, #eef3fa); cursor: pointer; font: 12px Tahoma, sans-serif; }
.svc:hover:not(:disabled) { border-color: #3d7fd6; box-shadow: 0 2px 8px rgba(30,60,110,.15); }
.svc:disabled { opacity: .5; cursor: default; }
.ico { width: 46px; height: 46px; border-radius: 10px; background: linear-gradient(135deg, #b8c6d8, #56667c); color: #fff; font-size: 26px; display: flex; align-items: center; justify-content: center; }
.svc small { color: #6a7b8f; }
.veh .rl-btn { display: inline-flex; gap: 4px; align-items: center; }
</style>
