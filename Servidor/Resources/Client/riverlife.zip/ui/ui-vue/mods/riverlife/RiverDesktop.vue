<template>
  <main class="rlos" :class="{ seethrough: seeThrough }" @pointerdown.self="startOpen = false" @pointerdown="ctxMenu = null" @focusin="typingFocus" @focusout="typingBlur" aria-label="Computador RiverOS">
    <div class="rlos-wallpaper" @pointerdown="startOpen = false; ctxMenu = null" @contextmenu.prevent="openCtx">
      <Wallpaper :value="wallpaper" />
    </div>
    <div class="rlos-brand"><b>River<span>OS</span></b><small>Edição Carreira · {{ facility }}</small></div>

    <nav class="rlos-icons" aria-label="Área de trabalho" @contextmenu.self.prevent="openCtx">
      <button v-for="a in desktopApps" :key="a.id" class="rlos-icon" :class="{ selected: selectedIcon === a.id }"
        @click="clickIcon(a.id)" @keydown.enter="openApp(a.id)">
        <span class="rlos-tile" :style="{ background: a.color }"><BngIcon :type="a.icon" /></span>
        <span class="rlos-icon-label">{{ a.desktop || a.title }}</span>
        <span v-if="badge(a.id)" class="rlos-badge">{{ badge(a.id) }}</span>
      </button>
    </nav>

    <XPWindow v-if="showNativeFallback && !nativeWin.minimized" key="native" :win="nativeWin" :title="nativeView.title" icon="cogs" native
      :focused="focused === 'native'" :z="20 + Math.max(0, order.indexOf('native'))" @focus="focus('native')" @close="closeNative"
      @minimize="nativeWin.minimized = true" @maximize="nativeWin.maximized = !nativeWin.maximized">
      <component :is="nativeView.component" v-bind="nativeView.attrs || {}" />
    </XPWindow>

    <!-- River Explorer: every page opens in a tab of this one browser window. Hidden tabs stay mounted,
         so their RLS sessions and half-filled forms survive. -->
    <XPWindow v-if="tabs.length" v-show="!browser.minimized" key="browser" class="rlos-browser" :win="browser" :title="browserTitle" icon="globe"
      :focused="focused === 'browser'" :z="20 + Math.max(0, order.indexOf('browser'))" @focus="focus('browser')" @close="closeBrowser"
      @minimize="browser.minimized = true" @maximize="browser.maximized = !browser.maximized">
      <div class="rb">
        <div class="rb-tabs" role="tablist">
          <div v-for="t in tabs" :key="t.id" class="rb-tab" :class="{ on: t.id === activeId }" role="tab" :aria-selected="t.id === activeId"
            :title="tabTitle(t)" @pointerdown="activate(t.id)" @auxclick.prevent="e => e.button === 1 && closeTab(t.id)">
            <BngIcon :type="appOf(pageOf(t).app).icon" color="#2b5ea8" /><span>{{ tabTitle(t) }}</span>
            <button class="rb-tab-x" aria-label="Fechar aba" @pointerdown.stop @click.stop="closeTab(t.id)">×</button>
          </div>
          <button class="rb-newtab" title="Nova aba" aria-label="Nova aba" @click="openApp('internet', null, { newTab: true })">+</button>
        </div>
        <div class="rb-tools">
          <button :disabled="!canBack" title="Voltar" @click="go(-1)"><BngIcon type="arrowLargeLeft" color="#1f6f2a" /> Voltar</button>
          <button :disabled="!canForward" title="Avançar" @click="go(1)"><BngIcon type="arrowLargeRight" color="#1f6f2a" /></button>
          <button title="Atualizar" @click="refresh"><BngIcon type="sync" color="#2b5ea8" /></button>
          <button title="Página inicial" @click="openFrom(activeId, 'internet')"><BngIcon type="house" color="#2b5ea8" /> Início</button>
          <div class="rb-url"><BngIcon type="globe" color="#2b6cc4" />
            <input v-model="address" class="rl-input" aria-label="Endereço" spellcheck="false" @keydown.enter="typed(address)" @focus="e => e.target.select()" />
          </div>
          <button class="rb-go" @click="typed(address)">Ir</button>
        </div>
        <div class="rb-links">
          <span>Links</span>
          <button v-for="l in links" :key="l" :class="{ on: activeTab && pageOf(activeTab).app === l }" @click="openFrom(activeId, l)">
            <BngIcon :type="appOf(l).icon" color="#2b5ea8" /> {{ appOf(l).short || appOf(l).title }}</button>
        </div>
        <div class="rb-pages">
          <div v-for="t in tabs" v-show="t.id === activeId" :key="t.id" class="rb-page">
            <component :is="appOf(pageOf(t).app).component" :key="pageKey(t)" :ref="el => setAppRef(t.id, el)" v-bind="pageProps(t)"
              @open="e => openFrom(t.id, e)" @go="s => openFrom(t.id, siteApp(s))" @title="x => (t.subtitle = x)" @close="closeTab(t.id, true)" />
          </div>
        </div>
        <div class="rb-status"><span><BngIcon type="checkmark" color="#2f8a22" /> Concluído</span><span>{{ rl.view.connected ? "Internet" : "Trabalhando offline" }}</span></div>
      </div>
    </XPWindow>

    <!-- 3D tools (painting, tuning, parts) stay side windows: the car must be visible next to them. -->
    <XPWindow v-for="w in windows" v-show="!w.minimized" :key="w.id" :win="w" class="view3d" :title="titleOf(w)" :icon="appOf(w.app).icon"
      :focused="focused === w.id" :z="20 + order.indexOf(w.id)"
      @focus="focus(w.id)" @close="closeWindow(w.id)" @minimize="w.minimized = true" @maximize="w.maximized = !w.maximized">
      <component :is="appOf(w.app).component" :ref="el => setAppRef(w.id, el)" v-bind="w.props || {}"
        @open="openApp" @title="t => (w.subtitle = t)" @close="closeWindow(w.id, true)" />
    </XPWindow>

    <section v-if="startOpen" class="rlos-start" aria-label="Menu Iniciar">
      <header>
        <span class="rlos-avatar"><BngIcon type="personSolid" /></span>
        <div><b>{{ me.name || "Motorista" }}</b><small>{{ rl.view.mode === "BeamMP" ? (rl.view.serverName || "Servidor River") : "Carreira solo" }}</small></div>
      </header>
      <div class="rlos-start-body">
        <div class="rlos-start-left">
          <button v-for="a in desktopApps" :key="a.id" @click="openApp(a.id); startOpen = false">
            <span class="rlos-mini" :style="{ background: a.color }"><BngIcon :type="a.icon" /></span>
            <span><b>{{ a.desktop || a.title }}</b><small>{{ a.hint }}</small></span>
          </button>
        </div>
        <div class="rlos-start-right">
          <p class="rlos-start-title">Serviços da garagem</p>
          <button v-for="f in nativeGeneral" :key="f.id" :disabled="f.disabled" :title="f.reason?.label || ''" @click="native(f)">
            <BngIcon :type="RLS_FUNCTIONS[f.id]?.icon || 'cogs'" color="#0c3a7d" /> {{ rlsName(f) }}</button>
          <p v-if="!nativeGeneral.length" class="rlos-muted">Use um computador de garagem para os serviços nativos.</p>
          <p class="rlos-start-title">Painel de controle</p>
          <button @click="startOpen = false; wallpaperOpen = true"><BngIcon type="screen" color="#0c3a7d" /> Personalizar área de trabalho</button>
        </div>
      </div>
      <footer><button @click="shutdown"><BngIcon type="powerOnOff" /> Desligar</button></footer>
    </section>

    <div v-if="ctxMenu" class="rlos-ctx" :style="{ left: ctxMenu.x + 'px', top: ctxMenu.y + 'px' }" @pointerdown.stop>
      <button @click="ctxMenu = null; request('refresh')">Atualizar</button>
      <hr />
      <button @click="ctxMenu = null; wallpaperOpen = true"><b>Personalizar área de trabalho…</b></button>
    </div>

    <footer class="rlos-taskbar">
      <button class="rlos-startbtn" :class="{ on: startOpen }" @click="startOpen = !startOpen"><BngIcon type="globe" /><i>iniciar</i></button>
      <div class="rlos-tasks">
        <button v-if="showNativeFallback" class="rlos-task" :class="{ on: focused === 'native' && !nativeWin.minimized }"
          @click="nativeWin.minimized = !nativeWin.minimized; focus('native')"><BngIcon type="cogs" /><span>{{ nativeView.title }}</span></button>
        <button v-if="tabs.length" class="rlos-task" :class="{ on: focused === 'browser' && !browser.minimized }" @click="toggleBrowser">
          <BngIcon type="globe" /><span>{{ browserTitle }}</span></button>
        <button v-for="w in windows" :key="w.id" class="rlos-task" :class="{ on: focused === w.id && !w.minimized }"
          @click="toggleTask(w)"><BngIcon :type="appOf(w.app).icon" /><span>{{ titleOf(w) }}</span></button>
      </div>
      <div class="rlos-tray">
        <span class="rlos-net" :class="{ on: rl.view.connected }" :title="rl.view.connected ? 'Conectado' : 'Conectando'"><BngIcon type="signal" /></span>
        <span v-if="unread" class="rlos-mailtray" @click="openApp('mail')"><BngIcon type="envelope" />{{ unread }}</span>
        <b class="rlos-money">{{ money(rl.view.money) }}</b>
        <span class="rlos-clock">{{ clock }}</span>
      </div>
    </footer>

    <WallpaperDialog v-if="wallpaperOpen" :value="wallpaper" @close="wallpaperOpen = false" @preview="w => (localWallpaper = w)" />

    <div v-if="desk.peek" class="rlos-peek"><button class="rl-btn primary" @click="desk.peek = false"><BngIcon type="arrowLargeLeft" /> Voltar para a loja</button></div>

    <div v-if="rl.confirm" class="rlos-confirm" @pointerdown.self="answer(false)">
      <div class="rlos-confirm-box" role="alertdialog">
        <header>RiverOS</header>
        <p>{{ rl.confirm.text }}</p>
        <div class="rl-row"><button class="rl-btn primary" @click="answer(true)">{{ rl.confirm.label }}</button>
          <button class="rl-btn" @click="answer(false)">Cancelar</button></div>
      </div>
    </div>

    <div class="rlos-balloons">
      <div v-for="n in rl.notices" :key="n.id" class="rlos-balloon" :class="n.kind" role="status">
        <b>RiverLife</b><p>{{ n.text }}</p>
      </div>
    </div>
  </main>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, markRaw, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, wire, request, engineLua, money, me, unread, attention, onAction, myNpcs, shopOrders, myOrders, myGig, typing, RLS_FUNCTIONS, rlsName, answer } from "./rl.js"
import { desk } from "./desk.js"
import XPWindow from "./components/XPWindow.vue"
import Wallpaper from "./components/Wallpaper.vue"
import WallpaperDialog from "./components/WallpaperDialog.vue"
import SiteHome from "./apps/SiteHome.vue"
import SiteNews from "./apps/SiteNews.vue"
import SiteDirectory from "./apps/SiteDirectory.vue"
import SiteNotFound from "./apps/SiteNotFound.vue"
import AppMarket from "./apps/AppMarket.vue"
import AppGarage from "./apps/AppGarage.vue"
import AppStore from "./apps/AppStore.vue"
import AppWorkshop from "./apps/AppWorkshop.vue"
import AppAgenda from "./apps/AppAgenda.vue"
import AppMessages from "./apps/AppMessages.vue"
import AppPlayers from "./apps/AppPlayers.vue"
import AppFinance from "./apps/AppFinance.vue"
import AppNative from "./apps/AppNative.vue"
import AppSell from "./apps/AppSell.vue"
import AppJobs from "./apps/AppJobs.vue"
import AppDealer from "./apps/AppDealer.vue"
import AppLoans from "./apps/AppLoans.vue"
import AppSleep from "./apps/AppSleep.vue"
import AppInsurance from "./apps/AppInsurance.vue"
import AppMyParts from "./apps/AppMyParts.vue"
import AppPaint from "./apps/AppPaint.vue"
import AppTuning from "./apps/AppTuning.vue"
import AppParts from "./apps/AppParts.vue"
import AppPartStore from "./apps/AppPartStore.vue"
import AppRepair from "./apps/AppRepair.vue"
import AppMaintenance from "./apps/AppMaintenance.vue"
import AppEngine from "./apps/AppEngine.vue"
import AppPerformance from "./apps/AppPerformance.vue"
import AppAbstract from "./apps/AppAbstract.vue"

const APPS = {
  internet: { title: "Portal River", desktop: "River Explorer", short: "Início", host: "portal.river", hint: "Classificados, lojas, oficinas e jogadores", icon: "globe", color: "linear-gradient(135deg,#4aa3ff,#0d4fb8)", component: markRaw(SiteHome) },
  market: { title: "Classificados", host: "classificados.river", hint: "Compre e venda carros", icon: "carStarred", color: "linear-gradient(135deg,#ffb347,#e46a00)", component: markRaw(AppMarket) },
  stores: { title: "Lojas", host: "lojas.river", hint: "Lojas de carros dos jogadores", icon: "carDealer", color: "linear-gradient(135deg,#ff7a7a,#b51f1f)", component: markRaw(SiteDirectory), props: { kind: "stores" } },
  workshops: { title: "Oficinas", host: "oficinas.river", hint: "Oficinas dos jogadores", icon: "houseWrench", color: "linear-gradient(135deg,#9aa7b8,#3c4b60)", component: markRaw(SiteDirectory), props: { kind: "workshops" } },
  sell: { title: "Anunciar carro", host: "classificados.river/anunciar", hint: "Fotos, preço e local da visita", icon: "camera3Fourth1", color: "linear-gradient(135deg,#ffd86b,#d48f00)", component: markRaw(AppSell) },
  garage: { title: "Meus veículos", host: "garagem.river", hint: "Retirar, entregar, guardar e personalizar", icon: "keys1", color: "linear-gradient(135deg,#7bd389,#24813a)", component: markRaw(AppGarage), launch: "vehicleInventory" },
  store: { title: "Minha loja", host: "minhaloja.river", hint: "Concessionária, estoque e clientes", icon: "carDealer", color: "linear-gradient(135deg,#ff7a7a,#b51f1f)", component: markRaw(AppStore) },
  workshop: { title: "Minha oficina", host: "minhaoficina.river", hint: "Elevadores, orçamentos e clientes", icon: "houseWrench", color: "linear-gradient(135deg,#9aa7b8,#3c4b60)", component: markRaw(AppWorkshop) },
  agenda: { title: "Agenda", host: "agenda.river", hint: "Visitas, propostas e serviços", icon: "calendar", color: "linear-gradient(135deg,#7fd6ff,#1a7bb0)", component: markRaw(AppAgenda) },
  mail: { title: "E-mail", host: "mail.river", hint: "Mensagens e avisos", icon: "envelope", color: "linear-gradient(135deg,#f9e27a,#c99a00)", component: markRaw(AppMessages) },
  players: { title: "Jogadores", host: "jogadores.river", hint: "Quem está online e onde", icon: "peopleOutline", color: "linear-gradient(135deg,#c59bff,#6b2fc0)", component: markRaw(AppPlayers) },
  finance: { title: "Extrato", host: "bancoriver.river/extrato", hint: "Vendas, compras e serviços", icon: "chartBars", color: "linear-gradient(135deg,#8ee3c8,#178a69)", component: markRaw(AppFinance) },
  native: { title: "Serviços da garagem", host: "servicos.river", hint: "Todos os serviços deste computador", icon: "cogs", color: "linear-gradient(135deg,#b8c6d8,#56667c)", component: markRaw(AppNative) },
  // RLS services rebuilt as RiverOS pages; "launch" opens them through the RLS computer button.
  dealer: { title: "Concessionárias", short: "RiverAutos", host: "riverautos.river", hint: "Carros do RLS e venda do seu carro", icon: "carDealer", color: "linear-gradient(135deg,#5fd1ff,#0b6bb5)", component: markRaw(AppDealer), launch: "vehicleShop" },
  partstore: { title: "RiverPeças", host: "riverpecas.river", hint: "Peças com foto para o seu carro", icon: "engine", color: "linear-gradient(135deg,#ffb36b,#c4501b)", component: markRaw(AppPartStore) },
  loans: { title: "Banco River", host: "bancoriver.river", hint: "Empréstimos e financiamentos", icon: "banknotes", color: "linear-gradient(135deg,#9be37a,#2f7d1e)", component: markRaw(AppLoans), launch: "loans" },
  insurance: { title: "Seguros", host: "seguros.river", hint: "Apólices, coberturas e pontuação", icon: "shieldCheckmark", color: "linear-gradient(135deg,#8fb8ff,#2a4fb0)", component: markRaw(AppInsurance), launch: "insurances" },
  myparts: { title: "Minhas peças", host: "minhaspecas.river", hint: "Peças guardadas e venda", icon: "engine", color: "linear-gradient(135deg,#e2c29b,#8a5a2b)", component: markRaw(AppMyParts), launch: "partInventory" },
  sleep: { title: "Dormir", host: "dormir.river", hint: "Descansar até um horário", icon: "calendar", color: "linear-gradient(135deg,#6f7fd8,#1d2a6b)", component: markRaw(AppSleep), launch: "sleep" },
  abstract: { title: "Ficha do motorista", host: "ficha.river", hint: "Pontuação e histórico", icon: "documentOutline", color: "linear-gradient(135deg,#d7d7d7,#6f6f6f)", component: markRaw(AppAbstract), launch: "playerAbstract" },
  repair: { title: "Reparo", host: "reparo.river", hint: "Consertar pelo seguro ou particular", icon: "wrench", color: "linear-gradient(135deg,#ffb27a,#c4501b)", component: markRaw(AppRepair) },
  maintenance: { title: "Manutenção", host: "manutencao.river", hint: "Óleo, fluidos, pneus e revisões", icon: "wrench", color: "linear-gradient(135deg,#a5d6a7,#2e7d32)", component: markRaw(AppMaintenance) },
  engine: { title: "Pacotes de motor", host: "motores.river", hint: "Guardar e trocar motores", icon: "engine", color: "linear-gradient(135deg,#cfd8dc,#37474f)", component: markRaw(AppEngine) },
  performance: { title: "Desempenho", host: "desempenho.river", hint: "Classe e certificação", icon: "chartBars", color: "linear-gradient(135deg,#80deea,#00838f)", component: markRaw(AppPerformance) },
  jobs: { title: "Empregos & Bicos", short: "Empregos", host: "empregos.river", hint: "Translados, vistorias e vagas", icon: "badge", color: "linear-gradient(135deg,#ffcf5a,#d06d00)", component: markRaw(AppJobs) },
  news: { title: "Jornal do River", short: "Notícias", host: "noticias.river", hint: "Notícias e rankings do servidor", icon: "documentOutline", color: "linear-gradient(135deg,#d7d7d7,#6f6f6f)", component: markRaw(SiteNews) },
  notfound: { title: "Página não encontrada", host: "", icon: "globe", component: markRaw(SiteNotFound) },
  // 3D side windows.
  paint: { title: "Pintura", hint: "Cores e acabamento", icon: "documentOutline", component: markRaw(AppPaint), view3d: true },
  tuning: { title: "Tuning", hint: "Ajustes finos do carro", icon: "gearTuningOutline", component: markRaw(AppTuning), view3d: true },
  parts: { title: "Peças e personalização", hint: "Comprar e trocar peças", icon: "engine", component: markRaw(AppParts), view3d: true },
  perftest: { title: "Teste de certificação", hint: "Teste na pista", icon: "chartBars", component: markRaw(AppPerformance), view3d: true },
}
const DESKTOP = ["internet", "market", "garage", "dealer", "partstore", "store", "workshop", "jobs", "agenda", "mail", "players", "news", "finance", "loans", "insurance", "native", "sell"]
const LINKS = ["internet", "market", "dealer", "partstore", "stores", "workshops", "jobs", "news", "players"]
// Old site names used by pages ("go" events and { app: "internet", props: { start } }).
const SITES = { home: "internet", classificados: "market", lojas: "stores", oficinas: "workshops", jogadores: "players", noticias: "news", empregos: "jobs", pecas: "partstore", autos: "dealer" }

const props = defineProps({ nativeView: Object })
const windows = desk.windows
const tabs = desk.tabs
const order = desk.order
const browser = desk.browser
const focused = ref(desk.focused)
const startOpen = ref(false)
const selectedIcon = ref("")
const clock = ref("")
const ctxMenu = ref(null)
const wallpaperOpen = ref(false)
const localWallpaper = ref(null)
const links = LINKS
let timer, offAction, launchTimer

// The RLS parts screen shows as the RiverPeças store unless the player asked for the 3D panel.
const hostedApp = view => (view?.app === "parts" && desk.partsMode !== "3d" ? "partstore" : view?.app)
const showNativeFallback = computed(() => !!props.nativeView && !APPS[props.nativeView.app])
const nativeWin = reactive({ id: "native", x: 30, y: 16, w: Math.max(900, innerWidth - 60), h: Math.max(560, innerHeight - 90), minimized: false, maximized: true })

const desktopApps = computed(() => DESKTOP.map(id => ({ id, ...APPS[id] })))
const facility = computed(() => rl.view.computer?.facilityName || (rl.view.mode === "BeamMP" ? "Online" : "Solo"))
const nativeGeneral = computed(() => Object.values(rl.view.computer?.computerFunctions?.general || {})
  .filter(f => f.id !== "riverLife").sort((a, b) => (a.order || 0) - (b.order || 0)))
const wallpaper = computed(() => localWallpaper.value || rl.view.desktop?.wallpaper || { kind: "theme", value: "bliss" })

function appOf(id) { return APPS[id] || APPS.internet }
function titleOf(w) { return w.subtitle ? appOf(w.app).title + " — " + w.subtitle : appOf(w.app).title }
function siteApp(s) { return SITES[s] || (APPS[s] ? s : "internet") }
function badge(id) {
  if (id === "mail") return unread.value || ""
  if (id === "agenda") return attention.value.filter(a => ["visit", "offer", "quote"].includes(a.kind)).length || ""
  if (id === "store") return myNpcs.value.filter(n => n.status === "negotiating" && n.storeId).length || ""
  if (id === "workshop") return shopOrders.value.filter(o => ["requested", "accepted"].includes(o.status)).length || ""
  if (id === "jobs") return myGig.value ? "1" : ""
  return ""
}
function focus(id) {
  const i = order.indexOf(id)
  if (i >= 0) order.splice(i, 1)
  order.push(id)
  focused.value = id
  desk.focused = id
}

/* ---------------- browser tabs ---------------- */
const activeId = computed({ get: () => desk.active, set: v => { desk.active = v } })
const activeTab = computed(() => tabs.find(t => t.id === desk.active) || null)
function pageOf(t) { return t.history[t.pos] || t.history[0] }
function pageProps(t) { const p = pageOf(t); return { ...(APPS[p.app]?.props || {}), ...(p.props || {}) } }
// A page is rebuilt when it changes or when its RLS session arrives (a launcher page becomes the real one).
function pageKey(t) { const p = pageOf(t); return t.id + ":" + t.pos + ":" + p.app + ":" + (p.props?.route || "") }
function tabTitle(t) {
  const title = appOf(pageOf(t).app).title
  return t.subtitle && t.subtitle !== title && pageOf(t).app !== "internet" ? title + " — " + t.subtitle : title
}
const browserTitle = computed(() => (activeTab.value ? tabTitle(activeTab.value) + " - " : "") + "River Explorer")
const canBack = computed(() => !!activeTab.value && !activeTab.value.hostedRoute && activeTab.value.pos > 0)
const canForward = computed(() => !!activeTab.value && !activeTab.value.hostedRoute && activeTab.value.pos < activeTab.value.history.length - 1)
function urlOf(t) {
  if (!t) return ""
  const p = pageOf(t)
  if (p.app === "notfound") return p.props?.url || ""
  return "http://www." + (appOf(p.app).host || "portal.river") + "/"
}
const address = ref("")
watch(() => urlOf(activeTab.value), u => { address.value = u }, { immediate: true })

function showBrowser() {
  if (!browser.placed) {
    const W = Math.round(Math.min(1500, Math.max(900, innerWidth - 140))), H = Math.round(Math.max(520, innerHeight - 38 - 56))
    Object.assign(browser, { w: W, h: H, x: Math.max(8, Math.round((innerWidth - W) / 2)), y: 14, maximized: innerWidth < 1200 || innerHeight < 720, placed: true })
  }
  browser.minimized = false
  focus("browser")
}
function activate(id) {
  if (!tabs.some(t => t.id === id)) return
  desk.active = id
  showBrowser()
}
function newTab(page, hostedRoute) {
  const t = reactive({ id: "tab-" + Date.now() + "-" + Math.floor(Math.random() * 1000), history: [page], pos: 0, subtitle: "", hostedRoute: hostedRoute || "" })
  const i = tabs.findIndex(x => x.id === desk.active)
  tabs.splice(i >= 0 ? i + 1 : tabs.length, 0, t)
  return tabs.find(x => x.id === t.id)
}
function normalize(id, p) {
  let app = id && typeof id === "object" ? id.app : id
  let extra = id && typeof id === "object" ? id.props : p
  if ((app === "internet" || app === "market" || app === "news") && extra?.start && SITES[extra.start]) {
    app = SITES[extra.start]
    const { start, ...rest } = extra
    extra = rest
  }
  return { app: APPS[app] ? app : "internet", props: extra || null }
}
function rlsFunction(app) {
  const id = APPS[app]?.launch
  return id && rl.view.computer?.computerFunctions?.general?.[id]
}
// RLS services first ask the game for their screen; the page arrives with the RLS route.
function launchRls(app) {
  const fn = rlsFunction(app)
  if (!fn || fn.disabled || tabs.some(t => pageOf(t).app === app && t.hostedRoute)) return false
  startOpen.value = false
  request("native", { buttonId: fn.id })
  clearTimeout(launchTimer)
  launchTimer = setTimeout(() => openApp(app, { launchFailed: true }), 6000)
  return true
}
// Desktop icons, start menu, balloons: an existing tab of that page comes to the front, otherwise a new tab.
function openApp(id, p, opts = {}) {
  const { app, props: extra } = normalize(id, p)
  if (APPS[app].view3d) { openWindow(app, extra); return }
  if (!extra?.route && !extra?.launchFailed && launchRls(app)) return
  let t = !opts.newTab && tabs.find(x => pageOf(x).app === app)
  if (t) {
    if (extra) { const page = pageOf(t); page.props = { ...(page.props || {}), ...extra, nonce: Date.now() } }
  } else t = newTab({ app, props: extra ? { ...extra } : null })
  activate(t.id)
  request("refresh")
}
// Links inside a page navigate in the same tab (with Back); RLS screens and 3D tools get their own place.
function openFrom(tabId, id, p) {
  const t = tabs.find(x => x.id === tabId)
  const { app, props: extra } = normalize(id, p)
  if (!t || t.hostedRoute || APPS[app].view3d || APPS[app].launch) { openApp(app, extra); return }
  const cur = pageOf(t)
  if (cur.app === app) {
    if (extra) cur.props = { ...(cur.props || {}), ...extra, nonce: Date.now() }
  } else {
    t.history.splice(t.pos + 1)
    t.history.push({ app, props: extra ? { ...extra } : null })
    t.pos = t.history.length - 1
    t.subtitle = ""
  }
  activate(t.id)
}
function go(d) {
  const t = activeTab.value
  if (!t || t.hostedRoute) return
  const pos = Math.max(0, Math.min(t.history.length - 1, t.pos + d))
  if (pos !== t.pos) { t.pos = pos; t.subtitle = "" }
}
function refresh() {
  request("refresh")
  const t = activeTab.value
  if (t && !t.hostedRoute) { const p = pageOf(t); p.props = { ...(p.props || {}), nonce: Date.now() } }
}
function typed(text) {
  const raw = String(text || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "")
  const host = raw.split("?")[0].replace(/\/+$/, "")
  let app = Object.keys(APPS).find(k => APPS[k].host && APPS[k].host === host)
  if (!app) app = Object.keys(APPS).find(k => APPS[k].host && (host === k || APPS[k].host.split(/[./]/)[0] === host.split(/[./]/)[0]))
  if (!app && SITES[host.split(".")[0]]) app = SITES[host.split(".")[0]]
  const sites = LINKS.map(k => ({ app: k, host: APPS[k].host, title: APPS[k].title }))
  if (app) openFrom(desk.active, app)
  else openFrom(desk.active, "notfound", { url: "http://" + (raw || "") , sites })
}
// An RLS screen opened by the game shows our page in a tab; closing that tab also leaves the RLS screen.
function openHosted(view) {
  const app = hostedApp(view)
  const page = { app, props: { route: view.name, routeProps: { ...(view.attrs || {}) }, nonce: Date.now() } }
  if (APPS[app]?.view3d) {
    openWindow(app, page.props)
    const w = windows.find(x => x.app === app)
    if (w) { w.hostedRoute = view.name; delete w.staleHost; layoutFor(w) }
    return
  }
  let t = tabs.find(x => pageOf(x).app === app && (x.hostedRoute || pageOf(x).props?.launchFailed)) || tabs.find(x => pageOf(x).app === app)
  if (t) { t.history.splice(0, t.history.length, page); t.pos = 0; t.hostedRoute = view.name; delete t.staleHost }
  else t = newTab(page, view.name)
  desk.active = t.id
  showBrowser()
}
const appRefs = {}
function setAppRef(id, el) { if (el) appRefs[id] = el; else delete appRefs[id] }
function closeTab(id, force = false) {
  const t = tabs.find(x => x.id === id)
  if (!t) return
  const app = appRefs[id]
  if (!force && t.hostedRoute && typeof app?.requestClose === "function") { app.requestClose(); return }
  if (!force && t.hostedRoute && window.vueRouter?.currentRoute?.value?.name === t.hostedRoute) { closeNative(); return }
  const i = tabs.findIndex(x => x.id === id)
  tabs.splice(i, 1)
  if (desk.active === id) desk.active = (tabs[i] || tabs[i - 1] || {}).id || ""
  if (!tabs.length) {
    const j = order.indexOf("browser")
    if (j >= 0) order.splice(j, 1)
    focused.value = order[order.length - 1] || ""
  }
}
// The window's X closes the tabs one by one (hosted ones may ask first).
function closeBrowser() {
  for (const t of [...tabs].reverse()) closeTab(t.id)
}
function toggleBrowser() {
  if (focused.value === "browser" && !browser.minimized) browser.minimized = true
  else showBrowser()
}

/* ---------------- 3D side windows ---------------- */
function openWindow(app, extra) {
  let w = windows.find(x => x.app === app)
  if (!w) {
    w = { id: app + "-" + Date.now(), app, w: 560, h: innerHeight - 60, x: 8, y: 8, minimized: false, maximized: false, props: { ...(APPS[app]?.props || {}), ...(extra || {}) } }
    windows.push(w)
    w = windows[windows.length - 1]
    layoutFor(w)
  } else {
    w.minimized = false
    if (extra) w.props = { ...w.props, ...extra, nonce: Date.now() }
  }
  focus(w.id)
  request("refresh")
}
function layoutFor(w) {
  if (!APPS[w.app]?.view3d) return
  w.maximized = false; w.x = 8; w.y = 8; w.w = Math.min(560, Math.round(innerWidth * 0.36)); w.h = innerHeight - 60
}
const seeThrough = computed(() => desk.peek || windows.some(w => !w.minimized && APPS[w.app]?.view3d && focused.value === w.id))
function closeWindow(id, force = false) {
  const closing = windows.find(w => w.id === id)
  const app = appRefs[id]
  if (!force && closing?.hostedRoute && typeof app?.requestClose === "function") { app.requestClose(); return }
  if (!force && closing?.hostedRoute && window.vueRouter?.currentRoute?.value?.name === closing.hostedRoute) { closeNative(); return }
  const i = windows.findIndex(w => w.id === id)
  if (i >= 0) windows.splice(i, 1)
  const j = order.indexOf(id)
  if (j >= 0) order.splice(j, 1)
  focused.value = order[order.length - 1] || ""
}
function toggleTask(w) {
  if (focused.value === w.id && !w.minimized) w.minimized = true
  else { w.minimized = false; focus(w.id) }
}

/* ---------------- desktop ---------------- */
let lastIconClick = { id: "", at: 0 }
function clickIcon(id) {
  selectedIcon.value = id
  const now = Date.now()
  if (lastIconClick.id === id && now - lastIconClick.at < 900) return
  lastIconClick = { id, at: now }
  openApp(id)
}
function openCtx(e) {
  startOpen.value = false
  ctxMenu.value = { x: Math.min(e.clientX, innerWidth - 230), y: Math.min(e.clientY, innerHeight - 120) }
}
function native(f) { startOpen.value = false; request("native", { buttonId: f.id }) }
// The hosted RLS screen closes the way its own Back button would.
function closeNative() {
  const i = order.indexOf("native")
  if (i >= 0) order.splice(i, 1)
  engineLua("if extensions.ui_router and extensions.ui_router.back then extensions.ui_router.back() end")
  setTimeout(() => {
    const r = window.vueRouter?.currentRoute?.value
    if (r && props.nativeView && r.name === props.nativeView.name) window.vueRouter.push({ name: "career.computer" }).catch(() => {})
  }, 600)
}
// Typing in a text field must not drive the car.
let typingOn = false
function isText(el) { return el && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !["checkbox", "radio", "range", "button", "submit", "color"].includes(el.type))) }
function typingFocus(e) { if (isText(e.target) && !typingOn) { typingOn = true; typing(true) } }
function typingBlur(e) { if (typingOn && !isText(e.relatedTarget)) { typingOn = false; typing(false) } }
function shutdown() {
  startOpen.value = false
  engineLua("if career_career then career_career.closeAllMenus() end")
}

// Every RLS screen remounts the desktop: settle its page before the first render, so the page
// is built with its RLS session (a page built without it would never load its data).
{
  const stale = order.indexOf("native")
  if (stale >= 0 && !props.nativeView) order.splice(stale, 1)
  const app = hostedApp(props.nativeView)
  if (props.nativeView && APPS[app]) openHosted(props.nativeView)
  // Pages of an RLS screen that is gone end with it.
  for (let i = tabs.length - 1; i >= 0; i--) if (tabs[i].staleHost) { tabs.splice(i, 1) }
  for (let i = windows.length - 1; i >= 0; i--) if (windows[i].staleHost) { const k = order.indexOf(windows[i].id); if (k >= 0) order.splice(k, 1); windows.splice(i, 1) }
  if (desk.active && !tabs.some(t => t.id === desk.active)) desk.active = (tabs[tabs.length - 1] || {}).id || ""
  if (!tabs.length) { const k = order.indexOf("browser"); if (k >= 0) order.splice(k, 1) }
  if (props.nativeView && !APPS[app]) focus("native")
  if (hostedApp(props.nativeView) !== "partstore") desk.peek = false
}

onMounted(() => {
  wire()
  request("desk", { open: true })
  const tick = () => { clock.value = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) }
  tick(); timer = setInterval(tick, 1000)
  offAction = onAction(e => {
    if (e?.op === "open" && e.open) openApp(e.app || "market", e.focus ? { focus: e.focus } : undefined)
  })
  if (!tabs.length && !windows.length && !props.nativeView) openApp(desk.firstApp || "internet")
  request("refresh")
})
onUnmounted(() => {
  clearInterval(timer); clearTimeout(launchTimer); offAction && offAction()
  request("desk", { open: false })
  // Like the RLS computer screen: leaving it drops the "stay near the computer" tether, so screens
  // that seat you in the car (painting, tuning, parts) don't close the menu.
  engineLua("if career_modules_computer and career_modules_computer.onMenuClosed then career_modules_computer.onMenuClosed() end")
  if (typingOn) { typingOn = false; typing(false) }
  // Pages of this RLS screen are reused by the next desktop if it shows the same screen; otherwise they end.
  for (const t of tabs) if (t.hostedRoute) t.staleHost = true
  for (const w of windows) if (w.hostedRoute) w.staleHost = true
})
</script>

<style>
.rlos { position: fixed; inset: 0; z-index: 900; overflow: hidden; font: 13px Tahoma, Verdana, "Segoe UI", sans-serif; color: #1b2733; user-select: none; text-align: left; }
.rlos * { box-sizing: border-box; }
.rlos-wallpaper { position: absolute; inset: 0; }
.rlos-brand { position: absolute; right: 36px; bottom: 64px; color: #fff; text-align: right; text-shadow: 0 2px 6px rgba(10,40,90,.6); pointer-events: none; }
.rlos-brand b { font: 300 46px "Trebuchet MS", Tahoma, sans-serif; letter-spacing: -2px; } .rlos-brand span { font-weight: 700; color: #ffcb5c; }
.rlos-brand small { display: block; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; }
.rlos-icons { position: absolute; left: 14px; top: 14px; bottom: 50px; display: grid; grid-auto-flow: column; grid-template-rows: repeat(auto-fill, 96px); grid-auto-columns: 92px; gap: 6px 6px; }
.rlos-icon { position: relative; display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 6px 4px; border: 1px solid transparent; background: none; color: #fff; cursor: pointer; border-radius: 3px; font: inherit; }
.rlos-icon:hover { background: rgba(80,140,230,.25); border-color: rgba(200,225,255,.45); }
.rlos-icon.selected { background: rgba(49,106,197,.55); border-color: rgba(200,225,255,.7); }
.rlos-tile { width: 46px; height: 46px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #fff; box-shadow: 0 3px 6px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.5); }
.rlos-icon-label { font-size: 11.5px; text-align: center; line-height: 1.25; text-shadow: 1px 1px 2px #000, 0 0 4px rgba(0,0,0,.6); }
.rlos-badge { position: absolute; top: 2px; right: 14px; min-width: 18px; height: 18px; border-radius: 9px; background: #e8322c; color: #fff; font-size: 11px; font-weight: bold; display: flex; align-items: center; justify-content: center; padding: 0 5px; box-shadow: 0 1px 2px #0006; }
.rlos-taskbar { position: absolute; left: 0; right: 0; bottom: 0; height: 38px; display: flex; align-items: center; background: linear-gradient(180deg, #3f8cf3 0%, #2667d8 9%, #245edb 50%, #1e4fb9 92%, #1a43a4 100%); border-top: 1px solid #0b3aa1; z-index: 1000; }
.rlos-startbtn { height: 38px; padding: 0 22px 0 12px; border: 0; border-radius: 0 16px 16px 0; display: flex; align-items: center; gap: 6px; color: #fff; cursor: pointer; font: italic bold 18px "Trebuchet MS", Tahoma, sans-serif; text-shadow: 1px 1px 2px #1b3d13; background: linear-gradient(180deg, #5eb84c 0%, #3c9c2f 12%, #378f2b 55%, #2f7c25 90%, #3b8f30 100%); box-shadow: inset 0 1px 2px #a6e38f, 2px 0 4px rgba(0,0,0,.35); }
.rlos-startbtn.on, .rlos-startbtn:active { background: linear-gradient(180deg, #2c7a22, #3b9631); }
.rlos-startbtn i { text-transform: lowercase; }
.rlos-tasks { flex: 1; display: flex; gap: 4px; padding: 0 8px; overflow: hidden; }
.rlos-task { max-width: 240px; min-width: 120px; height: 28px; display: flex; align-items: center; gap: 6px; padding: 0 9px; border: 1px solid #1c4bb0; border-radius: 3px; color: #fff; font: 12px Tahoma, sans-serif; cursor: pointer; background: linear-gradient(180deg, #4a95f2, #2f71dc); box-shadow: inset 0 1px 1px rgba(255,255,255,.35); overflow: hidden; white-space: nowrap; }
.rlos-task span { overflow: hidden; text-overflow: ellipsis; }
.rlos-task.on { background: linear-gradient(180deg, #1d4fae, #2156c2); box-shadow: inset 1px 2px 3px rgba(0,0,0,.35); }
.rlos-tray { height: 38px; display: flex; align-items: center; gap: 12px; padding: 0 14px; color: #fff; font-size: 12px; background: linear-gradient(180deg, #1291ee 0%, #0f7fdc 50%, #0d6fc8 100%); border-left: 1px solid #0b5bb0; box-shadow: inset 1px 0 1px rgba(255,255,255,.3); }
.rlos-net { opacity: .55; } .rlos-net.on { opacity: 1; color: #c5ffb5; }
.rlos-mailtray { cursor: pointer; display: flex; gap: 3px; align-items: center; color: #ffe27a; font-weight: bold; }
.rlos-money { color: #dfffd2; }
.rlos-start { position: absolute; left: 0; bottom: 38px; width: 480px; z-index: 1001; border-radius: 8px 8px 0 0; overflow: hidden; box-shadow: 4px -2px 16px rgba(0,0,0,.45); border: 1px solid #1c4bb0; background: #fff; }
.rlos-start header { display: flex; align-items: center; gap: 10px; padding: 10px 12px; color: #fff; background: linear-gradient(180deg, #1868ce, #2b7be4 40%, #1a5ec6); }
.rlos-start header b { font-size: 15px; } .rlos-start header small { display: block; font-size: 11px; opacity: .85; }
.rlos-avatar { width: 42px; height: 42px; border-radius: 6px; border: 2px solid #fff; background: #e9b44c; display: flex; align-items: center; justify-content: center; font-size: 26px; }
.rlos-start-body { display: flex; max-height: 70vh; }
.rlos-start-left { flex: 1.3; padding: 6px; overflow: auto; }
.rlos-start-left button { width: 100%; display: flex; align-items: center; gap: 9px; padding: 5px 6px; border: 0; background: none; text-align: left; cursor: pointer; font: inherit; color: #1b2733; border-radius: 3px; }
.rlos-start-left button:hover { background: #316ac5; color: #fff; }
.rlos-start-left small { display: block; font-size: 10.5px; opacity: .7; }
.rlos-mini { width: 30px; height: 30px; border-radius: 7px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 18px; flex-shrink: 0; }
.rlos-start-right { flex: 1; padding: 8px; background: #d3e5fa; border-left: 1px solid #95bde7; overflow: auto; }
.rlos-start-right button { display: flex; gap: 6px; align-items: center; width: 100%; text-align: left; padding: 5px 6px; border: 0; background: none; cursor: pointer; font: bold 12px Tahoma, sans-serif; color: #0c3a7d; border-radius: 3px; }
.rlos-start-right button:hover:not(:disabled) { background: #316ac5; color: #fff; }
.rlos-start-right button:disabled { opacity: .45; }
.rlos-start-title { margin: 2px 6px 6px; font-weight: bold; color: #4b5d73; font-size: 11px; text-transform: uppercase; }
.rlos-start-title + button, .rlos-start-right button + .rlos-start-title { margin-top: 10px; }
.rlos-start footer { display: flex; justify-content: flex-end; padding: 6px 10px; background: linear-gradient(180deg, #4b8ced, #2a64cf); }
.rlos-start footer button { display: flex; align-items: center; gap: 6px; border: 0; background: none; color: #fff; cursor: pointer; font: 12px Tahoma, sans-serif; }
.rlos-ctx { position: absolute; z-index: 1002; min-width: 220px; padding: 2px; background: #fff; border: 1px solid #848484; box-shadow: 2px 3px 6px rgba(0,0,0,.35); }
.rlos-ctx button { display: block; width: 100%; padding: 5px 22px; border: 0; background: none; text-align: left; font: 12px Tahoma, sans-serif; color: #111; cursor: pointer; }
.rlos-ctx button:hover { background: #316ac5; color: #fff; }
.rlos-ctx hr { border: 0; border-top: 1px solid #c5c2b2; margin: 2px 0; }
.rlos-confirm { position: absolute; inset: 0; z-index: 1003; display: flex; align-items: center; justify-content: center; background: rgba(0, 20, 60, .25); }
.rlos-confirm-box { width: 380px; border: 1px solid #0b3aa1; border-radius: 8px 8px 3px 3px; background: #ece9d8; box-shadow: 4px 6px 18px rgba(0,0,0,.45); overflow: hidden; }
.rlos-confirm-box header { display: flex; gap: 6px; align-items: center; padding: 6px 10px; color: #fff; font-weight: bold; background: linear-gradient(180deg, #0a5bd8, #2b7be4 40%, #0a4fc4); }
.rlos-confirm-box p { margin: 14px 14px 10px; line-height: 1.5; }
.rlos-confirm-box .rl-row { justify-content: flex-end; padding: 0 12px 12px; }
.rlos-balloons { position: absolute; right: 14px; bottom: 48px; display: flex; flex-direction: column; gap: 8px; z-index: 1002; }
.rlos-balloon { width: 300px; padding: 10px 12px; border: 1px solid #7a7a5a; border-radius: 8px; background: #ffffe1; box-shadow: 2px 3px 8px rgba(0,0,0,.35); font-size: 12px; animation: rlos-in .25s ease-out; }
.rlos-balloon.error { border-color: #b33; background: #fff0ee; } .rlos-balloon.warning { background: #fff7d6; }
.rlos-balloon p { margin: 4px 0 0; line-height: 1.45; }
@keyframes rlos-in { from { transform: translateY(12px); opacity: 0; } to { transform: none; opacity: 1; } }
.rlos-muted { color: #627287; font-size: 11.5px; }
.rlos-peek { position: absolute; left: 50%; bottom: 56px; transform: translateX(-50%); z-index: 1005; pointer-events: auto; }
.rlos-peek .rl-btn { font-size: 14px; padding: 9px 18px; box-shadow: 0 3px 10px rgba(0,0,0,.4); }

/* River Explorer */
.rb { display: flex; flex-direction: column; height: 100%; background: #ece9d8; }
.rb-tabs { display: flex; align-items: flex-end; gap: 2px; padding: 5px 6px 0; background: linear-gradient(180deg, #dfe8f6, #cdd9ec); border-bottom: 1px solid #8fa6c8; overflow: hidden; }
.rb-tab { flex: 0 1 210px; min-width: 90px; height: 28px; display: flex; align-items: center; gap: 6px; padding: 0 4px 0 9px; border: 1px solid #8fa6c8; border-bottom: 0;
  border-radius: 6px 6px 0 0; background: linear-gradient(180deg, #f3f6fb, #dbe4f2); font: 12px Tahoma, sans-serif; color: #1b2733; cursor: default; position: relative; top: 1px; }
.rb-tab span { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.rb-tab.on { background: #fff; border-color: #6f8cba; height: 30px; z-index: 1; font-weight: bold; }
.rb-tab:not(.on):hover { background: linear-gradient(180deg, #fff, #e6edf8); }
.rb-tab-x { width: 18px; height: 18px; border: 0; border-radius: 3px; background: none; color: #555; font: bold 14px Tahoma, sans-serif; line-height: 1; cursor: pointer; flex-shrink: 0; }
.rb-tab-x:hover { background: #d2421f; color: #fff; }
.rb-newtab { width: 28px; height: 24px; margin: 0 0 2px 2px; border: 1px solid transparent; border-radius: 4px; background: none; font: bold 16px Tahoma, sans-serif; color: #2b4c7e; cursor: pointer; }
.rb-newtab:hover { border-color: #8fa6c8; background: #eef3fb; }
.rb-tools { display: flex; align-items: center; gap: 3px; padding: 4px 6px; border-bottom: 1px solid #d0cdbd; background: #f5f3ea; }
.rb-tools > button { display: flex; align-items: center; gap: 4px; border: 1px solid transparent; background: none; padding: 3px 7px; cursor: pointer; font: 12px Tahoma, sans-serif; border-radius: 3px; color: #111; white-space: nowrap; }
.rb-tools > button:hover:not(:disabled) { border-color: #aac0e0; background: #fff; }
.rb-tools > button:disabled { opacity: .4; cursor: default; }
.rb-url { flex: 1; min-width: 160px; display: flex; align-items: center; gap: 4px; margin: 0 4px; background: #fff; border: 1px solid #7f9db9; padding: 0 4px; color: #2b6cc4; }
.rb-url input { flex: 1; border: 0 !important; outline: 0 !important; padding: 4px 2px !important; }
.rb-links { display: flex; align-items: center; gap: 2px; padding: 2px 6px; border-bottom: 1px solid #d0cdbd; font-size: 11.5px; color: #555; background: #f5f3ea; overflow: hidden; }
.rb-links > span { padding-right: 6px; margin-right: 2px; border-right: 1px solid #c5c2b2; }
.rb-links button { display: flex; align-items: center; gap: 4px; border: 1px solid transparent; background: none; padding: 2px 7px; cursor: pointer; font: 11.5px Tahoma, sans-serif; color: #1b2733; border-radius: 3px; white-space: nowrap; }
.rb-links button:hover { border-color: #aac0e0; background: #fff; }
.rb-links button.on { border-color: #aac0e0; background: #e3ecf9; }
.rb-pages { flex: 1; min-height: 0; position: relative; background: #fff; }
.rb-page { position: absolute; inset: 0; overflow: auto; }
.rb-status { display: flex; justify-content: space-between; padding: 3px 8px; font-size: 11px; color: #444; border-top: 1px solid #d0cdbd; }
.rb-status span { display: flex; align-items: center; gap: 4px; }

/* Shared widgets inside RiverOS windows */
.rlos .rl-tabs { display: flex; gap: 2px; border-bottom: 1px solid #919b9c; margin: 6px 0 12px; }
.rlos .rl-tabs button { font: 12px Tahoma, sans-serif; padding: 6px 14px; border: 1px solid #919b9c; border-bottom: 0; border-radius: 4px 4px 0 0; background: linear-gradient(180deg, #fff, #ecebe5); cursor: pointer; position: relative; top: 1px; }
.rlos .rl-tabs button.on { background: #fff; border-top: 2px solid #f8b636; font-weight: bold; padding-top: 5px; }
.rlos.seethrough .rlos-wallpaper, .rlos.seethrough .rlos-brand, .rlos.seethrough .rlos-icons, .rlos.seethrough .xpw:not(.view3d) { display: none; }
.rlos.seethrough { pointer-events: none; }
.rlos.seethrough .xpw, .rlos.seethrough .rlos-taskbar, .rlos.seethrough .rlos-start, .rlos.seethrough .rlos-balloons, .rlos.seethrough .rlos-confirm { pointer-events: auto; }
.rlos .xpw.native .xpw-body { transform: translateZ(0); contain: layout paint; position: relative; overflow: hidden; background: #1b1f27; }
.rlos .xpw.rlos-browser .xpw-body { overflow: hidden; }
.rlos .rl-page { padding: 18px 22px; }
.rlos .rl-h1 { font: 300 24px "Trebuchet MS", Tahoma, sans-serif; color: #12407c; margin: 0 0 6px; }
.rlos .rl-h2 { font-size: 15px; color: #1d3f69; margin: 18px 0 8px; }
.rlos .rl-muted { color: #5f7186; font-size: 12px; line-height: 1.5; }
.rlos .rl-btn { font: 12px Tahoma, sans-serif; padding: 6px 12px; border: 1px solid #003c74; border-radius: 3px; cursor: pointer; color: #000; background: linear-gradient(180deg, #fff 0%, #ecebe6 86%, #d6d0c5 100%); box-shadow: inset -1px -1px 0 rgba(0,0,0,.08); }
.rlos .rl-btn:hover:not(:disabled) { box-shadow: inset 0 0 0 2px #f8b636; }
.rlos .rl-btn:disabled { color: #9c9c9c; border-color: #b6b6b6; cursor: default; }
.rlos .rl-btn.primary { color: #fff; border-color: #0b3b8a; background: linear-gradient(180deg, #5d9bf0 0%, #2d6ad6 60%, #2259c0 100%); font-weight: bold; }
.rlos .rl-btn.danger { color: #fff; border-color: #7a1212; background: linear-gradient(180deg, #ef6a5d, #c62d1f); }
.rlos .rl-btn.go { color: #fff; border-color: #1c5a14; background: linear-gradient(180deg, #6cc35a, #2f8a22); font-weight: bold; }
.rlos .rl-btn.primary:disabled, .rlos .rl-btn.go:disabled, .rlos .rl-btn.danger:disabled { filter: grayscale(1) opacity(.5); box-shadow: none; }
.rlos .rl-input, .rlos textarea.rl-input { font: 12.5px Tahoma, sans-serif; padding: 6px 8px; border: 1px solid #7f9db9; border-radius: 2px; background: #fff; color: #111; user-select: text; }
.rlos .rl-input:focus { outline: 1px solid #316ac5; }
.rlos .rl-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.rlos .rl-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 12px; }
.rlos .rl-card { background: #fff; border: 1px solid #c9d7e8; border-radius: 4px; overflow: hidden; }
.rlos .rl-card:hover { border-color: #6f9bd8; box-shadow: 0 2px 8px rgba(30,60,110,.15); }
.rlos .rl-box { border: 1px solid #c9d7e8; background: #f6f9fd; border-radius: 4px; padding: 12px 14px; margin: 10px 0; }
.rlos .rl-badge { display: inline-block; font-size: 10.5px; padding: 2px 8px; border-radius: 9px; border: 1px solid #a7c1e0; background: #e8f1fd; color: #24508c; }
.rlos .rl-badge.ok { background: #e3f7e0; border-color: #9fd696; color: #236b1a; }
.rlos .rl-badge.warn { background: #fff4d6; border-color: #e8c76c; color: #7b5600; }
.rlos .rl-badge.bad { background: #fde6e4; border-color: #e6a19a; color: #8e2318; }
.rlos .rl-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 8px; margin: 10px 0; }
.rlos .rl-stats > div { background: linear-gradient(180deg, #fff, #eef4fb); border: 1px solid #c9d7e8; border-bottom: 3px solid #3d7fd6; padding: 10px 12px; border-radius: 3px; }
.rlos .rl-stats b { display: block; font-size: 17px; color: #164a8c; } .rlos .rl-stats small { font-size: 11px; color: #64768b; }
.rlos .rl-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.rlos .rl-table th { text-align: left; background: #ece9d8; border-bottom: 1px solid #aca899; padding: 6px 8px; font-weight: normal; }
.rlos .rl-table td { border-bottom: 1px solid #e3e8ee; padding: 7px 8px; vertical-align: middle; }
.rlos .rl-empty { text-align: center; padding: 36px 12px; color: #5f7186; }
.rlos .rl-empty b { display: block; font-size: 15px; color: #23476f; margin-bottom: 6px; }
.rlos .rl-progress { height: 14px; border: 1px solid #686868; border-radius: 2px; background: #fff; padding: 1px; }
.rlos .rl-progress i { display: block; height: 100%; background: repeating-linear-gradient(90deg, #36c13c 0 8px, #fff 8px 10px); }
.rlos .rl-form { display: grid; gap: 10px; max-width: 760px; }
.rlos .rl-form label { display: grid; gap: 4px; font-size: 12px; color: #2c4a6e; }
.rlos .rl-two { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.rlos .rl-thumb { width: 100%; aspect-ratio: 16/9; object-fit: cover; background: #e7eef6; display: block; }
.rlos .rl-error { color: #b0281a; }
</style>
