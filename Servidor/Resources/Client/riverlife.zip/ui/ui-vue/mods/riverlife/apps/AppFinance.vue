<template>
  <div class="rl-page">
    <h2 class="rl-h1">Extrato RiverLife</h2>
    <div class="rl-stats">
      <div><b>{{ money(rl.view.money) }}</b><small>Saldo da carreira</small></div>
      <div><b>{{ me.sales || 0 }}</b><small>Carros vendidos</small></div>
      <div><b>{{ me.purchases || 0 }}</b><small>Carros comprados</small></div>
      <div><b>{{ money(me.earnings) }}</b><small>Ganhos com negócios</small></div>
      <div><b>★ {{ ((me.reputation || 0) / 20).toFixed(1) }}</b><small>Reputação</small></div>
    </div>
    <h3 class="rl-h2">Movimentações</h3>
    <table v-if="rows.length" class="rl-table">
      <tr><th>Data</th><th>Descrição</th><th class="r">Valor</th><th>Situação</th></tr>
      <tr v-for="r in rows" :key="r.id">
        <td>{{ dateTime(r.at) }}</td><td>{{ r.text }}<br /><small class="rl-muted">{{ r.id }}</small></td>
        <td class="r" :class="r.amount >= 0 ? 'in' : 'out'">{{ (r.amount >= 0 ? "+" : "−") + money(Math.abs(r.amount)) }}</td><td>{{ r.state }}</td>
      </tr>
    </table>
    <p v-else class="rl-muted">Nenhuma movimentação ainda.</p>
    <p class="rl-muted">Carros comprados podem aguardar uma vaga livre na garagem; o recibo continua válido depois de reconectar.</p>
  </div>
</template>

<script setup>
import { computed } from "vue"
import { rl, money, dateTime, me, listingTitle } from "../rl.js"
const rows = computed(() => {
  const out = []
  const id = me.value.id
  for (const r of rl.view.receipts || []) {
    const sold = r.seller === id
    const kind = r.kind === "trade_in" ? "Compra de cliente (troca)" : sold ? "Venda" : "Compra"
    out.push({ id: r.id, at: r.createdAt, text: kind + " · " + (r.title || listingTitle(r.listingId) || r.summary?.niceName || "carro"),
      amount: sold ? r.price - (r.fee || 0) : -r.price,
      state: (!sold && !r.buyerApplied) ? "Entrega pendente" : "Registrado" })
  }
  for (const o of rl.view.orders || []) {
    if (o.status !== "completed") continue
    if (o.shopOwner === id) out.push({ id: o.id, at: o.completedAt, text: "Serviço na oficina · " + (o.vehicle?.niceName || "") + " de " + (o.customerName || ""), amount: (o.paid || 0) - (o.quote?.parts || 0), state: "Recebido" })
    if (o.customer === id) out.push({ id: o.id, at: o.completedAt, text: "Serviço em " + o.shopName + " · " + (o.vehicle?.niceName || ""), amount: -(o.paid || 0), state: o.customerApplied ? "Carro pronto" : "Aplicando" })
  }
  return out.sort((a, b) => (b.at || 0) - (a.at || 0))
})
</script>

<style scoped>
.r { text-align: right; } .in { color: #22801c; font-weight: bold; } .out { color: #b02a1a; }
</style>
