<template>
  <!-- Opened from the desktop: pick a car at this garage and start the RLS maintenance session. -->
  <div v-if="!hosted" class="rl-page">
    <header class="ap-head">
      <span class="ap-tile"><BngIcon type="wrench" /></span>
      <div><h2 class="rl-h1">Manutenção</h2><p class="rl-muted">Óleo, arrefecimento, transmissão e pneus dos carros desta garagem.</p></div>
    </header>
    <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>A manutenção do RLS só funciona em um computador de garagem.</div>
    <div v-else-if="!launchList.length" class="rl-empty"><b>Nenhum veículo nesta garagem</b>Traga o carro até a garagem para fazer a manutenção.</div>
    <table v-else class="rl-table"><tbody>
      <tr><th>Veículo</th><th>Situação</th><th></th></tr>
      <tr v-for="v in launchList" :key="v.inventoryId">
        <td><b>{{ v.name }}</b></td>
        <td><span v-if="!v.fn" class="rl-muted">Modo de manutenção desativado</span>
          <span v-else-if="v.fn.disabled" class="rl-muted">{{ v.fn.reason?.label || "Indisponível agora" }}</span>
          <span v-else class="rl-badge ok">Disponível</span></td>
        <td class="ap-right"><button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button></td>
      </tr>
    </tbody></table>
  </div>

  <div v-else class="mt">
    <div class="mt-main">
      <header class="ap-head">
        <span class="ap-tile"><BngIcon type="wrench" /></span>
        <div>
          <h2 class="rl-h1">{{ vehicleName || "Manutenção" }}</h2>
          <p class="rl-muted">{{ facility }} · Verificar é grátis; os serviços entram no carrinho e são pagos juntos.</p>
        </div>
      </header>

      <div v-if="errorMessage" class="mt-banner" :class="{ busy: checkoutBusy }"><BngIcon :type="checkoutBusy ? 'info' : 'danger'" /> {{ errorMessage }}</div>
      <div v-if="loading" class="rl-empty"><b>Carregando a manutenção...</b>Lendo o estado do veículo.</div>

      <template v-else>
        <section v-for="cat in categories" :key="cat.name" class="mt-cat">
          <button class="mt-cat-head" @click="toggle(cat.name)">
            <BngIcon class="mt-fold" :type="collapsed[cat.name] ? 'plus' : 'minus'" />
            <span class="mt-ico"><BngIcon :type="CAT_ICON[cat.name] || 'cogs'" /></span>
            <span class="mt-cat-title"><b>{{ catLabel(cat) }}</b><small>{{ kmFromMiles(cat.avgMiles) }} rodados (média das peças)</small></span>
            <span class="rl-badge" :class="summary(cat).tone">{{ summary(cat).text }}</span>
          </button>
          <div v-if="!collapsed[cat.name]" class="mt-rows">
            <div v-for="row in arr(cat.rows)" :key="row.category + ':' + row.item" class="mt-row">
              <div class="mt-row-main">
                <b>{{ itemLabel(row) }}</b>
                <div class="mt-level">
                  <div class="mt-bar" :class="row.isRevealed ? tone(row.revealedPercent) : 'unknown'"><i :style="{ width: (row.isRevealed ? clamp(row.revealedPercent) : 0) + '%' }"></i></div>
                  <span :class="'t-' + (row.isRevealed ? tone(row.revealedPercent) : 'unknown')">{{ row.isRevealed ? fmtPct(row.revealedPercent) : "Desconhecido" }}</span>
                </div>
              </div>
              <div class="mt-actions">
                <button class="rl-btn" :disabled="busyKey === key(row, 'check') || checkoutBusy" @click="runCheck(row)">
                  {{ busyKey === key(row, "check") ? "Verificando..." : "Verificar" }}</button>
                <button class="rl-btn mt-svc" :class="{ primary: !inCart(row) && !covered(row), on: inCart(row) }" :disabled="covered(row) || checkoutBusy" @click="toggleService(row)">
                  <template v-if="covered(row)">Incluído</template>
                  <template v-else-if="inCart(row)"><BngIcon type="undo" /> Remover</template>
                  <template v-else>{{ actionLabel(row) }} <span class="mt-price">{{ price(row.servicePrice) }}</span></template>
                </button>
              </div>
            </div>
            <p v-if="!arr(cat.rows).length" class="rl-muted">Nada para manter nesta categoria.</p>
          </div>
        </section>

        <section class="mt-cat">
          <button class="mt-cat-head" @click="toggle('tires')">
            <BngIcon class="mt-fold" :type="collapsed.tires ? 'plus' : 'minus'" />
            <span class="mt-ico"><BngIcon type="tire3Fourth" /></span>
            <span class="mt-cat-title"><b>Pneus</b><small>{{ tireShop?.provider?.name || "Desgaste e temperatura dos pneus" }}</small></span>
            <span class="rl-badge" :class="tireSummary.tone">{{ tireSummary.text }}</span>
          </button>
          <div v-if="!collapsed.tires" class="mt-rows">
            <p v-if="!tireShop?.available" class="rl-muted mt-pad">{{ tr(tireShop?.message) || "Troca de pneus indisponível." }}</p>
            <div v-else-if="!tireShop.inspected" class="mt-pad">
              <button class="rl-btn primary" :disabled="busyKey === 'tires:check' || checkoutBusy" @click="runTireCheck">
                {{ busyKey === "tires:check" ? "Verificando..." : "Verificar todos os pneus — grátis" }}</button>
              <p class="rl-muted">É preciso verificar os pneus antes de trocá-los.</p>
            </div>
            <template v-else>
              <div v-for="axle in arr(tireShop.axles)" :key="axle.id" class="mt-row">
                <div class="mt-row-main">
                  <b>{{ axleLabel(axle.label) }} <small class="rl-muted">· {{ axle.tireName || "Pneu" }} · {{ axle.tireCount }} pneu(s)</small></b>
                  <div class="mt-level">
                    <div class="mt-bar" :class="axle.flat ? 'bad' : tone(axle.remainingPercent)"><i :style="{ width: (axle.flat ? 100 : clamp(axle.remainingPercent)) + '%' }"></i></div>
                    <span :class="'t-' + (axle.flat ? 'bad' : tone(axle.remainingPercent))">{{ axle.flat ? "Furado" : fmtPct(axle.remainingPercent) }}</span>
                  </div>
                  <small class="rl-muted">{{ arr(axle.wheelStates).map(w => w.name + ": " + (w.flat ? "FURADO" : fmtPct(w.remainingPercent))).join(" · ") }}</small>
                </div>
                <div class="mt-actions">
                  <button class="rl-btn mt-svc" :class="{ primary: !tireInCart(axle.id), on: tireInCart(axle.id) }" :disabled="checkoutBusy" @click="toggleTire(axle.id)">
                    <template v-if="tireInCart(axle.id)"><BngIcon type="undo" /> Remover</template>
                    <template v-else>Trocar <span class="mt-price">{{ price(axle.subtotal) }}</span></template>
                  </button>
                </div>
              </div>
              <div class="mt-pad mt-right">
                <button class="rl-btn" :class="{ primary: !allTiresInCart }" :disabled="checkoutBusy || !arr(tireShop.axles).length" @click="toggleAllTires">
                  {{ allTiresInCart ? "Remover todos os pneus" : "Trocar todos — " + price(tireShop.replaceAllSubtotal) }}</button>
              </div>
            </template>
          </div>
        </section>
      </template>
    </div>

    <aside class="mt-cart">
      <h3><BngIcon type="shoppingCart" /> Carrinho</h3>
      <div class="mt-items">
        <p v-if="!cart.items.length" class="rl-muted">Vazio. Escolha os serviços ao lado.</p>
        <div v-for="it in cart.items" :key="it.kind + ':' + (it.axleId || it.category + it.item)" class="mt-item">
          <div><b>{{ it.name }}</b><small v-if="it.extra">{{ it.extra }}</small></div>
          <span>{{ price(it.price) }}</span>
          <button class="mt-x" title="Remover" :disabled="checkoutBusy" @click="removeItem(it)">×</button>
        </div>
      </div>
      <div class="mt-sum">
        <div><span>Total</span><b>{{ price(cart.total) }}</b></div>
        <div><span>Seu saldo</span><b>{{ playerMoney != null ? price(playerMoney) : "—" }}</b></div>
        <div v-if="playerMoney != null && cart.total > 0"><span>Após pagar</span><b :class="{ neg: playerMoney - cart.total < 0 }">{{ price(playerMoney - cart.total) }}</b></div>
      </div>
      <p v-if="cantAfford" class="rl-error">Saldo insuficiente.</p>
      <div v-if="askLeave" class="rl-box mt-confirm">
        <b>Sair da manutenção? O carrinho será esvaziado.</b>
        <div class="rl-row"><button class="rl-btn danger" @click="leave">Sim, sair</button><button class="rl-btn" @click="askLeave = false">Não</button></div>
      </div>
      <div class="mt-buttons">
        <button class="rl-btn go" :disabled="!cart.items.length || checkoutBusy || cantAfford" @click="applyCart">{{ checkoutBusy ? "Pagando..." : "Confirmar" }}</button>
        <button class="rl-btn" :disabled="checkoutBusy" @click="requestClose">Cancelar</button>
      </div>
    </aside>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaString, dollars, arr, toast } from "../rl.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])
const MOD = "career_modules_maintenanceComputer"

const CAT_ICON = { engine: "engine", radiator: "coolantTemp", transmission: "transmissionM" }
const CAT_LABEL = { engine: "Motor", radiator: "Arrefecimento", transmission: "Transmissão" }
const ITEM_LABEL = { oilLevel: "Nível do óleo", oilCondition: "Qualidade do óleo", ignitionService: "Ignição / injetores",
  coolantLevel: "Nível do líquido de arrefecimento", coolantIntegrity: "Qualidade do líquido de arrefecimento",
  fluidLevel: "Nível do fluido da transmissão", fluidCondition: "Qualidade do fluido da transmissão" }
const ACTION_LABEL = { Fill: "Completar", Replace: "Trocar" }
const MESSAGES = {
  "Cart is empty.": "O carrinho está vazio.", "Invalid vehicle.": "Veículo inválido.", "Vehicle not found.": "Veículo não encontrado.",
  "Tire replacement is unavailable.": "Troca de pneus indisponível.", "Check all tires before replacing them.": "Verifique todos os pneus antes de trocá-los.",
  "Tire condition or pricing changed. Review the updated quote.": "O estado ou o preço dos pneus mudou. Confira o orçamento atualizado.",
  "Select at least one axle.": "Escolha pelo menos um eixo.", "Payment failed.": "O pagamento falhou.", "Not enough money.": "Saldo insuficiente.",
  "Maintenance checkout failed; payment was refunded.": "A manutenção falhou; o pagamento foi devolvido.",
  "Failed to complete maintenance checkout.": "Não foi possível concluir a manutenção.", "Maintenance data failed to load.": "Não foi possível carregar a manutenção.",
  "Failed to complete maintenance check.": "Não foi possível concluir a verificação.", "Failed to inspect tires.": "Não foi possível verificar os pneus.",
  "Tire inspection is unavailable.": "Verificação de pneus indisponível.", "Maintenance Mode is not enabled.": "O modo de manutenção está desativado.",
  "Maintenance mode is not enabled.": "O modo de manutenção está desativado.", "Unknown maintenance item.": "Item de manutenção desconhecido.",
  "That system is not installed on this vehicle.": "Este sistema não existe neste veículo.", "Maintenance state unavailable for this item.": "Estado indisponível para este item.",
  "Tire layout is not available yet. Retrieve or respawn this vehicle once.": "Os pneus ainda não foram lidos. Retire (ou recarregue) o veículo uma vez.",
  "The selected external tire provider does not expose the RLS integration API.": "O mod de pneus escolhido não permite a troca pelo RLS.",
  "Tire replacement failed; payment was refunded.": "A troca de pneus falhou; o pagamento foi devolvido.",
}

const hosted = computed(() => !!props.route)
const uiData = ref({ facilityName: "", vehicle: null, categories: [], tireShop: null, playerMoney: null })
const loading = ref(true)
const errorMessage = ref("")
const busyKey = ref("")
const checkoutBusy = ref(false)
const askLeave = ref(false)
const collapsed = reactive({})
const cartServices = ref([])
const cartTireAxles = ref([])
let refreshing = false
let alive = true

function tr(m) { return m ? (MESSAGES[m] || m) : "" }
function clamp(p) { return Math.max(0, Math.min(100, Number(p) || 0)) }
function fmtPct(p) { return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 }).format(Number(p) || 0) + "%" }
function price(v) { return dollars(Math.max(0, Math.round(Number(v) || 0))) }
function kmFromMiles(mi) { return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format((Number(mi) || 0) * 1.609344) + " km" }
function tone(p) { if (p == null) return "unknown"; const n = Number(p); return n <= 25 ? "bad" : n <= 50 ? "warn" : "ok" }
function toggle(k) { collapsed[k] = !collapsed[k] }
function catLabel(cat) { return CAT_LABEL[cat.name] || cat.label || cat.name }
function itemLabel(row) { return ITEM_LABEL[row.item] || row.label || row.item }
function actionLabel(row) { return ACTION_LABEL[row.actionLabel] || row.actionLabel || "Fazer" }
function axleLabel(l) {
  const m = /^(Front|Rear) Axle(?: (\d+))?$/.exec(String(l || ""))
  if (!m) return l || "Eixo"
  return (m[1] === "Front" ? "Eixo dianteiro" : "Eixo traseiro") + (m[2] ? " " + m[2] : "")
}
function parseMoney(v) {
  if (v && typeof v === "object") v = v.value
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

const vehicleName = computed(() => uiData.value.vehicle?.niceName || uiData.value.vehicle?.name || "")
const facility = computed(() => uiData.value.facilityName && uiData.value.facilityName !== "Maintenance" ? uiData.value.facilityName : "Oficina da garagem")
const categories = computed(() => arr(uiData.value.categories))
const tireShop = computed(() => uiData.value.tireShop || null)
const playerMoney = computed(() => parseMoney(uiData.value.playerMoney))

function summary(cat) {
  const rows = arr(cat.rows)
  const revealed = rows.filter(r => r.isRevealed)
  if (!revealed.length) return { text: "Não verificado", tone: "" }
  const worst = Math.min(...revealed.map(r => Number(r.revealedPercent) || 0))
  const unknown = rows.length - revealed.length
  return { text: fmtPct(worst) + (unknown ? " · " + unknown + " desconhecido(s)" : ""), tone: badgeTone(tone(worst)) }
}
function badgeTone(t) { return t === "bad" ? "bad" : t === "warn" ? "warn" : t === "ok" ? "ok" : "" }
const tireSummary = computed(() => {
  const shop = tireShop.value
  if (!shop?.available) return { text: "Indisponível", tone: "" }
  if (!shop.inspected) return { text: "Não verificado", tone: "" }
  const axles = arr(shop.axles)
  if (axles.some(a => a.flat)) return { text: "Furado", tone: "bad" }
  if (!axles.length) return { text: "Verificado", tone: "ok" }
  const worst = Math.min(...axles.map(a => Number(a.remainingPercent) || 0))
  return { text: fmtPct(worst), tone: badgeTone(tone(worst)) }
})

// Cart (same rules as the RLS screen: a "replace" that fills another item makes that item "Incluído").
function findRow(category, item) {
  for (const cat of categories.value) for (const row of arr(cat.rows)) if (row.category === category && row.item === item) return row
  return null
}
function findAxle(id) { return arr(tireShop.value?.axles).find(a => a.id === id) }
function inCart(row) { return cartServices.value.some(e => e.category === row.category && e.item === row.item) }
function covered(row) {
  return cartServices.value.some(e => {
    const r = findRow(e.category, e.item)
    return r && r.category === row.category && r.fillsItem === row.item
  })
}
function tireInCart(id) { return cartTireAxles.value.includes(id) }
const allTiresInCart = computed(() => {
  const axles = arr(tireShop.value?.axles)
  return axles.length > 0 && axles.every(a => tireInCart(a.id))
})
function pruneCart() {
  cartServices.value = cartServices.value.filter(e => findRow(e.category, e.item))
  cartTireAxles.value = cartTireAxles.value.filter(id => !!findAxle(id))
}
const cart = computed(() => {
  const items = []
  let total = 0
  for (const e of cartServices.value) {
    const row = findRow(e.category, e.item)
    if (!row || covered(row)) continue
    const p = Number(row.servicePrice) || 0
    const cat = categories.value.find(c => c.name === row.category)
    items.push({ kind: "service", category: row.category, item: row.item, name: actionLabel(row) + ": " + itemLabel(row), extra: cat ? catLabel(cat) : "", price: p })
    total += p
  }
  for (const id of cartTireAxles.value) {
    const axle = findAxle(id)
    if (!axle) continue
    const p = Number(axle.subtotal) || 0
    items.push({ kind: "tire", axleId: id, name: "Trocar pneus: " + axleLabel(axle.label), extra: (axle.tireName || "Pneu") + " · " + axle.tireCount + " pneu(s)", price: p })
    total += p
  }
  return { items, total }
})
const cantAfford = computed(() => cart.value.total > 0 && playerMoney.value != null && cart.value.total > playerMoney.value)

function toggleService(row) {
  if (covered(row)) return
  if (inCart(row)) {
    cartServices.value = cartServices.value.filter(e => !(e.category === row.category && e.item === row.item))
    return
  }
  if (row.fillsItem) cartServices.value = cartServices.value.filter(e => !(e.category === row.category && e.item === row.fillsItem))
  cartServices.value = [...cartServices.value, { category: row.category, item: row.item }]
}
function toggleTire(id) {
  cartTireAxles.value = tireInCart(id) ? cartTireAxles.value.filter(x => x !== id) : [...cartTireAxles.value, id]
}
function toggleAllTires() {
  cartTireAxles.value = allTiresInCart.value ? [] : arr(tireShop.value?.axles).map(a => a.id)
}
function removeItem(it) {
  if (it.kind === "tire") return toggleTire(it.axleId)
  const row = findRow(it.category, it.item)
  if (row) toggleService(row)
}
function key(row, action) { return row.category + ":" + row.item + ":" + action }

// Lua
async function requestData() {
  if (refreshing) return
  refreshing = true
  try {
    const result = await luaCall(MOD + ".getMaintenanceUiData()")
    if (!result) { errorMessage.value = "Não foi possível carregar a manutenção."; return }
    if (result.errorMessage) { errorMessage.value = tr(result.errorMessage); return }
    if (!result.enabled || !result.vehicle) { await close(); return }
    let money = parseMoney(result.playerMoney)
    if (money == null) money = parseMoney(await luaCall("career_modules_playerAttributes.getAttributeValue('money')"))
    uiData.value = { ...result, playerMoney: money }
    emit("title", result.vehicle?.niceName || "")
    pruneCart()
    if (!checkoutBusy.value) errorMessage.value = ""
  } finally {
    loading.value = false
    refreshing = false
  }
}
async function runCheck(row) {
  busyKey.value = key(row, "check")
  try {
    const r = await luaCall(MOD + ".startCheck(" + Number(uiData.value.inventoryId) + ", " + luaString(row.category) + ", " + luaString(row.item) + ")")
    if (!r?.ok) { errorMessage.value = tr(r?.message) || "Não foi possível concluir a verificação."; return }
    await requestData()
  } finally { busyKey.value = "" }
}
async function runTireCheck() {
  busyKey.value = "tires:check"
  try {
    const r = await luaCall(MOD + ".inspectTires(" + Number(uiData.value.inventoryId) + ")")
    if (!r?.ok) { errorMessage.value = tr(r?.message) || "Não foi possível verificar os pneus."; return }
    await requestData()
  } finally { busyKey.value = "" }
}
async function applyCart() {
  if (!cart.value.items.length || checkoutBusy.value || cantAfford.value) return
  checkoutBusy.value = true
  errorMessage.value = "Fechando a conta..."
  try {
    const payload = JSON.stringify({
      services: cartServices.value.map(e => ({ category: e.category, item: e.item })),
      tireAxleIds: [...cartTireAxles.value],
      quoteRevision: tireShop.value?.quoteRevision || "",
    })
    const result = await Promise.race([
      luaCall(MOD + ".checkoutCart(" + Number(uiData.value.inventoryId) + ", " + luaString(payload) + ")"),
      new Promise(resolve => setTimeout(() => resolve({ ok: false, message: "A manutenção demorou demais para responder." }), 15000)),
    ])
    if (!result || result.ok === false || result.staleQuote) {
      errorMessage.value = tr(result?.message) || "Não foi possível concluir a manutenção."
      if (result?.staleQuote) await requestData()
      return
    }
    errorMessage.value = ""
    toast("Manutenção concluída: " + price(result.price ?? cart.value.total) + ".")
    cartServices.value = []
    cartTireAxles.value = []
    // RLS closes the menu itself after a successful checkout; same fallback as the RLS screen.
    backToComputer()
  } finally { checkoutBusy.value = false }
}
function backToComputer() {
  setTimeout(() => { if (alive) luaCall("extensions.ui_router.navigate('career.computer')") }, 700)
}
async function close() {
  await luaCall(MOD + ".closeMenu()")
  backToComputer()
}
function leave() {
  askLeave.value = false
  cartServices.value = []
  cartTireAxles.value = []
  close()
}

// Launcher
const launchList = computed(() => {
  const c = rl.view.computer
  if (!c) return []
  return arr(c.vehicles).map(v => ({
    inventoryId: v.inventoryId, name: v.vehicleName || v.niceName || "Veículo",
    fn: c.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.maintenance || null,
  }))
})
function launch(v) { request("native", { buttonId: "maintenance", inventoryId: v.inventoryId }) }

function requestClose() {
  if (!hosted.value) { emit("close"); return }
  if (checkoutBusy.value) return
  if (cart.value.items.length) { askLeave.value = true; return }
  close()
}
defineExpose({ requestClose })

onMounted(() => { if (hosted.value) requestData(); else loading.value = false })
onUnmounted(() => { alive = false })
</script>

<style scoped>
.ap-head { display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }
.ap-head .rl-h1 { margin: 0; }
.ap-head p { margin: 2px 0 0; }
.ap-tile { width: 44px; height: 44px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #fff;
  background: linear-gradient(135deg, #9aa7b8, #3c4b60); box-shadow: 0 2px 4px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.45); flex-shrink: 0; }
.ap-right { text-align: right; }
.mt { display: flex; height: 100%; min-height: 420px; }
.mt-main { flex: 1; min-width: 0; padding: 14px 18px; overflow: auto; }
.mt-banner { display: flex; gap: 6px; align-items: center; padding: 7px 10px; margin: 6px 0 10px; border: 1px solid #e6a19a; background: #fde6e4; color: #8e2318; border-radius: 3px; }
.mt-banner.busy { border-color: #a7c1e0; background: #e8f1fd; color: #24508c; }
.mt-cat { margin: 8px 0; border: 1px solid #b9c7d8; border-radius: 4px; background: #fff; overflow: hidden; }
.mt-cat-head { width: 100%; display: flex; gap: 10px; align-items: center; padding: 7px 10px; border: 0; border-bottom: 1px solid #d0dae6; cursor: pointer; text-align: left;
  background: linear-gradient(180deg, #f7f9fc, #e3eaf4); font: 12.5px Tahoma, sans-serif; color: #1b3355; }
.mt-fold { color: #4b5d73; }
.mt-ico { width: 30px; height: 30px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 19px; color: #fff;
  background: linear-gradient(135deg, #7fa7d8, #2c5aa0); flex-shrink: 0; }
.mt-cat-title { flex: 1; display: grid; }
.mt-cat-title b { font-size: 13.5px; }
.mt-cat-title small { color: #64768b; font-size: 11px; }
.mt-rows { padding: 2px 10px 6px; }
.mt-row { display: flex; gap: 12px; align-items: center; padding: 8px 2px; border-bottom: 1px dotted #dfe4ea; }
.mt-row:last-child { border-bottom: 0; }
.mt-row-main { flex: 1; min-width: 0; display: grid; gap: 4px; }
.mt-level { display: flex; gap: 8px; align-items: center; }
.mt-bar { width: 180px; height: 10px; border: 1px solid #8f9aa6; border-radius: 2px; background: #fff; padding: 1px; }
.mt-bar i { display: block; height: 100%; background: #36c13c; }
.mt-bar.warn i { background: #e8b42a; } .mt-bar.bad i { background: #d9452f; } .mt-bar.unknown { background: repeating-linear-gradient(45deg, #f1f1f1 0 4px, #e2e2e2 4px 8px); }
.t-ok { color: #236b1a; font-weight: bold; } .t-warn { color: #8a5a00; font-weight: bold; } .t-bad { color: #b0281a; font-weight: bold; } .t-unknown { color: #7a8796; }
.mt-actions { display: flex; gap: 6px; flex-shrink: 0; }
.mt-svc { min-width: 128px; display: inline-flex; gap: 6px; align-items: center; justify-content: center; }
.mt-svc.on { color: #7a1212; border-color: #7a1212; background: linear-gradient(180deg, #fff, #f7dcd8); }
.mt-price { font-weight: normal; opacity: .9; }
.mt-pad { padding: 8px 2px; }
.mt-right { text-align: right; }
.mt-cart { width: 290px; flex-shrink: 0; display: flex; flex-direction: column; gap: 8px; padding: 12px; background: #ece9d8; border-left: 1px solid #aca899; overflow: auto; }
.mt-cart h3 { margin: 0; display: flex; gap: 6px; align-items: center; font-size: 14px; color: #1d3f69; }
.mt-items { flex: 1; min-height: 80px; overflow: auto; background: #fff; border: 1px solid #7f9db9; padding: 6px; }
.mt-item { display: flex; gap: 6px; align-items: flex-start; padding: 5px 2px; border-bottom: 1px dotted #e0e5eb; font-size: 12px; }
.mt-item > div { flex: 1; display: grid; }
.mt-item small { color: #64768b; font-size: 11px; }
.mt-x { border: 1px solid #b6b6b6; background: #fff; border-radius: 2px; width: 18px; height: 18px; line-height: 14px; padding: 0; cursor: pointer; color: #8e2318; font-weight: bold; }
.mt-x:hover:not(:disabled) { border-color: #c62d1f; }
.mt-sum { display: grid; gap: 3px; padding: 6px 2px; border-top: 1px solid #aca899; }
.mt-sum > div { display: flex; justify-content: space-between; font-size: 12.5px; }
.mt-sum > div:first-child b { font-size: 16px; color: #12407c; }
.mt-sum .neg { color: #b0281a; }
.mt-confirm { display: grid; gap: 8px; margin: 0; }
.mt-buttons { display: grid; gap: 6px; }
.mt-buttons .rl-btn { padding: 8px 12px; }
</style>
