// RiverLife UI entry point. Original code.
// Replaces the RLS computer screen with the RiverOS desktop (same route name, so
// RLS and the game keep opening "career.computer" as usual), adds the RiverLife
// phone app to the RLS phone, and opens the app when Lua asks for it.
import { defineAsyncComponent, defineComponent, h, markRaw } from "vue"
import { lua, useBridge } from "@/bridge"
import RiverDesktop from "./RiverDesktop.vue"
import RiverPhone from "./RiverPhone.vue"
import { wire } from "./rl.js"

const SOURCE = "riverlife.routes"
const NATIVE_SOURCE = "riverlife.native"
// RLS computer screens are sibling routes of the computer; each one is re-registered
// under the same name and path with a host that draws the RiverOS desktop around it,
// so they open inside a RiverOS window instead of replacing the computer screen.
const NATIVE_TITLES = {
  "career.computer.vehicleInventory": "Meus veículos (RLS)", "career.computer.vehicleShopping.vehicleInventory": "Meus veículos (RLS)",
  "career.computer.painting": "Pintura", "career.computer.tuning": "Tuning", "career.computer.repair": "Reparos e seguro",
  "career.computer.partShopping": "Peças e personalização", "career.computer.partShopping.category": "Peças e personalização",
  "career.computer.partShopping.category.slot": "Peças e personalização", "career.computer.partInventory": "Minhas peças",
  "career.computer.enginePackages": "Pacotes de motor", "career.computer.vehicleShopping": "Concessionárias e marketplace",
  "career.computer.vehicleShopping.vehicles": "Concessionárias e marketplace",
  "career.computer.vehicleShopping.vehicles.vehiclePurchase": "Compra de veículo", "career.computer.insurances": "Seguros",
  "career.computer.vehiclePerformance": "Certificação de desempenho", "career.computer.vehiclePerformance.certificationTest": "Teste de certificação",
  "career.computer.playerAbstract": "Resumo da carreira", "loans-menu": "Empréstimos", "sleep-menu": "Dormir", "maintenance": "Manutenção",
}
const NATIVE_EXTRA = ["loans-menu", "sleep-menu", "maintenance"]
// Every RLS computer screen is rebuilt as a RiverOS app; an unknown screen (e.g. from another mod)
// falls back to the original inside a window.
const NATIVE_APPS = {
  "career.computer.vehicleInventory": "garage", "career.computer.vehicleShopping.vehicleInventory": "garage",
  "career.computer.vehicleShopping": "dealer", "career.computer.vehicleShopping.vehicles": "dealer",
  "career.computer.vehicleShopping.vehicles.vehiclePurchase": "dealer",
  "career.computer.painting": "paint", "career.computer.tuning": "tuning",
  "career.computer.partShopping": "parts", "career.computer.partShopping.category": "parts", "career.computer.partShopping.category.slot": "parts",
  "career.computer.partInventory": "myparts", "career.computer.repair": "repair", "career.computer.insurances": "insurance",
  "loans-menu": "loans", "sleep-menu": "sleep", "maintenance": "maintenance", "career.computer.enginePackages": "engine",
  "career.computer.vehiclePerformance": "performance", "career.computer.vehiclePerformance.certificationTest": "perftest",
  "career.computer.playerAbstract": "abstract",
}
const SKIP = ["career.computer", "career.computer.loading"]

function lazyLoader(c) { return typeof c === "function" && !c.__vccOpts && !c.render && !c.setup && !c.displayName }
function hostFor(original, title, name) {
  return defineComponent({
    name: "RiverNativeHost",
    inheritAttrs: false,
    setup(_, { attrs }) {
      return () => h(RiverDesktop, { nativeView: { component: original, attrs: { ...attrs }, title, name, app: NATIVE_APPS[name] } })
    },
  })
}
// The original RLS records are kept on window so a mod reload can rebuild (or restore) them.
function originals() {
  const cache = window.__riverNativeOriginals || (window.__riverNativeOriginals = {})
  for (const r of window.vueRouter.getRoutes()) {
    const name = typeof r.name === "string" ? r.name : ""
    if (!name || SKIP.includes(name) || r.meta?.riverHosted) continue
    if (!name.startsWith("career.computer.") && !NATIVE_EXTRA.includes(name)) continue
    if (!r.components?.default) continue
    cache[name] = { path: r.path, name, component: r.components.default, props: r.props?.default ?? false, meta: r.meta || {} }
  }
  return cache
}
function nativeRoutes() {
  return Object.values(originals()).map(o => {
    const comp = lazyLoader(o.component) ? defineAsyncComponent(o.component) : o.component
    const title = NATIVE_TITLES[o.name] || o.meta?.luaRoute?.title || "Serviço RLS"
    return { path: o.path, name: o.name, component: hostFor(markRaw(comp), title, o.name), props: o.props,
      // Our apps load their own data, so the router gets its mount ack as soon as the host is up.
      meta: { ...o.meta, handlesOwnReady: false, riverHosted: true, infoBar: { visible: false }, topBar: { visible: false }, uiApps: { shown: false } } }
  })
}
function restoreNativeScreens() {
  for (const o of Object.values(window.__riverNativeOriginals || {})) {
    try { window.vueRouter.addRoute({ path: o.path, name: o.name, component: o.component, props: o.props, meta: o.meta }) } catch (err) { /* ignore */ }
  }
}
function hostNativeScreens() {
  try {
    const routes = nativeRoutes()
    if (routes.length) window.bngRoutes.add([{ path: NATIVE_SOURCE, routes }])
    console.log("[riverlife] " + routes.length + " telas do RLS dentro do RiverOS")
  } catch (err) {
    console.warn("[riverlife] RLS screens keep their own layout", err)
  }
}
const PHONE_PATH = "/career/phone-riverlife"
const routes = [
  { path: "/career/computer", name: "career.computer", component: RiverDesktop, props: true,
    meta: { infoBar: { visible: false }, uiApps: { shown: false }, topBar: { visible: false } } },
  { path: PHONE_PATH, name: "phone-riverlife", component: RiverPhone, meta: { uiApps: { shown: false } } },
]
const MANIFEST = {
  id: "riverlife", name: "RiverLife", icon: "carDealer", route: PHONE_PATH, color: "#13897a", iconColor: "#ffffff",
  category: "Negócios", storeTagline: "Classificados, lojas, oficinas e jogadores",
  storeDescription: "Anuncie seu carro com fotos, marque visitas, negocie no local, abra sua loja de carros ou sua oficina e veja quem está online.",
  defaultPage: 0, defaultPosition: 3,
}

let handler
function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

async function waitForApp(timeoutMs = 60000) {
  const start = Date.now()
  while (Date.now() - start < timeoutMs) {
    if (window.bngRoutes && window.vueRouter) return true
    await sleep(100)
  }
  return false
}

// RLS builds its phone catalogue from a static list; add RiverLife to the same array.
async function addPhoneApp() {
  try {
    const registry = await import("@/modules/career/utils/phoneAppRegistry.js")
    const { APP_DEFINITIONS } = registry.usePhoneApps()
    if (Array.isArray(APP_DEFINITIONS) && !APP_DEFINITIONS.some(a => a.id === MANIFEST.id)) {
      APP_DEFINITIONS.push({ ...MANIFEST, systemApp: false, hideFromStore: false })
    }
  } catch (err) {
    console.warn("[riverlife] RLS phone not available; RiverLife opens with its own shortcut", err)
  }
}

function openPhone(p) {
  const router = window.vueRouter
  if (!router) return
  const current = router.currentRoute?.value
  // Inside the computer the desktop handles the request itself.
  if (current?.name === "career.computer") return
  const query = {}
  if (p?.app) query.app = p.app
  if (p?.focus) query.focus = p.focus
  sessionStorage.setItem("phoneVisible", "true")
  router.push({ path: PHONE_PATH, query }).catch(() => {})
}

export async function onLoad() {
  if (!(await waitForApp())) { console.error("[riverlife] Vue router unavailable"); return }
  window.bngRoutes.add([{ path: SOURCE, routes }])
  // RLS registers some screens after us; give it a moment, then wrap them.
  setTimeout(hostNativeScreens, 1500)
  try {
    await lua.extensions.ui_router_routeManager.registerModRoutes(SOURCE + ".lua", [
      { name: "phone-riverlife", path: PHONE_PATH, meta: { uiApps: { shown: false } } },
    ])
  } catch (err) {
    console.warn("[riverlife] Lua route registration skipped", err)
  }
  await addPhoneApp()
  wire()
  const { events } = useBridge()
  handler = p => { if (p?.open && p.phone !== false) openPhone(p) }
  events.on("RiverLifeOpenPhone", handler)
  console.log("[riverlife] RiverOS e app RiverLife prontos")
}

export async function onUnload() {
  const { events } = useBridge()
  if (handler) events.off("RiverLifeOpenPhone", handler)
  if (window.bngRoutes) window.bngRoutes.remove([SOURCE, NATIVE_SOURCE])
  if (window.vueRouter) restoreNativeScreens()
  try { await lua.extensions.ui_router_routeManager.unregisterModRoutes(SOURCE + ".lua", { fallbackRoute: "menu" }) } catch (err) { /* ignore */ }
}
