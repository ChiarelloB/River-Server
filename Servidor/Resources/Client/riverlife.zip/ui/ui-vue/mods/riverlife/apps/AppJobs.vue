<template>
  <div class="rl-page jobs">
    <nav class="rl-tabs">
      <button v-for="t in TABS" :key="t.id" :class="{ on: tab === t.id }" @click="tab = t.id">{{ t.label }}</button>
    </nav>

    <section v-if="tab === 'gigs'">
      <article v-if="current" class="rl-box current">
        <div class="rl-row between">
          <b><BngIcon :type="current.kind === 'vistoria' ? 'search' : 'steeringWheelCommon'" /> {{ current.title }}</b>
          <span class="rl-badge warn">Em andamento</span>
        </div>
        <template v-if="current.kind === 'translado'">
          <p>Cliente: {{ current.client }}. Pegue o carro no ponto de partida e estacione no destino. Avarias descontam do pagamento
            e atrasos pagam 70%.</p>
          <p class="rl-muted">Distância {{ distanceText(current.distance) }} · prazo {{ deadline(current) }} · paga até <b>{{ money(current.pay) }}</b></p>
          <div class="rl-row">
            <button class="rl-btn" @click="request('gpsTo', current.from)">GPS da retirada</button>
            <button class="rl-btn" @click="request('gpsTo', current.to)">GPS do destino</button>
            <button class="rl-btn danger" :disabled="rl.busy.gigAbandon" @click="ask('Desistir deste bico? Ele volta para a lista e você não recebe nada.', () => request('gigAbandon', { gigId: current.id }), 'Desistir')">Desistir</button>
          </div>
        </template>
        <template v-else>
          <p>Vá até o carro anunciado e chegue perto dele: a vistoria é feita na hora e o laudo vai para o anúncio.</p>
          <p class="rl-muted">Paga <b>{{ money(current.pay) }}</b> · a {{ distanceText(distance(rl.view.position, current.to)) }}</p>
          <div class="rl-row">
            <button class="rl-btn" @click="request('gpsTo', current.to)">GPS do carro</button>
            <button class="rl-btn danger" :disabled="rl.busy.gigAbandon" @click="ask('Desistir deste bico? Ele volta para a lista e você não recebe nada.', () => request('gigAbandon', { gigId: current.id }), 'Desistir')">Desistir</button>
          </div>
        </template>
      </article>

      <h3 class="rl-h2">Bicos disponíveis</h3>
      <p class="rl-muted small">Novos pedidos aparecem a cada poucos minutos. Translado: leve o carro de um cliente de um ponto a outro.
        Vistoria: confira um carro anunciado e emita o laudo.</p>
      <div v-if="!gigs.length" class="rl-muted">Nenhum bico agora. Volte daqui a pouco.</div>
      <article v-for="g in gigs" :key="g.id" class="rl-box gig">
        <div class="rl-row between">
          <b><BngIcon :type="g.kind === 'vistoria' ? 'search' : 'steeringWheelCommon'" /> {{ g.title }}</b>
          <b class="pay">{{ money(g.pay) }}</b>
        </div>
        <p class="rl-muted" v-if="g.kind === 'translado'">De um ponto a {{ distanceText(distance(rl.view.position, g.from)) }} de você,
          {{ distanceText(g.distance) }} de viagem · cliente {{ g.client }} · expira em {{ expires(g) }}</p>
        <p class="rl-muted" v-else>Carro a {{ distanceText(distance(rl.view.position, g.to)) }} · pedido por {{ g.clientName || "vendedor" }}</p>
        <button class="rl-btn primary" :disabled="!!current || rl.busy.gigTake" @click="request('gigTake', { gigId: g.id })">Pegar bico</button>
      </article>
    </section>

    <section v-else-if="tab === 'vacancies'">
      <h3 class="rl-h2">Vagas em lojas e oficinas</h3>
      <div v-if="!vacancies.length" class="rl-muted">Nenhuma vaga aberta. Donos de lojas e oficinas publicam vagas no app deles.</div>
      <article v-for="v in vacancies" :key="v.id" class="rl-box">
        <div class="rl-row between"><b>{{ v.label }} — {{ v.businessName }}</b><span class="rl-badge">{{ v.commission }}% de comissão</span></div>
        <p class="rl-muted">Dono(a): {{ v.ownerName }} · {{ v.wage ? money(v.wage) + " por dia" : "sem salário fixo" }} ·
          a {{ distanceText(distance(rl.view.position, v.position)) }}</p>
        <p v-if="v.note">"{{ v.note }}"</p>
        <div class="rl-row">
          <button class="rl-btn primary" :disabled="v.owner === me.id || rl.busy.applyVacancy" @click="request('applyVacancy', { vacancyId: v.id })">Aceitar a vaga</button>
          <button class="rl-btn" @click="request('gps', { position: v.position })">GPS</button>
        </div>
      </article>
    </section>

    <section v-else-if="tab === 'work'">
      <h3 class="rl-h2">Onde você trabalha</h3>
      <div v-if="!jobs.length" class="rl-muted">Você não trabalha para ninguém. Veja as vagas abertas.</div>
      <article v-for="j in jobs" :key="j.businessId" class="rl-box">
        <div class="rl-row between"><b>{{ ROLES[j.role] }} em {{ j.name }}</b>
          <button class="rl-btn" :disabled="rl.busy.quitJob" @click="ask('Pedir demissão deste emprego?', () => request('quitJob', { businessId: j.businessId }), 'Pedir demissão')">Pedir demissão</button></div>
        <p class="rl-muted" v-if="j.role === 'vendedor'">Propostas dos clientes da loja aparecem na sua Agenda. Você responde em nome da loja
          e ganha a comissão de cada venda que fechar.</p>
        <p class="rl-muted" v-else>Os pedidos da oficina aparecem em Minha oficina. Você pode orçar e começar serviços; a comissão sai da mão de obra.</p>
        <button class="rl-btn primary" @click="$emit('open', j.role === 'vendedor' ? 'agenda' : 'workshop')">Abrir {{ j.role === "vendedor" ? "Agenda" : "Oficina" }}</button>
      </article>
    </section>

    <section v-else>
      <h3 class="rl-h2">Carteira de trabalho</h3>
      <div class="profs">
        <article v-for="(p, key) in PROFESSIONS" :key="key" class="rl-box prof">
          <BngIcon :type="p.icon" class="pi" />
          <div><b>{{ p.label }}</b>
            <small>Nível {{ prof(key).level || 0 }} · {{ prof(key).done || 0 }} trabalho(s) · {{ money(prof(key).earned) }}</small>
            <div class="rl-progress"><i :style="{ width: nextLevel(key) + '%' }"></i></div></div>
        </article>
      </div>
      <p class="rl-muted small">Cada nível de translado aumenta 5% o pagamento dos próximos. Reputação: {{ me.reputation || 0 }}/100.</p>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, money, distance, distanceText, me, myGig, openGigs, ROLES, PROFESSIONS, ask } from "../rl.js"

const props = defineProps({ start: String, nonce: Number })
defineEmits(["open"])
const TABS = [
  { id: "gigs", label: "Bicos" }, { id: "vacancies", label: "Vagas" }, { id: "work", label: "Meu trabalho" }, { id: "card", label: "Carteira" },
]
const tab = ref(props.start || "gigs")
const now = ref(Date.now() / 1000)
let ticker
watch(() => [props.start, props.nonce], () => { if (props.start) tab.value = props.start })

const current = computed(() => myGig.value)
const gigs = computed(() => openGigs.value.slice().sort((a, b) => distance(rl.view.position, a.from || a.to) - distance(rl.view.position, b.from || b.to)))
const vacancies = computed(() => rl.view.vacancies || [])
const jobs = computed(() => rl.view.jobs || [])
function prof(key) { return (me.value.prof || {})[key] || {} }
function nextLevel(key) {
  const p = prof(key), lvl = p.level || 0, done = p.done || 0
  const a = lvl * lvl, b = (lvl + 1) * (lvl + 1)
  return Math.round(Math.min(100, ((done - a) / Math.max(1, b - a)) * 100))
}
function expires(g) { const s = Math.max(0, Math.round(g.expiresAt - now.value)); return Math.floor(s / 60) + " min" }
function deadline(g) {
  if (!g.deadline) return "—"
  const s = Math.round(g.deadline - now.value)
  return s > 0 ? Math.floor(s / 60) + " min" : "atrasado"
}
onMounted(() => { ticker = setInterval(() => { now.value = Date.now() / 1000 }, 1000) })
onUnmounted(() => clearInterval(ticker))
</script>

<style scoped>
.between { justify-content: space-between; }
.small { font-size: 11.5px; }
.current { border-color: #e8c35a; background: #fff9e3; }
.pay { color: #1d7a2c; font-size: 15px; }
.gig b :deep(.bng-icon), .current b :deep(.bng-icon) { margin-right: 4px; }
.profs { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 8px; }
.prof { display: flex; gap: 10px; align-items: center; }
.prof .pi { font-size: 30px; color: #2d6ad6; }
.prof small { display: block; color: #556; margin: 2px 0 4px; }
</style>
