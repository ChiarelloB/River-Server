<template>
  <div class="rl-page sell">
    <h2 class="rl-h1">Anunciar um carro</h2>
    <div class="modes">
      <button type="button" class="mode" :class="{ on: draft.mode === 'visit' }" @click="draft.mode = 'visit'">
        <b>Anúncio com visita</b><small>Você tira as fotos, o comprador marca a visita e vocês negociam no local.</small></button>
      <button type="button" class="mode" :class="{ on: draft.mode === 'street' }" @click="draft.mode = 'street'">
        <b>Vende-se na rua</b><small>O carro fica estacionado aqui com a placa. Quem passar faz proposta e o RiverLife responde por você,
          até o seu preço mínimo — e ele pode vender mesmo com você desconectado.</small></button>
    </div>
    <p class="rl-muted">{{ draft.mode === "street" ? "Estacione o carro num lugar aberto e visível (fora da garagem e da pista) e fique perto dele para publicar. As fotos são tiradas sozinhas."
      : "O anúncio fica no local onde você está agora: é ali que o comprador vem ver o carro. Tire as fotos com o carro estacionado." }}
      Peças, pintura, quilometragem e danos acompanham a venda.</p>
    <form class="rl-form" @submit.prevent="publish">
      <label>Veículo da garagem
        <XPSelect v-model="draft.inventoryId" placeholder="Escolha um carro" :options="garage.map(v => ({ value: v.inventoryId, disabled: v.locked || !!v.timeToAccess,
          label: v.niceName + (v.locked ? ' · já anunciado' : v.timeToAccess ? ' · indisponível' : '') }))" />
      </label>
      <div v-if="chosen" class="rl-box chosen">
        <img :src="chosen.thumbnail" alt="" />
        <div>
          <b>{{ chosen.niceName }}</b>
          <p class="rl-muted">{{ km(chosen.mileage) }} · valor de tabela {{ money(chosen.value) }}{{ chosen.needsRepair ? " · precisa de reparo (" + money(chosen.repairCost) + ")" : "" }}</p>
          <p v-if="!chosen.spawned" class="rl-error">O carro está guardado. Traga-o para perto para fotografar e anunciar.</p>
          <p v-else class="rl-muted">Distância até você: {{ distanceText(distance(rl.view.position, chosen.position)) }}</p>
          <button v-if="!chosen.spawned" type="button" class="rl-btn" @click="request('spawn', { inventoryId: chosen.inventoryId })">Trazer o carro</button>
        </div>
      </div>
      <label>Título<input v-model.trim="draft.title" class="rl-input" maxlength="100" required placeholder="Ex.: Civic revisado, pneus novos" /></label>
      <div class="rl-two">
        <label>Preço ($)<input v-model.number="draft.price" class="rl-input" type="number" min="1" max="5000000" step="1" required /></label>
        <label v-if="draft.mode === 'street'">Preço mínimo ($)
          <input v-model.number="draft.minimum" class="rl-input" type="number" :min="Math.ceil((draft.price || 0) / 2)" :max="draft.price" required /></label>
        <label v-else>Vender por
          <XPSelect v-model="draft.storeId" :options="[{ value: '', label: 'Particular' }, ...(myStore ? [{ value: myStore.id, label: myStore.name + ' (estoque da loja)' }] : [])]" />
        </label>
      </div>
      <p v-if="chosen && chosen.value" class="rl-muted">Sugestão pelo valor de tabela: {{ money(chosen.value * 0.95) }} a {{ money(chosen.value * 1.1) }}.
        <a href="#" @click.prevent="draft.price = Math.round(chosen.value / 100)">Usar valor de tabela</a></p>
      <p v-if="draft.mode === 'street'" class="rl-muted">Propostas a partir de {{ money((draft.minimum || 0) * 100) }} fecham na hora; abaixo disso o
        carro faz uma contraproposta. Até 2 carros na rua por vez; o anúncio dura 3 dias e depois o carro volta para você no mesmo lugar.</p>
      <p v-if="draft.storeId && draft.mode !== 'street'" class="rl-muted">No estoque da loja: compradores NPC visitam durante o horário de funcionamento. Taxa de 1,5% por venda.</p>
      <label>Descrição<textarea v-model="draft.description" class="rl-input" maxlength="1600" rows="4" placeholder="Estado do carro, manutenção, modificações..."></textarea></label>
      <template v-if="draft.mode !== 'street'">
      <div class="rl-row between">
        <b>Fotos reais · {{ draft.photos.length }} / 6</b>
        <div class="rl-row">
          <button v-for="a in angles" :key="a.angle" type="button" class="rl-btn" :disabled="!chosen?.spawned || rl.capturing || draft.photos.length >= 6"
            @click="capture(a.angle)">{{ a.label }}</button>
        </div>
      </div>
      <p v-if="rl.capturing" class="rl-muted">Fotografando... {{ rl.view.mode === "BeamMP" ? "enviando ao servidor." : "" }}</p>
      <div class="strip">
        <div v-for="(p, i) in draft.photos" :key="p"><img :src="photo(p)" alt="Foto do anúncio" /><button type="button" aria-label="Remover foto" @click="draft.photos.splice(i, 1)">×</button></div>
        <div v-if="!draft.photos.length" class="hint">Pelo menos 2 fotos: frente e traseira funcionam bem.</div>
      </div>
      <label class="check"><input v-model="draft.negotiable" type="checkbox" /> Aceito negociar o preço na visita</label>
      </template>
      <div class="rl-row">
        <button class="rl-btn primary" :disabled="busy || !draft.inventoryId || !chosen?.spawned || chosen?.locked || (draft.mode === 'street' ? !streetReady : draft.photos.length < 2)">
          {{ busy ? "Publicando..." : draft.mode === "street" ? "Deixar à venda aqui" : "Publicar anúncio" }}</button>
        <span class="rl-muted">{{ draft.mode === "street" ? (streetReady ? "" : "Fique a até 30 m do carro.") : "Anúncios ficam ativos por 7 dias." }}</span>
      </div>
    </form>
  </div>
</template>

<script setup>
import XPSelect from "../components/XPSelect.vue"
import { computed, onMounted, onUnmounted, reactive, ref, watch } from "vue"
import { rl, request, money, km, photo, distance, distanceText, myStore, toast, onAction } from "../rl.js"

const props = defineProps({ inventoryId: [String, Number], storeId: String, nonce: Number })
const emit = defineEmits(["open", "title"])
const draft = reactive({ inventoryId: "", title: "", description: "", price: 10000, minimum: 9000, photos: [], storeId: "", negotiable: true, mode: "visit" })
const busy = ref(false)
const angles = [{ angle: 35, label: "Frente" }, { angle: 215, label: "Traseira" }, { angle: 125, label: "Lateral" }, { angle: 305, label: "3/4" }]
let off

const garage = computed(() => rl.view.garage || [])
const chosen = computed(() => garage.value.find(v => String(v.inventoryId) === String(draft.inventoryId)))
const streetReady = computed(() => !!chosen.value?.spawned && distance(rl.view.position, chosen.value.position) <= 30)
watch(() => draft.price, p => { if (p) draft.minimum = Math.round(p * 0.9) })
watch(() => draft.inventoryId, () => {
  draft.photos = []
  if (chosen.value) { draft.title = chosen.value.niceName; if (chosen.value.value) draft.price = Math.round(chosen.value.value / 100) }
})
watch(() => [props.inventoryId, props.storeId, props.nonce], () => {
  if (props.inventoryId) draft.inventoryId = props.inventoryId
  if (props.storeId) draft.storeId = props.storeId
}, { immediate: true })

function capture(angle) { rl.capturing = true; request("capture", { inventoryId: draft.inventoryId, angle }); setTimeout(() => { rl.capturing = false }, 15000) }
function publish() {
  busy.value = true
  if (draft.mode === "street") {
    request("streetSellVehicle", { inventoryId: Number(draft.inventoryId), title: draft.title, description: draft.description,
      price: Math.round(draft.price * 100), minimum: Math.round(Math.min(draft.minimum || 0, draft.price) * 100) })
    return
  }
  request("publishVehicle", { inventoryId: Number(draft.inventoryId), title: draft.title, description: draft.description,
    price: Math.round(draft.price * 100), photos: [...draft.photos], storeId: draft.storeId || undefined, negotiable: draft.negotiable })
}
onMounted(() => {
  emit("title", "novo anúncio")
  off = onAction(e => {
    if (e?.op === "photoReady" && String(e.inventoryId) === String(draft.inventoryId) && !draft.photos.includes(e.photoId) && draft.photos.length < 6) draft.photos.push(e.photoId)
    if (e?.op === "streetSell") {
      busy.value = false
      if (e.result?.ok) {
        toast("Carro à venda na rua! A placa já está nele.")
        draft.inventoryId = ""
        emit("open", { app: "market", props: { start: "classificados" } })
      }
    }
    if (e?.op === "publish") {
      busy.value = false
      if (e.result?.ok) {
        toast("Anúncio publicado com suas fotos!")
        draft.inventoryId = ""; draft.photos = []; draft.description = ""
        emit("open", { app: "market", props: { start: "classificados" } })
      }
    }
  })
})
onUnmounted(() => off && off())
</script>

<style scoped>
.between { justify-content: space-between; }
.chosen { display: flex; gap: 14px; align-items: center; }
.chosen img { width: 160px; height: 90px; object-fit: contain; background: #e9eef4; }
.chosen p { margin: 4px 0; }
.strip { display: flex; gap: 8px; flex-wrap: wrap; min-height: 80px; }
.strip > div { position: relative; width: 140px; height: 80px; }
.strip img { width: 100%; height: 100%; object-fit: cover; border-radius: 3px; }
.strip button { position: absolute; right: 2px; top: 2px; border: 0; background: rgba(0,0,0,.6); color: #fff; border-radius: 3px; cursor: pointer; }
.strip .hint { width: auto; height: auto; color: #6b7c8f; font-size: 12px; padding: 10px; }
.modes { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 6px 0 10px; }
.mode { display: grid; gap: 4px; text-align: left; padding: 10px 12px; border: 1px solid #c9d7e8; border-radius: 6px; background: #fff; cursor: pointer; font: 12px Tahoma, sans-serif; color: #1b2733; }
.mode small { color: #627287; line-height: 1.4; }
.mode.on { border-color: #2d6ad6; box-shadow: inset 0 0 0 1px #2d6ad6; background: #eef4fd; }
.check { display: flex !important; grid-template-columns: none; flex-direction: row; align-items: center; gap: 6px; }
</style>
