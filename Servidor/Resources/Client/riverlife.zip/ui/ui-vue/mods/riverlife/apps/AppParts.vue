<template>
  <div class="prt">
    <!-- Sem sessão do RLS: escolher o carro desta garagem -->
    <div v-if="!route" class="rl-page">
      <h2 class="rl-h1">Peças e personalização</h2>
      <p class="rl-muted">Troque peças do carro vendo o resultado na hora: motor, suspensão, rodas, carroceria e acessórios de carga. Você só paga ao confirmar o carrinho.</p>
      <div v-if="!rl.view.computer" class="rl-empty"><b>Abra pelo computador de uma garagem</b>A loja de peças monta tudo no carro estacionado na garagem.</div>
      <div v-else-if="!launchVehicles.length" class="rl-empty"><b>Nenhum carro nesta garagem</b>Estacione um carro perto do computador e tente de novo.</div>
      <article v-for="v in launchVehicles" :key="v.inventoryId" class="lv rl-card">
        <img v-if="v.thumbnail" :src="v.thumbnail" alt="" />
        <div class="lv-main">
          <b>{{ v.niceName || v.vehicleName || "Veículo" }}</b>
          <small class="rl-muted">{{ v.fn ? (v.fn.disabled ? reasonText(v.fn) : "Pronto para montar") : "Esta garagem não vende peças" }}</small>
        </div>
        <button class="rl-btn primary" :disabled="!v.fn || v.fn.disabled" @click="launch(v)">Abrir</button>
      </article>
    </div>

    <template v-else>
      <header class="bar">
        <span class="bar-ico"><BngIcon type="engine" /></span>
        <div class="bar-txt"><b>Peças</b><small>{{ vehicleName || "Personalização do veículo" }}</small></div>
        <span v-if="working" class="rl-badge">Montando…</span>
      </header>

      <div class="tools">
        <div class="tabs">
          <button :class="{ on: tab === 'all' }" :disabled="tutorial" @click="setTab('all')">Todas as peças</button>
          <button :class="{ on: tab === 'cargo' }" @click="setTab('cargo')"><BngIcon type="boxPickUp03" /> Carga</button>
        </div>
        <input v-model="queryModel" class="rl-input search" :placeholder="listMode ? 'Filtrar peças…' : 'Buscar peça ou encaixe…'"
          @focus="typing(true)" @blur="typing(false)" />
      </div>

      <div v-if="restoring" class="restore">Restaurando o carrinho salvo… {{ restoreProgress.current }}/{{ restoreProgress.total }}</div>

      <div ref="bodyEl" class="body">
        <div v-if="!data" class="rl-empty"><b>Abrindo a loja…</b>Lendo as peças compatíveis com este carro.</div>

        <!-- lista de peças de um encaixe (ou da categoria carga) -->
        <template v-else-if="listMode">
          <div class="crumb">
            <button v-if="tab === 'all'" class="rl-btn sm" @click="closeSlot"><BngIcon type="arrowSmallLeft" /> Encaixes</button>
            <div class="crumb-txt">
              <small v-if="tab === 'all' && slotInfo?.nicePath">{{ slotInfo.nicePath }}</small>
              <b>{{ tab === "cargo" ? "Acessórios de carga" : (slotInfo?.slotNiceName || slotNice(slot)) }}</b>
              <small v-if="tab === 'all'" class="rl-muted">No carro agora: {{ currentPartName || "vazio" }}</small>
            </div>
          </div>
          <div v-if="!shownParts.length" class="rl-empty">
            <b>{{ partQuery ? "Nada encontrado" : "Nenhuma peça aqui" }}</b>{{ partQuery ? "Nenhuma peça com esse nome neste encaixe." : "A loja não tem peças compatíveis para este encaixe." }}
          </div>
          <div v-for="p in shownParts" :key="partKey(p)" class="part" :class="{ incart: !!cartPartOf(p), off: p.disabled }">
            <div class="p-main">
              <b>{{ partLabel(p) }}</b>
              <small>
                <span v-if="tab === 'cargo'">{{ slotNice(p.slot) }}</span>
                <span v-if="p.partId">Do seu estoque<template v-if="p.partCondition?.odometer"> · {{ km(p.partCondition.odometer) }} rodados</template></span>
                <span v-if="p.disabled && p.disabledReason" class="rl-error">{{ p.disabledReason }}</span>
              </small>
            </div>
            <span v-if="isInstalled(p)" class="rl-badge ok">Instalada</span>
            <span v-else-if="cartPartOf(p)" class="rl-badge warn">No carrinho</span>
            <span class="p-price">{{ p.emptyPlaceholder ? "" : p.partId ? "grátis" : dollars(p.finalValue, true) }}</span>
            <button class="rl-btn sm" :class="buttonOf(p).kind" :disabled="buttonOf(p).disabled" :title="buttonOf(p).title" @click="buttonOf(p).action()">
              {{ buttonOf(p).label }}
            </button>
          </div>
        </template>

        <!-- busca: lista plana de encaixes -->
        <template v-else-if="slotQuery.trim()">
          <div v-if="!searchSlots.length" class="rl-empty"><b>Nada encontrado</b>Nenhuma peça ou encaixe com esse nome.</div>
          <button v-for="s in searchSlots" :key="s.path" class="srow" @click="openSlot(s.path)">
            <span class="s-main"><small v-if="s.nicePath">{{ s.nicePath }}</small><b>{{ s.slotNiceName || s.slotName }}</b></span>
            <span class="s-part">{{ s.partNiceName || "—" }}</span>
            <i v-if="cartSlots.has(s.path)" class="cart-dot" title="Tem peça no carrinho"></i>
          </button>
        </template>

        <!-- árvore de encaixes, estilo Explorer -->
        <template v-else>
          <div v-if="!treeRows.length" class="rl-empty"><b>Sem encaixes</b>Este carro não tem peças trocáveis.</div>
          <div v-else class="tree">
            <div v-for="r in treeRows" :key="r.path" class="trow" :class="{ sel: r.path === lastSlot }" :style="{ paddingLeft: 4 + r.depth * 16 + 'px' }"
              @click="openSlot(r.path)">
              <button v-if="r.expandable" class="pm" @click.stop="toggleNode(r.path)">{{ expanded[r.path] ? "−" : "+" }}</button>
              <span v-else class="pm-sp"></span>
              <span class="t-slot">{{ r.slotNiceName || r.slotName }}</span>
              <span class="t-part" :class="{ empty: !r.partNiceName }">{{ r.partNiceName || "vazio" }}</span>
              <i v-if="cartSlots.has(r.path)" class="cart-dot" title="Tem peça no carrinho"></i>
            </div>
          </div>
        </template>
      </div>

      <section class="cart">
        <button class="cart-h" @click="cartOpen = !cartOpen">
          <BngIcon type="shoppingCart" /> <b>Carrinho</b> <small>({{ cartIn.length }} peça(s){{ cartOut.length ? ", " + cartOut.length + " saindo" : "" }})</small>
          <i class="pm sm right">{{ cartOpen ? "−" : "+" }}</i>
        </button>
        <div v-if="cartOpen" class="cart-list">
          <p v-if="!cartIn.length && !cartOut.length" class="rl-muted">Carrinho vazio. Escolha um encaixe e instale uma peça para ver no carro.</p>
          <div v-for="c in cartIn" :key="'in' + c.containingSlot" class="crow" :class="{ dep: !c.sourcePart }">
            <button v-if="c.sourcePart" class="mini x" :disabled="restoring || tutorial || working || busy" title="Tirar do carrinho" @click="removeSlot(c.containingSlot)"><BngIcon type="abandon" /></button>
            <span v-else class="mini-sp"></span>
            <span class="cname" :title="slotNice(c.slot)">
              {{ cartName(c) }}
              <small v-if="!c.sourcePart">incluída</small>
              <small v-else-if="c.partCondition?.odometer">{{ km(c.partCondition.odometer) }}</small>
            </span>
            <span class="cprice">{{ c.emptyPlaceholder ? "—" : dollars(c.finalValue, true) }}</span>
          </div>
          <template v-if="cartOut.length">
            <p class="out-h">Saem do carro e vão para o seu estoque:</p>
            <div v-for="(o, k) in cartOut" :key="'out' + k" class="crow out">
              <span class="mini-sp"></span><span class="cname">{{ o.description?.description || o.name }}</span><span class="cprice"></span>
            </div>
          </template>
        </div>
      </section>

      <footer class="foot">
        <div class="sums">
          <span>Subtotal <b>{{ dollars(subtotal, true) }}</b></span>
          <span>Impostos (7%) <b>{{ dollars(taxes, true) }}</b></span>
          <span class="tot">Total <b>{{ dollars(total, true) }}</b></span>
        </div>
        <div class="money"><span class="rl-muted">Saldo {{ playerMoney === null ? "—" : dollars(playerMoney) }}</span>
          <span v-if="tooExpensive" class="rl-error">Saldo insuficiente</span>
        </div>
        <div class="btns">
          <button class="rl-btn go" :disabled="!canBuy" @click="buy">Comprar</button>
          <button class="rl-btn" :disabled="!cartIn.length || restoring || busy" title="Guarda o carrinho para a próxima visita e devolve o carro como está" @click="askSave">Salvar carrinho</button>
          <button class="rl-btn" :disabled="!cartIn.length || busy" @click="askDiscard">Descartar</button>
          <span class="grow"></span>
          <button class="rl-btn" :disabled="busy" @click="requestClose">Cancelar</button>
        </div>
      </footer>

      <div v-if="confirm" class="cfm-mask">
        <div class="cfm" role="dialog">
          <b>{{ confirm.title }}</b>
          <p>{{ confirm.text }}</p>
          <div class="btns">
            <button v-for="b in confirm.buttons" :key="b.label" class="rl-btn" :class="b.kind" @click="b.action">{{ b.label }}</button>
          </div>
        </div>
      </div>
      <div v-if="busy" class="busy"><span>{{ busyText }}</span></div>
    </template>
  </div>
</template>

<script>
// While the window is minimized nothing of ours is mounted: this router hook still ends the session (like the
// RLS view's unmount) if the part shopping routes are left meanwhile.
let routeGuard = null
function dropGuard() { if (routeGuard) { routeGuard(); routeGuard = null } }
</script>

<script setup>
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, shallowRef, watch } from "vue"
import { BngIcon } from "@/common/components/base"
import { rl, request, luaCall, luaRun, luaString, onGameEvent, dollars, arr, typing, toast, km } from "../rl.js"
import { desk } from "../desk.js"

const props = defineProps({ route: String, routeProps: Object, nonce: Number })
const emit = defineEmits(["open", "title", "close"])

const ROUTE_PREFIX = "career.computer.partShopping"

const data = shallowRef(null) // whole payload is replaced on every send
const tab = ref("all")
const slot = ref("")
const lastSlot = ref("")
const slotQuery = ref("")
const partQuery = ref("")
const expanded = reactive({})
const working = ref(false)
const busy = ref(false)
const busyText = ref("")
const confirm = ref(null)
const cartOpen = ref(true)
const vehicleName = ref("")
const bodyEl = ref(null)
let offs = []
let workTimer = null
let busyTimer = null
let started = false
let firstData = true
let treeScroll = 0

// ---- launcher (no RLS session) ----
const launchVehicles = computed(() => arr(rl.view.computer?.vehicles).map(v => ({
  ...v, fn: rl.view.computer?.computerFunctions?.vehicleSpecific?.[String(v.inventoryId)]?.partShop,
})))
function reasonText(fn) { const r = fn?.reason; return (typeof r?.label === "string" ? r.label : r?.label?.txt) || "Indisponível agora" }
function launch(v) { request("native", { buttonId: "partShop", inventoryId: v.inventoryId }) }

// ---- data views ----
const partsInShop = computed(() => arr(data.value?.partsInShop).filter(Boolean))
const niceNames = computed(() => data.value?.slotsNiceName || {})
const slotNice = s => (s && niceNames.value[s]) || s || ""
const tutorialNames = computed(() => data.value?.tutorialPartNames)
const tutorial = computed(() => tutorialNames.value !== undefined && tutorialNames.value !== null)
const restoring = computed(() => !!data.value?.restoreInProgress)
const restoreProgress = computed(() => data.value?.restoreProgress || { current: 0, total: 0 })
const listMode = computed(() => tab.value === "cargo" || !!slot.value)
const queryModel = computed({
  get: () => (listMode.value ? partQuery.value : slotQuery.value),
  set: v => { if (listMode.value) partQuery.value = v; else slotQuery.value = v },
})

// Slot tree (children arrive as maps; sorted by nice name like the RLS store).
function kids(node) {
  return arr(node?.children).filter(Boolean).sort((a, b) => String(a.slotNiceName || a.slotName || "").localeCompare(String(b.slotNiceName || b.slotName || "")))
}
const nodeByPath = computed(() => {
  const map = {}
  const walk = n => { if (!n) return; if (n.path) map[n.path] = n; for (const c of kids(n)) walk(c) }
  walk(data.value?.partTree)
  return map
})
const treeRows = computed(() => {
  const rows = []
  const walk = (node, depth) => {
    for (const c of kids(node)) {
      const children = kids(c)
      const expandable = !!c.chosenPartName && children.length > 0
      rows.push({ path: c.path, depth, expandable, slotName: c.slotName, slotNiceName: c.slotNiceName, partNiceName: c.chosenPartName ? (c.chosenPartNiceName || c.chosenPartName) : "" })
      if (expandable && expanded[c.path]) walk(c, depth + 1)
    }
  }
  walk(data.value?.partTree, 0)
  return rows
})
function toggleNode(path) { expanded[path] = !expanded[path] }
const searchList = computed(() => arr(data.value?.searchSlotList).filter(Boolean))
const slotInfo = computed(() => searchList.value.find(s => s.path === slot.value))
const currentPartName = computed(() => {
  const n = nodeByPath.value[slot.value]
  return n && n.chosenPartName ? (n.chosenPartNiceName || n.chosenPartName) : ""
})
// Same search as the RLS store: a slot matches when its name or any of its parts' names contains the text.
const searchSlots = computed(() => {
  const q = slotQuery.value.trim().toLowerCase()
  if (!q) return []
  const hit = {}
  for (const p of partsInShop.value) {
    if (!p.slot) continue
    const sn = String(niceNames.value[p.slot] ?? p.slot).toLowerCase()
    if (String(p.description?.description || "").toLowerCase().includes(q) || sn.includes(q)) hit[p.containingSlot] = true
  }
  return searchList.value.filter(s => hit[s.path])
})
// Parts of the open slot (or every cargo part), ordered like the RLS list: remove option, stock parts, then by name.
const slotParts = computed(() => {
  const list = partsInShop.value.filter(p => p.slot && (tab.value === "cargo" ? String(p.name || "").includes("cargo_load") : p.containingSlot === slot.value))
  return list.sort((a, b) => {
    if (!!a.emptyPlaceholder !== !!b.emptyPlaceholder) return a.emptyPlaceholder ? -1 : 1
    if ((a.partId != null) !== (b.partId != null)) return a.partId != null ? -1 : 1
    return String(a.description?.description || "").localeCompare(String(b.description?.description || ""))
  })
})
const shownParts = computed(() => {
  const q = partQuery.value.trim().toLowerCase()
  return q ? slotParts.value.filter(p => String(p.description?.description || "").toLowerCase().includes(q)) : slotParts.value
})
function partKey(p) {
  if (p.partShopId != null) return "shop-" + p.partShopId
  if (p.partId != null) return "inv-" + p.partId
  return (p.containingSlot || "slot") + "-" + (p.name || "part")
}
function partLabel(p) {
  if (p.emptyPlaceholder) return "Deixar vazio (tirar a peça atual)"
  return (p.description?.description || p.name) + (p.partId != null ? " (estoque)" : "")
}

// ---- cart ----
const cart = computed(() => data.value?.shoppingCart || {})
const cartIn = computed(() => arr(cart.value.partsInList).filter(Boolean))
const cartOut = computed(() => arr(cart.value.partsOutList).filter(Boolean))
const cartSlots = computed(() => new Set(cartIn.value.map(c => c.containingSlot)))
const total = computed(() => Number(cart.value.total) || 0)
const taxes = computed(() => Number(cart.value.taxes) || 0)
const subtotal = computed(() => total.value - taxes.value)
const playerMoney = computed(() => (data.value && isFinite(Number(data.value.playerMoney)) && data.value.playerMoney !== null ? Number(data.value.playerMoney) : null))
const tooExpensive = computed(() => total.value > 0 && playerMoney.value !== null && total.value > playerMoney.value)
const canBuy = computed(() => cartIn.value.length > 0 && !tooExpensive.value && !restoring.value && !working.value && !busy.value)
const sameId = (a, b) => (a ?? null) === (b ?? null)
function cartPartOf(p) { return cartIn.value.find(c => sameId(c.partId, p.partId) && c.name === p.name && c.containingSlot === p.containingSlot) || null }
function cartName(c) {
  if (c.emptyPlaceholder) return "Tirar: " + (slotNice(c.slot) || "peça")
  return (c.description?.description || c.name) + (c.partId != null ? " (estoque)" : "")
}
function isInstalled(p) {
  if (p.emptyPlaceholder) return false
  const own = data.value?.vehicleSlotToPartMap?.[p.containingSlot]
  return !!own && !!p.description?.description && own.description?.description === p.description.description && !cartPartOf(p)
}
function tutorialBlocks(p, removable) {
  if (!tutorial.value) return false
  return !tutorialNames.value[p.name] || removable
}
function buttonOf(p) {
  const inCart = cartPartOf(p)
  const removable = !!inCart && !!inCart.sourcePart
  const disabled = restoring.value || working.value || busy.value || !!p.disabled || tutorialBlocks(p, removable) || (!!inCart && !inCart.sourcePart)
  if (removable) return { label: "Desfazer", kind: "", disabled, title: "Tirar do carrinho", action: () => removeSlot(p.containingSlot) }
  if (inCart) return { label: "Incluída", kind: "", disabled: true, title: "Vem junto com outra peça do carrinho", action: () => {} }
  if (p.emptyPlaceholder) return { label: "Remover", kind: "danger", disabled, title: "Deixa o encaixe vazio", action: () => install(p) }
  return { label: "Instalar", kind: "primary", disabled, title: p.disabledReason || "", action: () => install(p) }
}

// ---- navigation inside the app (no route changes, so the RLS session stays put) ----
function setTab(t) {
  if (tab.value === t) return
  tab.value = t
  partQuery.value = ""
  if (t === "all" && !slot.value) restoreTreeScroll()
}
function openSlot(path) {
  if (!slot.value && tab.value === "all" && bodyEl.value) treeScroll = bodyEl.value.scrollTop
  // Open the ancestors so the tree shows where we were when coming back.
  const segs = String(path).split("/").filter(Boolean)
  let acc = String(path).startsWith("/") ? "/" : ""
  for (let i = 0; i < segs.length - 1; i++) { acc += segs[i] + "/"; if (nodeByPath.value[acc]) expanded[acc] = true }
  tab.value = "all"
  slot.value = path
  lastSlot.value = path
  partQuery.value = ""
  nextTick(() => { if (bodyEl.value) bodyEl.value.scrollTop = 0 })
}
function closeSlot() {
  slot.value = ""
  partQuery.value = ""
  restoreTreeScroll()
}
function restoreTreeScroll() { nextTick(() => { if (bodyEl.value) bodyEl.value.scrollTop = treeScroll }) }

// ---- actions ----
function startWork() {
  working.value = true
  clearTimeout(workTimer)
  workTimer = setTimeout(() => (working.value = false), 8000)
}
function install(p) {
  if (p.partShopId == null) return
  startWork()
  luaCall("career_modules_partShopping.installPartByPartShopId(" + Number(p.partShopId) + ")")
}
function removeSlot(containingSlot) {
  startWork()
  luaCall("career_modules_partShopping.removePartBySlot(" + luaString(String(containingSlot)) + ")")
}
function setBusy(text, ms) {
  busy.value = true
  busyText.value = text
  clearTimeout(busyTimer)
  busyTimer = setTimeout(() => { busy.value = false; toast("O RLS não respondeu. Tente de novo.", "error") }, ms)
}
function buy() {
  if (!canBuy.value) return
  setBusy("Pagando e instalando as peças…", 10000)
  luaCall("career_modules_partShopping.applyShopping()")
}
function discard() {
  confirm.value = null
  setBusy("Devolvendo o carro como estava…", 10000)
  luaCall("career_modules_partShopping.discardShopping()")
}
function saveForLater() {
  confirm.value = null
  setBusy("Guardando o carrinho…", 10000)
  luaCall("career_modules_partShopping.saveCartForLater()")
}
const keepShopping = () => (confirm.value = null)
function askDiscard() {
  if (!cartIn.value.length) return
  confirm.value = {
    title: "Descartar o carrinho?",
    text: "As peças do carrinho saem do carro e o carrinho é apagado. O carro volta a ser como era.",
    buttons: [{ label: "Descartar", kind: "danger", action: discard }, { label: "Voltar", kind: "", action: keepShopping }],
  }
}
function askSave() {
  if (!cartIn.value.length || restoring.value) return
  confirm.value = {
    title: "Salvar o carrinho para depois?",
    text: "O carrinho fica guardado para este carro e ele volta ao estado atual. Na próxima visita as peças voltam para o carrinho.",
    buttons: [{ label: "Salvar e sair", kind: "primary", action: saveForLater }, { label: "Voltar", kind: "", action: keepShopping }],
  }
}
// X of the window, "Cancelar" and the game's back key: leave, asking what to do with a non-empty cart.
function requestClose() {
  if (!props.route) { emit("close"); return }
  if (busy.value) return
  if (!cartIn.value.length) { discard(); return }
  const buttons = [{ label: "Descartar", kind: "danger", action: discard }]
  if (!restoring.value) buttons.push({ label: "Salvar e sair", kind: "primary", action: saveForLater })
  buttons.push({ label: "Continuar comprando", kind: "", action: keepShopping })
  confirm.value = { title: "Sair da loja de peças?", text: "O carrinho ainda não foi pago. Você pode descartar as peças ou guardar o carrinho para a próxima visita.", buttons }
}
defineExpose({ requestClose })

// ---- Lua events ----
function onData(d) {
  if (!d || typeof d !== "object") return
  data.value = d
  working.value = false
  clearTimeout(workTimer)
  if (firstData) {
    firstData = false
    // The RLS route may already point at a category/slot: open the same place.
    if (d.activePanel === "parts") {
      if (d.category === "cargo") tab.value = "cargo"
      else if (d.slot) openSlot(d.slot)
    }
    findVehicleName(d)
  }
}
async function findVehicleName(d) {
  const owned = Object.values(d.vehicleSlotToPartMap || {}).find(p => p && p.location != null)
  const id = owned?.location
  if (id == null) return
  let name = arr(rl.view.computer?.vehicles).find(v => String(v.inventoryId) === String(id))?.niceName
  if (!name) name = await luaRun("local v = career_modules_inventory.getVehicles()[" + Number(id) + "] return v and v.niceName or nil")
  if (typeof name === "string" && name) { vehicleName.value = name; emit("title", name) }
}

function start() {
  if (started || !props.route) return
  started = true
  dropGuard()
  offs.push(onGameEvent("partShoppingData", onData))
  offs.push(onGameEvent("partShoppingRequestExit", requestClose))
  luaCall("career_modules_partShopping.sendShoppingDataToUI()")
}
onMounted(start)
watch(() => props.route, r => { if (r) start() })
onUnmounted(() => {
  for (const off of offs) off()
  offs = []
  clearTimeout(workTimer)
  clearTimeout(busyTimer)
  if (!started) return
  // Like the RLS view (which stays mounted across its category/slot routes): end the session when the screen goes away.
  // cancelShopping keeps a non-empty cart as a saved draft. A minimized window or a move to another part shopping
  // route keeps the session open.
  const now = String(window.vueRouter?.currentRoute?.value?.name || "")
  const windowAlive = desk.windows.some(w => w.props && w.props.nonce === props.nonce)
  if (!(now.startsWith(ROUTE_PREFIX) && windowAlive)) { luaCall("career_modules_partShopping.cancelShopping()"); return }
  dropGuard()
  if (window.vueRouter?.afterEach) {
    routeGuard = window.vueRouter.afterEach(to => {
      if (String(to?.name || "").startsWith(ROUTE_PREFIX)) return
      dropGuard()
      luaCall("career_modules_partShopping.cancelShopping()")
    })
  }
})
</script>

<style scoped>
.prt { position: relative; height: 100%; display: flex; flex-direction: column; background: #fff; font-size: 12px; }
.bar { flex: none; display: flex; align-items: center; gap: 8px; padding: 6px 10px; background: linear-gradient(180deg, #f7f6f0, #ece9d8); border-bottom: 1px solid #aca899; }
.bar-ico { width: 30px; height: 30px; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 19px; background: linear-gradient(135deg, #9aa7b8, #3c4b60); box-shadow: inset 0 1px 0 rgba(255,255,255,.4); }
.bar-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.bar-txt b { font-size: 13px; color: #12407c; } .bar-txt small { color: #5f7186; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tools { flex: none; padding: 5px 10px 6px; background: #ece9d8; border-bottom: 1px solid #aca899; display: flex; flex-direction: column; gap: 5px; }
.tabs { display: flex; gap: 2px; }
.tabs button { display: inline-flex; align-items: center; gap: 4px; font: 12px Tahoma, sans-serif; padding: 4px 12px; border: 1px solid #919b9c; border-radius: 4px 4px 0 0; background: linear-gradient(180deg, #fff, #ecebe5); cursor: pointer; }
.tabs button.on { background: #fff; border-top: 2px solid #f8b636; font-weight: bold; }
.tabs button:disabled { color: #9c9c9c; cursor: default; }
.search { width: 100%; padding: 4px 7px !important; }
.restore { flex: none; padding: 5px 10px; background: #fff8dc; border-bottom: 1px solid #e8d48a; color: #6b5500; }
.body { flex: 1; min-height: 0; overflow-y: auto; padding: 6px 8px 10px; }
.tree { border: 1px solid #c9d7e8; border-radius: 3px; background: #fff; padding: 2px 0; }
.trow { display: flex; align-items: center; gap: 6px; padding: 3px 8px 3px 4px; cursor: pointer; border: 1px solid transparent; }
.trow:hover { background: #e8f1fd; border-color: #c5d9f3; }
.trow.sel { background: #316ac5; color: #fff; }
.trow.sel .t-part { color: #dfe9ff; }
.pm { width: 13px; height: 13px; flex: none; padding: 0; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #7f9db9; background: #fff; color: #1d3f69; font: bold 11px/1 Tahoma, sans-serif; font-style: normal; cursor: pointer; }
.pm.sm { width: 11px; height: 11px; font-size: 10px; }
.pm-sp { width: 13px; flex: none; }
.t-slot { flex: none; max-width: 48%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.t-part { flex: 1; min-width: 0; text-align: right; color: #5f7186; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.t-part.empty { font-style: italic; color: #a0a9b5; }
.cart-dot { width: 8px; height: 8px; border-radius: 50%; background: #e8a200; flex: none; box-shadow: 0 0 0 1px #b07a00; }
.srow { width: 100%; display: flex; align-items: center; gap: 8px; padding: 5px 8px; border: 0; border-bottom: 1px solid #eef1f5; background: none; text-align: left; cursor: pointer; font: 12px Tahoma, sans-serif; color: #1b2733; }
.srow:hover { background: #e8f1fd; }
.s-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.s-main small { color: #8291a3; font-size: 10.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.s-part { max-width: 45%; color: #5f7186; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.crumb { display: flex; align-items: center; gap: 8px; padding: 2px 0 8px; border-bottom: 1px solid #e3e8ee; margin-bottom: 6px; }
.crumb-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.crumb-txt small { color: #8291a3; font-size: 10.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.crumb-txt b { color: #12407c; font-size: 13px; }
.part { display: flex; align-items: center; gap: 6px; padding: 6px 6px; border-bottom: 1px solid #eef1f5; border-left: 3px solid transparent; }
.part:hover { background: #f4f8fd; }
.part.incart { border-left-color: #e8a200; background: #fffbea; }
.part.off { opacity: .6; }
.p-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.p-main b { font-weight: normal; color: #1b2733; overflow: hidden; text-overflow: ellipsis; }
.p-main small { color: #6a7b8f; font-size: 10.5px; display: flex; gap: 6px; flex-wrap: wrap; }
.p-price { white-space: nowrap; color: #1b3355; min-width: 64px; text-align: right; }
.rl-btn.sm { padding: 3px 9px; font-size: 11.5px; display: inline-flex; align-items: center; gap: 4px; }
.part .rl-btn.sm { min-width: 70px; justify-content: center; }
.cart { flex: none; border-top: 1px solid #aca899; background: #fff; }
.cart-h { width: 100%; display: flex; align-items: center; gap: 6px; padding: 5px 10px; border: 0; background: linear-gradient(180deg, #f7f6f0, #e8e5d4); cursor: pointer; font: 12px Tahoma, sans-serif; color: #1d3f69; text-align: left; }
.cart-h small { color: #6a7b8f; flex: 1; }
.right { margin-left: auto; }
.cart-list { max-height: 26vh; overflow-y: auto; padding: 4px 10px 6px; }
.cart-list p { margin: 4px 0; }
.crow { display: flex; align-items: center; gap: 6px; padding: 2px 0; border-bottom: 1px solid #eef1f5; }
.crow.dep .cname { padding-left: 10px; color: #5f7186; }
.crow.out .cname { color: #5f7186; }
.cname { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cname small { color: #8291a3; margin-left: 4px; }
.cprice { white-space: nowrap; }
.out-h { color: #4b5d73; font-weight: bold; margin-top: 6px !important; }
.mini { width: 20px; height: 20px; padding: 0; flex: none; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #7f9db9; border-radius: 3px; background: linear-gradient(180deg, #fff, #e9eef5); color: #1d3f69; cursor: pointer; font-size: 12px; }
.mini:disabled { opacity: .4; cursor: default; }
.mini.x { border-color: #a33; color: #a33; background: linear-gradient(180deg, #fff, #f6dcd8); }
.mini-sp { width: 20px; flex: none; }
.foot { flex: none; border-top: 1px solid #aca899; background: #ece9d8; padding: 6px 10px 8px; }
.sums { display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; color: #4b5d73; }
.sums b { color: #1b2733; } .sums .tot { margin-left: auto; } .sums .tot b { font-size: 16px; color: #164a8c; }
.money { display: flex; justify-content: space-between; gap: 8px; margin: 3px 0 6px; font-size: 11.5px; }
.btns { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.grow { flex: 1; }
.cfm-mask { position: absolute; inset: 0; background: rgba(40,60,90,.25); display: flex; align-items: center; justify-content: center; z-index: 5; }
.cfm { width: 88%; max-width: 400px; background: #ece9d8; border: 2px solid #0831d9; border-radius: 6px; padding: 12px 14px; box-shadow: 3px 4px 14px rgba(0,0,0,.35); }
.cfm b { color: #12407c; font-size: 13px; } .cfm p { margin: 6px 0 12px; line-height: 1.45; }
.cfm .btns { justify-content: flex-end; }
.busy { position: absolute; inset: 0; z-index: 6; background: rgba(255,255,255,.55); display: flex; align-items: center; justify-content: center; cursor: progress; }
.busy span { padding: 8px 14px; background: #ffffe1; border: 1px solid #7a7a5a; border-radius: 4px; box-shadow: 2px 2px 6px rgba(0,0,0,.25); }
.lv { display: flex; align-items: center; gap: 10px; padding: 8px; margin: 8px 0; }
.lv img { width: 96px; height: 54px; object-fit: contain; background: #eef2f7; border-radius: 3px; flex: none; }
.lv-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.lv-main b { color: #1b3355; font-size: 13px; }
</style>
